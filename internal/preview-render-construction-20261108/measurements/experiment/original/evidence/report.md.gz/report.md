# R11/R19 isolated paired prototype

Date: 2026-11-08

## Decision

Keep this exact candidate out of production and preserve it as a runnable
research pair. The optimized primary result is smaller than duplicate-baseline
variation and does not justify adoption. Do not claim a speedup from the naive
secondary signal.

The isolated implementation preserves the current HTML-definition table,
child-array ownership, dynamic CustomElement fallback, validation and property
provenance, namespace ordering, controlled-content behavior, Mount and Block
rendering, HtmlBuilder identity, and lazy-cache contracts. Source checking,
affected runtime tests, package build, emitted declaration consumers, relocated
consumers, and targeted mutation controls pass.

This is still one R11/R19 pair. There is no standalone normalization or
standalone metadata claim, and the historical 3.18% result is not a current
expectation or acceptance threshold. The current optimized batch is
directionally positive but inconclusive against duplicate-baseline variation;
the naive secondary control has a stronger positive signal. Neither supports a
universal latency, speedup or adoption claim.

## Identity

- Isolated root:
  `/private/tmp/foldkit-r11-r19-prototype-20261108.OnQh5N/repo`
- Baseline commit:
  `7cc7d90e68dc5a55b4765bbd7f0469b55cdd928f`
- Candidate patch:
  `/private/tmp/foldkit-r11-r19-prototype-20261108.OnQh5N/evidence/candidate.patch`
- Candidate patch SHA-256:
  `1cbbb93cdfa7000339f3a1b91fffd6ff372f999a7de615b0553a242a8b2f67fe`
- Node: `v26.13.0`, executable SHA-256
  `533bd644c5ae0e0ea3a80e433aad16b817447ccba1e1eea701875eac80cb75d4`
- TypeScript: `7.1.0-beta`

Candidate source hashes:

| File | SHA-256 |
| --- | --- |
| `packages/foldkit/src/domReflection.ts` | `1c2443cccc86f7d732b8a7fa0611c8bb3e39372079520ddbcba6be54ae2f373d` |
| `packages/foldkit/src/snabbdom/h.ts` | `6c6ca6b0cac5f955af5397088151ebd4d0941e747a60f134f48921c9ca0dd486` |
| `packages/foldkit/src/html/index.ts` | `4326babe14f1229cb90797067eba48988cfdfe1002f624cf4e2fb9ca43203243` |
| `packages/foldkit/src/html/htmlBuilder.test.ts` | `799ad5d222ae8677d342589f2b8803201541f6fd49d4e32d3007de1a13961ee8` |
| `packages/foldkit/src/html/keyed.test.ts` | `a8da37fae3a6a24e76561ce39c7c6c182068dbc81a5375082ffd478256fcf73e` |
| `packages/foldkit/src/patchVNode.test.ts` | `3c09e2d31c71bb967fadd061654d6fc7eaca765ec71b2fc4a26adc9730c98384` |

## Implementation

The candidate keeps the current exhaustive `elementDefinitions` boolean table
unchanged. A mapped type requires one metadata entry for every exact element
key. The generated record derives immutable-by-contract built-in facts from the
same table, including its void classification. Direct, void, and keyed
constructors capture their entry; `customElement(string)` passes no metadata
and retains dynamic lowercasing and validation.

Current validators accept optional built-in metadata. Built-ins reuse the
lowercase tag, input/content/void classifications, and double/long IDL sets.
Dynamic tags retain the current computations. A new already-lowercase
reflection helper is internal; the existing dynamic helper lowercases once and
delegates.

Child construction still creates one fresh parent-owned array and drops only
nullish empty children. It now creates primitive text VNodes during that pass,
preserving empty strings and existing child VNode identity. Snabbdom's generic
`h` and the internal normalized-child entry share one finalization function for
SVG and MathML namespace propagation.

Validation still precedes namespace propagation. Foreign-property validation
still follows propagation. The candidate adds no public package export, cast,
consumer annotation, compiler transformation, persistent cache, ownership
change, budget change, or application change.

## Verification

- Formatting and `git diff --check`: pass.
- Candidate patch applies cleanly to a second detached `7cc7d90e68` baseline:
  pass.
- Package source check with TypeScript 7.1 beta: pass.
- Affected 16-file runtime set: 507 tests passed, 0 failed.
  - HtmlBuilder, keyed, and patchVNode focused regressions.
  - SVG/MathML and Snabbdom consumers.
  - serializer and server rendering.
  - hydration.
  - CustomElement.
  - Block, child-attribute, boundary, and Mount consumers.
- Isolated Foldkit package build: pass.
- Full emitted declaration gate: pass.
  - direct source contracts;
  - external emission;
  - rejected wiring;
  - source-free relocation;
  - compiler diagnostics;
  - native completions and documentation.
- Child-instance gate: source, emitted, emit-consumer, relocated, and negative
  controls pass.

Affected-test JSON:
`/private/tmp/foldkit-r11-r19-prototype-20261108.OnQh5N/affected-tests.json`
(SHA-256
`0e289731bb53c6cb905e8d333287359b0fd88f871352f866551717960268986e`).

## Negative and structural controls

The durable control receipt is
`/private/tmp/foldkit-r11-r19-prototype-20261108.OnQh5N/controls/receipt.json`
(SHA-256
`bfe8b8276dc277fa4f3ccd53ca1db02490c23b90545c09208b5c690c08b84bf0`).

Every mutation produced its targeted failure and restored the exact candidate
hash:

- missing generated element key;
- wrong void table classification;
- wrong non-void table classification;
- metadata dropping the table's void fact;
- metadata dropping the input fact;
- corrupted primitive text normalization.

Structural controls require:

- direct, void, and keyed constructors to capture generated metadata;
- dynamic CustomElement construction to use the conservative fallback;
- metadata to be mapped from the exact element-definition table;
- shared Snabbdom finalization;
- the internal owned-normalized-child entry.

## Emitted identity

| File | SHA-256 |
| --- | --- |
| `dist/domReflection.js` | `6e425f5a408f6b4caab91fb05d5c201657529e962dd15d9e6e9074f56c44c4d4` |
| `dist/html/index.js` | `bcf113e80791ea0e7a667ed8f39443bd28ccdcf5b922909053fb7bb01dc7404f` |
| `dist/snabbdom/h.js` | `d9aa54aad1ddbe74d3acdda31e61e5fd0dd4b73f2a15f8b9cc0905697e489520` |
| `dist/domReflection.d.ts` | `e133e1323ada32b541be43e470b99368488b9ee7019a48da05eaab92c8de066e` |
| `dist/html/index.d.ts` | `bc4e64d169e78b5affc1b896e56d8c8ed0c8806553fed8ff401403660cdd6004` |
| `dist/snabbdom/h.d.ts` | `29907d2fd076b7bc9694da2dbafab4341658c1d437a1f912d279efce36396e8c` |

## Asset preparation and work-count guard

Baseline and candidate twins were built from the same `7cc7d90e68` checkpoint
with pinned Node and Vite executables and self-contained Foldkit/plugin links.
The baseline package dependency link initially missing from the disposable
clone was added to match the candidate and recorded in both link receipts. The
four ordinary assets and four hidden-map twins passed exact JavaScript byte
identity. Plugin outputs, lockfile, optimized view, driver and instrumentation
were identical between the twins.

- Asset receipt: `evidence/assets/receipt.json`, SHA-256
  `8ba6d06bf00d7e9cb0014c3a9f133db76cdc8cbbd07d565747189f23e3c1c68a`.
- Hidden-map receipt: `evidence/maps/receipt.json`, SHA-256
  `7953c29c6fe3bf6ec7d73fb88d2344ad0ebfd68f3fc36878097c416574575033`.
- Functional receipt: `evidence/functional/receipt.json`, SHA-256
  `da73cb41daf7ca4adb7e342e3b4fa0ab279da335a8e35b80faedf118185bb725`.
- Precise-coverage receipt: `evidence/work-counts/receipt.json`, SHA-256
  `780ffa4479e7045200499b4e78764e2bd6d88a24a2737b63c0c130307259b420`.
- Source-matched work-count analysis: `evidence/work-counts/analysis.json`,
  SHA-256
  `5544b1361bb994489f7531bbac6e44c4461091480452f35469b765a05d6361d0`.
- Work-count guard receipt: `evidence/work-counts/guard-receipt.json`, SHA-256
  `f8bc131fd6814772574da2a85b50237d5f3b6cf19b89481e300485b5af256a64`.

All four functional flows pass. The separate precise-coverage pass authenticates
served and executed bytes, final empty DOM, exactly 400 synchronous and 400 rAF
callbacks, and no timeout/microtask/promise callbacks. Coverage elapsed values
are invalid and unused.

Optimized and naive baseline/candidate pairs have exact equal call counts in
unchanged application, lazy, renderer, patch and VDOM work. The paired
normalization count is 3,906 optimized and 132,125 naive; the new finalization
path has the same count as the old Snabbdom `h` boundary. Lower-tag reflection
has the same 1,216 optimized / 54,688 naive count as its old boundary. Immutable
built-in metadata is derived 213 times in both variants. Candidate coverage has
five additional declared functions in each variant, matching the deliberately
introduced helpers rather than extra workload steps.

Failed preparation receipts are preserved separately: the first asset build
lacked only the baseline package dependency link; the first map recipe used the
wrong disposable candidate directory name; the first two functional launches
respectively lacked a local Playwright link and local-listen permission. None
launched a benchmark browser or produced accepted timing evidence.

## Ordinary Runtime batch

One coordinated quiet-window batch used the unchanged driver (SHA-256
`a93c12e6fe411eb5fa8abc342e32974d94496622ba8a475b81f7d6dc9bbc26f0`),
pinned Node and Chromium, six cyclic slots and 12 rounds. It retained all 72
samples with two visits to every ordinal position and ran no retry. Every slot's
summary reports cross-origin isolation, 400 synchronous callbacks, 400 rAF
callbacks and no timeout, microtask or Promise callbacks.

| Variant | Baseline A median | Candidate median | Baseline B median | Candidate vs baseline-median midpoint | Median paired delta | Median duplicate-baseline absolute difference |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Optimized | 338.7 ms | 332.8 ms | 344.4 ms | -8.75 ms (-2.562%) | -13.825 ms | 26.5 ms |
| Naive | 797.6 ms | 734.1 ms | 755.2 ms | -42.3 ms (-5.448%) | -44.675 ms | 29.85 ms |

The candidate was faster than its same-round baseline midpoint in seven of 12
optimized rounds and eight of 12 naive rounds. Optimized paired deltas ranged
from -36.15 to +40.75 ms; duplicate baselines differed by as much as 65.9 ms.
That primary result is directionally positive but does not demonstrate a
speedup. Naive paired deltas ranged from -100.95 to +28.65 ms; duplicate
baselines differed by as much as 133.3 ms. The secondary signal is stronger,
but remains one noisy batch.

The unchanged driver displays per-round totals to one decimal place. Paired and
duplicate calculations use those retained values and cannot recover sub-0.1 ms
detail; the driver summary medians use its original in-memory precision.

The original outer receipt remains failed. After the driver exited zero and
all browser/server cleanup completed, the wrapper rejected one exact 69-byte
stderr line from the driver's caught pre-work `git rev-parse HEAD` in its
generated non-Git timing harness directory. Stdout separately records `harness
revision: unknown`. There was no other stderr, page error or semantic failure,
and no rerun. A separate readback receipt validates the retained payload
without rewriting the failed original.

- Original failed outer receipt: `evidence/timing/receipt.json`, SHA-256
  `bd0bff8d66b3e9988c673f9ab285d391f689c18d6d83ab1549b19f960fe2cf24`.
- Raw stdout: `evidence/timing/timing.stdout.log`, SHA-256
  `34bc54130ab06b890b6cf8dad631a2960540ac45ebc12f72aa135089b63a2d0d`.
- Exact stderr: `evidence/timing/timing.stderr.log`, SHA-256
  `d2b35cacadc66b7fad8dedd1be5244e17150a6625978c9330f831bd7a9cd6b1e`.
- Validity and paired-round analysis:
  `evidence/timing/validity-analysis.json`, SHA-256
  `61fd6ad4eb0497f1d8d94946e97a2ce96c3c8484f81b3307969c380b5ed11f06`.

Cleanup is explicit: no pinned Chromium process remained and the owned port was
available on IPv4 and IPv6.

## Compiler allocation and current-source gates

All nine unchanged compiler allocation fixtures pass against this exact
candidate under TypeScript 7.1 beta. The workload inventory is byte-identical
before and after the run (28 files, SHA-256
`da92c6aca5a772102f2a94de57caeb006e1aa58e60f96c018d3e708ba2d4609b`).
This completes the candidate's correctness/ceiling proof artifact; it is not a
reason to adopt the runtime change or run another timing batch.

- Compiler ceiling receipt: `evidence/compiler-ceilings/receipt.json`, SHA-256
  `0c0098671b15d10573819ada9ee6f74485bc037d6b90bc6b61720b93e6458af8`.
- Compiler stdout: `evidence/compiler-ceilings/stdout.log`, SHA-256
  `46a257cdf8109344bc665d0d279a084e12c89867a4eeed6e2e9392482a069f27`.
- Compiler stderr: `evidence/compiler-ceilings/stderr.log`, SHA-256
  `23cf3bebf5d24d6eb1af5b4c24801e172a194ef82188fabd4cad6cb69656bf4f`.

This isolated measurement starts from `7cc7d90e68` and deliberately excludes
the later cadence and view-default changes. The next functional check belongs
to the actual current source containing those accepted changes without
R11/R19. Cadence may arm one idle rAF callback, so verify that the unchanged
driver still reports exactly 400 rAF callbacks. If it does not, diagnose the
extra work; do not weaken the guard. No additional R11/R19 timing is justified
by this batch alone.
