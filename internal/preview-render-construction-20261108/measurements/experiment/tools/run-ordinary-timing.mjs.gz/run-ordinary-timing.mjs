import assert from 'node:assert/strict'
import { spawn, execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import {
  appendFileSync,
  copyFileSync,
  existsSync,
  mkdirSync,
  readFileSync,
  realpathSync,
  readdirSync,
  statSync,
  symlinkSync,
  writeFileSync,
} from 'node:fs'
import { createServer } from 'node:net'
import { cpus, freemem, loadavg, platform, release, totalmem, uptime } from 'node:os'
import { join, relative } from 'node:path'

const workspace = '/private/tmp/foldkit-r11-r19-prototype-20261108.OnQh5N'
const evidence = join(workspace, 'evidence')
const output = join(evidence, 'timing')
const harness = join(output, 'harness')
const driverRoot = '/private/tmp/foldkit-record-release-rendering-xpwmm820/driver'
const driver = join(driverRoot, 'run.mjs')
const node = '/Users/devinjameson/.vite-plus/js_runtime/node/26.13.0/bin/node'
const chromium =
  '/Users/devinjameson/Library/Caches/ms-playwright/chromium-1243/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing'
const instrumentation =
  '/private/tmp/foldkit-record-release-rendering-xpwmm820/harness/priv/instrumentation.js'
const assetReceiptPath = join(evidence, 'assets/receipt.json')
const assetReceipt = JSON.parse(readFileSync(assetReceiptPath, 'utf8'))
const port = 38630
const runCount = 12
const slots = [
  { name: 'r11-baseline-optimised-a', tree: 'baseline', variant: 'optimised' },
  { name: 'r11-candidate-optimised', tree: 'candidate', variant: 'optimised' },
  { name: 'r11-baseline-optimised-b', tree: 'baseline', variant: 'optimised' },
  { name: 'r11-baseline-naive-a', tree: 'baseline', variant: 'naive' },
  { name: 'r11-candidate-naive', tree: 'candidate', variant: 'naive' },
  { name: 'r11-baseline-naive-b', tree: 'baseline', variant: 'naive' },
]

assert.equal(
  process.env.QUIET_WINDOW_CONFIRMED,
  '1',
  'Refusing to time without an explicit coordinated quiet window.',
)
assert.equal(existsSync(output), false, `Refusing to overwrite ${output}`)
mkdirSync(join(harness, 'priv/implementations'), { recursive: true })
copyFileSync(instrumentation, join(harness, 'priv/instrumentation.js'))

const sha256 = value => createHash('sha256').update(value).digest('hex')
const fileFacts = path => {
  const bytes = readFileSync(path)
  return { path, bytes: bytes.length, sha256: sha256(bytes) }
}
const filesUnder = source => {
  const files = []
  const visit = root => {
    for (const entry of readdirSync(root, { withFileTypes: true })) {
      const path = join(root, entry.name)
      if (entry.isDirectory()) visit(path)
      else if (entry.isFile()) files.push({
        path: relative(source, path),
        bytes: statSync(path).size,
        sha256: sha256(readFileSync(path)),
      })
    }
  }
  visit(source)
  return files.sort((left, right) => left.path.localeCompare(right.path))
}
const host = () => ({
  capturedAt: new Date().toISOString(),
  platform: `${platform()} ${release()}`,
  cpuModels: [...new Set(cpus().map(cpu => cpu.model))],
  logicalCpus: cpus().length,
  totalMemory: totalmem(),
  freeMemory: freemem(),
  loadAverage: loadavg(),
  uptimeSeconds: uptime(),
})
const browserProcesses = () =>
  execFileSync('ps', ['-axo', 'pid=,command='], { encoding: 'utf8' })
    .split('\n')
    .map(line => line.trim())
    .filter(line => line.includes('Google Chrome for Testing'))
const portAvailable = hostName =>
  new Promise(resolve => {
    const server = createServer()
    server.once('error', () => resolve(false))
    server.listen(port, hostName, () =>
      server.close(() => resolve(true)),
    )
  })

for (const slot of slots) {
  const treeRoot = join(workspace, slot.tree === 'candidate' ? 'repo' : slot.tree)
  const source = join(treeRoot, 'internal/lustre-benchmark/dist', slot.variant)
  const slotRoot = join(harness, 'priv/implementations', slot.name)
  mkdirSync(slotRoot, { recursive: true })
  symlinkSync(source, join(slotRoot, 'dist'), 'dir')
  assert.equal(realpathSync(join(slotRoot, 'dist')), realpathSync(source))
  const expected = assetReceipt.trees[slot.tree].assets
    .filter(asset => asset.path.startsWith(`${slot.variant}/`))
    .map(asset => ({
      ...asset,
      path: asset.path.slice(slot.variant.length + 1),
    }))
  assert.deepEqual(filesUnder(source), expected)
  slot.source = realpathSync(source)
  slot.files = expected
}
assert.deepEqual(slots[0].files, slots[2].files)
assert.deepEqual(slots[3].files, slots[5].files)

assert.equal(await portAvailable('127.0.0.1'), true)
assert.equal(await portAvailable('::1'), true)
const processesBefore = browserProcesses()
assert.deepEqual(processesBefore, [], 'Pinned Chromium is already running.')

const stdoutPath = join(output, 'timing.stdout.log')
const stderrPath = join(output, 'timing.stderr.log')
writeFileSync(stdoutPath, '')
writeFileSync(stderrPath, '')
const receipt = {
  schemaVersion: 1,
  status: 'running',
  startedAt: new Date().toISOString(),
  interpretation:
    'One ordinary six-slot Runtime batch. Optimized pair is primary; naive is secondary. Duplicate baselines bound same-batch variation. No automatic retry.',
  quietWindowConfirmed: true,
  node: fileFacts(node),
  chromium: fileFacts(chromium),
  driver: fileFacts(driver),
  runner: fileFacts(join(driverRoot, 'runner.html')),
  server: fileFacts(join(driverRoot, 'server.mjs')),
  instrumentation: fileFacts(join(harness, 'priv/instrumentation.js')),
  assetReceiptSha256: sha256(readFileSync(assetReceiptPath)),
  candidatePatch: fileFacts(join(evidence, 'candidate.patch')),
  port,
  runCount,
  slots,
  cyclicOrdinalVisitsPerSlot: runCount / slots.length,
  hostBefore: host(),
  browserProcessesBefore: processesBefore,
  cleanup: {
    portAvailableOnIpv4: false,
    portAvailableOnIpv6: false,
    browserProcessesAfter: undefined,
  },
}
const receiptPath = join(output, 'receipt.json')
const writeReceipt = () =>
  writeFileSync(receiptPath, `${JSON.stringify(receipt, null, 2)}\n`)
writeReceipt()

const child = spawn(node, [driver], {
  cwd: driverRoot,
  env: {
    ...process.env,
    CI: '1',
    LANG: 'C.UTF-8',
    LC_ALL: 'C.UTF-8',
    NO_COLOR: '1',
    HARNESS_DIR: harness,
    IMPLS: slots.map(slot => slot.name).join(','),
    RUNS: String(runCount),
    PORT: String(port),
    FOLDKIT_BENCH_CHROMIUM: chromium,
  },
  stdio: ['ignore', 'pipe', 'pipe'],
})
let stdout = ''
let stderr = ''
child.stdout.on('data', chunk => {
  stdout += chunk
  appendFileSync(stdoutPath, chunk)
  process.stdout.write(chunk)
})
child.stderr.on('data', chunk => {
  stderr += chunk
  appendFileSync(stderrPath, chunk)
  process.stderr.write(chunk)
})
const exitCode = await new Promise((resolve, reject) => {
  child.once('error', reject)
  child.once('exit', code => resolve(code))
})

receipt.exitCode = exitCode
receipt.completedAt = new Date().toISOString()
receipt.hostAfter = host()
receipt.stdout = fileFacts(stdoutPath)
receipt.stderr = fileFacts(stderrPath)
receipt.cleanup.portAvailableOnIpv4 = await portAvailable('127.0.0.1')
receipt.cleanup.portAvailableOnIpv6 = await portAvailable('::1')
receipt.cleanup.browserProcessesAfter = browserProcesses()

try {
  assert.equal(exitCode, 0)
  assert.equal(receipt.cleanup.portAvailableOnIpv4, true)
  assert.equal(receipt.cleanup.portAvailableOnIpv6, true)
  assert.deepEqual(receipt.cleanup.browserProcessesAfter, [])
  assert.equal(stderr, '')

  const samples = [...stdout.matchAll(/^\[round (\d+)\/(\d+)\] ([^:]+): ([0-9.]+)ms$/gm)]
    .map(match => ({
      round: Number(match[1]),
      runCount: Number(match[2]),
      slot: match[3],
      totalMs: Number(match[4]),
    }))
  assert.equal(samples.length, runCount * slots.length)
  for (const slot of slots) {
    assert.equal(samples.filter(sample => sample.slot === slot.name).length, runCount)
  }
  const summaries = Object.fromEntries(
    slots.map(slot => {
      const expression = new RegExp(
        `^${slot.name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')} (\\{.*\\})$`,
        'm',
      )
      const match = expression.exec(stdout)
      assert(match, `Missing summary for ${slot.name}`)
      const summary = JSON.parse(match[1])
      assert.equal(summary.crossOriginIsolated, true)
      assert.deepEqual(summary.counts, {
        sync: 400,
        timeout: 0,
        animation_frame: 400,
        microtask: 0,
        promise: 0,
      })
      return [slot.name, summary]
    }),
  )
  receipt.samples = samples
  receipt.summaries = summaries
  receipt.retainedSamples = samples.length
  receipt.discardedSamples = 0
  receipt.status = 'complete'
} catch (error) {
  receipt.status = 'failed'
  receipt.error = error instanceof Error ? error.stack : String(error)
  throw error
} finally {
  writeReceipt()
}

process.stdout.write(`\nTIMING_RECEIPT ${receiptPath} ${sha256(readFileSync(receiptPath))}\n`)
