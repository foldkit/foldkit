import assert from 'node:assert/strict'
import { spawnSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import {
  existsSync,
  mkdirSync,
  readdirSync,
  readFileSync,
  statSync,
  writeFileSync,
} from 'node:fs'
import { join } from 'node:path'

const workspace = '/private/tmp/foldkit-r11-r19-prototype-20261108.OnQh5N'
const evidence = join(workspace, 'evidence')
const mapRoot = join(evidence, 'maps')
const node = '/Users/devinjameson/.vite-plus/js_runtime/node/26.13.0/bin/node'
const vite =
  '/Users/devinjameson/.codex/worktrees/block-completion-record/foldkit-unified-recovery-20261103/node_modules/.pnpm/vite@8.3.5_@types+node@26.4.0_jiti@2.7.0_yaml@2.9.1/node_modules/vite/bin/vite.js'
const assetReceipt = JSON.parse(
  readFileSync(join(evidence, 'assets/receipt.json'), 'utf8'),
)

assert.equal(existsSync(mapRoot), false, `Refusing to overwrite ${mapRoot}`)
mkdirSync(mapRoot, { recursive: true })

const sha256 = value => createHash('sha256').update(value).digest('hex')
const fileFacts = path => {
  const bytes = readFileSync(path)
  return { path, bytes: bytes.length, sha256: sha256(bytes) }
}
const commonEnv = { ...process.env }
delete commonEnv.NODE_ENV
delete commonEnv.VITE_USER_NODE_ENV
delete commonEnv.MODE
delete commonEnv.BUILD_VARIANT
Object.assign(commonEnv, {
  CI: '1',
  LANG: 'C.UTF-8',
  LC_ALL: 'C.UTF-8',
  NO_COLOR: '1',
})

const results = []
for (const tree of ['baseline', 'candidate']) {
  for (const variant of ['naive', 'optimised']) {
    const treeRoot = join(workspace, tree === 'candidate' ? 'repo' : tree)
    const benchmarkRoot = join(treeRoot, 'internal/lustre-benchmark')
    const output = join(mapRoot, tree, variant)
    const env =
      variant === 'optimised'
        ? { ...commonEnv, BUILD_VARIANT: 'optimised' }
        : commonEnv
    const command = [
      vite,
      'build',
      '--mode',
      'production',
      '--sourcemap',
      'hidden',
      '--outDir',
      output,
    ]
    const run = spawnSync(node, command, {
      cwd: benchmarkRoot,
      env,
      encoding: 'utf8',
    })
    writeFileSync(
      join(mapRoot, `${tree}-${variant}.log`),
      [
        `$ ${node} ${command.join(' ')}`,
        `cwd=${benchmarkRoot}`,
        `exit=${run.status}`,
        '',
        'stdout:',
        run.stdout ?? '',
        '',
        'stderr:',
        run.stderr ?? '',
      ].join('\n'),
    )
    assert.equal(run.status, 0, `${tree}-${variant} hidden-map build failed`)

    const assetDirectory = join(output, 'assets')
    const names = readdirSync(assetDirectory)
    const javascript = names.filter(name => name.endsWith('.js'))
    const maps = names.filter(name => name.endsWith('.js.map'))
    assert.equal(javascript.length, 1)
    assert.equal(maps.length, 1)
    const javascriptFacts = fileFacts(join(assetDirectory, javascript[0]))
    const mapFacts = fileFacts(join(assetDirectory, maps[0]))
    const expected = assetReceipt.trees[tree].assets.find(
      asset => asset.path.startsWith(`${variant}/assets/`) && asset.path.endsWith('.js'),
    )
    assert(expected, `Missing ${tree} ${variant} asset receipt`)
    assert.equal(javascriptFacts.bytes, expected.bytes)
    assert.equal(javascriptFacts.sha256, expected.sha256)
    assert(statSync(mapFacts.path).size > 0)
    results.push({ tree, variant, javascript: javascriptFacts, map: mapFacts })
  }
}

const receipt = {
  node: fileFacts(node),
  vite: fileFacts(vite),
  assetReceiptSha256: sha256(readFileSync(join(evidence, 'assets/receipt.json'))),
  results,
}
writeFileSync(
  join(mapRoot, 'receipt.json'),
  `${JSON.stringify(receipt, null, 2)}\n`,
)
process.stdout.write(`${JSON.stringify(receipt, null, 2)}\n`)
