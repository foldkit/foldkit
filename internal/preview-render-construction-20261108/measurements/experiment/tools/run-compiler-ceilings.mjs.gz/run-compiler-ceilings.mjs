import assert from 'node:assert/strict'
import { spawn } from 'node:child_process'
import { createHash } from 'node:crypto'
import {
  appendFileSync,
  existsSync,
  readFileSync,
  readdirSync,
  writeFileSync,
} from 'node:fs'
import { join, relative } from 'node:path'

const workspace = '/private/tmp/foldkit-r11-r19-prototype-20261108.OnQh5N'
const repository = join(workspace, 'repo')
const output = join(workspace, 'evidence/compiler-ceilings')
const node = '/Users/devinjameson/.vite-plus/js_runtime/node/26.13.0/bin/node'
const script = join(repository, 'packages/foldkit/scripts/check-block-type-performance.ts')
const typePerformanceRoot = join(repository, 'packages/foldkit/type-performance')
assert.equal(existsSync(output), false, `Refusing to overwrite ${output}`)
await import('node:fs').then(({ mkdirSync }) => mkdirSync(output))

const sha256 = value => createHash('sha256').update(value).digest('hex')
const fileFacts = path => {
  const bytes = readFileSync(path)
  return { path, bytes: bytes.length, sha256: sha256(bytes) }
}
const treeHash = root => {
  const files = []
  const visit = path => {
    for (const entry of readdirSync(path, { withFileTypes: true })) {
      const child = join(path, entry.name)
      if (entry.isDirectory()) visit(child)
      else if (entry.isFile()) files.push(relative(root, child))
    }
  }
  visit(root)
  const hash = createHash('sha256')
  for (const path of files.sort()) {
    hash.update(path)
    hash.update('\0')
    hash.update(readFileSync(join(root, path)))
    hash.update('\0')
  }
  return { fileCount: files.length, sha256: hash.digest('hex') }
}

const fixtureManifest = JSON.parse(
  readFileSync(join(typePerformanceRoot, 'fixtures.json'), 'utf8'),
)
const fixtures = fixtureManifest.fixtures
assert(Array.isArray(fixtures))
assert.equal(fixtures.length, 9)
const workloadBefore = treeHash(typePerformanceRoot)
const stdoutPath = join(output, 'stdout.log')
const stderrPath = join(output, 'stderr.log')
writeFileSync(stdoutPath, '')
writeFileSync(stderrPath, '')
const startedAt = new Date().toISOString()

const child = spawn(node, [script], {
  cwd: repository,
  env: {
    ...process.env,
    CI: '1',
    LANG: 'C.UTF-8',
    LC_ALL: 'C.UTF-8',
    NO_COLOR: '1',
    NODE_DISABLE_COMPILE_CACHE: '1',
  },
  stdio: ['ignore', 'pipe', 'pipe'],
})
child.stdout.on('data', chunk => {
  appendFileSync(stdoutPath, chunk)
  process.stdout.write(chunk)
})
child.stderr.on('data', chunk => {
  appendFileSync(stderrPath, chunk)
  process.stderr.write(chunk)
})
const exitCode = await new Promise((resolve, reject) => {
  child.once('error', reject)
  child.once('exit', code => resolve(code))
})
const workloadAfter = treeHash(typePerformanceRoot)
assert.deepEqual(workloadAfter, workloadBefore)

const receipt = {
  status: exitCode === 0 ? 'pass' : 'fail',
  startedAt,
  completedAt: new Date().toISOString(),
  command: [node, script],
  exitCode,
  node: fileFacts(node),
  script: fileFacts(script),
  fixtureCount: fixtures.length,
  fixtureNames: fixtures.map(fixture => fixture.name),
  workloadBefore,
  workloadAfter,
  stdout: fileFacts(stdoutPath),
  stderr: fileFacts(stderrPath),
}
const receiptPath = join(output, 'receipt.json')
writeFileSync(receiptPath, `${JSON.stringify(receipt, null, 2)}\n`)
assert.equal(exitCode, 0)
process.stdout.write(
  `\nCOMPILER_RECEIPT ${receiptPath} ${sha256(readFileSync(receiptPath))}\n`,
)
