import assert from 'node:assert/strict'
import { spawnSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import {
  existsSync,
  mkdirSync,
  readdirSync,
  readFileSync,
  realpathSync,
  renameSync,
  statSync,
  writeFileSync,
} from 'node:fs'
import { join, relative } from 'node:path'

const workspace =
  '/private/tmp/foldkit-r11-r19-prototype-20261108.OnQh5N'
const outputRoot = join(workspace, 'evidence/assets')
const node =
  '/Users/devinjameson/.vite-plus/js_runtime/node/26.13.0/bin/node'
const dependencyRoot =
  '/Users/devinjameson/.codex/worktrees/block-completion-record/foldkit-unified-recovery-20261103/node_modules/.pnpm'
const rimraf = join(
  dependencyRoot,
  'rimraf@6.1.3/node_modules/rimraf/dist/esm/bin.mjs',
)
const vite = join(
  dependencyRoot,
  'vite@8.3.5_@types+node@26.4.0_jiti@2.7.0_yaml@2.9.1/node_modules/vite/bin/vite.js',
)
const sha256 = value => createHash('sha256').update(value).digest('hex')
const fileSha256 = path => sha256(readFileSync(path))

mkdirSync(outputRoot, { recursive: true })

const commonEnv = { ...process.env }
delete commonEnv.NODE_ENV
delete commonEnv.VITE_USER_NODE_ENV
delete commonEnv.MODE
delete commonEnv.BUILD_VARIANT
Object.assign(commonEnv, {
  CI: '1',
  LANG: 'C.UTF-8',
  LC_ALL: 'C.UTF-8',
  NO_COLOR: '1',
})

const run = (name, command, cwd, env = commonEnv) => {
  const result = spawnSync(node, command, { cwd, env, encoding: 'utf8' })
  const output = [
    `$ ${node} ${command.join(' ')}`,
    `cwd=${cwd}`,
    `exit=${result.status}`,
    '',
    'stdout:',
    result.stdout ?? '',
    '',
    'stderr:',
    result.stderr ?? '',
  ].join('\n')
  writeFileSync(join(outputRoot, `${name}.log`), output)
  assert.equal(result.status, 0, `${name} failed:\n${output}`)
}

const filesUnder = root => {
  const files = []
  const visit = path => {
    for (const entry of readdirSync(path, { withFileTypes: true })) {
      const child = join(path, entry.name)
      if (entry.isDirectory()) {
        visit(child)
      } else if (entry.isFile()) {
        files.push({
          path: relative(root, child),
          bytes: statSync(child).size,
          sha256: fileSha256(child),
        })
      }
    }
  }
  visit(root)
  return files.sort((left, right) => left.path.localeCompare(right.path))
}

const trees = [
  { name: 'baseline', root: join(workspace, 'baseline') },
  { name: 'candidate', root: join(workspace, 'repo') },
]

for (const tree of trees) {
  const benchmarkRoot = join(tree.root, 'internal/lustre-benchmark')
  const pluginRoot = join(tree.root, 'packages/vite-plugin-foldkit')
  assert.equal(
    realpathSync(join(benchmarkRoot, 'node_modules/foldkit')),
    realpathSync(join(tree.root, 'packages/foldkit')),
  )
  assert.equal(
    realpathSync(join(benchmarkRoot, 'node_modules/@foldkit/vite-plugin')),
    realpathSync(pluginRoot),
  )
  assert.equal(
    realpathSync(join(tree.root, 'packages/foldkit/node_modules')),
    realpathSync(
      '/Users/devinjameson/.codex/worktrees/block-completion-record/foldkit-unified-recovery-20261103/packages/foldkit/node_modules',
    ),
  )

  run(
    `${tree.name}-clean-plugin`,
    [rimraf, 'dist', 'tsconfig.tsbuildinfo'],
    pluginRoot,
  )
  run(
    `${tree.name}-build-plugin`,
    [
      join(pluginRoot, 'node_modules/typescript/bin/tsc'),
      '-b',
      'tsconfig.json',
    ],
    pluginRoot,
  )
  run(`${tree.name}-clean-assets`, [rimraf, 'dist'], benchmarkRoot)
  run(
    `${tree.name}-build-naive`,
    [vite, 'build', '--mode', 'production'],
    benchmarkRoot,
  )
  run(
    `${tree.name}-build-optimised`,
    [vite, 'build', '--mode', 'production'],
    benchmarkRoot,
    { ...commonEnv, BUILD_VARIANT: 'optimised' },
  )
  const source = join(benchmarkRoot, 'dist/optimised/index.optimised.html')
  const target = join(benchmarkRoot, 'dist/optimised/index.html')
  assert(existsSync(source), source)
  renameSync(source, target)
}

const receipt = {
  node,
  nodeSha256: fileSha256(node),
  vite,
  viteSha256: fileSha256(vite),
  trees: Object.fromEntries(
    trees.map(tree => {
      const benchmarkRoot = join(tree.root, 'internal/lustre-benchmark')
      return [
        tree.name,
        {
          root: tree.root,
          htmlSourceSha256: fileSha256(
            join(tree.root, 'packages/foldkit/src/html/index.ts'),
          ),
          lockfileSha256: fileSha256(join(tree.root, 'pnpm-lock.yaml')),
          optimisedViewSha256: fileSha256(
            join(benchmarkRoot, 'src/view.optimised.ts'),
          ),
          driverSha256: fileSha256(join(benchmarkRoot, 'bench/run.mjs')),
          foldkitLink: realpathSync(
            join(benchmarkRoot, 'node_modules/foldkit'),
          ),
          pluginLink: realpathSync(
            join(benchmarkRoot, 'node_modules/@foldkit/vite-plugin'),
          ),
          foldkitDependenciesLink: realpathSync(
            join(tree.root, 'packages/foldkit/node_modules'),
          ),
          pluginFiles: filesUnder(
            join(tree.root, 'packages/vite-plugin-foldkit/dist'),
          ),
          assets: filesUnder(join(benchmarkRoot, 'dist')),
        },
      ]
    }),
  ),
}

assert.deepEqual(
  receipt.trees.baseline.pluginFiles,
  receipt.trees.candidate.pluginFiles,
  'baseline and candidate Vite plugin outputs differ',
)
assert.equal(
  receipt.trees.baseline.lockfileSha256,
  receipt.trees.candidate.lockfileSha256,
)
assert.equal(
  receipt.trees.baseline.optimisedViewSha256,
  receipt.trees.candidate.optimisedViewSha256,
)
assert.equal(
  receipt.trees.baseline.driverSha256,
  receipt.trees.candidate.driverSha256,
)

writeFileSync(
  join(outputRoot, 'receipt.json'),
  `${JSON.stringify(receipt, null, 2)}\n`,
)
process.stdout.write(`${JSON.stringify(receipt, null, 2)}\n`)
