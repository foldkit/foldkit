import assert from 'node:assert/strict'
import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import {
  existsSync,
  lstatSync,
  readFileSync,
  readdirSync,
  realpathSync,
  statSync,
  writeFileSync,
} from 'node:fs'
import { join, relative } from 'node:path'

const workspace = '/private/tmp/foldkit-r11-r19-prototype-20261108.OnQh5N'
const evidence = join(workspace, 'evidence')
const output = join(evidence, 'final-manifest.json')
assert.equal(existsSync(output), false, `Refusing to overwrite ${output}`)

const sha256 = value => createHash('sha256').update(value).digest('hex')
const facts = path => {
  const bytes = readFileSync(path)
  return { path, bytes: bytes.length, sha256: sha256(bytes) }
}
const filesUnder = root => {
  const files = []
  const links = []
  const visit = path => {
    for (const entry of readdirSync(path, { withFileTypes: true })) {
      const child = join(path, entry.name)
      if (entry.isSymbolicLink()) {
        links.push({
          path: relative(root, child),
          target: realpathSync(child),
        })
      } else if (entry.isDirectory()) {
        visit(child)
      } else if (entry.isFile()) {
        files.push({
          path: relative(root, child),
          bytes: statSync(child).size,
          sha256: sha256(readFileSync(child)),
        })
      }
    }
  }
  visit(root)
  return {
    files: files.sort((left, right) => left.path.localeCompare(right.path)),
    links: links.sort((left, right) => left.path.localeCompare(right.path)),
  }
}
const git = (root, args) =>
  execFileSync('git', args, { cwd: root, encoding: 'utf8' }).trim()

const baseline = join(workspace, 'baseline')
const candidate = join(workspace, 'repo')
const toolNames = [
  'build-assets.mjs',
  'prepare-maps.mjs',
  'run-functional-guards.mjs',
  'capture-work-counts.mjs',
  'analyse-work-counts.cjs',
  'verify-work-counts.mjs',
  'run-ordinary-timing.mjs',
  'analyse-ordinary-timing.mjs',
  'run-compiler-ceilings.mjs',
  'make-evidence-manifest.mjs',
]
const candidateNames = [
  'packages/foldkit/src/domReflection.ts',
  'packages/foldkit/src/html/index.ts',
  'packages/foldkit/src/snabbdom/h.ts',
  'packages/foldkit/src/html/htmlBuilder.test.ts',
  'packages/foldkit/src/html/keyed.test.ts',
  'packages/foldkit/src/patchVNode.test.ts',
]
const inventory = filesUnder(evidence)
const manifest = {
  formatVersion: 1,
  generatedAt: new Date().toISOString(),
  label:
    'Final isolated 7cc R11/R19 paired prototype correctness, compiler-ceiling, asset, work-count and one-batch ordinary Runtime evidence',
  workspace,
  identity: {
    baseline: {
      root: baseline,
      head: git(baseline, ['rev-parse', 'HEAD']),
      trackedStatus: git(baseline, ['status', '--short', '--untracked-files=no']),
    },
    candidate: {
      root: candidate,
      baseHead: git(candidate, ['rev-parse', 'HEAD']),
      trackedStatus: git(candidate, ['status', '--short', '--untracked-files=no']),
      patch: facts(join(evidence, 'candidate.patch')),
      files: candidateNames.map(path => facts(join(candidate, path))),
    },
  },
  tools: toolNames.map(path => facts(join(workspace, path))),
  evidenceFiles: inventory.files,
  evidenceLinks: inventory.links,
  timingClassification: {
    originalReceipt: 'failed',
    reason:
      'Post-cleanup outer wrapper rejected the unchanged driver\'s exact caught revision warning from the generated non-Git timing harness directory.',
    readback: 'valid-readback',
    retryCount: 0,
  },
  compilerCeilings: {
    status: 'pass',
    fixtureCount: 9,
    receipt: facts(join(evidence, 'compiler-ceilings/receipt.json')),
    workloadBeforeAndAfterSha256:
      'da92c6aca5a772102f2a94de57caeb006e1aa58e60f96c018d3e708ba2d4609b',
  },
  openFollowUp:
    'Final combined cadence source must retain exactly 400 rAF callbacks under the unchanged driver before production adoption or final-candidate timing.',
}
writeFileSync(output, `${JSON.stringify(manifest, null, 2)}\n`, { flag: 'wx' })
process.stdout.write(
  `${JSON.stringify({
    output,
    sha256: sha256(readFileSync(output)),
    evidenceFiles: manifest.evidenceFiles.length,
    evidenceLinks: manifest.evidenceLinks.length,
    bytes: lstatSync(output).size,
  }, null, 2)}\n`,
)
