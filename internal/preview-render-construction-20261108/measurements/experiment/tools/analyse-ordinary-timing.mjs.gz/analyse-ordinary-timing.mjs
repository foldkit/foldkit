import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { readFileSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'

const workspace = '/private/tmp/foldkit-r11-r19-prototype-20261108.OnQh5N'
const root = join(workspace, 'evidence/timing')
const originalReceiptPath = join(root, 'receipt.json')
const stdoutPath = join(root, 'timing.stdout.log')
const stderrPath = join(root, 'timing.stderr.log')
const original = JSON.parse(readFileSync(originalReceiptPath, 'utf8'))
const stdout = readFileSync(stdoutPath, 'utf8')
const stderr = readFileSync(stderrPath, 'utf8')
const sha256 = value => createHash('sha256').update(value).digest('hex')
const round = value => Number(value.toFixed(3))
const roundOneDecimal = value => Number(value.toFixed(1))
const median = values => {
  const sorted = [...values].sort((left, right) => left - right)
  const middle = Math.floor(sorted.length / 2)
  return sorted.length % 2 === 0
    ? (sorted[middle - 1] + sorted[middle]) / 2
    : sorted[middle]
}

assert.equal(original.status, 'failed')
assert.equal(original.exitCode, 0)
assert.deepEqual(original.cleanup, {
  portAvailableOnIpv4: true,
  portAvailableOnIpv6: true,
  browserProcessesAfter: [],
})
assert.equal(
  stderr,
  'fatal: not a git repository (or any of the parent directories): .git\n',
)
assert.match(stdout, /^harness revision: unknown$/m)
assert.equal(sha256(readFileSync(stdoutPath)), original.stdout.sha256)
assert.equal(sha256(readFileSync(stderrPath)), original.stderr.sha256)

const samples = [...stdout.matchAll(/^\[round (\d+)\/(\d+)\] ([^:]+): ([0-9.]+)ms$/gm)]
  .map(match => ({
    round: Number(match[1]),
    runCount: Number(match[2]),
    slot: match[3],
    totalMs: Number(match[4]),
  }))
assert.equal(samples.length, 72)
assert.equal(original.runCount, 12)
assert.equal(original.slots.length, 6)
for (let roundIndex = 0; roundIndex < original.runCount; roundIndex += 1) {
  const actual = samples
    .filter(sample => sample.round === roundIndex + 1)
    .map(sample => sample.slot)
  const offset = roundIndex % original.slots.length
  const expected = [
    ...original.slots.slice(offset),
    ...original.slots.slice(0, offset),
  ].map(slot => slot.name)
  assert.deepEqual(actual, expected)
}

const roundedSampleMedians = {}
const summaries = Object.fromEntries(
  original.slots.map(slot => {
    const expression = new RegExp(
      `^${slot.name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')} (\\{.*\\})$`,
      'm',
    )
    const match = expression.exec(stdout)
    assert(match, `Missing summary for ${slot.name}`)
    const summary = JSON.parse(match[1])
    assert.equal(summary.crossOriginIsolated, true)
    assert.deepEqual(summary.counts, {
      sync: 400,
      timeout: 0,
      animation_frame: 400,
      microtask: 0,
      promise: 0,
    })
    const sampleMedian = median(
      samples.filter(sample => sample.slot === slot.name).map(sample => sample.totalMs),
    )
    const roundedSampleMedian = roundOneDecimal(sampleMedian)
    assert(
      Math.abs(summary.total - roundedSampleMedian) <= 0.100001,
      `${slot.name} displayed summary differs from its one-decimal samples`,
    )
    roundedSampleMedians[slot.name] = {
      driverSummaryMedianMs: summary.total,
      medianFromDisplayedOneDecimalSamplesMs: roundedSampleMedian,
      differenceMs: round(summary.total - roundedSampleMedian),
    }
    return [slot.name, summary]
  }),
)

const variant = (name, baselineA, candidate, baselineB) => {
  const rounds = Array.from({ length: original.runCount }, (_, index) => {
    const roundNumber = index + 1
    const value = slot =>
      samples.find(sample => sample.round === roundNumber && sample.slot === slot)
        ?.totalMs ?? assert.fail(`Missing ${slot} round ${roundNumber}`)
    const a = value(baselineA)
    const c = value(candidate)
    const b = value(baselineB)
    const midpoint = (a + b) / 2
    return {
      round: roundNumber,
      baselineA: a,
      candidate: c,
      baselineB: b,
      baselineMidpoint: round(midpoint),
      candidateMinusBaselineMidpoint: round(c - midpoint),
      duplicateBaselineSignedDifference: round(a - b),
      duplicateBaselineAbsoluteDifference: round(Math.abs(a - b)),
    }
  })
  const baselineAMedian = summaries[baselineA].total
  const candidateMedian = summaries[candidate].total
  const baselineBMedian = summaries[baselineB].total
  const baselineMedianMidpoint = (baselineAMedian + baselineBMedian) / 2
  const candidateDelta = candidateMedian - baselineMedianMidpoint
  const paired = rounds.map(item => item.candidateMinusBaselineMidpoint)
  const duplicate = rounds.map(item => item.duplicateBaselineAbsoluteDifference)
  return {
    name,
    slots: { baselineA, candidate, baselineB },
    summary: {
      baselineAMedian,
      candidateMedian,
      baselineBMedian,
      baselineMedianMidpoint: round(baselineMedianMidpoint),
      candidateMinusBaselineMedianMidpointMs: round(candidateDelta),
      candidateMinusBaselineMedianMidpointPercent: round(
        (candidateDelta / baselineMedianMidpoint) * 100,
      ),
      candidateFasterRounds: paired.filter(value => value < 0).length,
      candidateSlowerRounds: paired.filter(value => value > 0).length,
      tiedRounds: paired.filter(value => value === 0).length,
      medianPairedDeltaMs: round(median(paired)),
      minimumPairedDeltaMs: Math.min(...paired),
      maximumPairedDeltaMs: Math.max(...paired),
      medianDuplicateBaselineAbsoluteDifferenceMs: round(median(duplicate)),
      maximumDuplicateBaselineAbsoluteDifferenceMs: Math.max(...duplicate),
      sync: {
        baselineA: summaries[baselineA].sync,
        candidate: summaries[candidate].sync,
        baselineB: summaries[baselineB].sync,
      },
      animationFrame: {
        baselineA: summaries[baselineA].animationFrame,
        candidate: summaries[candidate].animationFrame,
        baselineB: summaries[baselineB].animationFrame,
      },
      callbackCounts: {
        baselineA: summaries[baselineA].counts,
        candidate: summaries[candidate].counts,
        baselineB: summaries[baselineB].counts,
      },
    },
    rounds,
  }
}

const variants = [
  variant(
    'optimised',
    'r11-baseline-optimised-a',
    'r11-candidate-optimised',
    'r11-baseline-optimised-b',
  ),
  variant(
    'naive',
    'r11-baseline-naive-a',
    'r11-candidate-naive',
    'r11-baseline-naive-b',
  ),
]

const result = {
  schemaVersion: 1,
  status: 'valid-readback',
  analysedAt: new Date().toISOString(),
  originalReceipt: {
    path: originalReceiptPath,
    sha256: sha256(readFileSync(originalReceiptPath)),
    status: original.status,
    classificationFailure:
      'The wrapper rejected the unchanged driver\'s exact caught git-revision stderr after all samples and cleanup. Driver exit, samples and semantic guards passed; no retry was run.',
  },
  stdout: { path: stdoutPath, sha256: sha256(readFileSync(stdoutPath)) },
  stderr: {
    path: stderrPath,
    sha256: sha256(readFileSync(stderrPath)),
    exactExpectedText: stderr,
  },
  retainedSamples: samples.length,
  discardedSamples: 0,
  cyclicOrderingVerified: true,
  ordinalVisitsPerSlot: original.cyclicOrdinalVisitsPerSlot,
  driverExitCode: original.exitCode,
  cleanup: original.cleanup,
  limitations: [
    'This is one ordinary 12-round batch, not proof of a universal latency effect.',
    'Duplicate-baseline variation is the same-batch control for interpreting candidate deltas.',
    'Optimized is the primary result; naive is a secondary control.',
    'The isolated source is exactly 7cc plus the paired R11/R19 candidate and excludes the later cadence change.',
    'Per-round totals are retained at the unchanged driver\'s one-decimal display precision; paired and duplicate calculations cannot recover sub-0.1 ms detail.',
  ],
  variants,
  samples,
  summaries,
  roundedSampleMedians,
}
const output = join(root, 'validity-analysis.json')
writeFileSync(output, `${JSON.stringify(result, null, 2)}\n`, { flag: 'wx' })
process.stdout.write(
  `${JSON.stringify({
    output,
    sha256: sha256(readFileSync(output)),
    retainedSamples: result.retainedSamples,
    cleanup: result.cleanup,
    variants: variants.map(({ name, summary }) => ({ name, ...summary })),
  }, null, 2)}\n`,
)
