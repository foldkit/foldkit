import assert from 'node:assert/strict'
import { spawnSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import {
  copyFileSync,
  existsSync,
  mkdirSync,
  readFileSync,
  realpathSync,
  readdirSync,
  statSync,
  symlinkSync,
  writeFileSync,
} from 'node:fs'
import { join, relative } from 'node:path'

const workspace = '/private/tmp/foldkit-r11-r19-prototype-20261108.OnQh5N'
const evidence = join(workspace, 'evidence')
const output = join(evidence, 'functional')
const harness = join(output, 'harness')
const node = '/Users/devinjameson/.vite-plus/js_runtime/node/26.13.0/bin/node'
const chromium =
  '/Users/devinjameson/Library/Caches/ms-playwright/chromium-1243/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing'
const verify =
  '/private/tmp/foldkit-record-release-rendering-xpwmm820/driver/verify.mjs'
const instrumentation =
  '/private/tmp/foldkit-record-release-rendering-xpwmm820/harness/priv/instrumentation.js'
const assetReceiptPath = join(evidence, 'assets/receipt.json')
const assetReceipt = JSON.parse(readFileSync(assetReceiptPath, 'utf8'))
const sha256 = value => createHash('sha256').update(value).digest('hex')
const fileFacts = path => {
  const bytes = readFileSync(path)
  return { path, bytes: bytes.length, sha256: sha256(bytes) }
}

assert.equal(existsSync(output), false, `Refusing to overwrite ${output}`)
mkdirSync(join(harness, 'priv/implementations'), { recursive: true })
copyFileSync(instrumentation, join(harness, 'priv/instrumentation.js'))

const slots = [
  { name: 'r11-baseline-naive', tree: 'baseline', variant: 'naive' },
  { name: 'r11-baseline-optimised', tree: 'baseline', variant: 'optimised' },
  { name: 'r11-candidate-naive', tree: 'candidate', variant: 'naive' },
  { name: 'r11-candidate-optimised', tree: 'candidate', variant: 'optimised' },
]

for (const slot of slots) {
  const treeRoot = join(workspace, slot.tree === 'candidate' ? 'repo' : slot.tree)
  const source = join(treeRoot, 'internal/lustre-benchmark/dist', slot.variant)
  const slotRoot = join(harness, 'priv/implementations', slot.name)
  mkdirSync(slotRoot, { recursive: true })
  symlinkSync(source, join(slotRoot, 'dist'), 'dir')
  assert.equal(realpathSync(join(slotRoot, 'dist')), realpathSync(source))
}

const results = []
for (let index = 0; index < slots.length; index += 1) {
  const slot = slots[index]
  const port = 38610 + index
  const run = spawnSync(node, [verify], {
    cwd: '/private/tmp/foldkit-record-release-rendering-xpwmm820/driver',
    env: {
      ...process.env,
      HARNESS_DIR: harness,
      IMPL: slot.name,
      PORT: String(port),
      FOLDKIT_BENCH_CHROMIUM: chromium,
    },
    encoding: 'utf8',
    maxBuffer: 1024 * 1024,
  })
  const log = [
    `$ ${node} ${verify}`,
    `HARNESS_DIR=${harness}`,
    `IMPL=${slot.name}`,
    `PORT=${port}`,
    `exit=${run.status}`,
    '',
    'stdout:',
    run.stdout ?? '',
    '',
    'stderr:',
    run.stderr ?? '',
    '',
    `error=${run.error?.message ?? ''}`,
  ].join('\n')
  const logPath = join(output, `${slot.name}.log`)
  writeFileSync(logPath, log)
  assert.equal(run.status, 0, `${slot.name} functional guard failed:\n${log}`)
  assert.match(run.stdout, new RegExp(`VERIFY ${slot.name}: OK`))
  results.push({ ...slot, port, log: fileFacts(logPath) })
}

const assetFiles = source => {
  const files = []
  const visit = root => {
    for (const entry of readdirSync(root, { withFileTypes: true })) {
      const path = join(root, entry.name)
      if (entry.isDirectory()) visit(path)
      else if (entry.isFile()) files.push({
        path: relative(source, path),
        bytes: statSync(path).size,
        sha256: sha256(readFileSync(path)),
      })
    }
  }
  visit(source)
  return files.sort((left, right) => left.path.localeCompare(right.path))
}

const receipt = {
  interpretation: 'Functional correctness only; no elapsed value is retained or used.',
  node: fileFacts(node),
  chromium: fileFacts(chromium),
  verify: fileFacts(verify),
  instrumentation: fileFacts(join(harness, 'priv/instrumentation.js')),
  assetReceiptSha256: sha256(readFileSync(assetReceiptPath)),
  results: results.map(result => {
    const source = realpathSync(join(harness, 'priv/implementations', result.name, 'dist'))
    const expected = assetReceipt.trees[result.tree].assets.filter(asset =>
      asset.path.startsWith(`${result.variant}/`),
    ).map(asset => ({ ...asset, path: asset.path.slice(result.variant.length + 1) }))
    const actual = assetFiles(source)
    assert.deepEqual(actual, expected)
    return { ...result, source, files: actual }
  }),
}
writeFileSync(join(output, 'receipt.json'), `${JSON.stringify(receipt, null, 2)}\n`)
process.stdout.write(`${JSON.stringify(receipt, null, 2)}\n`)
