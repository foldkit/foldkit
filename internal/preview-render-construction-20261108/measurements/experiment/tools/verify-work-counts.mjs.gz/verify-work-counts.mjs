import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { readFileSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'

const workspace = '/private/tmp/foldkit-r11-r19-prototype-20261108.OnQh5N'
const root = join(workspace, 'evidence/work-counts')
const analysisPath = join(root, 'analysis.json')
const capturePath = join(root, 'receipt.json')
const analysis = JSON.parse(readFileSync(analysisPath, 'utf8'))
const capture = JSON.parse(readFileSync(capturePath, 'utf8'))
const sha256 = value => createHash('sha256').update(value).digest('hex')

assert.equal(capture.status, 'complete')
assert.equal(capture.browserAndServerClosed, true)
for (const result of capture.results) {
  assert.deepEqual(result.counts, {
    sync: 400,
    timeout: 0,
    animation_frame: 400,
    microtask: 0,
    promise: 0,
  })
  assert.deepEqual(result.finalDom, { hasNewTodo: true, todoCount: 0 })
  assert.equal(result.asset.sha256, result.asset.servedSha256)
  assert.equal(result.asset.sha256, result.asset.executedSha256)
}

const by = (tree, variant) =>
  analysis.results.find(result => result.tree === tree && result.variant === variant) ??
  assert.fail(`Missing ${tree} ${variant} analysis`)

const rowsFor = (result, predicate) =>
  result.relevantFunctions
    .filter(predicate)
    .map(({ source, name, line, column, count }) => ({
      source,
      name,
      line,
      column,
      count,
    }))
    .sort((left, right) => JSON.stringify(left).localeCompare(JSON.stringify(right)))

const countRowsFor = (result, predicate) =>
  result.relevantFunctions
    .filter(predicate)
    .map(({ source, name, count }) => ({ source, name, count }))
    .sort((left, right) => JSON.stringify(left).localeCompare(JSON.stringify(right)))

const unchangedSource = source =>
  /(?:internal\/lustre-benchmark\/src\/(?:todo|view\.optimised|application(?:\.optimised)?|entry(?:\.optimised)?)\.ts|packages\/foldkit\/src\/(?:html\/lazy|snabbdom\/init|runtime\/(?:renderer|runtime|program)|vdom)\.ts)/.test(source ?? '')

const count = (result, source, name) => {
  const rows = result.relevantFunctions.filter(
    row => row.source === source && row.name === name,
  )
  assert(rows.length > 0, `Missing ${result.name} ${source} ${name}`)
  return rows.reduce((total, row) => total + row.count, 0)
}

const pairs = []
for (const variant of ['optimised', 'naive']) {
  const baseline = by('baseline', variant)
  const candidate = by('candidate', variant)
  assert.deepEqual(
    rowsFor(candidate, row => unchangedSource(row.source)),
    rowsFor(baseline, row => unchangedSource(row.source)),
    `${variant} unchanged application/runtime work differs`,
  )

  const baselineHtml = countRowsFor(
    baseline,
    row =>
      row.source === 'packages/foldkit/src/html/index.ts' &&
      row.name !== 'copyChildrenDroppingEmpty',
  )
  const candidateHtml = countRowsFor(
    candidate,
    row =>
      row.source === 'packages/foldkit/src/html/index.ts' &&
      row.name !== 'normalizeChildrenDroppingEmpty' &&
      row.name !== 'createBuiltInElementMetadata' &&
      row.name !== '',
  )
  const baselineHtmlWithoutAnonymous = baselineHtml.filter(row => row.name !== '')
  assert.deepEqual(
    candidateHtml,
    baselineHtmlWithoutAnonymous,
    `${variant} unchanged Html builder work differs`,
  )

  const oldNormalizeCount = count(
    baseline,
    'packages/foldkit/src/html/index.ts',
    'copyChildrenDroppingEmpty',
  )
  const newNormalizeCount = count(
    candidate,
    'packages/foldkit/src/html/index.ts',
    'normalizeChildrenDroppingEmpty',
  )
  assert.equal(newNormalizeCount, oldNormalizeCount)

  const oldHCount = count(
    baseline,
    'packages/foldkit/src/snabbdom/h.ts',
    'h',
  )
  const finalizationCount = count(
    candidate,
    'packages/foldkit/src/snabbdom/h.ts',
    'finalizeVNode',
  )
  const normalizedHCount = count(
    candidate,
    'packages/foldkit/src/snabbdom/h.ts',
    '__hWithNormalizedChildren',
  )
  assert.equal(finalizationCount, oldHCount)
  assert.equal(normalizedHCount, oldHCount)

  const oldReflectionCount = count(
    baseline,
    'packages/foldkit/src/domReflection.ts',
    'isHtmlPropertyRepresentable',
  )
  const lowerReflectionCount = count(
    candidate,
    'packages/foldkit/src/domReflection.ts',
    'isHtmlPropertyRepresentableForLowerTag',
  )
  assert.equal(lowerReflectionCount, oldReflectionCount)
  const metadataCount = count(
    candidate,
    'packages/foldkit/src/html/index.ts',
    'createBuiltInElementMetadata',
  )
  assert.equal(metadataCount, 213)

  pairs.push({
    variant,
    unchangedRows: rowsFor(baseline, row => unchangedSource(row.source)).length,
    oldNormalizeCount,
    newNormalizeCount,
    oldHCount,
    finalizationCount,
    normalizedHCount,
    oldReflectionCount,
    lowerReflectionCount,
    metadataCount,
    baselineFunctionCount: capture.results.find(
      result => result.tree === 'baseline' && result.variant === variant,
    ).functionCount,
    candidateFunctionCount: capture.results.find(
      result => result.tree === 'candidate' && result.variant === variant,
    ).functionCount,
  })
}

const receipt = {
  status: 'pass',
  interpretation:
    'Precise-coverage call counts only. Exact workload, DOM, callback, unchanged application/runtime, normalization, finalization, reflection, and built-in metadata controls passed; elapsed coverage values are invalid.',
  captureSha256: sha256(readFileSync(capturePath)),
  analysisSha256: sha256(readFileSync(analysisPath)),
  pairs,
}
const receiptPath = join(root, 'guard-receipt.json')
writeFileSync(receiptPath, `${JSON.stringify(receipt, null, 2)}\n`, { flag: 'wx' })
process.stdout.write(`${JSON.stringify({ receiptPath, ...receipt }, null, 2)}\n`)
