const assert = require('node:assert/strict')
const { createHash } = require('node:crypto')
const { readFileSync, writeFileSync } = require('node:fs')
const { join } = require('node:path')
const ts = require('/Users/devinjameson/.codex/worktrees/block-completion-record/foldkit-unified-recovery-20261103/node_modules/typescript/lib/typescript.js')
const {
  TraceMap,
  decodedMappings,
} = require('/Users/devinjameson/.codex/worktrees/block-completion-record/foldkit-unified-recovery-20261103/node_modules/.pnpm/@jridgewell+trace-mapping@0.3.31/node_modules/@jridgewell/trace-mapping')

const workspace = '/private/tmp/foldkit-r11-r19-prototype-20261108.OnQh5N'
const evidence = join(workspace, 'evidence')
const captureRoot = join(evidence, 'work-counts')
const captureReceipt = JSON.parse(readFileSync(join(captureRoot, 'receipt.json'), 'utf8'))
const mapReceipt = JSON.parse(readFileSync(join(evidence, 'maps/receipt.json'), 'utf8'))
const sha256 = value => createHash('sha256').update(value).digest('hex')

assert.equal(captureReceipt.status, 'complete')
assert.equal(captureReceipt.browserAndServerClosed, true)
assert.equal(captureReceipt.mapReceiptSha256, sha256(readFileSync(join(evidence, 'maps/receipt.json'))))

const normalizeSource = source => {
  if (!source) return undefined
  for (const marker of ['packages/', 'internal/']) {
    const index = source.lastIndexOf(marker)
    if (index >= 0) return source.slice(index)
  }
  return source
}

const astCache = new Map()
const enclosingName = (source, content, line, column) => {
  if (!content || line == null || column == null) return undefined
  let cached = astCache.get(`${source}\0${content}`)
  if (!cached) {
    const file = ts.createSourceFile(source, content, ts.ScriptTarget.Latest, true)
    const functions = []
    const visit = (node, parents) => {
      let names = parents
      if (ts.isFunctionLike(node) && node.body) {
        let name = node.name?.getText(file)
        let owner = node
        if (
          ts.isVariableDeclaration(node.parent) ||
          ts.isPropertyAssignment(node.parent) ||
          ts.isMethodDeclaration(node.parent)
        ) {
          name = node.parent.name?.getText(file) ?? name
          owner = node.parent
        }
        names = name ? [...parents, name] : parents
        functions.push({
          start: owner.getStart(file),
          end: owner.end,
          name: names.join('.'),
        })
      }
      ts.forEachChild(node, child => visit(child, names))
    }
    visit(file, [])
    cached = { file, functions }
    astCache.set(`${source}\0${content}`, cached)
  }
  const offset = cached.file.getPositionOfLineAndCharacter(line - 1, column)
  return cached.functions
    .filter(item => item.start <= offset && offset < item.end)
    .sort((left, right) => left.end - left.start)[0]?.name
}

const lowerBound = (mappings, offset) => {
  let low = 0
  let high = mappings.length
  while (low < high) {
    const middle = (low + high) >> 1
    if (mappings[middle].offset < offset) low = middle + 1
    else high = middle
  }
  return low
}

const relevant = source =>
  /(?:internal\/lustre-benchmark\/src\/(?:todo|view\.optimised|application(?:\.optimised)?|entry(?:\.optimised)?)\.ts|packages\/foldkit\/src\/(?:domReflection|html\/(?:index|lazy)|snabbdom\/(?:h|init)|runtime\/(?:renderer|runtime|program)|vdom)\.ts)/.test(source ?? '')

const results = []
for (const captured of captureReceipt.results) {
  const mapFacts = mapReceipt.results.find(
    item => item.tree === captured.tree && item.variant === captured.variant,
  )
  assert(mapFacts)
  assert.equal(mapFacts.javascript.sha256, captured.asset.sha256)
  const javascript = readFileSync(mapFacts.javascript.path, 'utf8')
  const rawMap = JSON.parse(readFileSync(mapFacts.map.path, 'utf8'))
  assert.equal(sha256(Buffer.from(javascript)), mapFacts.javascript.sha256)
  assert.equal(sha256(readFileSync(mapFacts.map.path)), mapFacts.map.sha256)
  const trace = new TraceMap(rawMap)
  const lineStarts = [0]
  for (let index = 0; index < javascript.length; index += 1) {
    if (javascript.charCodeAt(index) === 10) lineStarts.push(index + 1)
  }
  const mappings = []
  for (const [line, segments] of decodedMappings(trace).entries()) {
    for (const segment of segments) {
      if (segment.length < 4) continue
      mappings.push({
        offset: lineStarts[line] + segment[0],
        source: rawMap.sources[segment[1]],
        sourceNormalized: normalizeSource(rawMap.sources[segment[1]]),
        line: segment[2] + 1,
        column: segment[3],
        mappedName:
          segment.length >= 5 ? rawMap.names?.[segment[4]] : undefined,
        content: rawMap.sourcesContent?.[segment[1]],
      })
    }
  }

  const captureBytes = readFileSync(join(captureRoot, captured.captureFile))
  assert.equal(sha256(captureBytes), captured.captureSha256)
  const scripts = JSON.parse(captureBytes)
  assert.equal(scripts.length, 1)
  const functions = []
  for (const fn of scripts[0].functions) {
    const range = fn.ranges[0]
    let index = lowerBound(mappings, range.startOffset)
    let mapping
    while (index < mappings.length && mappings[index].offset < range.endOffset) {
      if (mappings[index].source) {
        mapping = mappings[index]
        break
      }
      index += 1
    }
    if (!mapping) continue
    functions.push({
      source: mapping.sourceNormalized,
      name:
        enclosingName(
          mapping.source,
          mapping.content,
          mapping.line,
          mapping.column,
        ) ?? mapping.mappedName ?? fn.functionName ?? '(anonymous)',
      generatedName: fn.functionName,
      line: mapping.line,
      column: mapping.column,
      count: range.count,
      generatedStartOffset: range.startOffset,
      generatedEndOffset: range.endOffset,
    })
  }
  results.push({
    name: captured.name,
    tree: captured.tree,
    variant: captured.variant,
    assetSha256: captured.asset.sha256,
    captureSha256: captured.captureSha256,
    relevantFunctions: functions.filter(row => relevant(row.source)),
  })
}

const output = {
  interpretation:
    'Source-matched precise-coverage counts only; elapsed coverage values are invalid.',
  captureReceiptSha256: sha256(readFileSync(join(captureRoot, 'receipt.json'))),
  mapReceiptSha256: sha256(readFileSync(join(evidence, 'maps/receipt.json'))),
  results,
}
const outputPath = join(captureRoot, 'analysis.json')
writeFileSync(outputPath, `${JSON.stringify(output, null, 2)}\n`, { flag: 'wx' })
console.log(JSON.stringify({
  outputPath,
  sha256: sha256(readFileSync(outputPath)),
  rows: results.map(result => ({ name: result.name, relevantFunctions: result.relevantFunctions.length })),
}, null, 2))
