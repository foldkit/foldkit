# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: accessibility.spec.ts >> makes scrollable tables and virtual-list demos reachable by keyboard
- Location: e2e/accessibility.spec.ts:191:1

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  locator('[data-foldkit-build]')
Expected: 0
Received: 1
Timeout:  5000ms

Call log:
  - Expect "toHaveCount" locator('[data-foldkit-build]') with timeout 5000ms
  - waiting for locator('[data-foldkit-build]')
    14 × locator resolved to 1 element
       - unexpected value "1"

```

# Page snapshot

```yaml
- generic [ref=e2]:
  - link "Skip to main content" [ref=e3] [cursor=pointer]:
    - /url: "#main-content"
  - banner [ref=e4]:
    - generic [ref=e5]:
      - generic [ref=e6]:
        - link "Foldkit Beta" [ref=e7] [cursor=pointer]:
          - /url: /
          - img "Foldkit" [ref=e8]
          - generic "Beta" [ref=e9]
        - navigation "Primary" [ref=e10]:
          - link "Docs" [ref=e11] [cursor=pointer]:
            - /url: /core/architecture
          - link "Blog" [ref=e12] [cursor=pointer]:
            - /url: /blog
      - generic [ref=e13]:
        - button "Search documentation" [ref=e14] [cursor=pointer]:
          - generic [aria-hidden] [ref=e17]: ⌘K
        - generic [ref=e19]:
          - link "GitHub" [ref=e20] [cursor=pointer]:
            - /url: https://github.com/foldkit/foldkit
          - link "Discord" [ref=e23] [cursor=pointer]:
            - /url: https://discord.gg/kav8VNxqGm
          - link "X" [ref=e26] [cursor=pointer]:
            - /url: https://x.com/devinjameson
          - link "npm" [ref=e29] [cursor=pointer]:
            - /url: https://www.npmjs.com/package/foldkit
        - 'button "Theme: System" [ref=e34] [cursor=pointer]'
  - generic:
    - textbox [aria-hidden]
  - generic [ref=e37]:
    - complementary "Documentation sidebar" [ref=e38]:
      - navigation "Documentation" [ref=e39]:
        - list [ref=e40]:
          - listitem [ref=e41]:
            - link "Get Started" [ref=e42] [cursor=pointer]:
              - /url: /get-started
          - listitem [ref=e43]:
            - button "Introduction" [ref=e45] [cursor=pointer]
          - listitem [ref=e51]:
            - button "Core" [ref=e53] [cursor=pointer]
          - listitem [ref=e59]:
            - button "Comparisons" [ref=e61] [cursor=pointer]
          - listitem [ref=e67]:
            - button "Patterns" [ref=e69] [cursor=pointer]
          - listitem [ref=e75]:
            - button "Tooling" [ref=e77] [cursor=pointer]
          - listitem [ref=e83]:
            - button "FAQ" [ref=e85] [cursor=pointer]
          - listitem [ref=e91]:
            - generic [ref=e92]:
              - button "Foldkit UI" [disabled] [expanded] [ref=e93]
              - generic [ref=e97]:
                - list [ref=e99]:
                  - listitem [ref=e100]:
                    - link "Overview" [ref=e101] [cursor=pointer]:
                      - /url: /ui/overview
                  - listitem [ref=e102]:
                    - link "Selection Blocks" [ref=e103] [cursor=pointer]:
                      - /url: /ui/selection-blocks
                - list [ref=e105]:
                  - listitem [ref=e106]:
                    - link "Anchor" [ref=e107] [cursor=pointer]:
                      - /url: /ui/anchor
                  - listitem [ref=e108]:
                    - link "Animation" [ref=e109] [cursor=pointer]:
                      - /url: /ui/animation
                  - listitem [ref=e110]:
                    - link "Button" [ref=e111] [cursor=pointer]:
                      - /url: /ui/button
                  - listitem [ref=e112]:
                    - link "Calendar" [ref=e113] [cursor=pointer]:
                      - /url: /ui/calendar
                  - listitem [ref=e114]:
                    - link "Checkbox" [ref=e115] [cursor=pointer]:
                      - /url: /ui/checkbox
                  - listitem [ref=e116]:
                    - link "Combobox" [ref=e117] [cursor=pointer]:
                      - /url: /ui/combobox
                  - listitem [ref=e118]:
                    - link "Date Picker" [ref=e119] [cursor=pointer]:
                      - /url: /ui/date-picker
                  - listitem [ref=e120]:
                    - link "Dialog" [ref=e121] [cursor=pointer]:
                      - /url: /ui/dialog
                  - listitem [ref=e122]:
                    - link "Disclosure" [ref=e123] [cursor=pointer]:
                      - /url: /ui/disclosure
                  - listitem [ref=e124]:
                    - link "Drag and Drop" [ref=e125] [cursor=pointer]:
                      - /url: /ui/drag-and-drop
                  - listitem [ref=e126]:
                    - link "Fieldset" [ref=e127] [cursor=pointer]:
                      - /url: /ui/fieldset
                  - listitem [ref=e128]:
                    - link "File Drop" [ref=e129] [cursor=pointer]:
                      - /url: /ui/file-drop
                  - listitem [ref=e130]:
                    - link "Hover Intent" [ref=e131] [cursor=pointer]:
                      - /url: /ui/hover-intent
                  - listitem [ref=e132]:
                    - link "Input" [ref=e133] [cursor=pointer]:
                      - /url: /ui/input
                  - listitem [ref=e134]:
                    - link "Listbox" [ref=e135] [cursor=pointer]:
                      - /url: /ui/listbox
                  - listitem [ref=e136]:
                    - link "Menu" [ref=e137] [cursor=pointer]:
                      - /url: /ui/menu
                  - listitem [ref=e138]:
                    - link "Meter" [ref=e139] [cursor=pointer]:
                      - /url: /ui/meter
                  - listitem [ref=e140]:
                    - link "Nav" [ref=e141] [cursor=pointer]:
                      - /url: /ui/nav
                  - listitem [ref=e142]:
                    - link "Popover" [ref=e143] [cursor=pointer]:
                      - /url: /ui/popover
                  - listitem [ref=e144]:
                    - link "Progress" [ref=e145] [cursor=pointer]:
                      - /url: /ui/progress
                  - listitem [ref=e146]:
                    - link "Radio Group" [ref=e147] [cursor=pointer]:
                      - /url: /ui/radio-group
                  - listitem [ref=e148]:
                    - link "Select" [ref=e149] [cursor=pointer]:
                      - /url: /ui/select
                  - listitem [ref=e150]:
                    - link "Slider" [ref=e151] [cursor=pointer]:
                      - /url: /ui/slider
                  - listitem [ref=e152]:
                    - link "Switch" [ref=e153] [cursor=pointer]:
                      - /url: /ui/switch
                  - listitem [ref=e154]:
                    - link "Tabs" [ref=e155] [cursor=pointer]:
                      - /url: /ui/tabs
                  - listitem [ref=e156]:
                    - link "Textarea" [ref=e157] [cursor=pointer]:
                      - /url: /ui/textarea
                  - listitem [ref=e158]:
                    - link "Toast" [ref=e159] [cursor=pointer]:
                      - /url: /ui/toast
                  - listitem [ref=e160]:
                    - link "Tooltip" [ref=e161] [cursor=pointer]:
                      - /url: /ui/tooltip
                  - listitem [ref=e162]:
                    - link "Virtual List" [ref=e163] [cursor=pointer]:
                      - /url: /ui/virtual-list
          - listitem [ref=e164]:
            - button "AI" [ref=e166] [cursor=pointer]
          - listitem [ref=e172]:
            - button "Testing" [ref=e174] [cursor=pointer]
          - listitem [ref=e180]:
            - button "Best Practices" [ref=e182] [cursor=pointer]
          - listitem [ref=e188]:
            - button "Examples" [ref=e190] [cursor=pointer]
          - listitem [ref=e196]:
            - button "API Reference" [ref=e198] [cursor=pointer]
    - main [ref=e204]:
      - generic [ref=e205]:
        - generic [ref=e206]:
          - heading "Combobox" [level=1] [ref=e207]
          - generic [ref=e208]:
            - heading "Overview" [level=2] [ref=e209]
            - link "Copy link to Overview" [ref=e210] [cursor=pointer]:
              - /url: "#overview"
          - paragraph [ref=e213]:
            - text: "A searchable select with input filtering, keyboard navigation, and anchor positioning. Unlike Listbox (which uses a button trigger), Combobox has a text input for searching. You control the filtering logic: read"
            - code [ref=e214]: model.inputValue
            - text: "and pass the filtered items array. The parent owns the selection: it passes the chosen value in as"
            - code [ref=e215]: maybeSelectedValue
            - text: (multi-select passes
            - code [ref=e216]: selectedValues
            - text: ) along with
            - code [ref=e217]: restingInputValue
            - text: (the text the input rests at when closed), and folds the
            - code [ref=e218]: Selected
            - text: and
            - code [ref=e219]: ClearedSelection
            - text: OutMessages into its own state (single-select stores the value, multi-select toggles the value in its array).
          - generic [ref=e220]:
            - heading "Create a Typed Combobox" [level=3] [ref=e221]
            - link "Copy link to Create a Typed Combobox" [ref=e222] [cursor=pointer]:
              - /url: "#create-a-typed-combobox"
          - paragraph [ref=e225]:
            - text: Embed Combobox via the
            - link [ref=e226] [cursor=pointer]:
              - /url: /ui/selection-blocks
              - code [ref=e227]: Combobox.makeBlock(Item)
              - text: factory
            - text: "at module scope:"
            - code [ref=e228]: const CityComboboxBlock = Combobox.makeBlock(City)
            - text: . Pass the same string Schema used by the parent Model. The factory returns a passive Block contract whose view inputs, Binding operations, Message and OutMessage retain that Schema's exact type, so
            - code [ref=e229]: Selected
            - text: carries a
            - code [ref=e230]: City
            - text: . Provide
            - code [ref=e231]: Combobox.layer
            - text: to the parent's construction Layer to acquire its implementation.
          - paragraph [ref=e232]:
            - text: What the factory returns is typed
            - link [ref=e233] [cursor=pointer]:
              - /url: /ui/selection-blocks#completed-type
              - code [ref=e234]: Combobox.Completed<Item>
              - text: from
              - code [ref=e235]: "@foldkit/ui"
            - text: . The multi-select namespace exports its own
            - code [ref=e236]: Combobox.Multi.Completed<Item>
            - text: type for cases where a created Block has to be named.
          - paragraph [ref=e237]:
            - text: Call
            - code [ref=e238]: ParentBlock.makeRequiredFieldBinding
            - text: with the Block contract, its parent Model
            - code [ref=e239]: field
            - text: and an exhaustive OutMessage policy. Use explicit accessors for custom storage. Include the resulting Binding in the parent Composition's
            - code [ref=e240]: bindings
            - text: list; its acquired connection contributes the Combobox's handlers and Mounts.
            - code [ref=e241]: binding.embedView
            - text: supplies the canonical view and Message wrapper at the render site. See
            - link "Connecting a static placement" [ref=e242] [cursor=pointer]:
              - /url: /core/block#embedding
            - text: for the complete authoring flow. Use
            - code [ref=e243]: Combobox.makeBlock(Schema.String)
            - text: for plain strings;
            - code [ref=e244]: Combobox.makeBlock(Item)
            - text: requires the Item Schema.
          - generic [ref=e245]:
            - heading "Programmatic API" [level=3] [ref=e246]
            - link "Copy link to Programmatic API" [ref=e247] [cursor=pointer]:
              - /url: "#programmatic-api"
          - paragraph [ref=e250]:
            - text: The declared contract gives its Binding
            - code [ref=e251]: requestOpen
            - text: ","
            - code [ref=e252]: requestClose
            - text: ", and"
            - code [ref=e253]: requestSelectItem
            - text: methods. Call
            - code [ref=e254]: CityComboboxBinding.requestOpen()
            - text: ","
            - code [ref=e255]: CityComboboxBinding.requestClose(restingInputValue)
            - text: ", or"
            - code [ref=e256]: CityComboboxBinding.requestSelectItem(item, displayText)
            - text: to get a connected parent Step for the owning Composition. These calls do not require public access to the child's update function. Multi-select
            - code [ref=e257]: requestClose()
            - text: takes no input, and its
            - code [ref=e258]: requestSelectItem(item)
            - text: uses the item itself as display text.
          - generic [ref=e259]:
            - paragraph [ref=e260]:
              - generic [ref=e263]: See it in an app
            - paragraph [ref=e265]:
              - text: Check out how Combobox is wired up in a
              - link "real Foldkit app" [ref=e266] [cursor=pointer]:
                - /url: https://github.com/foldkit/foldkit/blob/main/examples/ui-showcase/src/blocks/ui/view/combobox.ts
              - text: .
          - paragraph [ref=e267]:
            - text: The Binding’s
            - code [ref=e268]: requestOpen()
            - text: method is generated from
            - code [ref=e269]: RequestedOpen
            - text: in the Combobox InMessage contract. The InMessage handler applies the same opening transition as local input interaction. Closing and selection retain their existing defaulted and positional argument adapters in both Single and Multi.
          - generic [ref=e270]:
            - heading "Examples" [level=2] [ref=e271]
            - link "Copy link to Examples" [ref=e272] [cursor=pointer]:
              - /url: "#examples"
          - generic [ref=e275]:
            - heading "Single-Select" [level=3] [ref=e276]
            - link "Copy link to Single-Select" [ref=e277] [cursor=pointer]:
              - /url: "#single-select"
          - paragraph [ref=e280]:
            - text: Pass
            - code [ref=e281]: itemToValue
            - text: and
            - code [ref=e282]: itemToDisplayText
            - text: to control how items map to values and what text appears in the input on selection. Filter the
            - code [ref=e283]: items
            - text: array yourself based on
            - code [ref=e284]: model.inputValue
            - text: .
          - region "Single-Select" [ref=e285]:
            - generic [ref=e287]:
              - generic [ref=e288]: City
              - generic [ref=e291]:
                - combobox "City" [ref=e292]
                - button "Show suggestions" [ref=e293] [cursor=pointer]
          - figure "Combobox" [ref=e296]:
            - generic [ref=e297]:
              - generic [ref=e298]: Combobox
              - generic [ref=e299]:
                - status [ref=e300]
                - button "Copy Combobox to clipboard" [ref=e301] [cursor=pointer]
            - generic [ref=e304]:
              - code [ref=e311]:
                - generic [ref=e312]: "import { Array, Layer, Option, Schema } from 'effect'"
                - generic [ref=e313]: "import { Block } from 'foldkit'"
                - generic [ref=e314]: "import { childAttributes } from 'foldkit/html'"
                - generic [ref=e315]: "import { defineMessageUnion } from 'foldkit/message'"
                - generic [ref=e316]: "import { Combobox } from '@foldkit/ui'"
                - generic [ref=e317]: const City = Schema.Literals(['Johannesburg', 'Kyiv', 'Oxford', 'Wellington'])
                - generic [ref=e318]: type City = typeof City.Type
                - generic [ref=e319]: const CityCombobox = Combobox.makeBlock(City)
                - generic [ref=e320]: "const Model = Schema.Struct({"
                - generic [ref=e321]: "maybeCity: Schema.Option(City),"
                - generic [ref=e322]: "combobox: CityCombobox.Model,"
                - generic [ref=e323]: "})"
                - generic [ref=e324]: type Model = typeof Model.Type
                - generic [ref=e325]: "const Message = defineMessageUnion({})"
                - generic [ref=e326]: type Message = typeof Message.Type
                - generic [ref=e327]: export const CityPickerKey = Symbol('CityPicker')
                - generic [ref=e328]: "export const CityPickerBlock = Block.make('CityPicker', {"
                - generic [ref=e329]: "key: CityPickerKey,"
                - generic [ref=e330]: "InitArgs: Schema.Tuple([]),"
                - generic [ref=e331]: Model,
                - generic [ref=e332]: Message,
                - generic [ref=e333]: "})"
                - generic [ref=e334]: "const {"
                - generic [ref=e335]: makeFieldsStep,
                - generic [ref=e336]: makeNoopStep,
                - generic [ref=e337]: makeOutMessageFold,
                - generic [ref=e338]: makeRequiredFieldBinding,
                - generic [ref=e339]: makeComposition,
                - generic [ref=e340]: "} = CityPickerBlock"
                - generic [ref=e341]: // The parent stores the committed selection reported by the child.
                - generic [ref=e342]: "const ComboboxBinding = makeRequiredFieldBinding(CityCombobox, {"
                - generic [ref=e343]: "field: 'combobox',"
                - generic [ref=e344]: "init: { contextToArgs: () => [{ id: 'city' }] },"
                - generic [ref=e345]: "}).withOutMessagePolicy({"
                - generic [ref=e346]: "fold: makeOutMessageFold(CityCombobox, {"
                - generic [ref=e347]: "Selected: ({ value }) =>"
                - generic [ref=e348]: "makeFieldsStep(() => ({"
                - generic [ref=e349]: "maybeCity: () => Option.some(value),"
                - generic [ref=e350]: "})),"
                - generic [ref=e351]: "ClearedSelection: makeNoopStep,"
                - generic [ref=e352]: "}),"
                - generic [ref=e353]: "})"
                - generic [ref=e354]: // Including the Binding collects its lifecycle and handler graph.
                - generic [ref=e355]: "const CityPickerComposition = makeComposition({"
                - generic [ref=e356]: "bindings: [ComboboxBinding],"
                - generic [ref=e357]: "})"
                - generic [ref=e358]: "const init = CityPickerComposition.makeInit(() => ({"
                - generic [ref=e359]: "model: { maybeCity: Option.none() },"
                - generic [ref=e360]: "}))"
                - generic [ref=e361]: "const update = CityPickerComposition.makeUpdate({})"
                - generic [ref=e362]: "const cities: ReadonlyArray<City> = ["
                - generic [ref=e363]: "'Johannesburg',"
                - generic [ref=e364]: "'Kyiv',"
                - generic [ref=e365]: "'Oxford',"
                - generic [ref=e366]: "'Wellington',"
                - generic [ref=e367]: "]"
                - generic [ref=e368]: "const view = CityPickerComposition.makeView((model, h) => {"
                - generic [ref=e369]: const filteredCities =
                - generic [ref=e370]: model.combobox.inputValue === ''
                - generic [ref=e371]: "? cities"
                - generic [ref=e372]: ": Array.filter(cities, city =>"
                - generic [ref=e373]: city.toLowerCase().includes(model.combobox.inputValue.toLowerCase()),
                - generic [ref=e374]: )
                - generic [ref=e375]: const labelId = 'city-label'
                - generic [ref=e376]: return h.div(
                - generic [ref=e377]: "[h.Class('flex flex-col gap-1.5')],"
                - generic [ref=e378]: "["
                - generic [ref=e379]: h.label([h.Id(labelId), h.For(Combobox.inputId('city'))], ['City']),
                - generic [ref=e380]: h.block(
                - generic [ref=e381]: "ComboboxBinding.embedView({"
                - generic [ref=e382]: "slotId: 'city',"
                - generic [ref=e383]: "model: model.combobox,"
                - generic [ref=e384]: "viewInputs: {"
                - generic [ref=e385]: "ariaLabelledBy: labelId,"
                - generic [ref=e386]: "items: filteredCities,"
                - generic [ref=e387]: "maybeSelectedValue: model.maybeCity,"
                - generic [ref=e388]: "restingInputValue: Option.getOrElse(model.maybeCity, () => ''),"
                - generic [ref=e389]: "itemToValue: city => city,"
                - generic [ref=e390]: "itemToDisplayText: city => city,"
                - generic [ref=e391]: "itemToConfig: (city, { isSelected }) => ({"
                - generic [ref=e392]: "className: 'px-3 py-2 cursor-pointer data-[active]:bg-blue-100',"
                - generic [ref=e393]: "content: h.div("
                - generic [ref=e394]: "[h.Class('flex items-center gap-2')],"
                - generic [ref=e395]: "["
                - generic [ref=e396]: "isSelected ? h.span([], ['✓']) : h.span([h.Class('w-4')]),"
                - generic [ref=e397]: h.span([], [city]),
                - generic [ref=e398]: "],"
                - generic [ref=e399]: ),
                - generic [ref=e400]: "}),"
                - generic [ref=e401]: "inputAttributes: childAttributes(["
                - generic [ref=e402]: h.Class('w-full rounded-lg border px-3 py-2'),
                - generic [ref=e403]: h.Placeholder('Search cities...'),
                - generic [ref=e404]: "]),"
                - generic [ref=e405]: "itemsAttributes: childAttributes(["
                - generic [ref=e406]: h.Class('rounded-lg border shadow-lg'),
                - generic [ref=e407]: "]),"
                - generic [ref=e408]: "backdropAttributes: childAttributes([h.Class('fixed inset-0')]),"
                - generic [ref=e409]: "anchor: { placement: 'bottom-start', gap: 8, padding: 8 },"
                - generic [ref=e410]: "},"
                - generic [ref=e411]: "}),"
                - generic [ref=e412]: ),
                - generic [ref=e413]: "],"
                - generic [ref=e414]: )
                - generic [ref=e415]: "})"
                - generic [ref=e416]: "export const layer = CityPickerBlock.makeLayer({"
                - generic [ref=e417]: init,
                - generic [ref=e418]: update,
                - generic [ref=e419]: view,
                - generic [ref=e420]: "}).pipe(Layer.provide(Combobox.layer))"
              - button "Show code" [ref=e421] [cursor=pointer]
          - generic [ref=e422]:
            - heading "Nullable" [level=3] [ref=e423]
            - link "Copy link to Nullable" [ref=e424] [cursor=pointer]:
              - /url: "#nullable"
          - paragraph [ref=e427]:
            - text: Pass
            - code [ref=e428]: "nullable: true"
            - text: at init to allow clearing the selection by clicking the selected item again, or by emptying the input and closing. Both paths reach the parent as OutMessages (
            - code [ref=e429]: Selected
            - text: toggles,
            - code [ref=e430]: ClearedSelection
            - text: clears), so the parent decides what an empty selection looks like.
          - paragraph [ref=e431]:
            - code [ref=e432]: nullable
            - text: governs the single-select input only. A multi-select never emits
            - code [ref=e433]: ClearedSelection
            - text: ", because its input rests empty by design and so an empty input on close carries no intent to clear. Clearing a multi-select is toggling its values off, one"
            - code [ref=e434]: Selected
            - text: at a time.
          - region "Nullable" [ref=e435]:
            - generic [ref=e437]:
              - generic [ref=e438]: City
              - generic [ref=e441]:
                - combobox "City" [ref=e442]
                - button "Show suggestions" [ref=e443] [cursor=pointer]
          - generic [ref=e446]:
            - heading "Select on Focus" [level=3] [ref=e447]
            - link "Copy link to Select on Focus" [ref=e448] [cursor=pointer]:
              - /url: "#select-on-focus"
          - paragraph [ref=e451]:
            - text: Pass
            - code [ref=e452]: "selectInputOnFocus: true"
            - text: at init to highlight the input text when the combobox receives focus. Typing immediately replaces the current value, making it easy to start a new search.
          - region "Select on Focus" [ref=e453]:
            - generic [ref=e455]:
              - generic [ref=e456]: City
              - generic [ref=e459]:
                - combobox "City" [ref=e460]
                - button "Show suggestions" [ref=e461] [cursor=pointer]
          - generic [ref=e464]:
            - heading "Locked Placement" [level=3] [ref=e465]
            - link "Copy link to Locked Placement" [ref=e466] [cursor=pointer]:
              - /url: "#locked-placement"
          - paragraph [ref=e469]:
            - text: Set
            - code [ref=e470]: anchor.isPlacementLocked
            - text: to
            - code [ref=e471]: "true"
            - text: when a panel should keep the side chosen when it opens, even if its size changes. Focus the input, then type
            - code [ref=e472]: Zurich
            - text: . The tall list initially opens above the input. After filtering, the list is short enough to fit below, but it stays above until it closes.
          - paragraph [ref=e473]: To make the behavior reproducible at any scroll position, this demo keeps the panel inside a constrained container. In normal use, you can leave the portal enabled.
          - region "Locked Placement" [ref=e474]:
            - generic [ref=e477]:
              - generic [ref=e478]: City
              - generic [ref=e481]:
                - combobox "City" [ref=e482]
                - button "Show suggestions" [ref=e483] [cursor=pointer]
          - generic [ref=e486]:
            - heading "Multi-Select" [level=3] [ref=e487]
            - link "Copy link to Multi-Select" [ref=e488] [cursor=pointer]:
              - /url: "#multi-select"
          - paragraph [ref=e491]:
            - text: Use
            - code [ref=e492]: Combobox.Multi.makeBlock(Schema.String)
            - text: and
            - code [ref=e493]: Combobox.Multi.makeBlock
            - text: for multi-selection. The dropdown stays open on selection and items toggle on/off. The parent stores the selected values and folds each
            - code [ref=e494]: Selected
            - text: OutMessage by toggling the value in its array.
          - region "Multi-Select" [ref=e495]:
            - generic [ref=e497]:
              - generic [ref=e498]: Cities
              - generic [ref=e499]:
                - generic [ref=e500]: No selection
                - generic [ref=e503]:
                  - combobox "Cities" [ref=e504]
                  - button "Show suggestions" [ref=e505] [cursor=pointer]
          - figure "Multi-select combobox" [ref=e508]:
            - generic [ref=e509]:
              - generic [ref=e510]: Multi-select combobox
              - generic [ref=e511]:
                - status [ref=e512]
                - button "Copy Multi-select combobox to clipboard" [ref=e513] [cursor=pointer]
            - generic [ref=e516]:
              - code [ref=e523]:
                - generic [ref=e524]: "import { Array, Layer, Schema } from 'effect'"
                - generic [ref=e525]: "import { Block } from 'foldkit'"
                - generic [ref=e526]: "import { childAttributes } from 'foldkit/html'"
                - generic [ref=e527]: "import { defineMessageUnion } from 'foldkit/message'"
                - generic [ref=e528]: "import { Combobox } from '@foldkit/ui'"
                - generic [ref=e529]: const City = Schema.Literals(['Johannesburg', 'Kyiv', 'Oxford', 'Wellington'])
                - generic [ref=e530]: type City = typeof City.Type
                - generic [ref=e531]: const CitiesCombobox = Combobox.Multi.makeBlock(City)
                - generic [ref=e532]: "const Model = Schema.Struct({"
                - generic [ref=e533]: "selectedCities: Schema.Array(City),"
                - generic [ref=e534]: "comboboxMulti: CitiesCombobox.Model,"
                - generic [ref=e535]: "})"
                - generic [ref=e536]: type Model = typeof Model.Type
                - generic [ref=e537]: "const Message = defineMessageUnion({})"
                - generic [ref=e538]: type Message = typeof Message.Type
                - generic [ref=e539]: export const CitiesPickerKey = Symbol('CitiesPicker')
                - generic [ref=e540]: "export const CitiesPickerBlock = Block.make('CitiesPicker', {"
                - generic [ref=e541]: "key: CitiesPickerKey,"
                - generic [ref=e542]: "InitArgs: Schema.Tuple([]),"
                - generic [ref=e543]: Model,
                - generic [ref=e544]: Message,
                - generic [ref=e545]: "})"
                - generic [ref=e546]: "const {"
                - generic [ref=e547]: makeFieldsStep,
                - generic [ref=e548]: makeNoopStep,
                - generic [ref=e549]: makeOutMessageFold,
                - generic [ref=e550]: makeRequiredFieldBinding,
                - generic [ref=e551]: makeComposition,
                - generic [ref=e552]: "} = CitiesPickerBlock"
                - generic [ref=e553]: // The parent toggles the committed value in the selection it owns.
                - generic [ref=e554]: "const ComboboxMultiBinding = makeRequiredFieldBinding(CitiesCombobox, {"
                - generic [ref=e555]: "field: 'comboboxMulti',"
                - generic [ref=e556]: "init: { contextToArgs: () => [{ id: 'cities-multi' }] },"
                - generic [ref=e557]: "}).withOutMessagePolicy({"
                - generic [ref=e558]: "fold: makeOutMessageFold(CitiesCombobox, {"
                - generic [ref=e559]: "Selected: ({ value }) =>"
                - generic [ref=e560]: "makeFieldsStep(() => ({"
                - generic [ref=e561]: "selectedCities: selectedCities =>"
                - generic [ref=e562]: Array.contains(selectedCities, value)
                - generic [ref=e563]: "? Array.filter(selectedCities, city => city !== value)"
                - generic [ref=e564]: ": Array.append(selectedCities, value),"
                - generic [ref=e565]: "})),"
                - generic [ref=e566]: "ClearedSelection: makeNoopStep,"
                - generic [ref=e567]: "}),"
                - generic [ref=e568]: "})"
                - generic [ref=e569]: // Including the Binding collects its lifecycle and handler graph.
                - generic [ref=e570]: "const CitiesPickerComposition = makeComposition({"
                - generic [ref=e571]: "bindings: [ComboboxMultiBinding],"
                - generic [ref=e572]: "})"
                - generic [ref=e573]: "const init = CitiesPickerComposition.makeInit(() => ({"
                - generic [ref=e574]: "model: {"
                - generic [ref=e575]: "selectedCities: [],"
                - generic [ref=e576]: "},"
                - generic [ref=e577]: "}))"
                - generic [ref=e578]: "const update = CitiesPickerComposition.makeUpdate({})"
                - generic [ref=e579]: "const cities: ReadonlyArray<City> = ["
                - generic [ref=e580]: "'Johannesburg',"
                - generic [ref=e581]: "'Kyiv',"
                - generic [ref=e582]: "'Oxford',"
                - generic [ref=e583]: "'Wellington',"
                - generic [ref=e584]: "]"
                - generic [ref=e585]: "const view = CitiesPickerComposition.makeView((model, h) => {"
                - generic [ref=e586]: const filteredCities =
                - generic [ref=e587]: model.comboboxMulti.inputValue === ''
                - generic [ref=e588]: "? cities"
                - generic [ref=e589]: ": Array.filter(cities, city =>"
                - generic [ref=e590]: city
                - generic [ref=e591]: .toLowerCase()
                - generic [ref=e592]: .includes(model.comboboxMulti.inputValue.toLowerCase()),
                - generic [ref=e593]: )
                - generic [ref=e594]: const labelId = 'cities-multi-label'
                - generic [ref=e595]: return h.div(
                - generic [ref=e596]: "[h.Class('flex flex-col gap-1.5')],"
                - generic [ref=e597]: "["
                - generic [ref=e598]: h.label(
                - generic [ref=e599]: "[h.Id(labelId), h.For(Combobox.inputId('cities-multi'))],"
                - generic [ref=e600]: "['Cities'],"
                - generic [ref=e601]: ),
                - generic [ref=e602]: h.block(
                - generic [ref=e603]: "ComboboxMultiBinding.embedView({"
                - generic [ref=e604]: "slotId: 'cities-multi',"
                - generic [ref=e605]: "model: model.comboboxMulti,"
                - generic [ref=e606]: "viewInputs: {"
                - generic [ref=e607]: "ariaLabelledBy: labelId,"
                - generic [ref=e608]: "items: filteredCities,"
                - generic [ref=e609]: "selectedValues: model.selectedCities,"
                - generic [ref=e610]: "restingInputValue: '',"
                - generic [ref=e611]: "itemToValue: city => city,"
                - generic [ref=e612]: "itemToDisplayText: city => city,"
                - generic [ref=e613]: "itemToConfig: (city, { isSelected }) => ({"
                - generic [ref=e614]: "className: 'px-3 py-2 cursor-pointer data-[active]:bg-blue-100',"
                - generic [ref=e615]: "content: h.div("
                - generic [ref=e616]: "[h.Class('flex items-center gap-2')],"
                - generic [ref=e617]: "["
                - generic [ref=e618]: "isSelected ? h.span([], ['✓']) : h.span([h.Class('w-4')]),"
                - generic [ref=e619]: h.span([], [city]),
                - generic [ref=e620]: "],"
                - generic [ref=e621]: ),
                - generic [ref=e622]: "}),"
                - generic [ref=e623]: "inputAttributes: childAttributes(["
                - generic [ref=e624]: h.Class('w-full rounded-lg border px-3 py-2'),
                - generic [ref=e625]: h.Placeholder('Search cities...'),
                - generic [ref=e626]: "]),"
                - generic [ref=e627]: "itemsAttributes: childAttributes(["
                - generic [ref=e628]: h.Class('rounded-lg border shadow-lg'),
                - generic [ref=e629]: "]),"
                - generic [ref=e630]: "backdropAttributes: childAttributes([h.Class('fixed inset-0')]),"
                - generic [ref=e631]: "anchor: { placement: 'bottom-start', gap: 8, padding: 8 },"
                - generic [ref=e632]: "},"
                - generic [ref=e633]: "}),"
                - generic [ref=e634]: ),
                - generic [ref=e635]: "],"
                - generic [ref=e636]: )
                - generic [ref=e637]: "})"
                - generic [ref=e638]: "export const layer = CitiesPickerBlock.makeLayer({"
                - generic [ref=e639]: init,
                - generic [ref=e640]: update,
                - generic [ref=e641]: view,
                - generic [ref=e642]: "}).pipe(Layer.provide(Combobox.Multi.layer))"
              - button "Show code" [ref=e643] [cursor=pointer]
          - generic [ref=e644]:
            - heading "Read-Only" [level=2] [ref=e645]
            - link "Copy link to Read-Only" [ref=e646] [cursor=pointer]:
              - /url: "#read-only"
          - generic [ref=e649]:
            - heading "Browsing Without Committing" [level=3] [ref=e650]
            - link "Copy link to Browsing Without Committing" [ref=e651] [cursor=pointer]:
              - /url: "#browsing-without-committing"
          - paragraph [ref=e654]:
            - code [ref=e655]: isReadOnly
            - text: keeps the Combobox browsable but not committable. It still opens from
            - code [ref=e656]: Arrow Down
            - text: ","
            - code [ref=e657]: Arrow Up
            - text: ", the toggle button, and"
            - code [ref=e658]: openOnFocus
            - text: ", still navigates with"
            - code [ref=e659]: Arrow Down
            - text: ","
            - code [ref=e660]: Arrow Up
            - text: ","
            - code [ref=e661]: Home
            - text: ", and"
            - code [ref=e662]: End
            - text: ", still tracks the active item through"
            - code [ref=e663]: aria-activedescendant
            - text: and pointer hover, and still closes on
            - code [ref=e664]: Escape
            - text: ", blur, and a backdrop click. The input still takes focus, and its text can still be selected and copied."
          - generic [ref=e665]:
            - heading "Commit Paths Are Inert" [level=4] [ref=e666]
            - link "Copy link to Commit Paths Are Inert" [ref=e667] [cursor=pointer]:
              - /url: "#commit-paths-are-inert"
          - paragraph [ref=e670]:
            - text: What a read-only Combobox never does is commit. Its input carries the native
            - code [ref=e671]: readonly
            - text: attribute and no
            - code [ref=e672]: OnInput
            - text: handler, so typing cannot change the value. Items carry no click handler.
            - code [ref=e673]: Enter
            - text: on the active item reports a
            - code [ref=e674]: SuppressedItemCommit
            - text: Message that leaves the Model unchanged. An
            - code [ref=e675]: immediate
            - text: Combobox stops committing as the arrow keys move. No
            - code [ref=e676]: Selected
            - text: OutMessage reaches the parent through any of them.
          - generic [ref=e677]:
            - heading "Closing Preserves the Selection" [level=4] [ref=e678]
            - link "Copy link to Closing Preserves the Selection" [ref=e679] [cursor=pointer]:
              - /url: "#closing-preserves-the-selection"
          - paragraph [ref=e682]:
            - text: Closing does not change the selection either. A nullable Combobox normally reads an empty input on close as the user clearing it and emits
            - code [ref=e683]: ClearedSelection
            - text: ; a read-only one never does, so a user who opens and closes it, by
            - code [ref=e684]: Escape
            - text: ", blur, the toggle button, or a backdrop click, leaves the parent's selection exactly as it was. This matters most for multi-select, whose input rests empty by design, and for a single-select whose input was never seeded. The programmatic"
            - code [ref=e685]: requestClose
            - text: operation is unaffected and clears as before.
          - generic [ref=e686]:
            - heading "Typing and Opening" [level=3] [ref=e687]
            - link "Copy link to Typing and Opening" [ref=e688] [cursor=pointer]:
              - /url: "#typing-and-opening"
          - paragraph [ref=e691]:
            - text: Typing is frozen rather than left to filter, because
            - code [ref=e692]: model.inputValue
            - text: is one field serving two purposes. It is the filter query you read to narrow
            - code [ref=e693]: items
            - text: ", and it is the display of the current selection, restored to"
            - code [ref=e694]: restingInputValue
            - text: on close and on blur. Letting a read-only Combobox be typed into would give the user a widget whose visible value they can change and which only snaps back on blur.
          - paragraph [ref=e695]:
            - text: Freezing typing removes an open path along with it. An interactive Combobox opens on the first keystroke, since
            - code [ref=e696]: UpdatedInputValue
            - text: opens a closed one, which makes clicking into the input feel like it opens the dropdown. A read-only Combobox has no
            - code [ref=e697]: OnInput
            - text: handler, so that path is gone and the toggle button and the arrow keys are what remain. Pass
            - code [ref=e698]: openOnFocus
            - text: when focusing the input should open it; it is unaffected by
            - code [ref=e699]: isReadOnly
            - text: .
          - generic [ref=e700]:
            - heading "Programmatic Changes" [level=3] [ref=e701]
            - link "Copy link to Programmatic Changes" [ref=e702] [cursor=pointer]:
              - /url: "#programmatic-changes"
          - paragraph [ref=e705]:
            - code [ref=e706]: isReadOnly
            - text: describes what the user may do, not what the program may do.
            - code [ref=e707]: requestSelectItem
            - text: and a directly dispatched
            - code [ref=e708]: SelectedItem
            - text: Message still select, because the parent owns the selection.
          - generic [ref=e709]:
            - heading "Displaying an Existing Selection" [level=3] [ref=e710]
            - link "Copy link to Displaying an Existing Selection" [ref=e711] [cursor=pointer]:
              - /url: "#displaying-an-existing-selection"
          - paragraph [ref=e714]:
            - text: A read-only single-select Combobox whose parent holds a preloaded selection renders an empty input until an open and close cycle happens, since
            - code [ref=e715]: model.inputValue
            - text: starts empty and only becomes the selection's display text through a selection or a close. Read-only removes the user's usual recovery path, since they cannot type to surface it. After initializing the child and assembling its parent Model, apply the Binding's
            - code [ref=e716]: requestSelectItem
            - text: Step with the preloaded selection. This sets
            - code [ref=e717]: inputValue
            - text: to the display text. A feature can expose the startup transition as a Message-producing
            - code [ref=e718]: boot
            - text: operation when it is useful to its parent; see
            - link "startup Steps" [ref=e719] [cursor=pointer]:
              - /url: /core/init-and-flags#startup-steps
            - text: .
          - paragraph [ref=e720]:
            - text: Seeding interacts with filtering. You derive
            - code [ref=e721]: items
            - text: from
            - code [ref=e722]: model.inputValue
            - text: ", so a read-only Combobox seeded with its selection opens showing only the items matching that text, often just the one. Filter on a separate field, or skip filtering while read-only, when the full list should stay visible."
          - generic [ref=e723]:
            - heading "Multi-Select Display" [level=3] [ref=e724]
            - link "Copy link to Multi-Select Display" [ref=e725] [cursor=pointer]:
              - /url: "#multi-select-display"
          - paragraph [ref=e728]:
            - text: Multi-select needs neither, and needs something else instead. Its
            - code [ref=e729]: restingInputValue
            - text: is an empty string by design, so the input never displays the selection and there is nothing to seed. That leaves the open panel, where
            - code [ref=e730]: aria-selected
            - text: and the
            - code [ref=e731]: isSelected
            - text: context mark the chosen items, as the only place the component shows what is selected. Render the selection yourself from the
            - code [ref=e732]: selectedValues
            - text: you already own, as a tag or chip list beside the Combobox, so a read-only multi-select reads as something other than an empty frozen input.
          - generic [ref=e733]:
            - heading "Read-Only and Disabled States" [level=3] [ref=e734]
            - link "Copy link to Read-Only and Disabled States" [ref=e735] [cursor=pointer]:
              - /url: "#read-only-and-disabled-states"
          - generic [ref=e738]:
            - heading "ARIA Semantics" [level=4] [ref=e739]
            - link "Copy link to ARIA Semantics" [ref=e740] [cursor=pointer]:
              - /url: "#aria-semantics"
          - paragraph [ref=e743]:
            - code [ref=e744]: isReadOnly
            - text: and
            - code [ref=e745]: isDisabled
            - text: both stop the Combobox from committing, and setting both emits both attribute sets. They differ in the semantics exposed to assistive technology, so they are not interchangeable.
            - code [ref=e746]: aria-disabled="true"
            - text: ", which"
            - code [ref=e747]: isDisabled
            - text: emits on the input and the toggle button, communicates that the Combobox is unavailable, and it removes their handlers so the dropdown cannot be opened at all.
            - code [ref=e748]: aria-readonly="true"
            - text: ", which"
            - code [ref=e749]: isReadOnly
            - text: emits on the input carrying
            - code [ref=e750]: role="combobox"
            - text: and on the items panel carrying
            - code [ref=e751]: role="listbox"
            - text: ", communicates that the value cannot be changed but remains relevant to the user."
          - generic [ref=e752]:
            - heading "Choosing a State" [level=4] [ref=e753]
            - link "Copy link to Choosing a State" [ref=e754] [cursor=pointer]:
              - /url: "#choosing-a-state"
          - paragraph [ref=e757]:
            - text: Assistive technology support for
            - code [ref=e758]: aria-readonly
            - text: on comboboxes varies. Pair it with a visible read-only treatment or explanatory text when users must distinguish it from disabled, and test the browser and assistive technology combinations your app supports.
          - paragraph [ref=e759]:
            - text: Use
            - code [ref=e760]: isReadOnly
            - text: when the selection is still information the user needs, such as a city chosen earlier in a flow, and
            - code [ref=e761]: isDisabled
            - text: when the Combobox is unavailable.
          - generic [ref=e762]:
            - heading "Styling" [level=2] [ref=e763]
            - link "Copy link to Styling" [ref=e764] [cursor=pointer]:
              - /url: "#styling"
          - paragraph [ref=e767]:
            - text: Combobox is headless. The
            - code [ref=e768]: itemToConfig
            - text: callback controls all item markup. Style the input, button, items container, and backdrop through their respective attribute props.
          - paragraph [ref=e769]:
            - text: "The items panel is portaled to the document body and positioned relative to the input wrapper with Floating UI. Ancestor stacking contexts and overflow clipping no longer apply, so a clipped container or a sibling overlay wrapper cannot hide the open panel. The panel still stacks at the document level: give it a z-index above elevated content like sticky headers or toasts, as the demos on this page do with"
            - code [ref=e770]: z-10
            - text: . Inside a
            - code [ref=e771]: <dialog>
            - text: ", the panel is portaled into that dialog, so it renders above the dialog's content and stays interactive. Keep the outer Combobox wrapper positioned, for example with"
            - code [ref=e772]: "className: 'relative'"
            - text: ", so the input paints above the click-outside backdrop. Pass"
            - code [ref=e773]: "anchor: { portal: false }"
            - text: to keep the panel inside the wrapper.
          - 'region "Table: Attribute, Condition" [ref=e774]':
            - table [ref=e775]:
              - rowgroup [ref=e776]:
                - row [ref=e777]:
                  - columnheader "Attribute" [ref=e778]
                  - columnheader "Condition" [ref=e779]
              - rowgroup [ref=e780]:
                - row [ref=e781]:
                  - cell [ref=e782]:
                    - code [ref=e783]: data-active
                  - cell "Present on the item currently highlighted by keyboard or pointer." [ref=e784]
                - row [ref=e785]:
                  - cell [ref=e786]:
                    - code [ref=e787]: data-selected
                  - cell "Present on the selected item(s)." [ref=e788]
                - row [ref=e789]:
                  - cell [ref=e790]:
                    - code [ref=e791]: data-disabled
                  - cell "Present on disabled items, and on the wrapper, the input, and the toggle button when the combobox is disabled." [ref=e792]
                - row [ref=e793]:
                  - cell [ref=e794]:
                    - code [ref=e795]: data-readonly
                  - cell "Present on the wrapper, the input, the toggle button, the items panel, and every item when isReadOnly is true." [ref=e796]
                - row [ref=e797]:
                  - cell [ref=e798]:
                    - code [ref=e799]: data-closed
                  - cell "Present during close animation when isAnimated is true." [ref=e800]
                - row [ref=e801]:
                  - cell [ref=e802]:
                    - code [ref=e803]: data-placement
                  - 'cell "Present on the items panel, set to the side it currently sits on: top, right, bottom, or left. Fixed to the first resolved side when isPlacementLocked is true." [ref=e804]'
          - generic [ref=e805]:
            - heading "Keyboard Interaction" [level=2] [ref=e806]
            - link "Copy link to Keyboard Interaction" [ref=e807] [cursor=pointer]:
              - /url: "#keyboard-interaction"
          - paragraph [ref=e810]:
            - text: Focus stays on the input while arrow keys navigate items via
            - code [ref=e811]: aria-activedescendant
            - text: .
          - 'region "Table: Key, Description" [ref=e812]':
            - table [ref=e813]:
              - rowgroup [ref=e814]:
                - row [ref=e815]:
                  - columnheader "Key" [ref=e816]
                  - columnheader "Description" [ref=e817]
              - rowgroup [ref=e818]:
                - row [ref=e819]:
                  - cell [ref=e820]:
                    - code [ref=e821]: Arrow Down
                  - cell "Opens the dropdown or moves to the next item." [ref=e822]
                - row [ref=e823]:
                  - cell [ref=e824]:
                    - code [ref=e825]: Arrow Up
                  - cell "Moves to the previous item." [ref=e826]
                - row [ref=e827]:
                  - cell [ref=e828]:
                    - code [ref=e829]: Enter
                  - cell "Selects the active item. Inert when isReadOnly is set." [ref=e830]
                - row [ref=e831]:
                  - cell [ref=e832]:
                    - code [ref=e833]: Home
                  - cell "Moves to the first enabled item." [ref=e834]
                - row [ref=e835]:
                  - cell [ref=e836]:
                    - code [ref=e837]: End
                  - cell "Moves to the last enabled item." [ref=e838]
                - row [ref=e839]:
                  - cell [ref=e840]:
                    - code [ref=e841]: Escape
                  - cell "Closes the dropdown." [ref=e842]
                - row [ref=e843]:
                  - cell [ref=e844]:
                    - code [ref=e845]: Type a character
                  - cell "Filters the items list. You control filtering in your view by passing filtered items. Frozen when isReadOnly is set." [ref=e846]
          - paragraph [ref=e847]: While an input method is composing, these keys stay with the composition. Enter confirms the conversion instead of selecting the active item.
          - paragraph [ref=e848]:
            - text: Opening, closing, and arrow,
            - code [ref=e849]: Home
            - text: ", and"
            - code [ref=e850]: End
            - text: navigation are unaffected by
            - code [ref=e851]: isReadOnly
            - text: . See
            - link "Read-Only" [ref=e852] [cursor=pointer]:
              - /url: "#read-only"
            - text: .
          - generic [ref=e853]:
            - heading "Empty Results" [level=3] [ref=e854]
            - link "Copy link to Empty Results" [ref=e855] [cursor=pointer]:
              - /url: "#empty-results"
          - paragraph [ref=e858]: When filtering leaves no items, the listbox disappears and navigation keys have no item to activate. The input stays focused. A modal Combobox keeps its backdrop available, so Escape and a backdrop click still close it and release the page. Render a visible and announced "No results" status in your view if users need feedback about the empty search.
          - generic [ref=e859]:
            - heading "Accessibility" [level=2] [ref=e860]
            - link "Copy link to Accessibility" [ref=e861] [cursor=pointer]:
              - /url: "#accessibility"
          - generic [ref=e864]:
            - heading "Combobox Semantics" [level=3] [ref=e865]
            - link "Copy link to Combobox Semantics" [ref=e866] [cursor=pointer]:
              - /url: "#combobox-semantics"
          - paragraph [ref=e869]:
            - text: The input receives
            - code [ref=e870]: role="combobox"
            - text: with
            - code [ref=e871]: aria-expanded
            - text: and
            - code [ref=e872]: aria-activedescendant
            - text: . The items container receives
            - code [ref=e873]: role="listbox"
            - text: and each item receives
            - code [ref=e874]: role="option"
            - text: with
            - code [ref=e875]: aria-selected
            - text: . The input also receives the native
            - code [ref=e876]: readonly
            - text: attribute and
            - code [ref=e877]: aria-readonly="true"
            - text: ", and the items container receives"
            - code [ref=e878]: aria-readonly="true"
            - text: ", when"
            - code [ref=e879]: isReadOnly
            - text: is set. The ARIA attribute is emitted on the input in addition to the native one because the explicit
            - code [ref=e880]: role="combobox"
            - text: overrides the element's native semantics, so the native attribute alone is not exposed to assistive technology. See
            - link "Read-Only" [ref=e881] [cursor=pointer]:
              - /url: "#read-only"
            - text: .
          - paragraph [ref=e882]:
            - text: When the filtered listbox disappears, the input reports
            - code [ref=e883]: aria-expanded="false"
            - text: and drops
            - code [ref=e884]: aria-controls
            - text: and
            - code [ref=e885]: aria-activedescendant
            - text: rather than pointing at missing elements.
          - generic [ref=e886]:
            - heading "Naming the Input" [level=3] [ref=e887]
            - link "Copy link to Naming the Input" [ref=e888] [cursor=pointer]:
              - /url: "#naming-the-input"
          - paragraph [ref=e891]:
            - text: The input is a form field, so give it an accessible name. For a visible label, wire a native
            - code [ref=e892]: <label for>
            - text: that targets the input id with
            - code [ref=e893]: Combobox.inputId(id)
            - text: from
            - code [ref=e894]: "@foldkit/ui"
            - text: rather than hardcoding the
            - code [ref=e895]: "-input"
            - text: convention. The
            - code [ref=e896]: for
            - text: "association makes the input properly labeled: assistive technology announces it by the visible label text, and clicking the label focuses the input. That is why it is the recommended pattern."
          - paragraph [ref=e897]:
            - text: Two view input fields cover the cases a
            - code [ref=e898]: <label for>
            - text: does not. Pass
            - code [ref=e899]: ariaLabel
            - text: when there is no visible label, or
            - code [ref=e900]: ariaLabelledBy
            - text: when the element that names the input is not a
            - code [ref=e901]: <label>
            - text: you can point
            - code [ref=e902]: for
            - text: at.
          - generic [ref=e903]:
            - heading "API Reference" [level=2] [ref=e904]
            - link "Copy link to API Reference" [ref=e905] [cursor=pointer]:
              - /url: "#api-reference"
          - generic [ref=e908]:
            - heading "InitConfig" [level=3] [ref=e909]
            - link "Copy link to InitConfig" [ref=e910] [cursor=pointer]:
              - /url: "#init-config"
          - paragraph [ref=e913]:
            - text: Configuration passed to the Binding for the public contract returned by
            - code [ref=e914]: Combobox.makeBlock(Item)
            - text: or
            - code [ref=e915]: Combobox.Multi.makeBlock(Item)
            - text: .
          - paragraph [ref=e916]:
            - text: The Binding’s
            - code [ref=e917]: init
            - text: "accepts the same configuration in its child argument tuple:"
            - code [ref=e918]: "ComboboxBinding.init({ args: [config], toParentModel })"
            - text: . It returns a passive initialization recipe with no
            - code [ref=e919]: .model
            - text: or
            - code [ref=e920]: .commands
            - text: fields. Return that recipe from the registered Composition’s
            - code [ref=e921]: makeInit
            - text: callback or
            - code [ref=e922]: makeUpdate
            - text: handler, or preserve it through a Block-owned Step; checked execution constructs the parent Model and retains the child Commands.
          - 'region "Table: Name, Type, Default, Description" [ref=e923]':
            - table [ref=e924]:
              - rowgroup [ref=e925]:
                - row [ref=e926]:
                  - columnheader "Name" [ref=e927]
                  - columnheader "Type" [ref=e928]
                  - columnheader "Default" [ref=e929]
                  - columnheader "Description" [ref=e930]
              - rowgroup [ref=e931]:
                - row [ref=e932]:
                  - cell [ref=e933]:
                    - code [ref=e934]: id
                  - cell [ref=e935]:
                    - code [ref=e936]: string
                  - cell "—" [ref=e937]
                  - cell "Unique ID for the combobox instance." [ref=e938]
                - row [ref=e939]:
                  - cell [ref=e940]:
                    - code [ref=e941]: isAnimated
                  - cell [ref=e942]:
                    - code [ref=e943]: boolean
                  - cell [ref=e944]:
                    - code [ref=e945]: "false"
                  - cell "Enables animation coordination." [ref=e946]
                - row [ref=e947]:
                  - cell [ref=e948]:
                    - code [ref=e949]: isModal
                  - cell [ref=e950]:
                    - code [ref=e951]: boolean
                  - cell [ref=e952]:
                    - code [ref=e953]: "false"
                  - cell "Locks page scroll and marks other elements inert when open." [ref=e954]
                - row [ref=e955]:
                  - cell [ref=e956]:
                    - code [ref=e957]: nullable
                  - cell [ref=e958]:
                    - code [ref=e959]: boolean
                  - cell [ref=e960]:
                    - code [ref=e961]: "false"
                  - cell "Allows clearing the selection by clicking the selected item again, or by emptying the single-select input and closing (which emits ClearedSelection). Multi-select never emits ClearedSelection." [ref=e962]
                - row [ref=e963]:
                  - cell [ref=e964]:
                    - code [ref=e965]: immediate
                  - cell [ref=e966]:
                    - code [ref=e967]: boolean
                  - cell [ref=e968]:
                    - code [ref=e969]: "false"
                  - 'cell "Emits Selected on every keyboard activation while open, so arrow keys commit as they move instead of waiting for Enter. Combining immediate with nullable is discouraged: a nullable toggle fold would deselect as the arrows pass back over the selected item." [ref=e970]'
                - row [ref=e971]:
                  - cell [ref=e972]:
                    - code [ref=e973]: selectInputOnFocus
                  - cell [ref=e974]:
                    - code [ref=e975]: boolean
                  - cell [ref=e976]:
                    - code [ref=e977]: "false"
                  - cell "Highlights the input text when the combobox receives focus, so typing replaces the current value." [ref=e978]
          - generic [ref=e979]:
            - heading "ViewInputs" [level=3] [ref=e980]
            - link "Copy link to ViewInputs" [ref=e981] [cursor=pointer]:
              - /url: "#view-config"
          - paragraph [ref=e984]:
            - text: Pass the child Model as
            - code [ref=e985]: model
            - text: and these fields as
            - code [ref=e986]: viewInputs
            - text: to the composed Binding's
            - code [ref=e987]: embedView
            - text: method. The Binding supplies the canonical view, Message wrapper, and composition scope. Keep callback fields at the top level, and use
            - code [ref=e988]: childAttributes
            - text: for handler-bearing attribute inputs; see
            - link "Callback dispatch boundaries" [ref=e989] [cursor=pointer]:
              - /url: /core/block#callback-dispatch-boundaries
            - text: .
          - 'region "Table: Name, Type, Default, Description" [ref=e990]':
            - table [ref=e991]:
              - rowgroup [ref=e992]:
                - row [ref=e993]:
                  - columnheader "Name" [ref=e994]
                  - columnheader "Type" [ref=e995]
                  - columnheader "Default" [ref=e996]
                  - columnheader "Description" [ref=e997]
              - rowgroup [ref=e998]:
                - row [ref=e999]:
                  - cell [ref=e1000]:
                    - code [ref=e1001]: items
                  - cell [ref=e1002]:
                    - code [ref=e1003]: ReadonlyArray<Item>
                  - cell "—" [ref=e1004]
                  - cell "The filtered list of items to display. You control the filtering logic based on model.inputValue." [ref=e1005]
                - row [ref=e1006]:
                  - cell [ref=e1007]:
                    - code [ref=e1008]: maybeSelectedValue
                  - cell [ref=e1009]:
                    - code [ref=e1010]: Option<Item>
                  - cell "—" [ref=e1011]
                  - cell [ref=e1012]:
                    - text: "The selection the parent owns. None when nothing is selected yet. Multi-select takes selectedValues:"
                    - code [ref=e1013]: ReadonlyArray<Item>
                    - text: instead. Drives the isSelected context and aria-selected.
                - row [ref=e1014]:
                  - cell [ref=e1015]:
                    - code [ref=e1016]: restingInputValue
                  - cell [ref=e1017]:
                    - code [ref=e1018]: string
                  - cell "—" [ref=e1019]
                  - 'cell "The text the input returns to when the combobox closes: the selected display text for single-select, an empty string for multi-select." [ref=e1020]'
                - row [ref=e1021]:
                  - cell [ref=e1022]:
                    - code [ref=e1023]: itemToConfig
                  - cell [ref=e1024]:
                    - code [ref=e1025]: (item, context) => ItemConfig
                  - cell "—" [ref=e1026]
                  - cell "Maps each item to its className and content. The context provides isActive, isSelected, isDisabled, and isReadOnly." [ref=e1027]
                - row [ref=e1028]:
                  - cell [ref=e1029]:
                    - code [ref=e1030]: itemToValue
                  - cell [ref=e1031]:
                    - code [ref=e1032]: "(item: Item, index: number) => Item"
                  - cell "—" [ref=e1033]
                  - cell "Extracts the value from an item." [ref=e1034]
                - row [ref=e1035]:
                  - cell [ref=e1036]:
                    - code [ref=e1037]: itemToDisplayText
                  - cell [ref=e1038]:
                    - code [ref=e1039]: "(item: Item, index: number) => string"
                  - cell "—" [ref=e1040]
                  - cell "Text shown in the input when an item is selected." [ref=e1041]
                - row [ref=e1042]:
                  - cell [ref=e1043]:
                    - code [ref=e1044]: isItemDisabled
                  - cell [ref=e1045]:
                    - code [ref=e1046]: "(item: Item, index: number) => boolean"
                  - cell "—" [ref=e1047]
                  - cell "Disables individual items." [ref=e1048]
                - row [ref=e1049]:
                  - cell [ref=e1050]:
                    - code [ref=e1051]: inputClassName / inputAttributes
                  - cell [ref=e1052]:
                    - code [ref=e1053]: string / ReadonlyArray<ChildAttribute>
                  - cell "—" [ref=e1054]
                  - cell "Class name and additional attributes for the text input." [ref=e1055]
                - row [ref=e1056]:
                  - cell [ref=e1057]:
                    - code [ref=e1058]: inputPlaceholder
                  - cell [ref=e1059]:
                    - code [ref=e1060]: string
                  - cell "—" [ref=e1061]
                  - cell "Placeholder text for the input." [ref=e1062]
                - row [ref=e1063]:
                  - cell [ref=e1064]:
                    - code [ref=e1065]: inputWrapperClassName / inputWrapperAttributes
                  - cell [ref=e1066]:
                    - code [ref=e1067]: string / ReadonlyArray<ChildAttribute>
                  - cell "—" [ref=e1068]
                  - cell "Class name and additional attributes for the input wrapper." [ref=e1069]
                - row [ref=e1070]:
                  - cell [ref=e1071]:
                    - code [ref=e1072]: itemsClassName / itemsAttributes
                  - cell [ref=e1073]:
                    - code [ref=e1074]: string / ReadonlyArray<ChildAttribute>
                  - cell "—" [ref=e1075]
                  - cell "Class name and additional attributes for the dropdown items panel." [ref=e1076]
                - row [ref=e1077]:
                  - cell [ref=e1078]:
                    - code [ref=e1079]: itemsScrollClassName / itemsScrollAttributes
                  - cell [ref=e1080]:
                    - code [ref=e1081]: string / ReadonlyArray<ChildAttribute>
                  - cell "—" [ref=e1082]
                  - cell "Class name and additional attributes for the inner scrollable item wrapper." [ref=e1083]
                - row [ref=e1084]:
                  - cell [ref=e1085]:
                    - code [ref=e1086]: backdropClassName / backdropAttributes
                  - cell [ref=e1087]:
                    - code [ref=e1088]: string / ReadonlyArray<ChildAttribute>
                  - cell "—" [ref=e1089]
                  - cell "Class name and additional attributes for the backdrop overlay." [ref=e1090]
                - row [ref=e1091]:
                  - cell [ref=e1092]:
                    - code [ref=e1093]: buttonContent
                  - cell [ref=e1094]:
                    - code [ref=e1095]: Html
                  - cell "—" [ref=e1096]
                  - cell "Content for the dropdown toggle button, typically a chevron icon." [ref=e1097]
                - row [ref=e1098]:
                  - cell [ref=e1099]:
                    - code [ref=e1100]: buttonClassName / buttonAttributes
                  - cell [ref=e1101]:
                    - code [ref=e1102]: string / ReadonlyArray<ChildAttribute>
                  - cell "—" [ref=e1103]
                  - cell "Class name and additional attributes for the toggle button." [ref=e1104]
                - row [ref=e1105]:
                  - cell [ref=e1106]:
                    - code [ref=e1107]: className / attributes
                  - cell [ref=e1108]:
                    - code [ref=e1109]: string / ReadonlyArray<ChildAttribute>
                  - cell "—" [ref=e1110]
                  - cell "Class name and additional attributes for the outer Combobox wrapper." [ref=e1111]
                - row [ref=e1112]:
                  - cell [ref=e1113]:
                    - code [ref=e1114]: formName
                  - cell [ref=e1115]:
                    - code [ref=e1116]: string
                  - cell "—" [ref=e1117]
                  - cell "Form field name. Creates hidden input(s) with the selected value(s)." [ref=e1118]
                - row [ref=e1119]:
                  - cell [ref=e1120]:
                    - code [ref=e1121]: anchor
                  - cell [ref=e1122]:
                    - code [ref=e1123]: AnchorConfig
                  - cell "—" [ref=e1124]
                  - 'cell "Floating positioning config: placement, gap, offset, padding, isPlacementLocked, and portal. The items panel is always anchored to the input wrapper; when omitted, the panel uses bottom-start placement. Portaled to the document body, or into an enclosing dialog, by default; pass portal: false to keep the panel inside its wrapper." [ref=e1125]'
                - row [ref=e1126]:
                  - cell [ref=e1127]:
                    - code [ref=e1128]: isDisabled
                  - cell [ref=e1129]:
                    - code [ref=e1130]: boolean
                  - cell [ref=e1131]:
                    - code [ref=e1132]: "false"
                  - cell [ref=e1133]:
                    - text: Marks the Combobox unavailable, with
                    - code [ref=e1134]: aria-disabled="true"
                    - text: on the input and the toggle button and
                    - code [ref=e1135]: data-disabled
                    - text: on both plus the wrapper, and removes their handlers so the dropdown cannot be opened.
                - row [ref=e1136]:
                  - cell [ref=e1137]:
                    - code [ref=e1138]: isReadOnly
                  - cell [ref=e1139]:
                    - code [ref=e1140]: boolean
                  - cell [ref=e1141]:
                    - code [ref=e1142]: "false"
                  - cell [ref=e1143]:
                    - text: Keeps the Combobox openable, navigable, and closable while freezing the input and making item clicks, the Enter commit, and the immediate arrow-commit inert. Carries the native readonly attribute and aria-readonly on the input, and aria-readonly on the items panel. Independent of isDisabled. See
                    - link "Read-Only" [ref=e1144] [cursor=pointer]:
                      - /url: "#read-only"
                    - text: .
                - row [ref=e1145]:
                  - cell [ref=e1146]:
                    - code [ref=e1147]: isInvalid
                  - cell [ref=e1148]:
                    - code [ref=e1149]: boolean
                  - cell [ref=e1150]:
                    - code [ref=e1151]: "false"
                  - cell "Marks the Combobox as invalid for validation styling and ARIA state." [ref=e1152]
                - row [ref=e1153]:
                  - cell [ref=e1154]:
                    - code [ref=e1155]: openOnFocus
                  - cell [ref=e1156]:
                    - code [ref=e1157]: boolean
                  - cell [ref=e1158]:
                    - code [ref=e1159]: "false"
                  - cell "Opens the Combobox when the input receives focus." [ref=e1160]
                - row [ref=e1161]:
                  - cell [ref=e1162]:
                    - code [ref=e1163]: itemGroupKey
                  - cell [ref=e1164]:
                    - code [ref=e1165]: "(item: Item, index: number) => string"
                  - cell "—" [ref=e1166]
                  - cell [ref=e1167]:
                    - text: Groups contiguous items by key. Use with
                    - code [ref=e1168]: groupToHeading
                    - text: to render section headers.
                - row [ref=e1169]:
                  - cell [ref=e1170]:
                    - code [ref=e1171]: groupToHeading
                  - cell [ref=e1172]:
                    - code [ref=e1173]: "(groupKey: string) => GroupHeading | undefined"
                  - cell "—" [ref=e1174]
                  - cell "Renders a heading for each group." [ref=e1175]
                - row [ref=e1176]:
                  - cell [ref=e1177]:
                    - code [ref=e1178]: groupClassName / groupAttributes
                  - cell [ref=e1179]:
                    - code [ref=e1180]: string / ReadonlyArray<ChildAttribute>
                  - cell "—" [ref=e1181]
                  - cell "Class name and additional attributes for each group wrapper." [ref=e1182]
                - row [ref=e1183]:
                  - cell [ref=e1184]:
                    - code [ref=e1185]: separatorClassName / separatorAttributes
                  - cell [ref=e1186]:
                    - code [ref=e1187]: string / ReadonlyArray<ChildAttribute>
                  - cell "—" [ref=e1188]
                  - cell "Class name and additional attributes for separators between adjacent groups." [ref=e1189]
                - row [ref=e1190]:
                  - cell [ref=e1191]:
                    - code [ref=e1192]: ariaLabel
                  - cell [ref=e1193]:
                    - code [ref=e1194]: string
                  - cell "—" [ref=e1195]
                  - cell "Accessible name for the input. Use when there is no visible label. Applied as aria-label, and takes precedence over ariaLabelledBy." [ref=e1196]
                - row [ref=e1197]:
                  - cell [ref=e1198]:
                    - code [ref=e1199]: ariaLabelledBy
                  - cell [ref=e1200]:
                    - code [ref=e1201]: string
                  - cell "—" [ref=e1202]
                  - cell "Id of an external element that labels the input, applied as aria-labelledby. Pair with a visible label element." [ref=e1203]
          - generic [ref=e1204]:
            - heading "OutMessage" [level=3] [ref=e1205]
            - link "Copy link to OutMessage" [ref=e1206] [cursor=pointer]:
              - /url: "#out-message"
          - paragraph [ref=e1209]:
            - text: The child update and programmatic API return these facts through their optional
            - code [ref=e1210]: outMessage
            - text: field. Pass the public Combobox contract to
            - code [ref=e1211]: ParentBlock.makeOutMessageFold(ComboboxBlock, handlers)
            - text: "whether the fold is inline or named. The forwarding API remains contextual when inline: use"
            - code [ref=e1212]: ParentBlock.makeOutMessageForward(handlers)
            - text: when facts continue to the current Block's parent, and pass the public Block contract when extracting the forward. The explicit fold child preserves the exact item type returned by
            - code [ref=e1213]: Combobox.makeBlock(Item)
            - text: or
            - code [ref=e1214]: Combobox.Multi.makeBlock(Item)
            - text: .
          - 'region "Table: Name, Type, Default, Description" [ref=e1215]':
            - table [ref=e1216]:
              - rowgroup [ref=e1217]:
                - row [ref=e1218]:
                  - columnheader "Name" [ref=e1219]
                  - columnheader "Type" [ref=e1220]
                  - columnheader "Default" [ref=e1221]
                  - columnheader "Description" [ref=e1222]
              - rowgroup [ref=e1223]:
                - row [ref=e1224]:
                  - cell [ref=e1225]:
                    - code [ref=e1226]: Selected
                  - cell [ref=e1227]:
                    - code [ref=e1228]: "{ value: Item }"
                  - cell "—" [ref=e1229]
                  - cell [ref=e1230]:
                    - text: Emitted when an item is activated. Carries the neutral fact that the item was activated; the parent owns the selection and decides what it means. Single-select stores the value; multi-select toggles the value in and out of its array. Handle it in the Binding's selected
                    - code [ref=e1231]: fold
                    - text: to lift the value into the selection you own. A read-only Combobox never emits it.
                - row [ref=e1232]:
                  - cell [ref=e1233]:
                    - code [ref=e1234]: ClearedSelection
                  - cell [ref=e1235]:
                    - code [ref=e1236]: "{}"
                  - cell "—" [ref=e1237]
                  - cell "Emitted when a nullable single-select Combobox closes with an empty input, meaning the user cleared it. The parent clears the selection it owns. Multi-select never emits it, since its input rests empty by design. A read-only Combobox never emits it either, so opening and closing one cannot clear the selection." [ref=e1238]
        - navigation "Page navigation" [ref=e1240]:
          - link "Previous Checkbox" [ref=e1241] [cursor=pointer]:
            - /url: /ui/checkbox
            - generic [ref=e1242]: Previous
            - generic [ref=e1243]: ←Checkbox
          - link "Next Date Picker" [ref=e1244] [cursor=pointer]:
            - /url: /ui/date-picker
            - generic [ref=e1245]: Next
            - generic [ref=e1246]: Date Picker→
      - generic [ref=e1248]:
        - paragraph [ref=e1249]: Stay in the update loop.
        - paragraph [ref=e1250]: New releases, patterns, and the occasional deep dive.
        - generic [ref=e1251]:
          - textbox "Email address" [ref=e1253]:
            - /placeholder: you@example.com
          - button "Subscribe" [ref=e1254] [cursor=pointer]
        - separator [ref=e1255]
        - generic [ref=e1256]:
          - paragraph [ref=e1257]:
            - text: Built with
            - link "Foldkit" [ref=e1258] [cursor=pointer]:
              - /url: https://github.com/foldkit/foldkit/tree/main/packages/website/src/composition/composition.ts
            - text: .
          - paragraph [ref=e1259]: © 2026 Devin Jameson
          - navigation "Site information" [ref=e1260]:
            - link "About" [ref=e1261] [cursor=pointer]:
              - /url: /about
            - link "Contact" [ref=e1262] [cursor=pointer]:
              - /url: /contact
            - link "Privacy" [ref=e1263] [cursor=pointer]:
              - /url: /privacy
            - link "Content API" [ref=e1264] [cursor=pointer]:
              - /url: /api
    - complementary [ref=e1265]:
      - heading [level=3] [aria-hidden] [ref=e1266]: On this page
      - navigation "Table of contents" [ref=e1267]:
        - list [ref=e1268]:
          - listitem [ref=e1269]:
            - link "Overview" [ref=e1270] [cursor=pointer]:
              - /url: "#overview"
          - listitem [ref=e1271]:
            - link "Create a Typed Combobox" [ref=e1272] [cursor=pointer]:
              - /url: "#create-a-typed-combobox"
          - listitem [ref=e1273]:
            - link "Programmatic API" [ref=e1274] [cursor=pointer]:
              - /url: "#programmatic-api"
          - listitem [ref=e1275]:
            - link "Examples" [ref=e1276] [cursor=pointer]:
              - /url: "#examples"
          - listitem [ref=e1277]:
            - link "Single-Select" [ref=e1278] [cursor=pointer]:
              - /url: "#single-select"
          - listitem [ref=e1279]:
            - link "Nullable" [ref=e1280] [cursor=pointer]:
              - /url: "#nullable"
          - listitem [ref=e1281]:
            - link "Select on Focus" [ref=e1282] [cursor=pointer]:
              - /url: "#select-on-focus"
          - listitem [ref=e1283]:
            - link "Locked Placement" [ref=e1284] [cursor=pointer]:
              - /url: "#locked-placement"
          - listitem [ref=e1285]:
            - link "Multi-Select" [ref=e1286] [cursor=pointer]:
              - /url: "#multi-select"
          - listitem [ref=e1287]:
            - link "Read-Only" [ref=e1288] [cursor=pointer]:
              - /url: "#read-only"
          - listitem [ref=e1289]:
            - link "Browsing Without Committing" [ref=e1290] [cursor=pointer]:
              - /url: "#browsing-without-committing"
          - listitem [ref=e1291]:
            - link "Commit Paths Are Inert" [ref=e1292] [cursor=pointer]:
              - /url: "#commit-paths-are-inert"
          - listitem [ref=e1293]:
            - link "Closing Preserves the Selection" [ref=e1294] [cursor=pointer]:
              - /url: "#closing-preserves-the-selection"
          - listitem [ref=e1295]:
            - link "Typing and Opening" [ref=e1296] [cursor=pointer]:
              - /url: "#typing-and-opening"
          - listitem [ref=e1297]:
            - link "Programmatic Changes" [ref=e1298] [cursor=pointer]:
              - /url: "#programmatic-changes"
          - listitem [ref=e1299]:
            - link "Displaying an Existing Selection" [ref=e1300] [cursor=pointer]:
              - /url: "#displaying-an-existing-selection"
          - listitem [ref=e1301]:
            - link "Multi-Select Display" [ref=e1302] [cursor=pointer]:
              - /url: "#multi-select-display"
          - listitem [ref=e1303]:
            - link "Read-Only and Disabled States" [ref=e1304] [cursor=pointer]:
              - /url: "#read-only-and-disabled-states"
          - listitem [ref=e1305]:
            - link "ARIA Semantics" [ref=e1306] [cursor=pointer]:
              - /url: "#aria-semantics"
          - listitem [ref=e1307]:
            - link "Choosing a State" [ref=e1308] [cursor=pointer]:
              - /url: "#choosing-a-state"
          - listitem [ref=e1309]:
            - link "Styling" [ref=e1310] [cursor=pointer]:
              - /url: "#styling"
          - listitem [ref=e1311]:
            - link "Keyboard Interaction" [ref=e1312] [cursor=pointer]:
              - /url: "#keyboard-interaction"
          - listitem [ref=e1313]:
            - link "Empty Results" [ref=e1314] [cursor=pointer]:
              - /url: "#empty-results"
          - listitem [ref=e1315]:
            - link "Accessibility" [ref=e1316] [cursor=pointer]:
              - /url: "#accessibility"
          - listitem [ref=e1317]:
            - link "Combobox Semantics" [ref=e1318] [cursor=pointer]:
              - /url: "#combobox-semantics"
          - listitem [ref=e1319]:
            - link "Naming the Input" [ref=e1320] [cursor=pointer]:
              - /url: "#naming-the-input"
          - listitem [ref=e1321]:
            - link "API Reference" [ref=e1322] [cursor=pointer]:
              - /url: "#api-reference"
          - listitem [ref=e1323]:
            - link "InitConfig" [ref=e1324] [cursor=pointer]:
              - /url: "#init-config"
          - listitem [ref=e1325]:
            - link "ViewInputs" [ref=e1326] [cursor=pointer]:
              - /url: "#view-config"
          - listitem [ref=e1327]:
            - link "OutMessage" [ref=e1328] [cursor=pointer]:
              - /url: "#out-message"
```

# Test source

```ts
  1   | import AxeBuilder from '@axe-core/playwright'
  2   | import { expect, test } from '@playwright/test'
  3   | import type { Locator, Page } from '@playwright/test'
  4   | 
  5   | const accessibilityTags = [
  6   |   'wcag2a',
  7   |   'wcag2aa',
  8   |   'wcag21a',
  9   |   'wcag21aa',
  10  |   'wcag22a',
  11  |   'wcag22aa',
  12  | ]
  13  | 
  14  | const expectNoAccessibilityViolations = async (page: Page) => {
  15  |   const results = await new AxeBuilder({ page })
  16  |     .withTags(accessibilityTags)
  17  |     .analyze()
  18  | 
  19  |   expect(results.violations).toEqual([])
  20  | }
  21  | 
  22  | const expectFullyVisible = async (locator: Locator) => {
  23  |   await expect
  24  |     .poll(() =>
  25  |       locator.evaluate(element => {
  26  |         const box = element.getBoundingClientRect()
  27  |         const elementAtCenter = document.elementFromPoint(
  28  |           box.left + box.width / 2,
  29  |           box.top + box.height / 2,
  30  |         )
  31  | 
  32  |         return (
  33  |           box.top >= 0 &&
  34  |           box.bottom <= window.innerHeight &&
  35  |           elementAtCenter !== null &&
  36  |           element.contains(elementAtCenter)
  37  |         )
  38  |       }),
  39  |     )
  40  |     .toBe(true)
  41  | }
  42  | 
  43  | const waitForClientRuntime = async (page: Page) => {
> 44  |   await expect(page.locator('[data-foldkit-build]')).toHaveCount(0)
      |                                                      ^ Error: expect(locator).toHaveCount(expected) failed
  45  |   await expect(page.locator('[data-browser-environment-loaded]')).toHaveCount(1)
  46  | }
  47  | 
  48  | const waitForRuntimeEffects = async (page: Page) => {
  49  |   await page.evaluate(
  50  |     () =>
  51  |       new Promise<void>(resolve =>
  52  |         requestAnimationFrame(() => requestAnimationFrame(() => resolve())),
  53  |       ),
  54  |   )
  55  | }
  56  | 
  57  | const isWithinInertSubtree = (locator: Locator): Promise<boolean> =>
  58  |   locator.evaluate(element => element.closest('[inert]') !== null)
  59  | 
  60  | test('keeps representative UI demos free of automated accessibility violations', async ({
  61  |   page,
  62  | }) => {
  63  |   for (const path of ['/ui/drag-and-drop', '/ui/virtual-list']) {
  64  |     await page.goto(path)
  65  |     await waitForClientRuntime(page)
  66  |     await expectNoAccessibilityViolations(page)
  67  |   }
  68  | 
  69  |   await page.goto('/ui/dialog')
  70  |   await waitForClientRuntime(page)
  71  |   await page.getByRole('button', { name: 'Open Dialog', exact: true }).click()
  72  |   await expect(
  73  |     page.getByRole('dialog', { name: 'Confirm Action' }),
  74  |   ).toBeVisible()
  75  |   await expectNoAccessibilityViolations(page)
  76  | })
  77  | 
  78  | test('keeps code snippets accessible while collapsed and expanded', async ({
  79  |   page,
  80  | }) => {
  81  |   for (const colorScheme of ['light', 'dark'] as const) {
  82  |     await page.emulateMedia({ colorScheme })
  83  |     await page.goto('/core/model')
  84  |     await waitForClientRuntime(page)
  85  | 
  86  |     const figure = page.getByRole('figure', { name: 'Model state union' })
  87  |     const toggle = figure.getByRole('button', { name: /^(Show|Hide) code$/ })
  88  |     const panel = figure.locator('[id$="-panel"]')
  89  |     const panelVisibilityWrapper = panel.locator('..')
  90  |     const shortFigure = page.getByRole('figure', {
  91  |       name: 'Counter Model',
  92  |       exact: true,
  93  |     })
  94  | 
  95  |     await expect(figure).toHaveCount(1)
  96  |     await expect(shortFigure).toHaveCount(1)
  97  |     await expect(
  98  |       shortFigure.getByRole('button', { name: /^(Show|Hide) code$/ }),
  99  |     ).toHaveCount(0)
  100 |     await expect(
  101 |       shortFigure.getByRole('button', {
  102 |         name: 'Copy Counter Model to clipboard',
  103 |       }),
  104 |     ).toBeVisible()
  105 |     await expect(
  106 |       figure.getByRole('button', {
  107 |         name: 'Copy Model state union to clipboard',
  108 |       }),
  109 |     ).toHaveAttribute('type', 'button')
  110 |     await expect(toggle).toHaveAccessibleName('Show code')
  111 |     await expect(toggle).toHaveAttribute('aria-expanded', 'false')
  112 |     await expect(panelVisibilityWrapper).toHaveAttribute('inert', '')
  113 |     await expect(panelVisibilityWrapper).toHaveAttribute('aria-hidden', 'true')
  114 |     await expectNoAccessibilityViolations(page)
  115 | 
  116 |     await toggle.focus()
  117 |     const scrollYBeforeExpand = await page.evaluate(() => window.scrollY)
  118 |     await toggle.press('Enter')
  119 |     await expect(toggle).toHaveAccessibleName('Hide code')
  120 |     await expect(toggle).toHaveAttribute('aria-expanded', 'true')
  121 |     await expect(toggle).toHaveAttribute(
  122 |       'aria-controls',
  123 |       await panel.evaluate(element => element.id),
  124 |     )
  125 |     await expect(panelVisibilityWrapper).not.toHaveAttribute('inert', '')
  126 |     await expect(panelVisibilityWrapper).not.toHaveAttribute(
  127 |       'aria-hidden',
  128 |       'true',
  129 |     )
  130 |     await expect(toggle).toBeFocused()
  131 |     await expectFullyVisible(toggle)
  132 |     await expect(toggle.locator('..')).toHaveCSS('position', 'sticky')
  133 |     await expect
  134 |       .poll(() => page.evaluate(() => window.scrollY))
  135 |       .toBe(scrollYBeforeExpand)
  136 |     await expectNoAccessibilityViolations(page)
  137 | 
  138 |     await toggle.press('Space')
  139 |     await expect(toggle).toHaveAccessibleName('Show code')
  140 |     await expect(toggle).toHaveAttribute('aria-expanded', 'false')
  141 |     await expect(toggle).toBeFocused()
  142 |     await expectFullyVisible(toggle)
  143 |   }
  144 | })
```