import { brandViewResult as __foldkitBrandViewResult } from "/@fs/Users/devinjameson/.codex/worktrees/block-completion-record/foldkit-unified-recovery-20261103/packages/foldkit/dist/brand/public.js"
import { Effect, Queue, Stream } from "/node_modules/.vite/deps/effect.js?v=74286a4c";
/**
* A cold Stream that emits the elapsed milliseconds on every
* `requestAnimationFrame` tick. Each subscriber owns its animation frame loop,
* and ending the Stream cancels the pending frame.
*
* The browser pauses `requestAnimationFrame` when the tab is hidden, so the
* first elapsed value after it becomes visible may be large. Cap the value in
* the Subscription handler when the update uses it for motion or physics.
*
* @example
* ```ts
* const ExampleKey = Symbol('Example')
* const ExampleBlock = Block.make('Example', {
*   key: ExampleKey,
*   Model,
*   Message,
*   InitArgs: Schema.Tuple([]),
* })
* const subscriptions = ExampleBlock.makeSubscriptions(entry => ({
*   frame: entry(
*     'AnimationFrameTicks',
*     { isActive: Schema.Boolean },
*     {
*       messages: [Message.Ticked],
*       modelToDependencies: model => ({ isActive: model.isActive }),
*       handler: function* () {
*         return ({ isActive }) =>
*           isActive
*             ? Dom.animationFrameTicks.pipe(
*                 Stream.map(deltaTime => Message.Ticked({ deltaTime })),
*               )
*             : Stream.empty
*       },
*     },
*   ),
* }))
*
* const EffectsLayer = subscriptions.frame.layer
* ```
*/
export const animationFrameTicks = Stream.callback((queue) => __foldkitBrandViewResult((Effect.acquireRelease(Effect.sync(() => {
	const state = {
		frameId: 0,
		lastTime: performance.now()
	};
	const tick = (now) => {
		const deltaTime = now - state.lastTime;
		state.lastTime = now;
		Queue.offerUnsafe(queue, deltaTime);
		state.frameId = requestAnimationFrame(tick);
	};
	state.frameId = requestAnimationFrame(tick);
	return __foldkitBrandViewResult((state), "../foldkit-r11-r19-prototype-20261108.OnQh5N/baseline/packages/foldkit/src/dom/animationFrameTicks.ts#anonymous~2");
}), (state) => __foldkitBrandViewResult((Effect.sync(() => __foldkitBrandViewResult((cancelAnimationFrame(state.frameId)), "../foldkit-r11-r19-prototype-20261108.OnQh5N/baseline/packages/foldkit/src/dom/animationFrameTicks.ts#anonymous~4"))), "../foldkit-r11-r19-prototype-20261108.OnQh5N/baseline/packages/foldkit/src/dom/animationFrameTicks.ts#anonymous~3")).pipe(Effect.flatMap(() => __foldkitBrandViewResult((Effect.never), "../foldkit-r11-r19-prototype-20261108.OnQh5N/baseline/packages/foldkit/src/dom/animationFrameTicks.ts#anonymous~5")))), "../foldkit-r11-r19-prototype-20261108.OnQh5N/baseline/packages/foldkit/src/dom/animationFrameTicks.ts#anonymous"));

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFNBQVMsUUFBUSxPQUFPLGNBQWM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBMEN0QyxPQUFPLE1BQU0sc0JBQ1gsT0FBTyxVQUFpQixvQ0FDdEIsT0FBTyxlQUNMLE9BQU8sV0FBVztDQUNoQixNQUFNLFFBQVE7RUFDWixTQUFTO0VBQ1QsVUFBVSxZQUFZLElBQUk7Q0FDNUI7Q0FFQSxNQUFNLFFBQVEsUUFBc0I7RUFDbEMsTUFBTSxZQUFZLE1BQU0sTUFBTTtFQUM5QixNQUFNLFdBQVc7RUFDakIsTUFBTSxZQUFZLE9BQU8sU0FBUztFQUNsQyxNQUFNLFVBQVUsc0JBQXNCLElBQUk7Q0FDNUM7Q0FFQSxNQUFNLFVBQVUsc0JBQXNCLElBQUk7Q0FDMUMsaUNBQU87QUFDVCxDQUFDLElBQ0Qsb0NBQVMsT0FBTyxxQ0FBVyxxQkFBcUIsTUFBTSxPQUFPLHdIQUFDLHdIQUNoRSxDQUFDLENBQUMsS0FBSyxPQUFPLHdDQUFjLE9BQU8sNEhBQUssQ0FBQyxzSEFDM0MiLCJuYW1lcyI6W10sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbImFuaW1hdGlvbkZyYW1lVGlja3MudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRWZmZWN0LCBRdWV1ZSwgU3RyZWFtIH0gZnJvbSAnZWZmZWN0J1xuXG4vKipcbiAqIEEgY29sZCBTdHJlYW0gdGhhdCBlbWl0cyB0aGUgZWxhcHNlZCBtaWxsaXNlY29uZHMgb24gZXZlcnlcbiAqIGByZXF1ZXN0QW5pbWF0aW9uRnJhbWVgIHRpY2suIEVhY2ggc3Vic2NyaWJlciBvd25zIGl0cyBhbmltYXRpb24gZnJhbWUgbG9vcCxcbiAqIGFuZCBlbmRpbmcgdGhlIFN0cmVhbSBjYW5jZWxzIHRoZSBwZW5kaW5nIGZyYW1lLlxuICpcbiAqIFRoZSBicm93c2VyIHBhdXNlcyBgcmVxdWVzdEFuaW1hdGlvbkZyYW1lYCB3aGVuIHRoZSB0YWIgaXMgaGlkZGVuLCBzbyB0aGVcbiAqIGZpcnN0IGVsYXBzZWQgdmFsdWUgYWZ0ZXIgaXQgYmVjb21lcyB2aXNpYmxlIG1heSBiZSBsYXJnZS4gQ2FwIHRoZSB2YWx1ZSBpblxuICogdGhlIFN1YnNjcmlwdGlvbiBoYW5kbGVyIHdoZW4gdGhlIHVwZGF0ZSB1c2VzIGl0IGZvciBtb3Rpb24gb3IgcGh5c2ljcy5cbiAqXG4gKiBAZXhhbXBsZVxuICogYGBgdHNcbiAqIGNvbnN0IEV4YW1wbGVLZXkgPSBTeW1ib2woJ0V4YW1wbGUnKVxuICogY29uc3QgRXhhbXBsZUJsb2NrID0gQmxvY2subWFrZSgnRXhhbXBsZScsIHtcbiAqICAga2V5OiBFeGFtcGxlS2V5LFxuICogICBNb2RlbCxcbiAqICAgTWVzc2FnZSxcbiAqICAgSW5pdEFyZ3M6IFNjaGVtYS5UdXBsZShbXSksXG4gKiB9KVxuICogY29uc3Qgc3Vic2NyaXB0aW9ucyA9IEV4YW1wbGVCbG9jay5tYWtlU3Vic2NyaXB0aW9ucyhlbnRyeSA9PiAoe1xuICogICBmcmFtZTogZW50cnkoXG4gKiAgICAgJ0FuaW1hdGlvbkZyYW1lVGlja3MnLFxuICogICAgIHsgaXNBY3RpdmU6IFNjaGVtYS5Cb29sZWFuIH0sXG4gKiAgICAge1xuICogICAgICAgbWVzc2FnZXM6IFtNZXNzYWdlLlRpY2tlZF0sXG4gKiAgICAgICBtb2RlbFRvRGVwZW5kZW5jaWVzOiBtb2RlbCA9PiAoeyBpc0FjdGl2ZTogbW9kZWwuaXNBY3RpdmUgfSksXG4gKiAgICAgICBoYW5kbGVyOiBmdW5jdGlvbiogKCkge1xuICogICAgICAgICByZXR1cm4gKHsgaXNBY3RpdmUgfSkgPT5cbiAqICAgICAgICAgICBpc0FjdGl2ZVxuICogICAgICAgICAgICAgPyBEb20uYW5pbWF0aW9uRnJhbWVUaWNrcy5waXBlKFxuICogICAgICAgICAgICAgICAgIFN0cmVhbS5tYXAoZGVsdGFUaW1lID0+IE1lc3NhZ2UuVGlja2VkKHsgZGVsdGFUaW1lIH0pKSxcbiAqICAgICAgICAgICAgICAgKVxuICogICAgICAgICAgICAgOiBTdHJlYW0uZW1wdHlcbiAqICAgICAgIH0sXG4gKiAgICAgfSxcbiAqICAgKSxcbiAqIH0pKVxuICpcbiAqIGNvbnN0IEVmZmVjdHNMYXllciA9IHN1YnNjcmlwdGlvbnMuZnJhbWUubGF5ZXJcbiAqIGBgYFxuICovXG5leHBvcnQgY29uc3QgYW5pbWF0aW9uRnJhbWVUaWNrczogU3RyZWFtLlN0cmVhbTxudW1iZXI+ID1cbiAgU3RyZWFtLmNhbGxiYWNrPG51bWJlcj4ocXVldWUgPT5cbiAgICBFZmZlY3QuYWNxdWlyZVJlbGVhc2UoXG4gICAgICBFZmZlY3Quc3luYygoKSA9PiB7XG4gICAgICAgIGNvbnN0IHN0YXRlID0ge1xuICAgICAgICAgIGZyYW1lSWQ6IDAsXG4gICAgICAgICAgbGFzdFRpbWU6IHBlcmZvcm1hbmNlLm5vdygpLFxuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgdGljayA9IChub3c6IG51bWJlcik6IHZvaWQgPT4ge1xuICAgICAgICAgIGNvbnN0IGRlbHRhVGltZSA9IG5vdyAtIHN0YXRlLmxhc3RUaW1lXG4gICAgICAgICAgc3RhdGUubGFzdFRpbWUgPSBub3dcbiAgICAgICAgICBRdWV1ZS5vZmZlclVuc2FmZShxdWV1ZSwgZGVsdGFUaW1lKVxuICAgICAgICAgIHN0YXRlLmZyYW1lSWQgPSByZXF1ZXN0QW5pbWF0aW9uRnJhbWUodGljaylcbiAgICAgICAgfVxuXG4gICAgICAgIHN0YXRlLmZyYW1lSWQgPSByZXF1ZXN0QW5pbWF0aW9uRnJhbWUodGljaylcbiAgICAgICAgcmV0dXJuIHN0YXRlXG4gICAgICB9KSxcbiAgICAgIHN0YXRlID0+IEVmZmVjdC5zeW5jKCgpID0+IGNhbmNlbEFuaW1hdGlvbkZyYW1lKHN0YXRlLmZyYW1lSWQpKSxcbiAgICApLnBpcGUoRWZmZWN0LmZsYXRNYXAoKCkgPT4gRWZmZWN0Lm5ldmVyKSksXG4gIClcbiJdLCJmaWxlIjoiL3ByaXZhdGUvdG1wL2ZvbGRraXQtcjExLXIxOS1wcm90b3R5cGUtMjAyNjExMDguT25RaDVOL2Jhc2VsaW5lL3BhY2thZ2VzL2ZvbGRraXQvc3JjL2RvbS9hbmltYXRpb25GcmFtZVRpY2tzLnRzIn0=