import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/@fs/private/tmp/foldkit-r11-r19-prototype-20261108.OnQh5N/baseline/packages/foldkit/src/runtime/renderer.ts");import { brandViewResult as __foldkitBrandViewResult } from "/@fs/Users/devinjameson/.codex/worktrees/block-completion-record/foldkit-unified-recovery-20261103/packages/foldkit/dist/brand/public.js"
import { Array, Cause, Context, Effect, Exit, Option, Predicate } from "/node_modules/.vite/deps/effect.js?v=74286a4c";
import { FOLDKIT_MOUNT_KEY, __beginRender as beginHtmlRender, __beginReplayRender as beginReplayHtmlRender, __clearRuntime as clearHtmlRuntime, __createBoundaryRegistry as createHtmlBoundaryRegistry, __endReplayRender as endReplayHtmlRender, __flushReplayUnmountsAfterPatchFailure as flushReplayUnmountsAfterPatchFailure, __setRuntime as setHtmlRuntime } from "/@fs/private/tmp/foldkit-r11-r19-prototype-20261108.OnQh5N/baseline/packages/foldkit/src/html/index.ts";
import { __hydrateVNode } from "/@fs/private/tmp/foldkit-r11-r19-prototype-20261108.OnQh5N/baseline/packages/foldkit/src/hydrate.ts";
import { FOLDKIT_APP_ATTRIBUTE } from "/@fs/private/tmp/foldkit-r11-r19-prototype-20261108.OnQh5N/baseline/packages/foldkit/src/hydrationMarker.ts";
import { MountRegistrationTypeId, MountRuntime, MountTracker } from "/@fs/private/tmp/foldkit-r11-r19-prototype-20261108.OnQh5N/baseline/packages/foldkit/src/mount/index.ts";
import { __patchVNode, __recoverVNodeAfterPatchFailure } from "/@fs/private/tmp/foldkit-r11-r19-prototype-20261108.OnQh5N/baseline/packages/foldkit/src/vdom.ts";
import { noOpDispatch, renderCrashView } from "/@fs/private/tmp/foldkit-r11-r19-prototype-20261108.OnQh5N/baseline/packages/foldkit/src/runtime/crashUI.ts";
import { Dispatch } from "/@fs/private/tmp/foldkit-r11-r19-prototype-20261108.OnQh5N/baseline/packages/foldkit/src/runtime/dispatch.ts";
import { applyDocumentMetadata } from "/@fs/private/tmp/foldkit-r11-r19-prototype-20261108.OnQh5N/baseline/packages/foldkit/src/runtime/documentMetadata.ts";
import { measureSlowPhase, reportSlowPhase } from "/@fs/private/tmp/foldkit-r11-r19-prototype-20261108.OnQh5N/baseline/packages/foldkit/src/runtime/slowPhase.ts";
import { __decideViewTransition, __silenceViewTransitionRejections } from "/@fs/private/tmp/foldkit-r11-r19-prototype-20261108.OnQh5N/baseline/packages/foldkit/src/runtime/viewTransition.ts";
/**
* Builds the render side of one runtime: the current vnode and, when
* hydrating, the server-rendered root the first render adopts, the crash
* renderer, the `Dispatch` service the view binds handlers to, the
* synchronous render that runs the view and patches the DOM, the render
* frame that runs in `requestAnimationFrame`, and the View Transition
* that frame may run inside. It also registers the teardown finalizer
* that patches the tree away and restores the container, so build it
* before forking the perpetual fibers: scope finalizers run
* last-registered first, and the container must be restored only after
* those fibers are interrupted.
*/
export const makeRenderer = ({ status, container, view, htmlBuilder, manageDocument, crash, buildId, initModel, maybeHydrationRoot, maybeSlowView, maybeSlowPatch, duplicateIdScanner, maybeResolvedViewTransition, commitNotifier, mounts, runtimeContext, readLiveModel, messageQueue, devToolsIntegration }) => __foldkitBrandViewResult((Effect.gen(function* () {
	const { enqueueMessage, enqueueMessageEffect, drainPendingMessages, resetDrainBudget, isAnyMessageDeferred } = messageQueue;
	const { mountTracker, mountRuntime, drainMountEvents, readViewState, setViewState, isPausedNow, resumeDevTools, attachRenderedMounts } = devToolsIntegration;
	const settlePendingCommit = () => {
		if (commitNotifier.service.isCommitPending()) {
			commitNotifier.notifyCommitted();
		}
	};
	// NOTE: `isRenderFrameScheduled` clears when the frame callback
	// starts, which on the View Transition path is before the patch runs.
	// `commitNotifier` tracks the patch itself, so `Render.afterCommit`
	// waits for the commit rather than for the frame that scheduled it.
	let isRenderFrameScheduled = false;
	// NOTE: resume clears the DevTools store's pause flag before its frame
	// patches the live view. This distinguishes that intentional repaint
	// from an ordinary frame that was already queued when jumpTo installed
	// the historical view.
	let isLiveViewRestorePending = false;
	// NOTE: the Model behind the DOM currently on screen, which is what a
	// View Transition animates away from. Seeded with `initModel` because
	// the init render paints it, and advanced only where a render actually
	// commits. The `viewTransition` predicate never runs before a Message
	// has dirtied the Model, and the init render completes behind the boot
	// barrier, so this is always the model of a paint that happened.
	let lastRenderedModel = initModel;
	// NOTE: the transition the browser is still animating, if any. Held so
	// the runtime can skip it: when a later frame supersedes it, when the
	// runtime crashes, and at teardown, where the browser would otherwise
	// animate over a released container. Declared above `crashWith`, which
	// calls the skip and can run as early as the init render.
	let maybePendingViewTransition = Option.none();
	const skipPendingViewTransition = () => {
		if (Option.isSome(maybePendingViewTransition)) {
			const { value: pendingViewTransition } = maybePendingViewTransition;
			// NOTE: cleared first. An implementation that runs the update
			// callback synchronously would otherwise re-enter this.
			maybePendingViewTransition = Option.none();
			pendingViewTransition.update.isInvalidated = true;
			try {
				pendingViewTransition.handle.skipTransition();
			} catch {}
		}
	};
	// NOTE: the current vnode is plain closure state. The frame reads and
	// writes it directly; the cold paths that run inside Effects (crash
	// rendering, the dispose finalizer, the replay render) read the same
	// slot synchronously, so no Ref is needed.
	const vnodeSlot = { maybeCurrentVNode: Option.none() };
	const patchRuntimeVNode = (maybeCurrentVNode, nextVNode, seen) => {
		try {
			return __foldkitBrandViewResult((__patchVNode(maybeCurrentVNode, nextVNode, container, seen, (patchedVNode) => {
				vnodeSlot.maybeCurrentVNode = Option.some(patchedVNode);
			})), "../foldkit-r11-r19-prototype-20261108.OnQh5N/baseline/packages/foldkit/src/runtime/renderer.ts#patchRuntimeVNode");
		} catch (error) {
			try {
				const maybeRecoveryVNode = vnodeSlot.maybeCurrentVNode;
				if (Option.isSome(maybeRecoveryVNode)) {
					vnodeSlot.maybeCurrentVNode = Option.some(__recoverVNodeAfterPatchFailure(maybeRecoveryVNode.value));
				}
			} finally {
				flushReplayUnmountsAfterPatchFailure();
			}
			throw error;
		}
	};
	// NOTE: consumed by the first render only. Set when this boot found
	// an adoptable server-rendered root; the first patch then goes
	// through `__hydrateVNode` instead of replacing the container.
	let pendingHydrationRoot = Option.getOrNull(maybeHydrationRoot);
	// NOTE: registered before any perpetual fiber is forked so it runs
	// after they are interrupted (scope finalizers are LIFO). Patching to
	// an empty tree fires snabbdom destroy hooks, which is what releases
	// Mounts; swapping the placeholder for the original container leaves
	// the host DOM as it was before the first render, ready for a fresh
	// embed of the same container. Gated on interruption: that is the
	// dispose path. A runtime that stops because it crashed completes
	// normally after rendering the crash view, and the crash view must
	// stay visible.
	yield* Effect.addFinalizer((exit) => __foldkitBrandViewResult((Effect.gen(function* () {
		if (Exit.hasInterrupts(exit)) {
			const maybeCurrentVNode = vnodeSlot.maybeCurrentVNode;
			yield* Option.match(maybeCurrentVNode, {
				onNone: () => __foldkitBrandViewResult((Effect.void), "../foldkit-r11-r19-prototype-20261108.OnQh5N/baseline/packages/foldkit/src/runtime/renderer.ts#onNone"),
				onSome: (currentVNode) => __foldkitBrandViewResult((Effect.sync(() => {
					const placeholderNode = __patchVNode(Option.some(currentVNode), null, container).elm;
					if (placeholderNode && placeholderNode.parentNode) {
						placeholderNode.parentNode.replaceChild(container, placeholderNode);
						container.replaceChildren();
					}
				})), "../foldkit-r11-r19-prototype-20261108.OnQh5N/baseline/packages/foldkit/src/runtime/renderer.ts#onSome")
			});
		}
		yield* mountRuntime.interruptFibers;
	})), "../foldkit-r11-r19-prototype-20261108.OnQh5N/baseline/packages/foldkit/src/runtime/renderer.ts#anonymous~3"));
	// NOTE: shared by every crash path: the init render, the plain
	// message drain and render frame (which reach it through
	// `Effect.runFork` from their catch blocks), and the Command and
	// Subscription fibers (a Command's Effect and a Subscription's
	// Stream are typed with a `never` error channel, so a cause
	// escaping one is an unrecoverable defect). Each path catches its
	// own cause so a failure surfaces as the crash view instead of
	// dying silently and leaving the DOM frozen at the last successful
	// render. The first crash wins: concurrent Command fibers can fail,
	// and only one should report and render.
	const crashWith = (cause, maybeMessage) => __foldkitBrandViewResult((Effect.sync(() => {
		if (status.isCrashed) {
			return;
		}
		status.isCrashed = true;
		messageQueue.drainPendingMessages();
		// NOTE: the crash view should appear at once, not animate in from
		// a snapshot of the state that crashed.
		skipPendingViewTransition();
		const model = readLiveModel();
		const squashed = Cause.squash(cause);
		const error = squashed instanceof Error ? squashed : new Error(String(squashed));
		renderCrashView({
			error,
			model,
			message: maybeMessage
		}, crash, container, vnodeSlot, manageDocument);
		settlePendingCommit();
	})), "../foldkit-r11-r19-prototype-20261108.OnQh5N/baseline/packages/foldkit/src/runtime/renderer.ts#crashWith");
	// NOTE: `maybeLastDirtyMessage` holds the most recent dirtying Message,
	// so slow render-phase callbacks during high-rate bursts attribute to
	// the last Message in the frame batch, not the specific one that pushed
	// the view past threshold. Acceptable for a debug callback; full
	// attribution would require correlating each message with its render
	// contribution, which isn't worth the complexity.
	let maybeLastDirtyMessage = Option.none();
	const setLastDirtyMessage = (message) => {
		maybeLastDirtyMessage = Option.some(message);
	};
	const dispatchSync = (message, isCurrent) => {
		/* eslint-disable-next-line @typescript-eslint/consistent-type-assertions */
		enqueueMessage(message, isCurrent);
	};
	const dispatchAsync = (message, isCurrent) => __foldkitBrandViewResult((enqueueMessageEffect(message, isCurrent)), "../foldkit-r11-r19-prototype-20261108.OnQh5N/baseline/packages/foldkit/src/runtime/renderer.ts#dispatchAsync");
	const dispatch = {
		dispatchAsync,
		dispatchSync
	};
	// NOTE: One boundary registry per runtime instance, shared
	// across renders so Block wrap blocks registered by
	// h.block persist between renders. The render function calls
	// `beginHtmlRender` at the start of each pass; wraps for
	// unmounted Blocks (e.g. an entry removed from a list) are
	// dropped from the registry via snabbdom `postdestroy` hooks
	// attached by `h.block` to each child vnode.
	const boundaryRegistry = createHtmlBoundaryRegistry();
	const registeredMounts = new Set(mounts.map((mount) => __foldkitBrandViewResult((mount[MountRegistrationTypeId]), "../foldkit-r11-r19-prototype-20261108.OnQh5N/baseline/packages/foldkit/src/runtime/renderer.ts#anonymous~7")));
	const mountValidationVisits = new Set();
	const assertLayeredMountsAreRegistered = (root) => {
		if (root === null) {
			return;
		}
		let missing;
		const walk = (node) => {
			const { children } = node;
			if (children !== undefined && Array.isArrayNonEmpty(children)) {
				if (mountValidationVisits.has(node)) {
					return;
				}
				mountValidationVisits.add(node);
			}
			/* eslint-disable-next-line @typescript-eslint/consistent-type-assertions */
			const marker = node.data?.[FOLDKIT_MOUNT_KEY];
			const registration = marker?.[MountRegistrationTypeId];
			if (marker !== undefined && registration !== undefined && !registeredMounts.has(registration)) {
				missing ??= new Map();
				missing.set(registration, marker.name);
			}
			if (children !== undefined) {
				for (const child of children) {
					if (!Predicate.isString(child)) {
						walk(child);
					}
				}
			}
		};
		try {
			walk(root);
		} finally {
			mountValidationVisits.clear();
		}
		if (missing === undefined) {
			return;
		}
		const names = globalThis.Array.from(missing.values()).sort();
		throw new Error(`[foldkit] The rendered view contains Layer-backed Mounts that were not registered: ${names.join(", ")}. ` + "Register each Mount Definition in the owning Composition's mounts field.");
	};
	// NOTE: callers set `isRenderingFrame` before calling this and clear
	// it after. Without it, a Message dispatched while the patch is still
	// running would run update against a half-patched DOM. For a replay,
	// `render` also calls `beginReplayHtmlRender` first, so the old
	// tree's unmount callbacks don't dispatch into live history.
	const renderSync = (model, maybeMessage, dispatchService, renderContext, renderMode) => {
		const maybeLiveRender = Option.liftPredicate(renderMode, (mode) => __foldkitBrandViewResult((mode === "Live"), "../foldkit-r11-r19-prototype-20261108.OnQh5N/baseline/packages/foldkit/src/runtime/renderer.ts#anonymous~8"));
		const maybeLiveSlowView = Option.flatMap(maybeLiveRender, () => __foldkitBrandViewResult((maybeSlowView), "../foldkit-r11-r19-prototype-20261108.OnQh5N/baseline/packages/foldkit/src/runtime/renderer.ts#anonymous~9"));
		const maybeLiveSlowPatch = Option.flatMap(maybeLiveRender, () => __foldkitBrandViewResult((maybeSlowPatch), "../foldkit-r11-r19-prototype-20261108.OnQh5N/baseline/packages/foldkit/src/runtime/renderer.ts#anonymous~10"));
		const [nextDocument, maybeViewDuration] = measureSlowPhase(maybeLiveSlowView, () => {
			beginHtmlRender(boundaryRegistry);
			setHtmlRuntime(dispatchService.dispatchSync, renderContext, boundaryRegistry, renderMode);
			try {
				return __foldkitBrandViewResult((view(model, htmlBuilder)), "../foldkit-r11-r19-prototype-20261108.OnQh5N/baseline/packages/foldkit/src/runtime/renderer.ts#anonymous~11");
			} finally {
				clearHtmlRuntime();
			}
		});
		const { body: nextVNode } = nextDocument;
		assertLayeredMountsAreRegistered(nextVNode);
		reportSlowPhase(maybeLiveSlowView, maybeViewDuration, (durationMs, thresholdMs) => (__foldkitBrandViewResult(({
			_tag: "View",
			model,
			message: maybeMessage,
			durationMs,
			thresholdMs
		}), "../foldkit-r11-r19-prototype-20261108.OnQh5N/baseline/packages/foldkit/src/runtime/renderer.ts#anonymous~12")));
		const { maybeCurrentVNode } = vnodeSlot;
		const [patchedVNode, maybePatchDuration] = measureSlowPhase(maybeLiveSlowPatch, () => {
			if (Option.isNone(maybeCurrentVNode) && pendingHydrationRoot !== null) {
				const hydrationRoot = pendingHydrationRoot;
				pendingHydrationRoot = null;
				// NOTE: strip the stamp before the patch, not after, so the
				// patch is the sole owner of the root's attributes. It has
				// already served its purpose of locating the root, and
				// removing it after would delete a `data-foldkit-app` the view
				// itself declares, which a later equal-vnode patch would not
				// restore. Removing it here also stops a later boot on the same
				// container (a dispose-then-embed remount) from re-detecting
				// this now-consumed root as hydratable.
				hydrationRoot.removeAttribute(FOLDKIT_APP_ATTRIBUTE);
				// An empty id reaches the adoption step's own check as a
				// value that matches nothing. Boot already refused a
				// hydration without an id, so this stands in only for a
				// caller that reached here another way.
				return __foldkitBrandViewResult((__hydrateVNode(hydrationRoot, nextVNode, boundaryRegistry.dedupeSeen, buildId ?? "")), "../foldkit-r11-r19-prototype-20261108.OnQh5N/baseline/packages/foldkit/src/runtime/renderer.ts#anonymous~13");
			}
			return __foldkitBrandViewResult((patchRuntimeVNode(maybeCurrentVNode, nextVNode, boundaryRegistry.dedupeSeen)), "../foldkit-r11-r19-prototype-20261108.OnQh5N/baseline/packages/foldkit/src/runtime/renderer.ts#anonymous~13");
		});
		vnodeSlot.maybeCurrentVNode = Option.some(patchedVNode);
		reportSlowPhase(maybeLiveSlowPatch, maybePatchDuration, (durationMs, thresholdMs) => (__foldkitBrandViewResult(({
			_tag: "Patch",
			model,
			message: maybeMessage,
			durationMs,
			thresholdMs
		}), "../foldkit-r11-r19-prototype-20261108.OnQh5N/baseline/packages/foldkit/src/runtime/renderer.ts#anonymous~14")));
		if (manageDocument) {
			applyDocumentMetadata(nextDocument, patchedVNode.elm);
		}
		if (import.meta.hot) {
			duplicateIdScanner?.schedule(patchedVNode.elm);
		}
	};
	// NOTE: `dispatchService` defaults to live dispatch but is overridable
	// so a time-travel render can bind both declarative handlers and newly
	// acquired Mounts to `noOpDispatch`. A live Mount keeps its dispatcher
	// across replay, while a replay-created Mount stays muted until a live
	// resume patch releases it and starts the live action. This preserves
	// valid async results from live Mounts without granting a historical
	// acquisition access to the live Model.
	const render = (model, maybeMessage, dispatchService = dispatch, renderMode = "Live") => __foldkitBrandViewResult((Effect.gen(function* () {
		status.isRenderingFrame = true;
		const renderContext = Context.add(Context.add(Context.add(runtimeContext, Dispatch, dispatchService), MountTracker, mountTracker), MountRuntime, mountRuntime);
		if (renderMode === "Replay") {
			beginReplayHtmlRender();
		}
		renderSync(model, maybeMessage, dispatchService, renderContext, renderMode);
	}).pipe(Effect.ensuring(Effect.sync(() => {
		status.isRenderingFrame = false;
		endReplayHtmlRender();
		drainPendingMessages();
	})))), "../foldkit-r11-r19-prototype-20261108.OnQh5N/baseline/packages/foldkit/src/runtime/renderer.ts#render");
	const liveRenderContext = Context.add(Context.add(Context.add(runtimeContext, Dispatch, dispatch), MountTracker, mountTracker), MountRuntime, mountRuntime);
	// NOTE: rendering before a deferred drain resumes would restore stale
	// controlled input values. Disposed or crashed runtimes use the frame guards.
	const isLiveModelBehindQueue = () => __foldkitBrandViewResult((isAnyMessageDeferred() && !status.isRuntimeDisposed && !status.isCrashed), "../foldkit-r11-r19-prototype-20261108.OnQh5N/baseline/packages/foldkit/src/runtime/renderer.ts#isLiveModelBehindQueue");
	// NOTE: the render, Mount drain, DevTools attribution, and
	// patch-time-buffer flush. Shared by the plain path (called directly)
	// and the View Transition path (called from the transition's update
	// callback), which run identical work; only whether they run inside
	// `document.startViewTransition` differs. `isRenderingFrame` gates the
	// buffering of Messages dispatched by patch-time hooks, so it must
	// wrap the actual patch, which on the transition path happens inside
	// the callback, not when the frame is scheduled.
	const runRenderFrameBody = () => {
		status.isRenderingFrame = true;
		// NOTE: captured before the patch, because `drainPendingMessages`
		// below can advance the live Model again before the next frame reads
		// it. What this frame painted is what the next transition animates
		// away from.
		const renderedModel = readLiveModel();
		const isResuming = readViewState() === "Paused";
		if (isResuming) {
			// NOTE: Messages accumulated while a historical view owned the DOM
			// did not cause this repaint. A Message arriving during the patch
			// can repopulate this field when the buffered queue drains.
			maybeLastDirtyMessage = Option.none();
		}
		try {
			renderSync(readLiveModel(), maybeLastDirtyMessage, dispatch, liveRenderContext, "Live");
			// NOTE: after the patch, so a render that threw leaves this on the
			// Model still on screen, and before `drainPendingMessages` below,
			// whose handlers can advance the live Model again.
			lastRenderedModel = renderedModel;
			// NOTE: resume clears the store's pause flag before this frame.
			// Publish Live only after the live DOM has been installed.
			setViewState("Live");
			attachRenderedMounts();
		} catch (error) {
			Effect.runFork(crashWith(Cause.die(error), maybeLastDirtyMessage));
		} finally {
			status.isRenderingFrame = false;
		}
		// NOTE: Messages dispatched by patch-time hooks (for example,
		// OnUnmount destroys, or Mount emissions) were buffered while the
		// frame held the stack; they process now, after the patch has
		// committed and the frame's Mount events are attributed.
		drainPendingMessages();
		// NOTE: last, so a waiter resumed by the commit observes the same
		// DOM and the same processed-Message ordering it saw when
		// `afterCommit` counted frames.
		settlePendingCommit();
	};
	// NOTE: starts a View Transition around this frame's render when the
	// `viewTransition` predicate matches, returning `true` when it did.
	// `startViewTransition` invokes its update callback asynchronously
	// after snapshotting the old DOM, so the callback reads the live Model
	// and `maybeLastDirtyMessage` fresh (the plain loop may have advanced
	// the model while the browser suppressed rendering) and re-checks the
	// disposal and crash guards, which can flip while the transition is
	// pending. The unconfigured path never reaches this function; the
	// `Option.isNone` check in `renderFramePlain` returns first, so a
	// runtime without `viewTransition` allocates no per-frame callback.
	const startFrameViewTransition = (resolved) => {
		if (readViewState() === "Paused") {
			return __foldkitBrandViewResult((false), "../foldkit-r11-r19-prototype-20261108.OnQh5N/baseline/packages/foldkit/src/runtime/renderer.ts#startFrameViewTransition");
		}
		if (resolved.reducedMotionQuery.matches) {
			return __foldkitBrandViewResult((false), "../foldkit-r11-r19-prototype-20261108.OnQh5N/baseline/packages/foldkit/src/runtime/renderer.ts#startFrameViewTransition");
		}
		if (Option.isNone(maybeLastDirtyMessage)) {
			return __foldkitBrandViewResult((false), "../foldkit-r11-r19-prototype-20261108.OnQh5N/baseline/packages/foldkit/src/runtime/renderer.ts#startFrameViewTransition");
		}
		const maybeDecision = __decideViewTransition(resolved.decide, {
			previousModel: lastRenderedModel,
			model: readLiveModel(),
			message: maybeLastDirtyMessage.value
		});
		if (Option.isNone(maybeDecision)) {
			return __foldkitBrandViewResult((false), "../foldkit-r11-r19-prototype-20261108.OnQh5N/baseline/packages/foldkit/src/runtime/renderer.ts#startFrameViewTransition");
		}
		// NOTE: invalidate an older transition before this one takes
		// ownership of the latest live repaint. The browser may still call
		// the older update callback, but its invalidation guard leaves the
		// DOM and commit notifier to this transition.
		skipPendingViewTransition();
		try {
			const update = {
				isInvalidated: false,
				didRun: false
			};
			const handle = resolved.startViewTransition(() => {
				if (update.isInvalidated || update.didRun) {
					return;
				}
				update.didRun = true;
				// NOTE: a drain may have been deferred since the preceding frame
				// started the transition. Leave the DOM unchanged until it catches up.
				if (isLiveModelBehindQueue()) {
					skipPendingViewTransition();
					scheduleRenderFrame();
					return;
				}
				// NOTE: the view state closes the resume window after the
				// store is live but before its plain frame has restored the live
				// DOM. A transition invalidated by jumpTo stays invalid forever,
				// so its callback cannot repaint inside the stale transition
				// even if it arrives after resume has published `Live`.
				if (status.isRuntimeDisposed || status.isCrashed || isPausedNow() || readViewState() === "Paused") {
					settlePendingCommit();
					return;
				}
				runRenderFrameBody();
			}, maybeDecision.value.maybeTypes);
			maybePendingViewTransition = Option.some({
				handle,
				update
			});
			__silenceViewTransitionRejections(handle);
			return __foldkitBrandViewResult((true), "../foldkit-r11-r19-prototype-20261108.OnQh5N/baseline/packages/foldkit/src/runtime/renderer.ts#startFrameViewTransition");
		} catch {
			// NOTE: an escaping throw would leave the rAF callback without a
			// patch and without settling the commit notifier, parking every
			// `Render.afterCommit` on this frame forever.
			return __foldkitBrandViewResult((false), "../foldkit-r11-r19-prototype-20261108.OnQh5N/baseline/packages/foldkit/src/runtime/renderer.ts#startFrameViewTransition");
		}
	};
	// NOTE: every path out of a scheduled frame settles the commit
	// notifier, whether or not it patched. A frame abandoned silently
	// would strand any `Render.afterCommit` registered against it, and
	// the Dom helpers that gate on it would never run their DOM work.
	const renderFramePlain = () => {
		// NOTE: retain the scheduled frame's pending commit while the drain waits.
		if (isLiveModelBehindQueue()) {
			requestAnimationFrame(renderFramePlain);
			return;
		}
		isRenderFrameScheduled = false;
		const isRestoringLiveView = isLiveViewRestorePending;
		isLiveViewRestorePending = false;
		// NOTE: a frame scheduled before disposal fires after it; a
		// disposed runtime must not repaint the released container.
		if (status.isRuntimeDisposed) {
			settlePendingCommit();
			return;
		}
		// NOTE: a frame is running, so the browser got control back; the
		// drain budget starts fresh.
		resetDrainBudget();
		// NOTE: a Message that dirtied the model can also be the one
		// whose Command crashed the runtime. Without this guard the
		// next animation frame would render the live view over the
		// crash view.
		if (status.isCrashed) {
			settlePendingCommit();
			return;
		}
		if (isPausedNow()) {
			settlePendingCommit();
			return;
		}
		if (readViewState() === "Paused" && !isRestoringLiveView) {
			settlePendingCommit();
			return;
		}
		// NOTE: the unconfigured path pays one `Option.isNone` check and
		// renders directly, allocating no per-frame callback. Only a
		// runtime configured with `viewTransition` reaches
		// `startFrameViewTransition`, which decides per frame whether to
		// wrap the render in `document.startViewTransition`. When it does,
		// the render runs later, inside the transition's update callback.
		if (Option.isNone(maybeResolvedViewTransition)) {
			runRenderFrameBody();
			return;
		}
		if (!startFrameViewTransition(maybeResolvedViewTransition.value)) {
			runRenderFrameBody();
		}
	};
	// NOTE: render frames run as plain JavaScript inside the
	// requestAnimationFrame callback. Messages arriving between frames mark
	// at most one pending frame; the callback renders once with the latest
	// model.
	const scheduleRenderFrame = (isRestoringLiveView = false) => {
		if (isRestoringLiveView) {
			isLiveViewRestorePending = true;
		}
		if (isRenderFrameScheduled) {
			return;
		}
		isRenderFrameScheduled = true;
		commitNotifier.markCommitPending();
		requestAnimationFrame(renderFramePlain);
	};
	const devToolsRenderBridge = {
		// NOTE: passes `noOpDispatch` so declarative handlers and Mounts
		// acquired by the replay cannot reach the live Model. Their
		// fibers stay alive and can observe view-state changes while the
		// historical view owns them. If resume reuses such an element,
		// OnMount releases the replay acquisition before starting the
		// live action. Also discards mount events fired during the render
		// so they don't get attributed to the next user-initiated dispatch.
		renderReplay: (model) => __foldkitBrandViewResult((Effect.gen(function* () {
			/* eslint-disable-next-line @typescript-eslint/consistent-type-assertions */
			const replayedModel = model;
			const previousRenderedModel = lastRenderedModel;
			// NOTE: a Mount surviving from the live view must observe
			// Paused before the historical patch can expose different
			// DOM. Mounts inserted by that patch capture this state when
			// acquired, so asynchronous setup cannot skip Paused even if
			// it consumes the Stream only after the live view returns.
			setViewState("Paused");
			// NOTE: a transition still animating belongs to the live
			// state this replay is about to paint over. Left running it
			// animates a dead snapshot across the replayed DOM.
			skipPendingViewTransition();
			const replayRenderExit = yield* Effect.exit(render(replayedModel, Option.none(), noOpDispatch, "Replay"));
			if (Exit.isFailure(replayRenderExit)) {
				drainMountEvents();
				if (isPausedNow()) {
					// NOTE: the failed patch may already have changed the
					// DOM. Repaint the Model at the store's previous paused
					// index before returning the failure. If that Model no
					// longer renders either, resume the store so its normal
					// live frame becomes the single recovery path.
					const rollbackExit = yield* Effect.exit(render(previousRenderedModel, Option.none(), noOpDispatch, "Replay"));
					drainMountEvents();
					if (Exit.isFailure(rollbackExit)) {
						yield* resumeDevTools;
					}
				} else {
					// NOTE: a failed first jump leaves the store live. Keep
					// Mounts Paused through the recovery patch, which
					// publishes Live only after the live DOM is restored.
					yield* Effect.sync(() => __foldkitBrandViewResult((scheduleRenderFrame(true)), "../foldkit-r11-r19-prototype-20261108.OnQh5N/baseline/packages/foldkit/src/runtime/renderer.ts#anonymous~19"));
				}
				return __foldkitBrandViewResult((yield* Effect.failCause(replayRenderExit.cause)), "../foldkit-r11-r19-prototype-20261108.OnQh5N/baseline/packages/foldkit/src/runtime/renderer.ts#anonymous~18");
			}
			drainMountEvents();
			// NOTE: a replay paints a past Model, so it owns the DOM on
			// screen until the next live frame. Leaving
			// `lastRenderedModel` on the pre-pause Model would hand the
			// `viewTransition` predicate a `previousModel` describing a
			// DOM that no longer exists, and the frame `resume`
			// schedules would animate the wrong direction out of the
			// wrong snapshot.
			lastRenderedModel = replayedModel;
			// NOTE: the Message that dirtied the pre-pause frame does not
			// describe this repaint. Clearing it means the frame `resume`
			// schedules renders plainly, matching the documented rule
			// that time-travel never animates.
			maybeLastDirtyMessage = Option.none();
		})), "../foldkit-r11-r19-prototype-20261108.OnQh5N/baseline/packages/foldkit/src/runtime/renderer.ts#renderReplay"),
		// NOTE: `resume` calls this after a jumpTo render attached DOM
		// listeners to `noOpDispatch`. Scheduling a frame renders the
		// live model with live dispatch and rebinds listeners.
		markRenderPending: Effect.sync(() => __foldkitBrandViewResult((scheduleRenderFrame(true)), "../foldkit-r11-r19-prototype-20261108.OnQh5N/baseline/packages/foldkit/src/runtime/renderer.ts#anonymous~20"))
	};
	return __foldkitBrandViewResult(({
		crashWith,
		render,
		setLastDirtyMessage,
		scheduleRenderFrame,
		skipPendingViewTransition,
		devToolsRenderBridge
	}), "../foldkit-r11-r19-prototype-20261108.OnQh5N/baseline/packages/foldkit/src/runtime/renderer.ts#anonymous");
})), "../foldkit-r11-r19-prototype-20261108.OnQh5N/baseline/packages/foldkit/src/runtime/renderer.ts#makeRenderer");

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFNBQ0UsT0FDQSxPQUNBLFNBQ0EsUUFDQSxNQUNBLFFBQ0EsaUJBRUs7QUFFUCxTQUdFLG1CQUdBLGlCQUFpQixpQkFDakIsdUJBQXVCLHVCQUN2QixrQkFBa0Isa0JBQ2xCLDRCQUE0Qiw0QkFDNUIscUJBQXFCLHFCQUNyQiwwQ0FBMEMsc0NBQzFDLGdCQUFnQixzQkFDWDtBQUNQLFNBQVMsc0JBQXNCO0FBQy9CLFNBQVMsNkJBQTZCO0FBQ3RDLFNBR0UseUJBQ0EsY0FDQSxvQkFDSztBQUVQLFNBRUUsY0FDQSx1Q0FDSztBQUNQLFNBR0UsY0FDQSx1QkFDSztBQUtQLFNBQVMsZ0JBQWdCO0FBQ3pCLFNBQVMsNkJBQTZCO0FBSXRDLFNBSUUsa0JBQ0EsdUJBQ0s7QUFDUCxTQUlFLHdCQUNBLHlDQUNLOzs7Ozs7Ozs7Ozs7O0FBMERQLE9BQU8sTUFBTSxnQkFBZ0MsRUFDM0MsUUFDQSxXQUNBLE1BQ0EsYUFDQSxnQkFDQSxPQUNBLFNBQ0EsV0FDQSxvQkFDQSxlQUNBLGdCQUNBLG9CQUNBLDZCQUNBLGdCQUNBLFFBQ0EsZ0JBQ0EsZUFDQSxjQUNBLG9EQTRCQSxPQUFPLElBQUksYUFBYTtDQUN0QixNQUFNLEVBQ0osZ0JBQ0Esc0JBQ0Esc0JBQ0Esa0JBQ0EseUJBQ0U7Q0FDSixNQUFNLEVBQ0osY0FDQSxjQUNBLGtCQUNBLGVBQ0EsY0FDQSxhQUNBLGdCQUNBLHlCQUNFO0NBRUosTUFBTSw0QkFBa0M7RUFDdEMsSUFBSSxlQUFlLFFBQVEsZ0JBQWdCLEdBQUc7R0FDNUMsZUFBZSxnQkFBZ0I7RUFDakM7Q0FDRjs7Ozs7Q0FNQSxJQUFJLHlCQUF5Qjs7Ozs7Q0FLN0IsSUFBSSwyQkFBMkI7Ozs7Ozs7Q0FRL0IsSUFBSSxvQkFBMkI7Ozs7OztDQU8vQixJQUFJLDZCQUE2QixPQUFPLEtBQTRCO0NBRXBFLE1BQU0sa0NBQXdDO0VBQzVDLElBQUksT0FBTyxPQUFPLDBCQUEwQixHQUFHO0dBQzdDLE1BQU0sRUFBRSxPQUFPLDBCQUEwQjs7O0dBR3pDLDZCQUE2QixPQUFPLEtBQUs7R0FDekMsc0JBQXNCLE9BQU8sZ0JBQWdCO0dBQzdDLElBQUk7SUFDRixzQkFBc0IsT0FBTyxlQUFlO0dBQzlDLFFBQVEsQ0FHUjtFQUNGO0NBQ0Y7Ozs7O0NBTUEsTUFBTSxZQUF1QixFQUFFLG1CQUFtQixPQUFPLEtBQUssRUFBRTtDQUVoRSxNQUFNLHFCQUNKLG1CQUNBLFdBQ0EsU0FDVTtFQUNWLElBQUk7R0FDRixpQ0FBTyxhQUNMLG1CQUNBLFdBQ0EsV0FDQSxPQUNBLGlCQUFnQjtJQUNkLFVBQVUsb0JBQW9CLE9BQU8sS0FBSyxZQUFZO0dBQ3hELENBQ0Y7RUFDRixTQUFTLE9BQU87R0FDZCxJQUFJO0lBQ0YsTUFBTSxxQkFBcUIsVUFBVTtJQUNyQyxJQUFJLE9BQU8sT0FBTyxrQkFBa0IsR0FBRztLQUNyQyxVQUFVLG9CQUFvQixPQUFPLEtBQ25DLGdDQUFnQyxtQkFBbUIsS0FBSyxDQUMxRDtJQUNGO0dBQ0YsVUFBVTtJQUNSLHFDQUFxQztHQUN2QztHQUNBLE1BQU07RUFDUjtDQUNGOzs7O0NBS0EsSUFBSSx1QkFDRixPQUFPLFVBQVUsa0JBQWtCOzs7Ozs7Ozs7O0NBV3JDLE9BQU8sT0FBTyxjQUFhLG1DQUN6QixPQUFPLElBQUksYUFBYTtFQUN0QixJQUFJLEtBQUssY0FBYyxJQUFJLEdBQUc7R0FDNUIsTUFBTSxvQkFBb0IsVUFBVTtHQUNwQyxPQUFPLE9BQU8sTUFBTSxtQkFBbUI7SUFDckMsd0NBQWMsT0FBTztJQUNyQixTQUFRLDJDQUNOLE9BQU8sV0FBVztLQUNoQixNQUFNLGtCQUFrQixhQUN0QixPQUFPLEtBQUssWUFBWSxHQUN4QixNQUNBLFNBQ0YsQ0FBQyxDQUFDO0tBQ0YsSUFBSSxtQkFBbUIsZ0JBQWdCLFlBQVk7TUFDakQsZ0JBQWdCLFdBQVcsYUFDekIsV0FDQSxlQUNGO01BQ0EsVUFBVSxnQkFBZ0I7S0FDNUI7SUFDRixDQUFDO0dBQ0wsQ0FBQztFQUNIO0VBRUEsT0FBTyxhQUFhO0NBQ3RCLENBQUMsaUhBQ0g7Ozs7Ozs7Ozs7O0NBWUEsTUFBTSxhQUNKLE9BQ0EsMkNBRUEsT0FBTyxXQUFXO0VBQ2hCLElBQUksT0FBTyxXQUFXO0dBQ3BCO0VBQ0Y7RUFDQSxPQUFPLFlBQVk7RUFDbkIsYUFBYSxxQkFBcUI7OztFQUdsQywwQkFBMEI7RUFDMUIsTUFBTSxRQUFRLGNBQWM7RUFDNUIsTUFBTSxXQUFXLE1BQU0sT0FBTyxLQUFLO0VBQ25DLE1BQU0sUUFDSixvQkFBb0IsUUFBUSxXQUFXLElBQUksTUFBTSxPQUFPLFFBQVEsQ0FBQztFQUNuRSxnQkFDRTtHQUFFO0dBQU87R0FBTyxTQUFTO0VBQWEsR0FDdEMsT0FDQSxXQUNBLFdBQ0EsY0FDRjtFQUNBLG9CQUFvQjtDQUN0QixDQUFDOzs7Ozs7O0NBUUgsSUFBSSx3QkFBd0IsT0FBTyxLQUFjO0NBRWpELE1BQU0sdUJBQXVCLFlBQTJCO0VBQ3RELHdCQUF3QixPQUFPLEtBQUssT0FBTztDQUM3QztDQUVBLE1BQU0sZ0JBQ0osU0FDQSxjQUNTOztFQUVULGVBQWUsU0FBb0IsU0FBUztDQUM5QztDQUVBLE1BQU0saUJBQ0osU0FDQSx3Q0FHQSxxQkFBcUIsU0FBb0IsU0FBUztDQUVwRCxNQUFNLFdBQVc7RUFBRTtFQUFlO0NBQWE7Ozs7Ozs7O0NBUy9DLE1BQU0sbUJBQXFDLDJCQUEyQjtDQUN0RSxNQUFNLG1CQUFtQixJQUFJLElBQzNCLE9BQU8sS0FBSSxvQ0FBUyxNQUFNLHdJQUF3QixDQUNwRDtDQUVBLE1BQU0sd0JBQXdCLElBQUksSUFBVztDQUU3QyxNQUFNLG9DQUFvQyxTQUE2QjtFQUNyRSxJQUFJLFNBQVMsTUFBTTtHQUNqQjtFQUNGO0VBRUEsSUFBSTtFQUNKLE1BQU0sUUFBUSxTQUFzQjtHQUNsQyxNQUFNLEVBQUUsYUFBYTtHQUNyQixJQUFJLGFBQWEsYUFBYSxNQUFNLGdCQUFnQixRQUFRLEdBQUc7SUFDN0QsSUFBSSxzQkFBc0IsSUFBSSxJQUFJLEdBQUc7S0FDbkM7SUFDRjtJQUNBLHNCQUFzQixJQUFJLElBQUk7R0FDaEM7O0dBR0EsTUFBTSxTQUFTLEtBQUssT0FBTztHQUczQixNQUFNLGVBQWUsU0FBUztHQUM5QixJQUNFLFdBQVcsYUFDWCxpQkFBaUIsYUFDakIsQ0FBQyxpQkFBaUIsSUFBSSxZQUFZLEdBQ2xDO0lBQ0EsWUFBWSxJQUFJLElBQW9CO0lBQ3BDLFFBQVEsSUFBSSxjQUFjLE9BQU8sSUFBSTtHQUN2QztHQUVBLElBQUksYUFBYSxXQUFXO0lBQzFCLEtBQUssTUFBTSxTQUFTLFVBQVU7S0FDNUIsSUFBSSxDQUFDLFVBQVUsU0FBUyxLQUFLLEdBQUc7TUFDOUIsS0FBSyxLQUFLO0tBQ1o7SUFDRjtHQUNGO0VBQ0Y7RUFDQSxJQUFJO0dBQ0YsS0FBSyxJQUFJO0VBQ1gsVUFBVTtHQUNSLHNCQUFzQixNQUFNO0VBQzlCO0VBRUEsSUFBSSxZQUFZLFdBQVc7R0FDekI7RUFDRjtFQUVBLE1BQU0sUUFBUSxXQUFXLE1BQU0sS0FBSyxRQUFRLE9BQU8sQ0FBQyxDQUFDLENBQUMsS0FBSztFQUMzRCxNQUFNLElBQUksTUFDUixzRkFBc0YsTUFBTSxLQUFLLElBQUksRUFBRSxNQUNyRywwRUFDSjtDQUNGOzs7Ozs7Q0FPQSxNQUFNLGNBQ0osT0FDQSxjQUNBLGlCQUNBLGVBQ0EsZUFDUztFQUNULE1BQU0sa0JBQWtCLE9BQU8sY0FDN0IsYUFDQSxtQ0FBUSxTQUFTLHNIQUNuQjtFQUNBLE1BQU0sb0JBQW9CLE9BQU8sUUFDL0IsaURBQ00sNkhBQ1I7RUFDQSxNQUFNLHFCQUFxQixPQUFPLFFBQ2hDLGlEQUNNLCtIQUNSO0VBQ0EsTUFBTSxDQUFDLGNBQWMscUJBQXFCLGlCQUN4Qyx5QkFDTTtHQUNKLGdCQUFnQixnQkFBZ0I7R0FDaEMsZUFDRSxnQkFBZ0IsY0FDaEIsZUFDQSxrQkFDQSxVQUNGO0dBRUEsSUFBSTtJQUNGLGlDQUFPLEtBQUssT0FBTyxXQUFXO0dBQ2hDLFVBQVU7SUFDUixpQkFBaUI7R0FDbkI7RUFDRixDQUNGO0VBQ0EsTUFBTSxFQUFFLE1BQU0sY0FBYztFQUM1QixpQ0FBaUMsU0FBUztFQUUxQyxnQkFDRSxtQkFDQSxvQkFDQyxZQUFZLDJDQUFpQjtHQUM1QixNQUFNO0dBQ047R0FDQSxTQUFTO0dBQ1Q7R0FDQTtFQUNGLG1IQUNGO0VBRUEsTUFBTSxFQUFFLHNCQUFzQjtFQUU5QixNQUFNLENBQUMsY0FBYyxzQkFBc0IsaUJBQ3pDLDBCQUNNO0dBQ0osSUFDRSxPQUFPLE9BQU8saUJBQWlCLEtBQy9CLHlCQUF5QixNQUN6QjtJQUNBLE1BQU0sZ0JBQWdCO0lBQ3RCLHVCQUF1Qjs7Ozs7Ozs7O0lBU3ZCLGNBQWMsZ0JBQWdCLHFCQUFxQjs7Ozs7SUFLbkQsaUNBQU8sZUFDTCxlQUNBLFdBQ0EsaUJBQWlCLFlBQ2pCLFdBQVcsRUFDYjtHQUNGO0dBQ0EsaUNBQU8sa0JBQ0wsbUJBQ0EsV0FDQSxpQkFBaUIsVUFDbkI7RUFDRixDQUNGO0VBQ0EsVUFBVSxvQkFBb0IsT0FBTyxLQUFLLFlBQVk7RUFFdEQsZ0JBQ0Usb0JBQ0EscUJBQ0MsWUFBWSwyQ0FBaUI7R0FDNUIsTUFBTTtHQUNOO0dBQ0EsU0FBUztHQUNUO0dBQ0E7RUFDRixtSEFDRjtFQUVBLElBQUksZ0JBQWdCO0dBQ2xCLHNCQUFzQixjQUFjLGFBQWEsR0FBRztFQUN0RDtFQUVBLElBQUksWUFBWSxLQUFLO0dBQ25CLG9CQUFvQixTQUFTLGFBQWEsR0FBRztFQUMvQztDQUNGOzs7Ozs7OztDQVNBLE1BQU0sVUFDSixPQUNBLGNBQ0Esa0JBQTJDLFVBQzNDLGFBQXlCLHFDQUV6QixPQUFPLElBQUksYUFBYTtFQUN0QixPQUFPLG1CQUFtQjtFQUMxQixNQUFNLGdCQUFnQixRQUFRLElBQzVCLFFBQVEsSUFDTixRQUFRLElBQUksZ0JBQWdCLFVBQVUsZUFBZSxHQUNyRCxjQUNBLFlBQ0YsR0FDQSxjQUNBLFlBQ0Y7RUFDQSxJQUFJLGVBQWUsVUFBVTtHQUMzQixzQkFBc0I7RUFDeEI7RUFDQSxXQUNFLE9BQ0EsY0FDQSxpQkFDQSxlQUNBLFVBQ0Y7Q0FDRixDQUFDLENBQUMsQ0FBQyxLQUNELE9BQU8sU0FDTCxPQUFPLFdBQVc7RUFDaEIsT0FBTyxtQkFBbUI7RUFDMUIsb0JBQW9CO0VBQ3BCLHFCQUFxQjtDQUN2QixDQUFDLENBQ0gsQ0FDRjtDQUVGLE1BQU0sb0JBQW9CLFFBQVEsSUFDaEMsUUFBUSxJQUNOLFFBQVEsSUFBSSxnQkFBZ0IsVUFBVSxRQUFRLEdBQzlDLGNBQ0EsWUFDRixHQUNBLGNBQ0EsWUFDRjs7O0NBSUEsTUFBTSx5REFDSixxQkFBcUIsS0FBSyxDQUFDLE9BQU8scUJBQXFCLENBQUMsT0FBTzs7Ozs7Ozs7O0NBVWpFLE1BQU0sMkJBQWlDO0VBQ3JDLE9BQU8sbUJBQW1COzs7OztFQUsxQixNQUFNLGdCQUFnQixjQUFjO0VBQ3BDLE1BQU0sYUFBYSxjQUFjLE1BQU07RUFDdkMsSUFBSSxZQUFZOzs7O0dBSWQsd0JBQXdCLE9BQU8sS0FBSztFQUN0QztFQUNBLElBQUk7R0FDRixXQUNFLGNBQWMsR0FDZCx1QkFDQSxVQUNBLG1CQUNBLE1BQ0Y7Ozs7R0FJQSxvQkFBb0I7OztHQUdwQixhQUFhLE1BQU07R0FDbkIscUJBQXFCO0VBQ3ZCLFNBQVMsT0FBTztHQUNkLE9BQU8sUUFBUSxVQUFVLE1BQU0sSUFBSSxLQUFLLEdBQUcscUJBQXFCLENBQUM7RUFDbkUsVUFBVTtHQUNSLE9BQU8sbUJBQW1CO0VBQzVCOzs7OztFQUtBLHFCQUFxQjs7OztFQUlyQixvQkFBb0I7Q0FDdEI7Ozs7Ozs7Ozs7O0NBWUEsTUFBTSw0QkFDSixhQUNZO0VBQ1osSUFBSSxjQUFjLE1BQU0sVUFBVTtHQUNoQyxpQ0FBTztFQUNUO0VBQ0EsSUFBSSxTQUFTLG1CQUFtQixTQUFTO0dBQ3ZDLGlDQUFPO0VBQ1Q7RUFDQSxJQUFJLE9BQU8sT0FBTyxxQkFBcUIsR0FBRztHQUN4QyxpQ0FBTztFQUNUO0VBQ0EsTUFBTSxnQkFBZ0IsdUJBQXVCLFNBQVMsUUFBUTtHQUM1RCxlQUFlO0dBQ2YsT0FBTyxjQUFjO0dBQ3JCLFNBQVMsc0JBQXNCO0VBQ2pDLENBQUM7RUFDRCxJQUFJLE9BQU8sT0FBTyxhQUFhLEdBQUc7R0FDaEMsaUNBQU87RUFDVDs7Ozs7RUFLQSwwQkFBMEI7RUFDMUIsSUFBSTtHQUNGLE1BQU0sU0FBUztJQUNiLGVBQWU7SUFDZixRQUFRO0dBQ1Y7R0FDQSxNQUFNLFNBQVMsU0FBUywwQkFBMEI7SUFDaEQsSUFBSSxPQUFPLGlCQUFpQixPQUFPLFFBQVE7S0FDekM7SUFDRjtJQUNBLE9BQU8sU0FBUzs7O0lBSWhCLElBQUksdUJBQXVCLEdBQUc7S0FDNUIsMEJBQTBCO0tBQzFCLG9CQUFvQjtLQUNwQjtJQUNGOzs7Ozs7SUFNQSxJQUNFLE9BQU8scUJBQ1AsT0FBTyxhQUNQLFlBQVksS0FDWixjQUFjLE1BQU0sVUFDcEI7S0FDQSxvQkFBb0I7S0FDcEI7SUFDRjtJQUNBLG1CQUFtQjtHQUNyQixHQUFHLGNBQWMsTUFBTSxVQUFVO0dBQ2pDLDZCQUE2QixPQUFPLEtBQUs7SUFBRTtJQUFRO0dBQU8sQ0FBQztHQUMzRCxrQ0FBa0MsTUFBTTtHQUN4QyxpQ0FBTztFQUNULFFBQVE7Ozs7R0FJTixpQ0FBTztFQUNUO0NBQ0Y7Ozs7O0NBTUEsTUFBTSx5QkFBK0I7O0VBRW5DLElBQUksdUJBQXVCLEdBQUc7R0FDNUIsc0JBQXNCLGdCQUFnQjtHQUN0QztFQUNGO0VBQ0EseUJBQXlCO0VBQ3pCLE1BQU0sc0JBQXNCO0VBQzVCLDJCQUEyQjs7O0VBRzNCLElBQUksT0FBTyxtQkFBbUI7R0FDNUIsb0JBQW9CO0dBQ3BCO0VBQ0Y7OztFQUdBLGlCQUFpQjs7Ozs7RUFLakIsSUFBSSxPQUFPLFdBQVc7R0FDcEIsb0JBQW9CO0dBQ3BCO0VBQ0Y7RUFDQSxJQUFJLFlBQVksR0FBRztHQUNqQixvQkFBb0I7R0FDcEI7RUFDRjtFQUNBLElBQUksY0FBYyxNQUFNLFlBQVksQ0FBQyxxQkFBcUI7R0FDeEQsb0JBQW9CO0dBQ3BCO0VBQ0Y7Ozs7Ozs7RUFPQSxJQUFJLE9BQU8sT0FBTywyQkFBMkIsR0FBRztHQUM5QyxtQkFBbUI7R0FDbkI7RUFDRjtFQUNBLElBQUksQ0FBQyx5QkFBeUIsNEJBQTRCLEtBQUssR0FBRztHQUNoRSxtQkFBbUI7RUFDckI7Q0FDRjs7Ozs7Q0FNQSxNQUFNLHVCQUNKLHNCQUErQixVQUN0QjtFQUNULElBQUkscUJBQXFCO0dBQ3ZCLDJCQUEyQjtFQUM3QjtFQUNBLElBQUksd0JBQXdCO0dBQzFCO0VBQ0Y7RUFDQSx5QkFBeUI7RUFDekIsZUFBZSxrQkFBa0I7RUFDakMsc0JBQXNCLGdCQUFnQjtDQUN4QztDQUVBLE1BQU0sdUJBQTZDOzs7Ozs7OztFQVFqRCxlQUFjLG9DQUNaLE9BQU8sSUFBSSxhQUFhOztHQUV0QixNQUFNLGdCQUFnQjtHQUN0QixNQUFNLHdCQUF3Qjs7Ozs7O0dBTTlCLGFBQWEsUUFBUTs7OztHQUlyQiwwQkFBMEI7R0FDMUIsTUFBTSxtQkFBbUIsT0FBTyxPQUFPLEtBQ3JDLE9BQU8sZUFBZSxPQUFPLEtBQUssR0FBRyxjQUFjLFFBQVEsQ0FDN0Q7R0FDQSxJQUFJLEtBQUssVUFBVSxnQkFBZ0IsR0FBRztJQUNwQyxpQkFBaUI7SUFDakIsSUFBSSxZQUFZLEdBQUc7Ozs7OztLQU1qQixNQUFNLGVBQWUsT0FBTyxPQUFPLEtBQ2pDLE9BQ0UsdUJBQ0EsT0FBTyxLQUFLLEdBQ1osY0FDQSxRQUNGLENBQ0Y7S0FDQSxpQkFBaUI7S0FDakIsSUFBSSxLQUFLLFVBQVUsWUFBWSxHQUFHO01BQ2hDLE9BQU87S0FDVDtJQUNGLE9BQU87Ozs7S0FJTCxPQUFPLE9BQU8scUNBQVcsb0JBQW9CLElBQUksa0hBQUM7SUFDcEQ7SUFDQSxpQ0FBTyxPQUFPLE9BQU8sVUFBVSxpQkFBaUIsS0FBSztHQUN2RDtHQUNBLGlCQUFpQjs7Ozs7Ozs7R0FRakIsb0JBQW9COzs7OztHQUtwQix3QkFBd0IsT0FBTyxLQUFLO0VBQ3RDLENBQUM7Ozs7RUFJSCxtQkFBbUIsT0FBTyxxQ0FBVyxvQkFBb0IsSUFBSSxrSEFBQztDQUNoRTtDQUVBLGlDQUFPO0VBQ0w7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0Y7QUFDRixDQUFDIiwibmFtZXMiOltdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJyZW5kZXJlci50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuICBBcnJheSxcbiAgQ2F1c2UsXG4gIENvbnRleHQsXG4gIEVmZmVjdCxcbiAgRXhpdCxcbiAgT3B0aW9uLFxuICBQcmVkaWNhdGUsXG4gIHR5cGUgU2NvcGUsXG59IGZyb20gJ2VmZmVjdCdcblxuaW1wb3J0IHtcbiAgdHlwZSBCb3VuZGFyeVJlZ2lzdHJ5LFxuICB0eXBlIERvY3VtZW50LFxuICBGT0xES0lUX01PVU5UX0tFWSxcbiAgdHlwZSBGb2xka2l0TW91bnRNYXJrZXIsXG4gIHR5cGUgSHRtbEJ1aWxkZXIsXG4gIF9fYmVnaW5SZW5kZXIgYXMgYmVnaW5IdG1sUmVuZGVyLFxuICBfX2JlZ2luUmVwbGF5UmVuZGVyIGFzIGJlZ2luUmVwbGF5SHRtbFJlbmRlcixcbiAgX19jbGVhclJ1bnRpbWUgYXMgY2xlYXJIdG1sUnVudGltZSxcbiAgX19jcmVhdGVCb3VuZGFyeVJlZ2lzdHJ5IGFzIGNyZWF0ZUh0bWxCb3VuZGFyeVJlZ2lzdHJ5LFxuICBfX2VuZFJlcGxheVJlbmRlciBhcyBlbmRSZXBsYXlIdG1sUmVuZGVyLFxuICBfX2ZsdXNoUmVwbGF5VW5tb3VudHNBZnRlclBhdGNoRmFpbHVyZSBhcyBmbHVzaFJlcGxheVVubW91bnRzQWZ0ZXJQYXRjaEZhaWx1cmUsXG4gIF9fc2V0UnVudGltZSBhcyBzZXRIdG1sUnVudGltZSxcbn0gZnJvbSAnLi4vaHRtbC9pbmRleC5qcydcbmltcG9ydCB7IF9faHlkcmF0ZVZOb2RlIH0gZnJvbSAnLi4vaHlkcmF0ZS5qcydcbmltcG9ydCB7IEZPTERLSVRfQVBQX0FUVFJJQlVURSB9IGZyb20gJy4uL2h5ZHJhdGlvbk1hcmtlci5qcydcbmltcG9ydCB7XG4gIHR5cGUgQW55TW91bnRIYW5kbGVyLFxuICB0eXBlIExheWVyZWRNb3VudERlZmluaXRpb24sXG4gIE1vdW50UmVnaXN0cmF0aW9uVHlwZUlkLFxuICBNb3VudFJ1bnRpbWUsXG4gIE1vdW50VHJhY2tlcixcbn0gZnJvbSAnLi4vbW91bnQvaW5kZXguanMnXG5pbXBvcnQgdHlwZSB7IENvbW1pdE5vdGlmaWVyIH0gZnJvbSAnLi4vcmVuZGVyL2NvbW1pdC5qcydcbmltcG9ydCB7XG4gIFZOb2RlLFxuICBfX3BhdGNoVk5vZGUsXG4gIF9fcmVjb3ZlclZOb2RlQWZ0ZXJQYXRjaEZhaWx1cmUsXG59IGZyb20gJy4uL3Zkb20uanMnXG5pbXBvcnQge1xuICB0eXBlIENyYXNoQ29uZmlnLFxuICB0eXBlIFZOb2RlU2xvdCxcbiAgbm9PcERpc3BhdGNoLFxuICByZW5kZXJDcmFzaFZpZXcsXG59IGZyb20gJy4vY3Jhc2hVSS5qcydcbmltcG9ydCB0eXBlIHtcbiAgRGV2VG9vbHNJbnRlZ3JhdGlvbixcbiAgRGV2VG9vbHNSZW5kZXJCcmlkZ2UsXG59IGZyb20gJy4vZGV2VG9vbHNJbnRlZ3JhdGlvbi5qcydcbmltcG9ydCB7IERpc3BhdGNoIH0gZnJvbSAnLi9kaXNwYXRjaC5qcydcbmltcG9ydCB7IGFwcGx5RG9jdW1lbnRNZXRhZGF0YSB9IGZyb20gJy4vZG9jdW1lbnRNZXRhZGF0YS5qcydcbmltcG9ydCB0eXBlIHsgRHVwbGljYXRlSWRTY2FubmVyIH0gZnJvbSAnLi9kdXBsaWNhdGVJZFNjYW5uZXIuanMnXG5pbXBvcnQgdHlwZSB7IE1lc3NhZ2VRdWV1ZSB9IGZyb20gJy4vbWVzc2FnZVF1ZXVlLmpzJ1xuaW1wb3J0IHR5cGUgeyBSdW50aW1lU3RhdHVzIH0gZnJvbSAnLi9ydW50aW1lU3RhdHVzLmpzJ1xuaW1wb3J0IHtcbiAgdHlwZSBSZXNvbHZlZFNsb3dQaGFzZUNvbmZpZyxcbiAgdHlwZSBTbG93UGF0Y2hDb250ZXh0LFxuICB0eXBlIFNsb3dWaWV3Q29udGV4dCxcbiAgbWVhc3VyZVNsb3dQaGFzZSxcbiAgcmVwb3J0U2xvd1BoYXNlLFxufSBmcm9tICcuL3Nsb3dQaGFzZS5qcydcbmltcG9ydCB7XG4gIHR5cGUgU3RhcnRWaWV3VHJhbnNpdGlvbixcbiAgdHlwZSBWaWV3VHJhbnNpdGlvbkNvbmZpZyxcbiAgdHlwZSBWaWV3VHJhbnNpdGlvbkhhbmRsZSxcbiAgX19kZWNpZGVWaWV3VHJhbnNpdGlvbixcbiAgX19zaWxlbmNlVmlld1RyYW5zaXRpb25SZWplY3Rpb25zLFxufSBmcm9tICcuL3ZpZXdUcmFuc2l0aW9uLmpzJ1xuXG4vKiogVGhlIGB2aWV3VHJhbnNpdGlvbmAgY29uZmlnIHJlc29sdmVkIGFnYWluc3QgdGhlIHJ1bm5pbmcgYnJvd3NlcjogdGhlXG4gKiAgcHJlZGljYXRlLCB0aGUgZmVhdHVyZS1kZXRlY3RlZCBgc3RhcnRWaWV3VHJhbnNpdGlvbmAsIGFuZCB0aGUgY2FjaGVkXG4gKiAgcmVkdWNlZC1tb3Rpb24gcXVlcnkuIEFic2VudCAodGhlIHJ1bnRpbWUgaG9sZHMgYE9wdGlvbi5ub25lKClgKSB3aGVuIHRoZVxuICogIGFwcCBkaWQgbm90IGNvbmZpZ3VyZSBgdmlld1RyYW5zaXRpb25gIG9yIHRoZSBicm93c2VyIGxhY2tzIHRoZSBBUEkuICovXG5leHBvcnQgdHlwZSBSZXNvbHZlZFZpZXdUcmFuc2l0aW9uPE1vZGVsLCBNZXNzYWdlPiA9IFJlYWRvbmx5PHtcbiAgZGVjaWRlOiBWaWV3VHJhbnNpdGlvbkNvbmZpZzxNb2RlbCwgTWVzc2FnZT5cbiAgc3RhcnRWaWV3VHJhbnNpdGlvbjogU3RhcnRWaWV3VHJhbnNpdGlvblxuICByZWR1Y2VkTW90aW9uUXVlcnk6IE1lZGlhUXVlcnlMaXN0XG59PlxuXG50eXBlIFJlbmRlck1vZGUgPSAnTGl2ZScgfCAnUmVwbGF5J1xuXG50eXBlIFBlbmRpbmdWaWV3VHJhbnNpdGlvbiA9IFJlYWRvbmx5PHtcbiAgaGFuZGxlOiBWaWV3VHJhbnNpdGlvbkhhbmRsZVxuICB1cGRhdGU6IHtcbiAgICBpc0ludmFsaWRhdGVkOiBib29sZWFuXG4gICAgZGlkUnVuOiBib29sZWFuXG4gIH1cbn0+XG5cbi8qKlxuICogV2hhdCB0aGUgYm9vdCBjbG9zdXJlIHVzZXMgZnJvbSB0aGUgcmVuZGVyIHNpZGUuIGBjcmFzaFdpdGhgIHBhaW50cyB0aGVcbiAqIGNyYXNoIHZpZXcgYW5kIHN0b3BzIHRoZSBydW50aW1lLCBgcmVuZGVyYCBydW5zIG9uZSBsaXZlIHJlbmRlciAodGhlIGJvb3RcbiAqIGNhbGxzIGl0IGZvciB0aGUgZmlyc3QgcGFpbnQpLCBgc2V0TGFzdERpcnR5TWVzc2FnZWAgcmVjb3JkcyB0aGUgTWVzc2FnZVxuICogdGhlIG5leHQgZnJhbWUgaXMgYXR0cmlidXRlZCB0bywgYHNjaGVkdWxlUmVuZGVyRnJhbWVgIGFza3MgZm9yIGEgZnJhbWUsXG4gKiBgc2tpcFBlbmRpbmdWaWV3VHJhbnNpdGlvbmAgY3V0cyBzaG9ydCBhIHRyYW5zaXRpb24gdGhlIGJyb3dzZXIgaXMgc3RpbGxcbiAqIGFuaW1hdGluZywgYW5kIGBkZXZUb29sc1JlbmRlckJyaWRnZWAgaXMgd2hhdCB0aGUgRGV2VG9vbHMgc3RvcmUgbmVlZHMgdG9cbiAqIHJlcGFpbnQgZHVyaW5nIHRpbWUgdHJhdmVsLlxuICovXG5leHBvcnQgdHlwZSBSZW5kZXJlcjxNb2RlbCwgTWVzc2FnZT4gPSBSZWFkb25seTx7XG4gIGNyYXNoV2l0aDogKFxuICAgIGNhdXNlOiBDYXVzZS5DYXVzZTxuZXZlcj4sXG4gICAgbWF5YmVNZXNzYWdlOiBPcHRpb24uT3B0aW9uPE1lc3NhZ2U+LFxuICApID0+IEVmZmVjdC5FZmZlY3Q8dm9pZD5cbiAgcmVuZGVyOiAoXG4gICAgbW9kZWw6IE1vZGVsLFxuICAgIG1heWJlTWVzc2FnZTogT3B0aW9uLk9wdGlvbjxNZXNzYWdlPixcbiAgKSA9PiBFZmZlY3QuRWZmZWN0PHZvaWQ+XG4gIHNldExhc3REaXJ0eU1lc3NhZ2U6IChtZXNzYWdlOiBNZXNzYWdlKSA9PiB2b2lkXG4gIHNjaGVkdWxlUmVuZGVyRnJhbWU6ICgpID0+IHZvaWRcbiAgc2tpcFBlbmRpbmdWaWV3VHJhbnNpdGlvbjogKCkgPT4gdm9pZFxuICBkZXZUb29sc1JlbmRlckJyaWRnZTogRGV2VG9vbHNSZW5kZXJCcmlkZ2Vcbn0+XG5cbi8qKlxuICogQnVpbGRzIHRoZSByZW5kZXIgc2lkZSBvZiBvbmUgcnVudGltZTogdGhlIGN1cnJlbnQgdm5vZGUgYW5kLCB3aGVuXG4gKiBoeWRyYXRpbmcsIHRoZSBzZXJ2ZXItcmVuZGVyZWQgcm9vdCB0aGUgZmlyc3QgcmVuZGVyIGFkb3B0cywgdGhlIGNyYXNoXG4gKiByZW5kZXJlciwgdGhlIGBEaXNwYXRjaGAgc2VydmljZSB0aGUgdmlldyBiaW5kcyBoYW5kbGVycyB0bywgdGhlXG4gKiBzeW5jaHJvbm91cyByZW5kZXIgdGhhdCBydW5zIHRoZSB2aWV3IGFuZCBwYXRjaGVzIHRoZSBET00sIHRoZSByZW5kZXJcbiAqIGZyYW1lIHRoYXQgcnVucyBpbiBgcmVxdWVzdEFuaW1hdGlvbkZyYW1lYCwgYW5kIHRoZSBWaWV3IFRyYW5zaXRpb25cbiAqIHRoYXQgZnJhbWUgbWF5IHJ1biBpbnNpZGUuIEl0IGFsc28gcmVnaXN0ZXJzIHRoZSB0ZWFyZG93biBmaW5hbGl6ZXJcbiAqIHRoYXQgcGF0Y2hlcyB0aGUgdHJlZSBhd2F5IGFuZCByZXN0b3JlcyB0aGUgY29udGFpbmVyLCBzbyBidWlsZCBpdFxuICogYmVmb3JlIGZvcmtpbmcgdGhlIHBlcnBldHVhbCBmaWJlcnM6IHNjb3BlIGZpbmFsaXplcnMgcnVuXG4gKiBsYXN0LXJlZ2lzdGVyZWQgZmlyc3QsIGFuZCB0aGUgY29udGFpbmVyIG11c3QgYmUgcmVzdG9yZWQgb25seSBhZnRlclxuICogdGhvc2UgZmliZXJzIGFyZSBpbnRlcnJ1cHRlZC5cbiAqL1xuZXhwb3J0IGNvbnN0IG1ha2VSZW5kZXJlciA9IDxNb2RlbCwgTWVzc2FnZT4oe1xuICBzdGF0dXMsXG4gIGNvbnRhaW5lcixcbiAgdmlldyxcbiAgaHRtbEJ1aWxkZXIsXG4gIG1hbmFnZURvY3VtZW50LFxuICBjcmFzaCxcbiAgYnVpbGRJZCxcbiAgaW5pdE1vZGVsLFxuICBtYXliZUh5ZHJhdGlvblJvb3QsXG4gIG1heWJlU2xvd1ZpZXcsXG4gIG1heWJlU2xvd1BhdGNoLFxuICBkdXBsaWNhdGVJZFNjYW5uZXIsXG4gIG1heWJlUmVzb2x2ZWRWaWV3VHJhbnNpdGlvbixcbiAgY29tbWl0Tm90aWZpZXIsXG4gIG1vdW50cyxcbiAgcnVudGltZUNvbnRleHQsXG4gIHJlYWRMaXZlTW9kZWwsXG4gIG1lc3NhZ2VRdWV1ZSxcbiAgZGV2VG9vbHNJbnRlZ3JhdGlvbixcbn06IFJlYWRvbmx5PHtcbiAgc3RhdHVzOiBSdW50aW1lU3RhdHVzXG4gIGNvbnRhaW5lcjogSFRNTEVsZW1lbnRcbiAgdmlldzogKG1vZGVsOiBNb2RlbCwgaDogSHRtbEJ1aWxkZXI8TWVzc2FnZSwgQW55TW91bnRIYW5kbGVyPikgPT4gRG9jdW1lbnRcbiAgaHRtbEJ1aWxkZXI6IEh0bWxCdWlsZGVyPE1lc3NhZ2UsIEFueU1vdW50SGFuZGxlcj5cbiAgbWFuYWdlRG9jdW1lbnQ6IGJvb2xlYW5cbiAgY3Jhc2g6IENyYXNoQ29uZmlnPE1vZGVsLCBNZXNzYWdlPiB8IHVuZGVmaW5lZFxuICBidWlsZElkOiBzdHJpbmcgfCB1bmRlZmluZWRcbiAgaW5pdE1vZGVsOiBNb2RlbFxuICBtYXliZUh5ZHJhdGlvblJvb3Q6IE9wdGlvbi5PcHRpb248SFRNTEVsZW1lbnQ+XG4gIG1heWJlU2xvd1ZpZXc6IE9wdGlvbi5PcHRpb248XG4gICAgUmVzb2x2ZWRTbG93UGhhc2VDb25maWc8U2xvd1ZpZXdDb250ZXh0PE1vZGVsLCBNZXNzYWdlPj5cbiAgPlxuICBtYXliZVNsb3dQYXRjaDogT3B0aW9uLk9wdGlvbjxcbiAgICBSZXNvbHZlZFNsb3dQaGFzZUNvbmZpZzxTbG93UGF0Y2hDb250ZXh0PE1vZGVsLCBNZXNzYWdlPj5cbiAgPlxuICBkdXBsaWNhdGVJZFNjYW5uZXI6IER1cGxpY2F0ZUlkU2Nhbm5lciB8IHVuZGVmaW5lZFxuICBtYXliZVJlc29sdmVkVmlld1RyYW5zaXRpb246IE9wdGlvbi5PcHRpb248XG4gICAgUmVzb2x2ZWRWaWV3VHJhbnNpdGlvbjxNb2RlbCwgTWVzc2FnZT5cbiAgPlxuICBjb21taXROb3RpZmllcjogQ29tbWl0Tm90aWZpZXJcbiAgbW91bnRzOiBSZWFkb25seUFycmF5PExheWVyZWRNb3VudERlZmluaXRpb24+XG4gIHJ1bnRpbWVDb250ZXh0OiBDb250ZXh0LkNvbnRleHQ8bmV2ZXI+XG4gIHJlYWRMaXZlTW9kZWw6ICgpID0+IE1vZGVsXG4gIG1lc3NhZ2VRdWV1ZTogTWVzc2FnZVF1ZXVlPE1lc3NhZ2UsIHVua25vd24+XG4gIGRldlRvb2xzSW50ZWdyYXRpb246IERldlRvb2xzSW50ZWdyYXRpb248TW9kZWwsIE1lc3NhZ2U+XG59Pik6IEVmZmVjdC5FZmZlY3Q8UmVuZGVyZXI8TW9kZWwsIE1lc3NhZ2U+LCBuZXZlciwgU2NvcGUuU2NvcGU+ID0+XG4gIEVmZmVjdC5nZW4oZnVuY3Rpb24qICgpIHtcbiAgICBjb25zdCB7XG4gICAgICBlbnF1ZXVlTWVzc2FnZSxcbiAgICAgIGVucXVldWVNZXNzYWdlRWZmZWN0LFxuICAgICAgZHJhaW5QZW5kaW5nTWVzc2FnZXMsXG4gICAgICByZXNldERyYWluQnVkZ2V0LFxuICAgICAgaXNBbnlNZXNzYWdlRGVmZXJyZWQsXG4gICAgfSA9IG1lc3NhZ2VRdWV1ZVxuICAgIGNvbnN0IHtcbiAgICAgIG1vdW50VHJhY2tlcixcbiAgICAgIG1vdW50UnVudGltZSxcbiAgICAgIGRyYWluTW91bnRFdmVudHMsXG4gICAgICByZWFkVmlld1N0YXRlLFxuICAgICAgc2V0Vmlld1N0YXRlLFxuICAgICAgaXNQYXVzZWROb3csXG4gICAgICByZXN1bWVEZXZUb29scyxcbiAgICAgIGF0dGFjaFJlbmRlcmVkTW91bnRzLFxuICAgIH0gPSBkZXZUb29sc0ludGVncmF0aW9uXG5cbiAgICBjb25zdCBzZXR0bGVQZW5kaW5nQ29tbWl0ID0gKCk6IHZvaWQgPT4ge1xuICAgICAgaWYgKGNvbW1pdE5vdGlmaWVyLnNlcnZpY2UuaXNDb21taXRQZW5kaW5nKCkpIHtcbiAgICAgICAgY29tbWl0Tm90aWZpZXIubm90aWZ5Q29tbWl0dGVkKClcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBOT1RFOiBgaXNSZW5kZXJGcmFtZVNjaGVkdWxlZGAgY2xlYXJzIHdoZW4gdGhlIGZyYW1lIGNhbGxiYWNrXG4gICAgLy8gc3RhcnRzLCB3aGljaCBvbiB0aGUgVmlldyBUcmFuc2l0aW9uIHBhdGggaXMgYmVmb3JlIHRoZSBwYXRjaCBydW5zLlxuICAgIC8vIGBjb21taXROb3RpZmllcmAgdHJhY2tzIHRoZSBwYXRjaCBpdHNlbGYsIHNvIGBSZW5kZXIuYWZ0ZXJDb21taXRgXG4gICAgLy8gd2FpdHMgZm9yIHRoZSBjb21taXQgcmF0aGVyIHRoYW4gZm9yIHRoZSBmcmFtZSB0aGF0IHNjaGVkdWxlZCBpdC5cbiAgICBsZXQgaXNSZW5kZXJGcmFtZVNjaGVkdWxlZCA9IGZhbHNlXG4gICAgLy8gTk9URTogcmVzdW1lIGNsZWFycyB0aGUgRGV2VG9vbHMgc3RvcmUncyBwYXVzZSBmbGFnIGJlZm9yZSBpdHMgZnJhbWVcbiAgICAvLyBwYXRjaGVzIHRoZSBsaXZlIHZpZXcuIFRoaXMgZGlzdGluZ3Vpc2hlcyB0aGF0IGludGVudGlvbmFsIHJlcGFpbnRcbiAgICAvLyBmcm9tIGFuIG9yZGluYXJ5IGZyYW1lIHRoYXQgd2FzIGFscmVhZHkgcXVldWVkIHdoZW4ganVtcFRvIGluc3RhbGxlZFxuICAgIC8vIHRoZSBoaXN0b3JpY2FsIHZpZXcuXG4gICAgbGV0IGlzTGl2ZVZpZXdSZXN0b3JlUGVuZGluZyA9IGZhbHNlXG5cbiAgICAvLyBOT1RFOiB0aGUgTW9kZWwgYmVoaW5kIHRoZSBET00gY3VycmVudGx5IG9uIHNjcmVlbiwgd2hpY2ggaXMgd2hhdCBhXG4gICAgLy8gVmlldyBUcmFuc2l0aW9uIGFuaW1hdGVzIGF3YXkgZnJvbS4gU2VlZGVkIHdpdGggYGluaXRNb2RlbGAgYmVjYXVzZVxuICAgIC8vIHRoZSBpbml0IHJlbmRlciBwYWludHMgaXQsIGFuZCBhZHZhbmNlZCBvbmx5IHdoZXJlIGEgcmVuZGVyIGFjdHVhbGx5XG4gICAgLy8gY29tbWl0cy4gVGhlIGB2aWV3VHJhbnNpdGlvbmAgcHJlZGljYXRlIG5ldmVyIHJ1bnMgYmVmb3JlIGEgTWVzc2FnZVxuICAgIC8vIGhhcyBkaXJ0aWVkIHRoZSBNb2RlbCwgYW5kIHRoZSBpbml0IHJlbmRlciBjb21wbGV0ZXMgYmVoaW5kIHRoZSBib290XG4gICAgLy8gYmFycmllciwgc28gdGhpcyBpcyBhbHdheXMgdGhlIG1vZGVsIG9mIGEgcGFpbnQgdGhhdCBoYXBwZW5lZC5cbiAgICBsZXQgbGFzdFJlbmRlcmVkTW9kZWw6IE1vZGVsID0gaW5pdE1vZGVsXG5cbiAgICAvLyBOT1RFOiB0aGUgdHJhbnNpdGlvbiB0aGUgYnJvd3NlciBpcyBzdGlsbCBhbmltYXRpbmcsIGlmIGFueS4gSGVsZCBzb1xuICAgIC8vIHRoZSBydW50aW1lIGNhbiBza2lwIGl0OiB3aGVuIGEgbGF0ZXIgZnJhbWUgc3VwZXJzZWRlcyBpdCwgd2hlbiB0aGVcbiAgICAvLyBydW50aW1lIGNyYXNoZXMsIGFuZCBhdCB0ZWFyZG93biwgd2hlcmUgdGhlIGJyb3dzZXIgd291bGQgb3RoZXJ3aXNlXG4gICAgLy8gYW5pbWF0ZSBvdmVyIGEgcmVsZWFzZWQgY29udGFpbmVyLiBEZWNsYXJlZCBhYm92ZSBgY3Jhc2hXaXRoYCwgd2hpY2hcbiAgICAvLyBjYWxscyB0aGUgc2tpcCBhbmQgY2FuIHJ1biBhcyBlYXJseSBhcyB0aGUgaW5pdCByZW5kZXIuXG4gICAgbGV0IG1heWJlUGVuZGluZ1ZpZXdUcmFuc2l0aW9uID0gT3B0aW9uLm5vbmU8UGVuZGluZ1ZpZXdUcmFuc2l0aW9uPigpXG5cbiAgICBjb25zdCBza2lwUGVuZGluZ1ZpZXdUcmFuc2l0aW9uID0gKCk6IHZvaWQgPT4ge1xuICAgICAgaWYgKE9wdGlvbi5pc1NvbWUobWF5YmVQZW5kaW5nVmlld1RyYW5zaXRpb24pKSB7XG4gICAgICAgIGNvbnN0IHsgdmFsdWU6IHBlbmRpbmdWaWV3VHJhbnNpdGlvbiB9ID0gbWF5YmVQZW5kaW5nVmlld1RyYW5zaXRpb25cbiAgICAgICAgLy8gTk9URTogY2xlYXJlZCBmaXJzdC4gQW4gaW1wbGVtZW50YXRpb24gdGhhdCBydW5zIHRoZSB1cGRhdGVcbiAgICAgICAgLy8gY2FsbGJhY2sgc3luY2hyb25vdXNseSB3b3VsZCBvdGhlcndpc2UgcmUtZW50ZXIgdGhpcy5cbiAgICAgICAgbWF5YmVQZW5kaW5nVmlld1RyYW5zaXRpb24gPSBPcHRpb24ubm9uZSgpXG4gICAgICAgIHBlbmRpbmdWaWV3VHJhbnNpdGlvbi51cGRhdGUuaXNJbnZhbGlkYXRlZCA9IHRydWVcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBwZW5kaW5nVmlld1RyYW5zaXRpb24uaGFuZGxlLnNraXBUcmFuc2l0aW9uKClcbiAgICAgICAgfSBjYXRjaCB7XG4gICAgICAgICAgLy8gTk9URTogc2tpcHBpbmcgcnVucyBvbiB0ZWFyZG93biBhbmQgY3Jhc2ggcGF0aHMsIHNvIGEgcmVmdXNhbFxuICAgICAgICAgIC8vIG11c3Qgbm90IHByb3BhZ2F0ZSBpbnRvIHRoZW0uXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBOT1RFOiB0aGUgY3VycmVudCB2bm9kZSBpcyBwbGFpbiBjbG9zdXJlIHN0YXRlLiBUaGUgZnJhbWUgcmVhZHMgYW5kXG4gICAgLy8gd3JpdGVzIGl0IGRpcmVjdGx5OyB0aGUgY29sZCBwYXRocyB0aGF0IHJ1biBpbnNpZGUgRWZmZWN0cyAoY3Jhc2hcbiAgICAvLyByZW5kZXJpbmcsIHRoZSBkaXNwb3NlIGZpbmFsaXplciwgdGhlIHJlcGxheSByZW5kZXIpIHJlYWQgdGhlIHNhbWVcbiAgICAvLyBzbG90IHN5bmNocm9ub3VzbHksIHNvIG5vIFJlZiBpcyBuZWVkZWQuXG4gICAgY29uc3Qgdm5vZGVTbG90OiBWTm9kZVNsb3QgPSB7IG1heWJlQ3VycmVudFZOb2RlOiBPcHRpb24ubm9uZSgpIH1cblxuICAgIGNvbnN0IHBhdGNoUnVudGltZVZOb2RlID0gKFxuICAgICAgbWF5YmVDdXJyZW50Vk5vZGU6IE9wdGlvbi5PcHRpb248Vk5vZGU+LFxuICAgICAgbmV4dFZOb2RlOiBWTm9kZSB8IG51bGwsXG4gICAgICBzZWVuPzogU2V0PG9iamVjdD4sXG4gICAgKTogVk5vZGUgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgcmV0dXJuIF9fcGF0Y2hWTm9kZShcbiAgICAgICAgICBtYXliZUN1cnJlbnRWTm9kZSxcbiAgICAgICAgICBuZXh0Vk5vZGUsXG4gICAgICAgICAgY29udGFpbmVyLFxuICAgICAgICAgIHNlZW4sXG4gICAgICAgICAgcGF0Y2hlZFZOb2RlID0+IHtcbiAgICAgICAgICAgIHZub2RlU2xvdC5tYXliZUN1cnJlbnRWTm9kZSA9IE9wdGlvbi5zb21lKHBhdGNoZWRWTm9kZSlcbiAgICAgICAgICB9LFxuICAgICAgICApXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvbnN0IG1heWJlUmVjb3ZlcnlWTm9kZSA9IHZub2RlU2xvdC5tYXliZUN1cnJlbnRWTm9kZVxuICAgICAgICAgIGlmIChPcHRpb24uaXNTb21lKG1heWJlUmVjb3ZlcnlWTm9kZSkpIHtcbiAgICAgICAgICAgIHZub2RlU2xvdC5tYXliZUN1cnJlbnRWTm9kZSA9IE9wdGlvbi5zb21lKFxuICAgICAgICAgICAgICBfX3JlY292ZXJWTm9kZUFmdGVyUGF0Y2hGYWlsdXJlKG1heWJlUmVjb3ZlcnlWTm9kZS52YWx1ZSksXG4gICAgICAgICAgICApXG4gICAgICAgICAgfVxuICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgIGZsdXNoUmVwbGF5VW5tb3VudHNBZnRlclBhdGNoRmFpbHVyZSgpXG4gICAgICAgIH1cbiAgICAgICAgdGhyb3cgZXJyb3JcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBOT1RFOiBjb25zdW1lZCBieSB0aGUgZmlyc3QgcmVuZGVyIG9ubHkuIFNldCB3aGVuIHRoaXMgYm9vdCBmb3VuZFxuICAgIC8vIGFuIGFkb3B0YWJsZSBzZXJ2ZXItcmVuZGVyZWQgcm9vdDsgdGhlIGZpcnN0IHBhdGNoIHRoZW4gZ29lc1xuICAgIC8vIHRocm91Z2ggYF9faHlkcmF0ZVZOb2RlYCBpbnN0ZWFkIG9mIHJlcGxhY2luZyB0aGUgY29udGFpbmVyLlxuICAgIGxldCBwZW5kaW5nSHlkcmF0aW9uUm9vdDogSFRNTEVsZW1lbnQgfCBudWxsID1cbiAgICAgIE9wdGlvbi5nZXRPck51bGwobWF5YmVIeWRyYXRpb25Sb290KVxuXG4gICAgLy8gTk9URTogcmVnaXN0ZXJlZCBiZWZvcmUgYW55IHBlcnBldHVhbCBmaWJlciBpcyBmb3JrZWQgc28gaXQgcnVuc1xuICAgIC8vIGFmdGVyIHRoZXkgYXJlIGludGVycnVwdGVkIChzY29wZSBmaW5hbGl6ZXJzIGFyZSBMSUZPKS4gUGF0Y2hpbmcgdG9cbiAgICAvLyBhbiBlbXB0eSB0cmVlIGZpcmVzIHNuYWJiZG9tIGRlc3Ryb3kgaG9va3MsIHdoaWNoIGlzIHdoYXQgcmVsZWFzZXNcbiAgICAvLyBNb3VudHM7IHN3YXBwaW5nIHRoZSBwbGFjZWhvbGRlciBmb3IgdGhlIG9yaWdpbmFsIGNvbnRhaW5lciBsZWF2ZXNcbiAgICAvLyB0aGUgaG9zdCBET00gYXMgaXQgd2FzIGJlZm9yZSB0aGUgZmlyc3QgcmVuZGVyLCByZWFkeSBmb3IgYSBmcmVzaFxuICAgIC8vIGVtYmVkIG9mIHRoZSBzYW1lIGNvbnRhaW5lci4gR2F0ZWQgb24gaW50ZXJydXB0aW9uOiB0aGF0IGlzIHRoZVxuICAgIC8vIGRpc3Bvc2UgcGF0aC4gQSBydW50aW1lIHRoYXQgc3RvcHMgYmVjYXVzZSBpdCBjcmFzaGVkIGNvbXBsZXRlc1xuICAgIC8vIG5vcm1hbGx5IGFmdGVyIHJlbmRlcmluZyB0aGUgY3Jhc2ggdmlldywgYW5kIHRoZSBjcmFzaCB2aWV3IG11c3RcbiAgICAvLyBzdGF5IHZpc2libGUuXG4gICAgeWllbGQqIEVmZmVjdC5hZGRGaW5hbGl6ZXIoZXhpdCA9PlxuICAgICAgRWZmZWN0LmdlbihmdW5jdGlvbiogKCkge1xuICAgICAgICBpZiAoRXhpdC5oYXNJbnRlcnJ1cHRzKGV4aXQpKSB7XG4gICAgICAgICAgY29uc3QgbWF5YmVDdXJyZW50Vk5vZGUgPSB2bm9kZVNsb3QubWF5YmVDdXJyZW50Vk5vZGVcbiAgICAgICAgICB5aWVsZCogT3B0aW9uLm1hdGNoKG1heWJlQ3VycmVudFZOb2RlLCB7XG4gICAgICAgICAgICBvbk5vbmU6ICgpID0+IEVmZmVjdC52b2lkLFxuICAgICAgICAgICAgb25Tb21lOiBjdXJyZW50Vk5vZGUgPT5cbiAgICAgICAgICAgICAgRWZmZWN0LnN5bmMoKCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IHBsYWNlaG9sZGVyTm9kZSA9IF9fcGF0Y2hWTm9kZShcbiAgICAgICAgICAgICAgICAgIE9wdGlvbi5zb21lKGN1cnJlbnRWTm9kZSksXG4gICAgICAgICAgICAgICAgICBudWxsLFxuICAgICAgICAgICAgICAgICAgY29udGFpbmVyLFxuICAgICAgICAgICAgICAgICkuZWxtXG4gICAgICAgICAgICAgICAgaWYgKHBsYWNlaG9sZGVyTm9kZSAmJiBwbGFjZWhvbGRlck5vZGUucGFyZW50Tm9kZSkge1xuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXJOb2RlLnBhcmVudE5vZGUucmVwbGFjZUNoaWxkKFxuICAgICAgICAgICAgICAgICAgICBjb250YWluZXIsXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyTm9kZSxcbiAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgIGNvbnRhaW5lci5yZXBsYWNlQ2hpbGRyZW4oKVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfSksXG4gICAgICAgICAgfSlcbiAgICAgICAgfVxuXG4gICAgICAgIHlpZWxkKiBtb3VudFJ1bnRpbWUuaW50ZXJydXB0RmliZXJzXG4gICAgICB9KSxcbiAgICApXG5cbiAgICAvLyBOT1RFOiBzaGFyZWQgYnkgZXZlcnkgY3Jhc2ggcGF0aDogdGhlIGluaXQgcmVuZGVyLCB0aGUgcGxhaW5cbiAgICAvLyBtZXNzYWdlIGRyYWluIGFuZCByZW5kZXIgZnJhbWUgKHdoaWNoIHJlYWNoIGl0IHRocm91Z2hcbiAgICAvLyBgRWZmZWN0LnJ1bkZvcmtgIGZyb20gdGhlaXIgY2F0Y2ggYmxvY2tzKSwgYW5kIHRoZSBDb21tYW5kIGFuZFxuICAgIC8vIFN1YnNjcmlwdGlvbiBmaWJlcnMgKGEgQ29tbWFuZCdzIEVmZmVjdCBhbmQgYSBTdWJzY3JpcHRpb24nc1xuICAgIC8vIFN0cmVhbSBhcmUgdHlwZWQgd2l0aCBhIGBuZXZlcmAgZXJyb3IgY2hhbm5lbCwgc28gYSBjYXVzZVxuICAgIC8vIGVzY2FwaW5nIG9uZSBpcyBhbiB1bnJlY292ZXJhYmxlIGRlZmVjdCkuIEVhY2ggcGF0aCBjYXRjaGVzIGl0c1xuICAgIC8vIG93biBjYXVzZSBzbyBhIGZhaWx1cmUgc3VyZmFjZXMgYXMgdGhlIGNyYXNoIHZpZXcgaW5zdGVhZCBvZlxuICAgIC8vIGR5aW5nIHNpbGVudGx5IGFuZCBsZWF2aW5nIHRoZSBET00gZnJvemVuIGF0IHRoZSBsYXN0IHN1Y2Nlc3NmdWxcbiAgICAvLyByZW5kZXIuIFRoZSBmaXJzdCBjcmFzaCB3aW5zOiBjb25jdXJyZW50IENvbW1hbmQgZmliZXJzIGNhbiBmYWlsLFxuICAgIC8vIGFuZCBvbmx5IG9uZSBzaG91bGQgcmVwb3J0IGFuZCByZW5kZXIuXG4gICAgY29uc3QgY3Jhc2hXaXRoID0gKFxuICAgICAgY2F1c2U6IENhdXNlLkNhdXNlPG5ldmVyPixcbiAgICAgIG1heWJlTWVzc2FnZTogT3B0aW9uLk9wdGlvbjxNZXNzYWdlPixcbiAgICApOiBFZmZlY3QuRWZmZWN0PHZvaWQ+ID0+XG4gICAgICBFZmZlY3Quc3luYygoKSA9PiB7XG4gICAgICAgIGlmIChzdGF0dXMuaXNDcmFzaGVkKSB7XG4gICAgICAgICAgcmV0dXJuXG4gICAgICAgIH1cbiAgICAgICAgc3RhdHVzLmlzQ3Jhc2hlZCA9IHRydWVcbiAgICAgICAgbWVzc2FnZVF1ZXVlLmRyYWluUGVuZGluZ01lc3NhZ2VzKClcbiAgICAgICAgLy8gTk9URTogdGhlIGNyYXNoIHZpZXcgc2hvdWxkIGFwcGVhciBhdCBvbmNlLCBub3QgYW5pbWF0ZSBpbiBmcm9tXG4gICAgICAgIC8vIGEgc25hcHNob3Qgb2YgdGhlIHN0YXRlIHRoYXQgY3Jhc2hlZC5cbiAgICAgICAgc2tpcFBlbmRpbmdWaWV3VHJhbnNpdGlvbigpXG4gICAgICAgIGNvbnN0IG1vZGVsID0gcmVhZExpdmVNb2RlbCgpXG4gICAgICAgIGNvbnN0IHNxdWFzaGVkID0gQ2F1c2Uuc3F1YXNoKGNhdXNlKVxuICAgICAgICBjb25zdCBlcnJvciA9XG4gICAgICAgICAgc3F1YXNoZWQgaW5zdGFuY2VvZiBFcnJvciA/IHNxdWFzaGVkIDogbmV3IEVycm9yKFN0cmluZyhzcXVhc2hlZCkpXG4gICAgICAgIHJlbmRlckNyYXNoVmlldyhcbiAgICAgICAgICB7IGVycm9yLCBtb2RlbCwgbWVzc2FnZTogbWF5YmVNZXNzYWdlIH0sXG4gICAgICAgICAgY3Jhc2gsXG4gICAgICAgICAgY29udGFpbmVyLFxuICAgICAgICAgIHZub2RlU2xvdCxcbiAgICAgICAgICBtYW5hZ2VEb2N1bWVudCxcbiAgICAgICAgKVxuICAgICAgICBzZXR0bGVQZW5kaW5nQ29tbWl0KClcbiAgICAgIH0pXG5cbiAgICAvLyBOT1RFOiBgbWF5YmVMYXN0RGlydHlNZXNzYWdlYCBob2xkcyB0aGUgbW9zdCByZWNlbnQgZGlydHlpbmcgTWVzc2FnZSxcbiAgICAvLyBzbyBzbG93IHJlbmRlci1waGFzZSBjYWxsYmFja3MgZHVyaW5nIGhpZ2gtcmF0ZSBidXJzdHMgYXR0cmlidXRlIHRvXG4gICAgLy8gdGhlIGxhc3QgTWVzc2FnZSBpbiB0aGUgZnJhbWUgYmF0Y2gsIG5vdCB0aGUgc3BlY2lmaWMgb25lIHRoYXQgcHVzaGVkXG4gICAgLy8gdGhlIHZpZXcgcGFzdCB0aHJlc2hvbGQuIEFjY2VwdGFibGUgZm9yIGEgZGVidWcgY2FsbGJhY2s7IGZ1bGxcbiAgICAvLyBhdHRyaWJ1dGlvbiB3b3VsZCByZXF1aXJlIGNvcnJlbGF0aW5nIGVhY2ggbWVzc2FnZSB3aXRoIGl0cyByZW5kZXJcbiAgICAvLyBjb250cmlidXRpb24sIHdoaWNoIGlzbid0IHdvcnRoIHRoZSBjb21wbGV4aXR5LlxuICAgIGxldCBtYXliZUxhc3REaXJ0eU1lc3NhZ2UgPSBPcHRpb24ubm9uZTxNZXNzYWdlPigpXG5cbiAgICBjb25zdCBzZXRMYXN0RGlydHlNZXNzYWdlID0gKG1lc3NhZ2U6IE1lc3NhZ2UpOiB2b2lkID0+IHtcbiAgICAgIG1heWJlTGFzdERpcnR5TWVzc2FnZSA9IE9wdGlvbi5zb21lKG1lc3NhZ2UpXG4gICAgfVxuXG4gICAgY29uc3QgZGlzcGF0Y2hTeW5jID0gKFxuICAgICAgbWVzc2FnZTogdW5rbm93bixcbiAgICAgIGlzQ3VycmVudD86ICgpID0+IGJvb2xlYW4sXG4gICAgKTogdm9pZCA9PiB7XG4gICAgICAvKiBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L2NvbnNpc3RlbnQtdHlwZS1hc3NlcnRpb25zICovXG4gICAgICBlbnF1ZXVlTWVzc2FnZShtZXNzYWdlIGFzIE1lc3NhZ2UsIGlzQ3VycmVudClcbiAgICB9XG5cbiAgICBjb25zdCBkaXNwYXRjaEFzeW5jID0gKFxuICAgICAgbWVzc2FnZTogdW5rbm93bixcbiAgICAgIGlzQ3VycmVudD86ICgpID0+IGJvb2xlYW4sXG4gICAgKTogRWZmZWN0LkVmZmVjdDx2b2lkPiA9PlxuICAgICAgLyogZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9jb25zaXN0ZW50LXR5cGUtYXNzZXJ0aW9ucyAqL1xuICAgICAgZW5xdWV1ZU1lc3NhZ2VFZmZlY3QobWVzc2FnZSBhcyBNZXNzYWdlLCBpc0N1cnJlbnQpXG5cbiAgICBjb25zdCBkaXNwYXRjaCA9IHsgZGlzcGF0Y2hBc3luYywgZGlzcGF0Y2hTeW5jIH1cblxuICAgIC8vIE5PVEU6IE9uZSBib3VuZGFyeSByZWdpc3RyeSBwZXIgcnVudGltZSBpbnN0YW5jZSwgc2hhcmVkXG4gICAgLy8gYWNyb3NzIHJlbmRlcnMgc28gQmxvY2sgd3JhcCBibG9ja3MgcmVnaXN0ZXJlZCBieVxuICAgIC8vIGguYmxvY2sgcGVyc2lzdCBiZXR3ZWVuIHJlbmRlcnMuIFRoZSByZW5kZXIgZnVuY3Rpb24gY2FsbHNcbiAgICAvLyBgYmVnaW5IdG1sUmVuZGVyYCBhdCB0aGUgc3RhcnQgb2YgZWFjaCBwYXNzOyB3cmFwcyBmb3JcbiAgICAvLyB1bm1vdW50ZWQgQmxvY2tzIChlLmcuIGFuIGVudHJ5IHJlbW92ZWQgZnJvbSBhIGxpc3QpIGFyZVxuICAgIC8vIGRyb3BwZWQgZnJvbSB0aGUgcmVnaXN0cnkgdmlhIHNuYWJiZG9tIGBwb3N0ZGVzdHJveWAgaG9va3NcbiAgICAvLyBhdHRhY2hlZCBieSBgaC5ibG9ja2AgdG8gZWFjaCBjaGlsZCB2bm9kZS5cbiAgICBjb25zdCBib3VuZGFyeVJlZ2lzdHJ5OiBCb3VuZGFyeVJlZ2lzdHJ5ID0gY3JlYXRlSHRtbEJvdW5kYXJ5UmVnaXN0cnkoKVxuICAgIGNvbnN0IHJlZ2lzdGVyZWRNb3VudHMgPSBuZXcgU2V0KFxuICAgICAgbW91bnRzLm1hcChtb3VudCA9PiBtb3VudFtNb3VudFJlZ2lzdHJhdGlvblR5cGVJZF0pLFxuICAgIClcblxuICAgIGNvbnN0IG1vdW50VmFsaWRhdGlvblZpc2l0cyA9IG5ldyBTZXQ8Vk5vZGU+KClcblxuICAgIGNvbnN0IGFzc2VydExheWVyZWRNb3VudHNBcmVSZWdpc3RlcmVkID0gKHJvb3Q6IFZOb2RlIHwgbnVsbCk6IHZvaWQgPT4ge1xuICAgICAgaWYgKHJvb3QgPT09IG51bGwpIHtcbiAgICAgICAgcmV0dXJuXG4gICAgICB9XG5cbiAgICAgIGxldCBtaXNzaW5nOiBNYXA8b2JqZWN0LCBzdHJpbmc+IHwgdW5kZWZpbmVkXG4gICAgICBjb25zdCB3YWxrID0gKG5vZGU6IFZOb2RlKTogdm9pZCA9PiB7XG4gICAgICAgIGNvbnN0IHsgY2hpbGRyZW4gfSA9IG5vZGVcbiAgICAgICAgaWYgKGNoaWxkcmVuICE9PSB1bmRlZmluZWQgJiYgQXJyYXkuaXNBcnJheU5vbkVtcHR5KGNoaWxkcmVuKSkge1xuICAgICAgICAgIGlmIChtb3VudFZhbGlkYXRpb25WaXNpdHMuaGFzKG5vZGUpKSB7XG4gICAgICAgICAgICByZXR1cm5cbiAgICAgICAgICB9XG4gICAgICAgICAgbW91bnRWYWxpZGF0aW9uVmlzaXRzLmFkZChub2RlKVxuICAgICAgICB9XG5cbiAgICAgICAgLyogZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9jb25zaXN0ZW50LXR5cGUtYXNzZXJ0aW9ucyAqL1xuICAgICAgICBjb25zdCBtYXJrZXIgPSBub2RlLmRhdGE/LltGT0xES0lUX01PVU5UX0tFWV0gYXNcbiAgICAgICAgICB8IEZvbGRraXRNb3VudE1hcmtlclxuICAgICAgICAgIHwgdW5kZWZpbmVkXG4gICAgICAgIGNvbnN0IHJlZ2lzdHJhdGlvbiA9IG1hcmtlcj8uW01vdW50UmVnaXN0cmF0aW9uVHlwZUlkXVxuICAgICAgICBpZiAoXG4gICAgICAgICAgbWFya2VyICE9PSB1bmRlZmluZWQgJiZcbiAgICAgICAgICByZWdpc3RyYXRpb24gIT09IHVuZGVmaW5lZCAmJlxuICAgICAgICAgICFyZWdpc3RlcmVkTW91bnRzLmhhcyhyZWdpc3RyYXRpb24pXG4gICAgICAgICkge1xuICAgICAgICAgIG1pc3NpbmcgPz89IG5ldyBNYXA8b2JqZWN0LCBzdHJpbmc+KClcbiAgICAgICAgICBtaXNzaW5nLnNldChyZWdpc3RyYXRpb24sIG1hcmtlci5uYW1lKVxuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGNoaWxkcmVuICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICBmb3IgKGNvbnN0IGNoaWxkIG9mIGNoaWxkcmVuKSB7XG4gICAgICAgICAgICBpZiAoIVByZWRpY2F0ZS5pc1N0cmluZyhjaGlsZCkpIHtcbiAgICAgICAgICAgICAgd2FsayhjaGlsZClcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHRyeSB7XG4gICAgICAgIHdhbGsocm9vdClcbiAgICAgIH0gZmluYWxseSB7XG4gICAgICAgIG1vdW50VmFsaWRhdGlvblZpc2l0cy5jbGVhcigpXG4gICAgICB9XG5cbiAgICAgIGlmIChtaXNzaW5nID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgcmV0dXJuXG4gICAgICB9XG5cbiAgICAgIGNvbnN0IG5hbWVzID0gZ2xvYmFsVGhpcy5BcnJheS5mcm9tKG1pc3NpbmcudmFsdWVzKCkpLnNvcnQoKVxuICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICBgW2ZvbGRraXRdIFRoZSByZW5kZXJlZCB2aWV3IGNvbnRhaW5zIExheWVyLWJhY2tlZCBNb3VudHMgdGhhdCB3ZXJlIG5vdCByZWdpc3RlcmVkOiAke25hbWVzLmpvaW4oJywgJyl9LiBgICtcbiAgICAgICAgICBcIlJlZ2lzdGVyIGVhY2ggTW91bnQgRGVmaW5pdGlvbiBpbiB0aGUgb3duaW5nIENvbXBvc2l0aW9uJ3MgbW91bnRzIGZpZWxkLlwiLFxuICAgICAgKVxuICAgIH1cblxuICAgIC8vIE5PVEU6IGNhbGxlcnMgc2V0IGBpc1JlbmRlcmluZ0ZyYW1lYCBiZWZvcmUgY2FsbGluZyB0aGlzIGFuZCBjbGVhclxuICAgIC8vIGl0IGFmdGVyLiBXaXRob3V0IGl0LCBhIE1lc3NhZ2UgZGlzcGF0Y2hlZCB3aGlsZSB0aGUgcGF0Y2ggaXMgc3RpbGxcbiAgICAvLyBydW5uaW5nIHdvdWxkIHJ1biB1cGRhdGUgYWdhaW5zdCBhIGhhbGYtcGF0Y2hlZCBET00uIEZvciBhIHJlcGxheSxcbiAgICAvLyBgcmVuZGVyYCBhbHNvIGNhbGxzIGBiZWdpblJlcGxheUh0bWxSZW5kZXJgIGZpcnN0LCBzbyB0aGUgb2xkXG4gICAgLy8gdHJlZSdzIHVubW91bnQgY2FsbGJhY2tzIGRvbid0IGRpc3BhdGNoIGludG8gbGl2ZSBoaXN0b3J5LlxuICAgIGNvbnN0IHJlbmRlclN5bmMgPSAoXG4gICAgICBtb2RlbDogTW9kZWwsXG4gICAgICBtYXliZU1lc3NhZ2U6IE9wdGlvbi5PcHRpb248TWVzc2FnZT4sXG4gICAgICBkaXNwYXRjaFNlcnZpY2U6IHR5cGVvZiBEaXNwYXRjaC5TZXJ2aWNlLFxuICAgICAgcmVuZGVyQ29udGV4dDogQ29udGV4dC5Db250ZXh0PG5ldmVyPixcbiAgICAgIHJlbmRlck1vZGU6IFJlbmRlck1vZGUsXG4gICAgKTogdm9pZCA9PiB7XG4gICAgICBjb25zdCBtYXliZUxpdmVSZW5kZXIgPSBPcHRpb24ubGlmdFByZWRpY2F0ZShcbiAgICAgICAgcmVuZGVyTW9kZSxcbiAgICAgICAgbW9kZSA9PiBtb2RlID09PSAnTGl2ZScsXG4gICAgICApXG4gICAgICBjb25zdCBtYXliZUxpdmVTbG93VmlldyA9IE9wdGlvbi5mbGF0TWFwKFxuICAgICAgICBtYXliZUxpdmVSZW5kZXIsXG4gICAgICAgICgpID0+IG1heWJlU2xvd1ZpZXcsXG4gICAgICApXG4gICAgICBjb25zdCBtYXliZUxpdmVTbG93UGF0Y2ggPSBPcHRpb24uZmxhdE1hcChcbiAgICAgICAgbWF5YmVMaXZlUmVuZGVyLFxuICAgICAgICAoKSA9PiBtYXliZVNsb3dQYXRjaCxcbiAgICAgIClcbiAgICAgIGNvbnN0IFtuZXh0RG9jdW1lbnQsIG1heWJlVmlld0R1cmF0aW9uXSA9IG1lYXN1cmVTbG93UGhhc2UoXG4gICAgICAgIG1heWJlTGl2ZVNsb3dWaWV3LFxuICAgICAgICAoKSA9PiB7XG4gICAgICAgICAgYmVnaW5IdG1sUmVuZGVyKGJvdW5kYXJ5UmVnaXN0cnkpXG4gICAgICAgICAgc2V0SHRtbFJ1bnRpbWUoXG4gICAgICAgICAgICBkaXNwYXRjaFNlcnZpY2UuZGlzcGF0Y2hTeW5jLFxuICAgICAgICAgICAgcmVuZGVyQ29udGV4dCxcbiAgICAgICAgICAgIGJvdW5kYXJ5UmVnaXN0cnksXG4gICAgICAgICAgICByZW5kZXJNb2RlLFxuICAgICAgICAgIClcblxuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICByZXR1cm4gdmlldyhtb2RlbCwgaHRtbEJ1aWxkZXIpXG4gICAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgIGNsZWFySHRtbFJ1bnRpbWUoKVxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgIClcbiAgICAgIGNvbnN0IHsgYm9keTogbmV4dFZOb2RlIH0gPSBuZXh0RG9jdW1lbnRcbiAgICAgIGFzc2VydExheWVyZWRNb3VudHNBcmVSZWdpc3RlcmVkKG5leHRWTm9kZSlcblxuICAgICAgcmVwb3J0U2xvd1BoYXNlPFNsb3dWaWV3Q29udGV4dDxNb2RlbCwgTWVzc2FnZT4+KFxuICAgICAgICBtYXliZUxpdmVTbG93VmlldyxcbiAgICAgICAgbWF5YmVWaWV3RHVyYXRpb24sXG4gICAgICAgIChkdXJhdGlvbk1zLCB0aHJlc2hvbGRNcykgPT4gKHtcbiAgICAgICAgICBfdGFnOiAnVmlldycsXG4gICAgICAgICAgbW9kZWwsXG4gICAgICAgICAgbWVzc2FnZTogbWF5YmVNZXNzYWdlLFxuICAgICAgICAgIGR1cmF0aW9uTXMsXG4gICAgICAgICAgdGhyZXNob2xkTXMsXG4gICAgICAgIH0pLFxuICAgICAgKVxuXG4gICAgICBjb25zdCB7IG1heWJlQ3VycmVudFZOb2RlIH0gPSB2bm9kZVNsb3RcblxuICAgICAgY29uc3QgW3BhdGNoZWRWTm9kZSwgbWF5YmVQYXRjaER1cmF0aW9uXSA9IG1lYXN1cmVTbG93UGhhc2UoXG4gICAgICAgIG1heWJlTGl2ZVNsb3dQYXRjaCxcbiAgICAgICAgKCkgPT4ge1xuICAgICAgICAgIGlmIChcbiAgICAgICAgICAgIE9wdGlvbi5pc05vbmUobWF5YmVDdXJyZW50Vk5vZGUpICYmXG4gICAgICAgICAgICBwZW5kaW5nSHlkcmF0aW9uUm9vdCAhPT0gbnVsbFxuICAgICAgICAgICkge1xuICAgICAgICAgICAgY29uc3QgaHlkcmF0aW9uUm9vdCA9IHBlbmRpbmdIeWRyYXRpb25Sb290XG4gICAgICAgICAgICBwZW5kaW5nSHlkcmF0aW9uUm9vdCA9IG51bGxcbiAgICAgICAgICAgIC8vIE5PVEU6IHN0cmlwIHRoZSBzdGFtcCBiZWZvcmUgdGhlIHBhdGNoLCBub3QgYWZ0ZXIsIHNvIHRoZVxuICAgICAgICAgICAgLy8gcGF0Y2ggaXMgdGhlIHNvbGUgb3duZXIgb2YgdGhlIHJvb3QncyBhdHRyaWJ1dGVzLiBJdCBoYXNcbiAgICAgICAgICAgIC8vIGFscmVhZHkgc2VydmVkIGl0cyBwdXJwb3NlIG9mIGxvY2F0aW5nIHRoZSByb290LCBhbmRcbiAgICAgICAgICAgIC8vIHJlbW92aW5nIGl0IGFmdGVyIHdvdWxkIGRlbGV0ZSBhIGBkYXRhLWZvbGRraXQtYXBwYCB0aGUgdmlld1xuICAgICAgICAgICAgLy8gaXRzZWxmIGRlY2xhcmVzLCB3aGljaCBhIGxhdGVyIGVxdWFsLXZub2RlIHBhdGNoIHdvdWxkIG5vdFxuICAgICAgICAgICAgLy8gcmVzdG9yZS4gUmVtb3ZpbmcgaXQgaGVyZSBhbHNvIHN0b3BzIGEgbGF0ZXIgYm9vdCBvbiB0aGUgc2FtZVxuICAgICAgICAgICAgLy8gY29udGFpbmVyIChhIGRpc3Bvc2UtdGhlbi1lbWJlZCByZW1vdW50KSBmcm9tIHJlLWRldGVjdGluZ1xuICAgICAgICAgICAgLy8gdGhpcyBub3ctY29uc3VtZWQgcm9vdCBhcyBoeWRyYXRhYmxlLlxuICAgICAgICAgICAgaHlkcmF0aW9uUm9vdC5yZW1vdmVBdHRyaWJ1dGUoRk9MREtJVF9BUFBfQVRUUklCVVRFKVxuICAgICAgICAgICAgLy8gQW4gZW1wdHkgaWQgcmVhY2hlcyB0aGUgYWRvcHRpb24gc3RlcCdzIG93biBjaGVjayBhcyBhXG4gICAgICAgICAgICAvLyB2YWx1ZSB0aGF0IG1hdGNoZXMgbm90aGluZy4gQm9vdCBhbHJlYWR5IHJlZnVzZWQgYVxuICAgICAgICAgICAgLy8gaHlkcmF0aW9uIHdpdGhvdXQgYW4gaWQsIHNvIHRoaXMgc3RhbmRzIGluIG9ubHkgZm9yIGFcbiAgICAgICAgICAgIC8vIGNhbGxlciB0aGF0IHJlYWNoZWQgaGVyZSBhbm90aGVyIHdheS5cbiAgICAgICAgICAgIHJldHVybiBfX2h5ZHJhdGVWTm9kZShcbiAgICAgICAgICAgICAgaHlkcmF0aW9uUm9vdCxcbiAgICAgICAgICAgICAgbmV4dFZOb2RlLFxuICAgICAgICAgICAgICBib3VuZGFyeVJlZ2lzdHJ5LmRlZHVwZVNlZW4sXG4gICAgICAgICAgICAgIGJ1aWxkSWQgPz8gJycsXG4gICAgICAgICAgICApXG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybiBwYXRjaFJ1bnRpbWVWTm9kZShcbiAgICAgICAgICAgIG1heWJlQ3VycmVudFZOb2RlLFxuICAgICAgICAgICAgbmV4dFZOb2RlLFxuICAgICAgICAgICAgYm91bmRhcnlSZWdpc3RyeS5kZWR1cGVTZWVuLFxuICAgICAgICAgIClcbiAgICAgICAgfSxcbiAgICAgIClcbiAgICAgIHZub2RlU2xvdC5tYXliZUN1cnJlbnRWTm9kZSA9IE9wdGlvbi5zb21lKHBhdGNoZWRWTm9kZSlcblxuICAgICAgcmVwb3J0U2xvd1BoYXNlPFNsb3dQYXRjaENvbnRleHQ8TW9kZWwsIE1lc3NhZ2U+PihcbiAgICAgICAgbWF5YmVMaXZlU2xvd1BhdGNoLFxuICAgICAgICBtYXliZVBhdGNoRHVyYXRpb24sXG4gICAgICAgIChkdXJhdGlvbk1zLCB0aHJlc2hvbGRNcykgPT4gKHtcbiAgICAgICAgICBfdGFnOiAnUGF0Y2gnLFxuICAgICAgICAgIG1vZGVsLFxuICAgICAgICAgIG1lc3NhZ2U6IG1heWJlTWVzc2FnZSxcbiAgICAgICAgICBkdXJhdGlvbk1zLFxuICAgICAgICAgIHRocmVzaG9sZE1zLFxuICAgICAgICB9KSxcbiAgICAgIClcblxuICAgICAgaWYgKG1hbmFnZURvY3VtZW50KSB7XG4gICAgICAgIGFwcGx5RG9jdW1lbnRNZXRhZGF0YShuZXh0RG9jdW1lbnQsIHBhdGNoZWRWTm9kZS5lbG0pXG4gICAgICB9XG5cbiAgICAgIGlmIChpbXBvcnQubWV0YS5ob3QpIHtcbiAgICAgICAgZHVwbGljYXRlSWRTY2FubmVyPy5zY2hlZHVsZShwYXRjaGVkVk5vZGUuZWxtKVxuICAgICAgfVxuICAgIH1cblxuICAgIC8vIE5PVEU6IGBkaXNwYXRjaFNlcnZpY2VgIGRlZmF1bHRzIHRvIGxpdmUgZGlzcGF0Y2ggYnV0IGlzIG92ZXJyaWRhYmxlXG4gICAgLy8gc28gYSB0aW1lLXRyYXZlbCByZW5kZXIgY2FuIGJpbmQgYm90aCBkZWNsYXJhdGl2ZSBoYW5kbGVycyBhbmQgbmV3bHlcbiAgICAvLyBhY3F1aXJlZCBNb3VudHMgdG8gYG5vT3BEaXNwYXRjaGAuIEEgbGl2ZSBNb3VudCBrZWVwcyBpdHMgZGlzcGF0Y2hlclxuICAgIC8vIGFjcm9zcyByZXBsYXksIHdoaWxlIGEgcmVwbGF5LWNyZWF0ZWQgTW91bnQgc3RheXMgbXV0ZWQgdW50aWwgYSBsaXZlXG4gICAgLy8gcmVzdW1lIHBhdGNoIHJlbGVhc2VzIGl0IGFuZCBzdGFydHMgdGhlIGxpdmUgYWN0aW9uLiBUaGlzIHByZXNlcnZlc1xuICAgIC8vIHZhbGlkIGFzeW5jIHJlc3VsdHMgZnJvbSBsaXZlIE1vdW50cyB3aXRob3V0IGdyYW50aW5nIGEgaGlzdG9yaWNhbFxuICAgIC8vIGFjcXVpc2l0aW9uIGFjY2VzcyB0byB0aGUgbGl2ZSBNb2RlbC5cbiAgICBjb25zdCByZW5kZXIgPSAoXG4gICAgICBtb2RlbDogTW9kZWwsXG4gICAgICBtYXliZU1lc3NhZ2U6IE9wdGlvbi5PcHRpb248TWVzc2FnZT4sXG4gICAgICBkaXNwYXRjaFNlcnZpY2U6IHR5cGVvZiBEaXNwYXRjaC5TZXJ2aWNlID0gZGlzcGF0Y2gsXG4gICAgICByZW5kZXJNb2RlOiBSZW5kZXJNb2RlID0gJ0xpdmUnLFxuICAgICkgPT5cbiAgICAgIEVmZmVjdC5nZW4oZnVuY3Rpb24qICgpIHtcbiAgICAgICAgc3RhdHVzLmlzUmVuZGVyaW5nRnJhbWUgPSB0cnVlXG4gICAgICAgIGNvbnN0IHJlbmRlckNvbnRleHQgPSBDb250ZXh0LmFkZChcbiAgICAgICAgICBDb250ZXh0LmFkZChcbiAgICAgICAgICAgIENvbnRleHQuYWRkKHJ1bnRpbWVDb250ZXh0LCBEaXNwYXRjaCwgZGlzcGF0Y2hTZXJ2aWNlKSxcbiAgICAgICAgICAgIE1vdW50VHJhY2tlcixcbiAgICAgICAgICAgIG1vdW50VHJhY2tlcixcbiAgICAgICAgICApLFxuICAgICAgICAgIE1vdW50UnVudGltZSxcbiAgICAgICAgICBtb3VudFJ1bnRpbWUsXG4gICAgICAgIClcbiAgICAgICAgaWYgKHJlbmRlck1vZGUgPT09ICdSZXBsYXknKSB7XG4gICAgICAgICAgYmVnaW5SZXBsYXlIdG1sUmVuZGVyKClcbiAgICAgICAgfVxuICAgICAgICByZW5kZXJTeW5jKFxuICAgICAgICAgIG1vZGVsLFxuICAgICAgICAgIG1heWJlTWVzc2FnZSxcbiAgICAgICAgICBkaXNwYXRjaFNlcnZpY2UsXG4gICAgICAgICAgcmVuZGVyQ29udGV4dCxcbiAgICAgICAgICByZW5kZXJNb2RlLFxuICAgICAgICApXG4gICAgICB9KS5waXBlKFxuICAgICAgICBFZmZlY3QuZW5zdXJpbmcoXG4gICAgICAgICAgRWZmZWN0LnN5bmMoKCkgPT4ge1xuICAgICAgICAgICAgc3RhdHVzLmlzUmVuZGVyaW5nRnJhbWUgPSBmYWxzZVxuICAgICAgICAgICAgZW5kUmVwbGF5SHRtbFJlbmRlcigpXG4gICAgICAgICAgICBkcmFpblBlbmRpbmdNZXNzYWdlcygpXG4gICAgICAgICAgfSksXG4gICAgICAgICksXG4gICAgICApXG5cbiAgICBjb25zdCBsaXZlUmVuZGVyQ29udGV4dCA9IENvbnRleHQuYWRkKFxuICAgICAgQ29udGV4dC5hZGQoXG4gICAgICAgIENvbnRleHQuYWRkKHJ1bnRpbWVDb250ZXh0LCBEaXNwYXRjaCwgZGlzcGF0Y2gpLFxuICAgICAgICBNb3VudFRyYWNrZXIsXG4gICAgICAgIG1vdW50VHJhY2tlcixcbiAgICAgICksXG4gICAgICBNb3VudFJ1bnRpbWUsXG4gICAgICBtb3VudFJ1bnRpbWUsXG4gICAgKVxuXG4gICAgLy8gTk9URTogcmVuZGVyaW5nIGJlZm9yZSBhIGRlZmVycmVkIGRyYWluIHJlc3VtZXMgd291bGQgcmVzdG9yZSBzdGFsZVxuICAgIC8vIGNvbnRyb2xsZWQgaW5wdXQgdmFsdWVzLiBEaXNwb3NlZCBvciBjcmFzaGVkIHJ1bnRpbWVzIHVzZSB0aGUgZnJhbWUgZ3VhcmRzLlxuICAgIGNvbnN0IGlzTGl2ZU1vZGVsQmVoaW5kUXVldWUgPSAoKTogYm9vbGVhbiA9PlxuICAgICAgaXNBbnlNZXNzYWdlRGVmZXJyZWQoKSAmJiAhc3RhdHVzLmlzUnVudGltZURpc3Bvc2VkICYmICFzdGF0dXMuaXNDcmFzaGVkXG5cbiAgICAvLyBOT1RFOiB0aGUgcmVuZGVyLCBNb3VudCBkcmFpbiwgRGV2VG9vbHMgYXR0cmlidXRpb24sIGFuZFxuICAgIC8vIHBhdGNoLXRpbWUtYnVmZmVyIGZsdXNoLiBTaGFyZWQgYnkgdGhlIHBsYWluIHBhdGggKGNhbGxlZCBkaXJlY3RseSlcbiAgICAvLyBhbmQgdGhlIFZpZXcgVHJhbnNpdGlvbiBwYXRoIChjYWxsZWQgZnJvbSB0aGUgdHJhbnNpdGlvbidzIHVwZGF0ZVxuICAgIC8vIGNhbGxiYWNrKSwgd2hpY2ggcnVuIGlkZW50aWNhbCB3b3JrOyBvbmx5IHdoZXRoZXIgdGhleSBydW4gaW5zaWRlXG4gICAgLy8gYGRvY3VtZW50LnN0YXJ0Vmlld1RyYW5zaXRpb25gIGRpZmZlcnMuIGBpc1JlbmRlcmluZ0ZyYW1lYCBnYXRlcyB0aGVcbiAgICAvLyBidWZmZXJpbmcgb2YgTWVzc2FnZXMgZGlzcGF0Y2hlZCBieSBwYXRjaC10aW1lIGhvb2tzLCBzbyBpdCBtdXN0XG4gICAgLy8gd3JhcCB0aGUgYWN0dWFsIHBhdGNoLCB3aGljaCBvbiB0aGUgdHJhbnNpdGlvbiBwYXRoIGhhcHBlbnMgaW5zaWRlXG4gICAgLy8gdGhlIGNhbGxiYWNrLCBub3Qgd2hlbiB0aGUgZnJhbWUgaXMgc2NoZWR1bGVkLlxuICAgIGNvbnN0IHJ1blJlbmRlckZyYW1lQm9keSA9ICgpOiB2b2lkID0+IHtcbiAgICAgIHN0YXR1cy5pc1JlbmRlcmluZ0ZyYW1lID0gdHJ1ZVxuICAgICAgLy8gTk9URTogY2FwdHVyZWQgYmVmb3JlIHRoZSBwYXRjaCwgYmVjYXVzZSBgZHJhaW5QZW5kaW5nTWVzc2FnZXNgXG4gICAgICAvLyBiZWxvdyBjYW4gYWR2YW5jZSB0aGUgbGl2ZSBNb2RlbCBhZ2FpbiBiZWZvcmUgdGhlIG5leHQgZnJhbWUgcmVhZHNcbiAgICAgIC8vIGl0LiBXaGF0IHRoaXMgZnJhbWUgcGFpbnRlZCBpcyB3aGF0IHRoZSBuZXh0IHRyYW5zaXRpb24gYW5pbWF0ZXNcbiAgICAgIC8vIGF3YXkgZnJvbS5cbiAgICAgIGNvbnN0IHJlbmRlcmVkTW9kZWwgPSByZWFkTGl2ZU1vZGVsKClcbiAgICAgIGNvbnN0IGlzUmVzdW1pbmcgPSByZWFkVmlld1N0YXRlKCkgPT09ICdQYXVzZWQnXG4gICAgICBpZiAoaXNSZXN1bWluZykge1xuICAgICAgICAvLyBOT1RFOiBNZXNzYWdlcyBhY2N1bXVsYXRlZCB3aGlsZSBhIGhpc3RvcmljYWwgdmlldyBvd25lZCB0aGUgRE9NXG4gICAgICAgIC8vIGRpZCBub3QgY2F1c2UgdGhpcyByZXBhaW50LiBBIE1lc3NhZ2UgYXJyaXZpbmcgZHVyaW5nIHRoZSBwYXRjaFxuICAgICAgICAvLyBjYW4gcmVwb3B1bGF0ZSB0aGlzIGZpZWxkIHdoZW4gdGhlIGJ1ZmZlcmVkIHF1ZXVlIGRyYWlucy5cbiAgICAgICAgbWF5YmVMYXN0RGlydHlNZXNzYWdlID0gT3B0aW9uLm5vbmUoKVxuICAgICAgfVxuICAgICAgdHJ5IHtcbiAgICAgICAgcmVuZGVyU3luYyhcbiAgICAgICAgICByZWFkTGl2ZU1vZGVsKCksXG4gICAgICAgICAgbWF5YmVMYXN0RGlydHlNZXNzYWdlLFxuICAgICAgICAgIGRpc3BhdGNoLFxuICAgICAgICAgIGxpdmVSZW5kZXJDb250ZXh0LFxuICAgICAgICAgICdMaXZlJyxcbiAgICAgICAgKVxuICAgICAgICAvLyBOT1RFOiBhZnRlciB0aGUgcGF0Y2gsIHNvIGEgcmVuZGVyIHRoYXQgdGhyZXcgbGVhdmVzIHRoaXMgb24gdGhlXG4gICAgICAgIC8vIE1vZGVsIHN0aWxsIG9uIHNjcmVlbiwgYW5kIGJlZm9yZSBgZHJhaW5QZW5kaW5nTWVzc2FnZXNgIGJlbG93LFxuICAgICAgICAvLyB3aG9zZSBoYW5kbGVycyBjYW4gYWR2YW5jZSB0aGUgbGl2ZSBNb2RlbCBhZ2Fpbi5cbiAgICAgICAgbGFzdFJlbmRlcmVkTW9kZWwgPSByZW5kZXJlZE1vZGVsXG4gICAgICAgIC8vIE5PVEU6IHJlc3VtZSBjbGVhcnMgdGhlIHN0b3JlJ3MgcGF1c2UgZmxhZyBiZWZvcmUgdGhpcyBmcmFtZS5cbiAgICAgICAgLy8gUHVibGlzaCBMaXZlIG9ubHkgYWZ0ZXIgdGhlIGxpdmUgRE9NIGhhcyBiZWVuIGluc3RhbGxlZC5cbiAgICAgICAgc2V0Vmlld1N0YXRlKCdMaXZlJylcbiAgICAgICAgYXR0YWNoUmVuZGVyZWRNb3VudHMoKVxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgRWZmZWN0LnJ1bkZvcmsoY3Jhc2hXaXRoKENhdXNlLmRpZShlcnJvciksIG1heWJlTGFzdERpcnR5TWVzc2FnZSkpXG4gICAgICB9IGZpbmFsbHkge1xuICAgICAgICBzdGF0dXMuaXNSZW5kZXJpbmdGcmFtZSA9IGZhbHNlXG4gICAgICB9XG4gICAgICAvLyBOT1RFOiBNZXNzYWdlcyBkaXNwYXRjaGVkIGJ5IHBhdGNoLXRpbWUgaG9va3MgKGZvciBleGFtcGxlLFxuICAgICAgLy8gT25Vbm1vdW50IGRlc3Ryb3lzLCBvciBNb3VudCBlbWlzc2lvbnMpIHdlcmUgYnVmZmVyZWQgd2hpbGUgdGhlXG4gICAgICAvLyBmcmFtZSBoZWxkIHRoZSBzdGFjazsgdGhleSBwcm9jZXNzIG5vdywgYWZ0ZXIgdGhlIHBhdGNoIGhhc1xuICAgICAgLy8gY29tbWl0dGVkIGFuZCB0aGUgZnJhbWUncyBNb3VudCBldmVudHMgYXJlIGF0dHJpYnV0ZWQuXG4gICAgICBkcmFpblBlbmRpbmdNZXNzYWdlcygpXG4gICAgICAvLyBOT1RFOiBsYXN0LCBzbyBhIHdhaXRlciByZXN1bWVkIGJ5IHRoZSBjb21taXQgb2JzZXJ2ZXMgdGhlIHNhbWVcbiAgICAgIC8vIERPTSBhbmQgdGhlIHNhbWUgcHJvY2Vzc2VkLU1lc3NhZ2Ugb3JkZXJpbmcgaXQgc2F3IHdoZW5cbiAgICAgIC8vIGBhZnRlckNvbW1pdGAgY291bnRlZCBmcmFtZXMuXG4gICAgICBzZXR0bGVQZW5kaW5nQ29tbWl0KClcbiAgICB9XG5cbiAgICAvLyBOT1RFOiBzdGFydHMgYSBWaWV3IFRyYW5zaXRpb24gYXJvdW5kIHRoaXMgZnJhbWUncyByZW5kZXIgd2hlbiB0aGVcbiAgICAvLyBgdmlld1RyYW5zaXRpb25gIHByZWRpY2F0ZSBtYXRjaGVzLCByZXR1cm5pbmcgYHRydWVgIHdoZW4gaXQgZGlkLlxuICAgIC8vIGBzdGFydFZpZXdUcmFuc2l0aW9uYCBpbnZva2VzIGl0cyB1cGRhdGUgY2FsbGJhY2sgYXN5bmNocm9ub3VzbHlcbiAgICAvLyBhZnRlciBzbmFwc2hvdHRpbmcgdGhlIG9sZCBET00sIHNvIHRoZSBjYWxsYmFjayByZWFkcyB0aGUgbGl2ZSBNb2RlbFxuICAgIC8vIGFuZCBgbWF5YmVMYXN0RGlydHlNZXNzYWdlYCBmcmVzaCAodGhlIHBsYWluIGxvb3AgbWF5IGhhdmUgYWR2YW5jZWRcbiAgICAvLyB0aGUgbW9kZWwgd2hpbGUgdGhlIGJyb3dzZXIgc3VwcHJlc3NlZCByZW5kZXJpbmcpIGFuZCByZS1jaGVja3MgdGhlXG4gICAgLy8gZGlzcG9zYWwgYW5kIGNyYXNoIGd1YXJkcywgd2hpY2ggY2FuIGZsaXAgd2hpbGUgdGhlIHRyYW5zaXRpb24gaXNcbiAgICAvLyBwZW5kaW5nLiBUaGUgdW5jb25maWd1cmVkIHBhdGggbmV2ZXIgcmVhY2hlcyB0aGlzIGZ1bmN0aW9uOyB0aGVcbiAgICAvLyBgT3B0aW9uLmlzTm9uZWAgY2hlY2sgaW4gYHJlbmRlckZyYW1lUGxhaW5gIHJldHVybnMgZmlyc3QsIHNvIGFcbiAgICAvLyBydW50aW1lIHdpdGhvdXQgYHZpZXdUcmFuc2l0aW9uYCBhbGxvY2F0ZXMgbm8gcGVyLWZyYW1lIGNhbGxiYWNrLlxuICAgIGNvbnN0IHN0YXJ0RnJhbWVWaWV3VHJhbnNpdGlvbiA9IChcbiAgICAgIHJlc29sdmVkOiBSZXNvbHZlZFZpZXdUcmFuc2l0aW9uPE1vZGVsLCBNZXNzYWdlPixcbiAgICApOiBib29sZWFuID0+IHtcbiAgICAgIGlmIChyZWFkVmlld1N0YXRlKCkgPT09ICdQYXVzZWQnKSB7XG4gICAgICAgIHJldHVybiBmYWxzZVxuICAgICAgfVxuICAgICAgaWYgKHJlc29sdmVkLnJlZHVjZWRNb3Rpb25RdWVyeS5tYXRjaGVzKSB7XG4gICAgICAgIHJldHVybiBmYWxzZVxuICAgICAgfVxuICAgICAgaWYgKE9wdGlvbi5pc05vbmUobWF5YmVMYXN0RGlydHlNZXNzYWdlKSkge1xuICAgICAgICByZXR1cm4gZmFsc2VcbiAgICAgIH1cbiAgICAgIGNvbnN0IG1heWJlRGVjaXNpb24gPSBfX2RlY2lkZVZpZXdUcmFuc2l0aW9uKHJlc29sdmVkLmRlY2lkZSwge1xuICAgICAgICBwcmV2aW91c01vZGVsOiBsYXN0UmVuZGVyZWRNb2RlbCxcbiAgICAgICAgbW9kZWw6IHJlYWRMaXZlTW9kZWwoKSxcbiAgICAgICAgbWVzc2FnZTogbWF5YmVMYXN0RGlydHlNZXNzYWdlLnZhbHVlLFxuICAgICAgfSlcbiAgICAgIGlmIChPcHRpb24uaXNOb25lKG1heWJlRGVjaXNpb24pKSB7XG4gICAgICAgIHJldHVybiBmYWxzZVxuICAgICAgfVxuICAgICAgLy8gTk9URTogaW52YWxpZGF0ZSBhbiBvbGRlciB0cmFuc2l0aW9uIGJlZm9yZSB0aGlzIG9uZSB0YWtlc1xuICAgICAgLy8gb3duZXJzaGlwIG9mIHRoZSBsYXRlc3QgbGl2ZSByZXBhaW50LiBUaGUgYnJvd3NlciBtYXkgc3RpbGwgY2FsbFxuICAgICAgLy8gdGhlIG9sZGVyIHVwZGF0ZSBjYWxsYmFjaywgYnV0IGl0cyBpbnZhbGlkYXRpb24gZ3VhcmQgbGVhdmVzIHRoZVxuICAgICAgLy8gRE9NIGFuZCBjb21taXQgbm90aWZpZXIgdG8gdGhpcyB0cmFuc2l0aW9uLlxuICAgICAgc2tpcFBlbmRpbmdWaWV3VHJhbnNpdGlvbigpXG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCB1cGRhdGUgPSB7XG4gICAgICAgICAgaXNJbnZhbGlkYXRlZDogZmFsc2UsXG4gICAgICAgICAgZGlkUnVuOiBmYWxzZSxcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBoYW5kbGUgPSByZXNvbHZlZC5zdGFydFZpZXdUcmFuc2l0aW9uKCgpID0+IHtcbiAgICAgICAgICBpZiAodXBkYXRlLmlzSW52YWxpZGF0ZWQgfHwgdXBkYXRlLmRpZFJ1bikge1xuICAgICAgICAgICAgcmV0dXJuXG4gICAgICAgICAgfVxuICAgICAgICAgIHVwZGF0ZS5kaWRSdW4gPSB0cnVlXG5cbiAgICAgICAgICAvLyBOT1RFOiBhIGRyYWluIG1heSBoYXZlIGJlZW4gZGVmZXJyZWQgc2luY2UgdGhlIHByZWNlZGluZyBmcmFtZVxuICAgICAgICAgIC8vIHN0YXJ0ZWQgdGhlIHRyYW5zaXRpb24uIExlYXZlIHRoZSBET00gdW5jaGFuZ2VkIHVudGlsIGl0IGNhdGNoZXMgdXAuXG4gICAgICAgICAgaWYgKGlzTGl2ZU1vZGVsQmVoaW5kUXVldWUoKSkge1xuICAgICAgICAgICAgc2tpcFBlbmRpbmdWaWV3VHJhbnNpdGlvbigpXG4gICAgICAgICAgICBzY2hlZHVsZVJlbmRlckZyYW1lKClcbiAgICAgICAgICAgIHJldHVyblxuICAgICAgICAgIH1cbiAgICAgICAgICAvLyBOT1RFOiB0aGUgdmlldyBzdGF0ZSBjbG9zZXMgdGhlIHJlc3VtZSB3aW5kb3cgYWZ0ZXIgdGhlXG4gICAgICAgICAgLy8gc3RvcmUgaXMgbGl2ZSBidXQgYmVmb3JlIGl0cyBwbGFpbiBmcmFtZSBoYXMgcmVzdG9yZWQgdGhlIGxpdmVcbiAgICAgICAgICAvLyBET00uIEEgdHJhbnNpdGlvbiBpbnZhbGlkYXRlZCBieSBqdW1wVG8gc3RheXMgaW52YWxpZCBmb3JldmVyLFxuICAgICAgICAgIC8vIHNvIGl0cyBjYWxsYmFjayBjYW5ub3QgcmVwYWludCBpbnNpZGUgdGhlIHN0YWxlIHRyYW5zaXRpb25cbiAgICAgICAgICAvLyBldmVuIGlmIGl0IGFycml2ZXMgYWZ0ZXIgcmVzdW1lIGhhcyBwdWJsaXNoZWQgYExpdmVgLlxuICAgICAgICAgIGlmIChcbiAgICAgICAgICAgIHN0YXR1cy5pc1J1bnRpbWVEaXNwb3NlZCB8fFxuICAgICAgICAgICAgc3RhdHVzLmlzQ3Jhc2hlZCB8fFxuICAgICAgICAgICAgaXNQYXVzZWROb3coKSB8fFxuICAgICAgICAgICAgcmVhZFZpZXdTdGF0ZSgpID09PSAnUGF1c2VkJ1xuICAgICAgICAgICkge1xuICAgICAgICAgICAgc2V0dGxlUGVuZGluZ0NvbW1pdCgpXG4gICAgICAgICAgICByZXR1cm5cbiAgICAgICAgICB9XG4gICAgICAgICAgcnVuUmVuZGVyRnJhbWVCb2R5KClcbiAgICAgICAgfSwgbWF5YmVEZWNpc2lvbi52YWx1ZS5tYXliZVR5cGVzKVxuICAgICAgICBtYXliZVBlbmRpbmdWaWV3VHJhbnNpdGlvbiA9IE9wdGlvbi5zb21lKHsgaGFuZGxlLCB1cGRhdGUgfSlcbiAgICAgICAgX19zaWxlbmNlVmlld1RyYW5zaXRpb25SZWplY3Rpb25zKGhhbmRsZSlcbiAgICAgICAgcmV0dXJuIHRydWVcbiAgICAgIH0gY2F0Y2gge1xuICAgICAgICAvLyBOT1RFOiBhbiBlc2NhcGluZyB0aHJvdyB3b3VsZCBsZWF2ZSB0aGUgckFGIGNhbGxiYWNrIHdpdGhvdXQgYVxuICAgICAgICAvLyBwYXRjaCBhbmQgd2l0aG91dCBzZXR0bGluZyB0aGUgY29tbWl0IG5vdGlmaWVyLCBwYXJraW5nIGV2ZXJ5XG4gICAgICAgIC8vIGBSZW5kZXIuYWZ0ZXJDb21taXRgIG9uIHRoaXMgZnJhbWUgZm9yZXZlci5cbiAgICAgICAgcmV0dXJuIGZhbHNlXG4gICAgICB9XG4gICAgfVxuXG4gICAgLy8gTk9URTogZXZlcnkgcGF0aCBvdXQgb2YgYSBzY2hlZHVsZWQgZnJhbWUgc2V0dGxlcyB0aGUgY29tbWl0XG4gICAgLy8gbm90aWZpZXIsIHdoZXRoZXIgb3Igbm90IGl0IHBhdGNoZWQuIEEgZnJhbWUgYWJhbmRvbmVkIHNpbGVudGx5XG4gICAgLy8gd291bGQgc3RyYW5kIGFueSBgUmVuZGVyLmFmdGVyQ29tbWl0YCByZWdpc3RlcmVkIGFnYWluc3QgaXQsIGFuZFxuICAgIC8vIHRoZSBEb20gaGVscGVycyB0aGF0IGdhdGUgb24gaXQgd291bGQgbmV2ZXIgcnVuIHRoZWlyIERPTSB3b3JrLlxuICAgIGNvbnN0IHJlbmRlckZyYW1lUGxhaW4gPSAoKTogdm9pZCA9PiB7XG4gICAgICAvLyBOT1RFOiByZXRhaW4gdGhlIHNjaGVkdWxlZCBmcmFtZSdzIHBlbmRpbmcgY29tbWl0IHdoaWxlIHRoZSBkcmFpbiB3YWl0cy5cbiAgICAgIGlmIChpc0xpdmVNb2RlbEJlaGluZFF1ZXVlKCkpIHtcbiAgICAgICAgcmVxdWVzdEFuaW1hdGlvbkZyYW1lKHJlbmRlckZyYW1lUGxhaW4pXG4gICAgICAgIHJldHVyblxuICAgICAgfVxuICAgICAgaXNSZW5kZXJGcmFtZVNjaGVkdWxlZCA9IGZhbHNlXG4gICAgICBjb25zdCBpc1Jlc3RvcmluZ0xpdmVWaWV3ID0gaXNMaXZlVmlld1Jlc3RvcmVQZW5kaW5nXG4gICAgICBpc0xpdmVWaWV3UmVzdG9yZVBlbmRpbmcgPSBmYWxzZVxuICAgICAgLy8gTk9URTogYSBmcmFtZSBzY2hlZHVsZWQgYmVmb3JlIGRpc3Bvc2FsIGZpcmVzIGFmdGVyIGl0OyBhXG4gICAgICAvLyBkaXNwb3NlZCBydW50aW1lIG11c3Qgbm90IHJlcGFpbnQgdGhlIHJlbGVhc2VkIGNvbnRhaW5lci5cbiAgICAgIGlmIChzdGF0dXMuaXNSdW50aW1lRGlzcG9zZWQpIHtcbiAgICAgICAgc2V0dGxlUGVuZGluZ0NvbW1pdCgpXG4gICAgICAgIHJldHVyblxuICAgICAgfVxuICAgICAgLy8gTk9URTogYSBmcmFtZSBpcyBydW5uaW5nLCBzbyB0aGUgYnJvd3NlciBnb3QgY29udHJvbCBiYWNrOyB0aGVcbiAgICAgIC8vIGRyYWluIGJ1ZGdldCBzdGFydHMgZnJlc2guXG4gICAgICByZXNldERyYWluQnVkZ2V0KClcbiAgICAgIC8vIE5PVEU6IGEgTWVzc2FnZSB0aGF0IGRpcnRpZWQgdGhlIG1vZGVsIGNhbiBhbHNvIGJlIHRoZSBvbmVcbiAgICAgIC8vIHdob3NlIENvbW1hbmQgY3Jhc2hlZCB0aGUgcnVudGltZS4gV2l0aG91dCB0aGlzIGd1YXJkIHRoZVxuICAgICAgLy8gbmV4dCBhbmltYXRpb24gZnJhbWUgd291bGQgcmVuZGVyIHRoZSBsaXZlIHZpZXcgb3ZlciB0aGVcbiAgICAgIC8vIGNyYXNoIHZpZXcuXG4gICAgICBpZiAoc3RhdHVzLmlzQ3Jhc2hlZCkge1xuICAgICAgICBzZXR0bGVQZW5kaW5nQ29tbWl0KClcbiAgICAgICAgcmV0dXJuXG4gICAgICB9XG4gICAgICBpZiAoaXNQYXVzZWROb3coKSkge1xuICAgICAgICBzZXR0bGVQZW5kaW5nQ29tbWl0KClcbiAgICAgICAgcmV0dXJuXG4gICAgICB9XG4gICAgICBpZiAocmVhZFZpZXdTdGF0ZSgpID09PSAnUGF1c2VkJyAmJiAhaXNSZXN0b3JpbmdMaXZlVmlldykge1xuICAgICAgICBzZXR0bGVQZW5kaW5nQ29tbWl0KClcbiAgICAgICAgcmV0dXJuXG4gICAgICB9XG4gICAgICAvLyBOT1RFOiB0aGUgdW5jb25maWd1cmVkIHBhdGggcGF5cyBvbmUgYE9wdGlvbi5pc05vbmVgIGNoZWNrIGFuZFxuICAgICAgLy8gcmVuZGVycyBkaXJlY3RseSwgYWxsb2NhdGluZyBubyBwZXItZnJhbWUgY2FsbGJhY2suIE9ubHkgYVxuICAgICAgLy8gcnVudGltZSBjb25maWd1cmVkIHdpdGggYHZpZXdUcmFuc2l0aW9uYCByZWFjaGVzXG4gICAgICAvLyBgc3RhcnRGcmFtZVZpZXdUcmFuc2l0aW9uYCwgd2hpY2ggZGVjaWRlcyBwZXIgZnJhbWUgd2hldGhlciB0b1xuICAgICAgLy8gd3JhcCB0aGUgcmVuZGVyIGluIGBkb2N1bWVudC5zdGFydFZpZXdUcmFuc2l0aW9uYC4gV2hlbiBpdCBkb2VzLFxuICAgICAgLy8gdGhlIHJlbmRlciBydW5zIGxhdGVyLCBpbnNpZGUgdGhlIHRyYW5zaXRpb24ncyB1cGRhdGUgY2FsbGJhY2suXG4gICAgICBpZiAoT3B0aW9uLmlzTm9uZShtYXliZVJlc29sdmVkVmlld1RyYW5zaXRpb24pKSB7XG4gICAgICAgIHJ1blJlbmRlckZyYW1lQm9keSgpXG4gICAgICAgIHJldHVyblxuICAgICAgfVxuICAgICAgaWYgKCFzdGFydEZyYW1lVmlld1RyYW5zaXRpb24obWF5YmVSZXNvbHZlZFZpZXdUcmFuc2l0aW9uLnZhbHVlKSkge1xuICAgICAgICBydW5SZW5kZXJGcmFtZUJvZHkoKVxuICAgICAgfVxuICAgIH1cblxuICAgIC8vIE5PVEU6IHJlbmRlciBmcmFtZXMgcnVuIGFzIHBsYWluIEphdmFTY3JpcHQgaW5zaWRlIHRoZVxuICAgIC8vIHJlcXVlc3RBbmltYXRpb25GcmFtZSBjYWxsYmFjay4gTWVzc2FnZXMgYXJyaXZpbmcgYmV0d2VlbiBmcmFtZXMgbWFya1xuICAgIC8vIGF0IG1vc3Qgb25lIHBlbmRpbmcgZnJhbWU7IHRoZSBjYWxsYmFjayByZW5kZXJzIG9uY2Ugd2l0aCB0aGUgbGF0ZXN0XG4gICAgLy8gbW9kZWwuXG4gICAgY29uc3Qgc2NoZWR1bGVSZW5kZXJGcmFtZSA9IChcbiAgICAgIGlzUmVzdG9yaW5nTGl2ZVZpZXc6IGJvb2xlYW4gPSBmYWxzZSxcbiAgICApOiB2b2lkID0+IHtcbiAgICAgIGlmIChpc1Jlc3RvcmluZ0xpdmVWaWV3KSB7XG4gICAgICAgIGlzTGl2ZVZpZXdSZXN0b3JlUGVuZGluZyA9IHRydWVcbiAgICAgIH1cbiAgICAgIGlmIChpc1JlbmRlckZyYW1lU2NoZWR1bGVkKSB7XG4gICAgICAgIHJldHVyblxuICAgICAgfVxuICAgICAgaXNSZW5kZXJGcmFtZVNjaGVkdWxlZCA9IHRydWVcbiAgICAgIGNvbW1pdE5vdGlmaWVyLm1hcmtDb21taXRQZW5kaW5nKClcbiAgICAgIHJlcXVlc3RBbmltYXRpb25GcmFtZShyZW5kZXJGcmFtZVBsYWluKVxuICAgIH1cblxuICAgIGNvbnN0IGRldlRvb2xzUmVuZGVyQnJpZGdlOiBEZXZUb29sc1JlbmRlckJyaWRnZSA9IHtcbiAgICAgIC8vIE5PVEU6IHBhc3NlcyBgbm9PcERpc3BhdGNoYCBzbyBkZWNsYXJhdGl2ZSBoYW5kbGVycyBhbmQgTW91bnRzXG4gICAgICAvLyBhY3F1aXJlZCBieSB0aGUgcmVwbGF5IGNhbm5vdCByZWFjaCB0aGUgbGl2ZSBNb2RlbC4gVGhlaXJcbiAgICAgIC8vIGZpYmVycyBzdGF5IGFsaXZlIGFuZCBjYW4gb2JzZXJ2ZSB2aWV3LXN0YXRlIGNoYW5nZXMgd2hpbGUgdGhlXG4gICAgICAvLyBoaXN0b3JpY2FsIHZpZXcgb3ducyB0aGVtLiBJZiByZXN1bWUgcmV1c2VzIHN1Y2ggYW4gZWxlbWVudCxcbiAgICAgIC8vIE9uTW91bnQgcmVsZWFzZXMgdGhlIHJlcGxheSBhY3F1aXNpdGlvbiBiZWZvcmUgc3RhcnRpbmcgdGhlXG4gICAgICAvLyBsaXZlIGFjdGlvbi4gQWxzbyBkaXNjYXJkcyBtb3VudCBldmVudHMgZmlyZWQgZHVyaW5nIHRoZSByZW5kZXJcbiAgICAgIC8vIHNvIHRoZXkgZG9uJ3QgZ2V0IGF0dHJpYnV0ZWQgdG8gdGhlIG5leHQgdXNlci1pbml0aWF0ZWQgZGlzcGF0Y2guXG4gICAgICByZW5kZXJSZXBsYXk6IG1vZGVsID0+XG4gICAgICAgIEVmZmVjdC5nZW4oZnVuY3Rpb24qICgpIHtcbiAgICAgICAgICAvKiBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L2NvbnNpc3RlbnQtdHlwZS1hc3NlcnRpb25zICovXG4gICAgICAgICAgY29uc3QgcmVwbGF5ZWRNb2RlbCA9IG1vZGVsIGFzIE1vZGVsXG4gICAgICAgICAgY29uc3QgcHJldmlvdXNSZW5kZXJlZE1vZGVsID0gbGFzdFJlbmRlcmVkTW9kZWxcbiAgICAgICAgICAvLyBOT1RFOiBhIE1vdW50IHN1cnZpdmluZyBmcm9tIHRoZSBsaXZlIHZpZXcgbXVzdCBvYnNlcnZlXG4gICAgICAgICAgLy8gUGF1c2VkIGJlZm9yZSB0aGUgaGlzdG9yaWNhbCBwYXRjaCBjYW4gZXhwb3NlIGRpZmZlcmVudFxuICAgICAgICAgIC8vIERPTS4gTW91bnRzIGluc2VydGVkIGJ5IHRoYXQgcGF0Y2ggY2FwdHVyZSB0aGlzIHN0YXRlIHdoZW5cbiAgICAgICAgICAvLyBhY3F1aXJlZCwgc28gYXN5bmNocm9ub3VzIHNldHVwIGNhbm5vdCBza2lwIFBhdXNlZCBldmVuIGlmXG4gICAgICAgICAgLy8gaXQgY29uc3VtZXMgdGhlIFN0cmVhbSBvbmx5IGFmdGVyIHRoZSBsaXZlIHZpZXcgcmV0dXJucy5cbiAgICAgICAgICBzZXRWaWV3U3RhdGUoJ1BhdXNlZCcpXG4gICAgICAgICAgLy8gTk9URTogYSB0cmFuc2l0aW9uIHN0aWxsIGFuaW1hdGluZyBiZWxvbmdzIHRvIHRoZSBsaXZlXG4gICAgICAgICAgLy8gc3RhdGUgdGhpcyByZXBsYXkgaXMgYWJvdXQgdG8gcGFpbnQgb3Zlci4gTGVmdCBydW5uaW5nIGl0XG4gICAgICAgICAgLy8gYW5pbWF0ZXMgYSBkZWFkIHNuYXBzaG90IGFjcm9zcyB0aGUgcmVwbGF5ZWQgRE9NLlxuICAgICAgICAgIHNraXBQZW5kaW5nVmlld1RyYW5zaXRpb24oKVxuICAgICAgICAgIGNvbnN0IHJlcGxheVJlbmRlckV4aXQgPSB5aWVsZCogRWZmZWN0LmV4aXQoXG4gICAgICAgICAgICByZW5kZXIocmVwbGF5ZWRNb2RlbCwgT3B0aW9uLm5vbmUoKSwgbm9PcERpc3BhdGNoLCAnUmVwbGF5JyksXG4gICAgICAgICAgKVxuICAgICAgICAgIGlmIChFeGl0LmlzRmFpbHVyZShyZXBsYXlSZW5kZXJFeGl0KSkge1xuICAgICAgICAgICAgZHJhaW5Nb3VudEV2ZW50cygpXG4gICAgICAgICAgICBpZiAoaXNQYXVzZWROb3coKSkge1xuICAgICAgICAgICAgICAvLyBOT1RFOiB0aGUgZmFpbGVkIHBhdGNoIG1heSBhbHJlYWR5IGhhdmUgY2hhbmdlZCB0aGVcbiAgICAgICAgICAgICAgLy8gRE9NLiBSZXBhaW50IHRoZSBNb2RlbCBhdCB0aGUgc3RvcmUncyBwcmV2aW91cyBwYXVzZWRcbiAgICAgICAgICAgICAgLy8gaW5kZXggYmVmb3JlIHJldHVybmluZyB0aGUgZmFpbHVyZS4gSWYgdGhhdCBNb2RlbCBub1xuICAgICAgICAgICAgICAvLyBsb25nZXIgcmVuZGVycyBlaXRoZXIsIHJlc3VtZSB0aGUgc3RvcmUgc28gaXRzIG5vcm1hbFxuICAgICAgICAgICAgICAvLyBsaXZlIGZyYW1lIGJlY29tZXMgdGhlIHNpbmdsZSByZWNvdmVyeSBwYXRoLlxuICAgICAgICAgICAgICBjb25zdCByb2xsYmFja0V4aXQgPSB5aWVsZCogRWZmZWN0LmV4aXQoXG4gICAgICAgICAgICAgICAgcmVuZGVyKFxuICAgICAgICAgICAgICAgICAgcHJldmlvdXNSZW5kZXJlZE1vZGVsLFxuICAgICAgICAgICAgICAgICAgT3B0aW9uLm5vbmUoKSxcbiAgICAgICAgICAgICAgICAgIG5vT3BEaXNwYXRjaCxcbiAgICAgICAgICAgICAgICAgICdSZXBsYXknLFxuICAgICAgICAgICAgICAgICksXG4gICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgZHJhaW5Nb3VudEV2ZW50cygpXG4gICAgICAgICAgICAgIGlmIChFeGl0LmlzRmFpbHVyZShyb2xsYmFja0V4aXQpKSB7XG4gICAgICAgICAgICAgICAgeWllbGQqIHJlc3VtZURldlRvb2xzXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIC8vIE5PVEU6IGEgZmFpbGVkIGZpcnN0IGp1bXAgbGVhdmVzIHRoZSBzdG9yZSBsaXZlLiBLZWVwXG4gICAgICAgICAgICAgIC8vIE1vdW50cyBQYXVzZWQgdGhyb3VnaCB0aGUgcmVjb3ZlcnkgcGF0Y2gsIHdoaWNoXG4gICAgICAgICAgICAgIC8vIHB1Ymxpc2hlcyBMaXZlIG9ubHkgYWZ0ZXIgdGhlIGxpdmUgRE9NIGlzIHJlc3RvcmVkLlxuICAgICAgICAgICAgICB5aWVsZCogRWZmZWN0LnN5bmMoKCkgPT4gc2NoZWR1bGVSZW5kZXJGcmFtZSh0cnVlKSlcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiB5aWVsZCogRWZmZWN0LmZhaWxDYXVzZShyZXBsYXlSZW5kZXJFeGl0LmNhdXNlKVxuICAgICAgICAgIH1cbiAgICAgICAgICBkcmFpbk1vdW50RXZlbnRzKClcbiAgICAgICAgICAvLyBOT1RFOiBhIHJlcGxheSBwYWludHMgYSBwYXN0IE1vZGVsLCBzbyBpdCBvd25zIHRoZSBET00gb25cbiAgICAgICAgICAvLyBzY3JlZW4gdW50aWwgdGhlIG5leHQgbGl2ZSBmcmFtZS4gTGVhdmluZ1xuICAgICAgICAgIC8vIGBsYXN0UmVuZGVyZWRNb2RlbGAgb24gdGhlIHByZS1wYXVzZSBNb2RlbCB3b3VsZCBoYW5kIHRoZVxuICAgICAgICAgIC8vIGB2aWV3VHJhbnNpdGlvbmAgcHJlZGljYXRlIGEgYHByZXZpb3VzTW9kZWxgIGRlc2NyaWJpbmcgYVxuICAgICAgICAgIC8vIERPTSB0aGF0IG5vIGxvbmdlciBleGlzdHMsIGFuZCB0aGUgZnJhbWUgYHJlc3VtZWBcbiAgICAgICAgICAvLyBzY2hlZHVsZXMgd291bGQgYW5pbWF0ZSB0aGUgd3JvbmcgZGlyZWN0aW9uIG91dCBvZiB0aGVcbiAgICAgICAgICAvLyB3cm9uZyBzbmFwc2hvdC5cbiAgICAgICAgICBsYXN0UmVuZGVyZWRNb2RlbCA9IHJlcGxheWVkTW9kZWxcbiAgICAgICAgICAvLyBOT1RFOiB0aGUgTWVzc2FnZSB0aGF0IGRpcnRpZWQgdGhlIHByZS1wYXVzZSBmcmFtZSBkb2VzIG5vdFxuICAgICAgICAgIC8vIGRlc2NyaWJlIHRoaXMgcmVwYWludC4gQ2xlYXJpbmcgaXQgbWVhbnMgdGhlIGZyYW1lIGByZXN1bWVgXG4gICAgICAgICAgLy8gc2NoZWR1bGVzIHJlbmRlcnMgcGxhaW5seSwgbWF0Y2hpbmcgdGhlIGRvY3VtZW50ZWQgcnVsZVxuICAgICAgICAgIC8vIHRoYXQgdGltZS10cmF2ZWwgbmV2ZXIgYW5pbWF0ZXMuXG4gICAgICAgICAgbWF5YmVMYXN0RGlydHlNZXNzYWdlID0gT3B0aW9uLm5vbmUoKVxuICAgICAgICB9KSxcbiAgICAgIC8vIE5PVEU6IGByZXN1bWVgIGNhbGxzIHRoaXMgYWZ0ZXIgYSBqdW1wVG8gcmVuZGVyIGF0dGFjaGVkIERPTVxuICAgICAgLy8gbGlzdGVuZXJzIHRvIGBub09wRGlzcGF0Y2hgLiBTY2hlZHVsaW5nIGEgZnJhbWUgcmVuZGVycyB0aGVcbiAgICAgIC8vIGxpdmUgbW9kZWwgd2l0aCBsaXZlIGRpc3BhdGNoIGFuZCByZWJpbmRzIGxpc3RlbmVycy5cbiAgICAgIG1hcmtSZW5kZXJQZW5kaW5nOiBFZmZlY3Quc3luYygoKSA9PiBzY2hlZHVsZVJlbmRlckZyYW1lKHRydWUpKSxcbiAgICB9XG5cbiAgICByZXR1cm4ge1xuICAgICAgY3Jhc2hXaXRoLFxuICAgICAgcmVuZGVyLFxuICAgICAgc2V0TGFzdERpcnR5TWVzc2FnZSxcbiAgICAgIHNjaGVkdWxlUmVuZGVyRnJhbWUsXG4gICAgICBza2lwUGVuZGluZ1ZpZXdUcmFuc2l0aW9uLFxuICAgICAgZGV2VG9vbHNSZW5kZXJCcmlkZ2UsXG4gICAgfVxuICB9KVxuIl0sImZpbGUiOiIvcHJpdmF0ZS90bXAvZm9sZGtpdC1yMTEtcjE5LXByb3RvdHlwZS0yMDI2MTEwOC5PblFoNU4vYmFzZWxpbmUvcGFja2FnZXMvZm9sZGtpdC9zcmMvcnVudGltZS9yZW5kZXJlci50cyJ9