import { Effect, Queue, Stream } from "/node_modules/.vite/deps/effect.js?v=1452da90";
/**
* A cold Stream that emits the elapsed milliseconds on every
* `requestAnimationFrame` tick. Each subscriber owns its animation frame loop,
* and ending the Stream cancels the pending frame.
*
* The browser pauses `requestAnimationFrame` when the tab is hidden, so the
* first elapsed value after it becomes visible may be large. Cap the value in
* the Subscription handler when the update uses it for motion or physics.
*
* @example
* ```ts
* const ExampleKey = Symbol('Example')
* const ExampleBlock = Block.make('Example', {
*   key: ExampleKey,
*   Model,
*   Message,
*   InitArgs: Schema.Tuple([]),
* })
* const subscriptions = ExampleBlock.makeSubscriptions(entry => ({
*   frame: entry(
*     'AnimationFrameTicks',
*     { isActive: Schema.Boolean },
*     {
*       messages: [Message.Ticked],
*       modelToDependencies: model => ({ isActive: model.isActive }),
*       handler: function* () {
*         return ({ isActive }) =>
*           isActive
*             ? Dom.animationFrameTicks.pipe(
*                 Stream.map(deltaTime => Message.Ticked({ deltaTime })),
*               )
*             : Stream.empty
*       },
*     },
*   ),
* }))
*
* const EffectsLayer = subscriptions.frame.layer
* ```
*/
export const animationFrameTicks = Stream.callback((queue) => Effect.acquireRelease(Effect.sync(() => {
	const state = {
		frameId: 0,
		lastTime: performance.now()
	};
	const tick = (now) => {
		const deltaTime = now - state.lastTime;
		state.lastTime = now;
		Queue.offerUnsafe(queue, deltaTime);
		state.frameId = requestAnimationFrame(tick);
	};
	state.frameId = requestAnimationFrame(tick);
	return state;
}), (state) => Effect.sync(() => cancelAnimationFrame(state.frameId))).pipe(Effect.flatMap(() => Effect.never)));

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxRQUFRLE9BQU8sY0FBYzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUEwQ3RDLE9BQU8sTUFBTSxzQkFDWCxPQUFPLFVBQWlCLFVBQ3RCLE9BQU8sZUFDTCxPQUFPLFdBQVc7Q0FDaEIsTUFBTSxRQUFRO0VBQ1osU0FBUztFQUNULFVBQVUsWUFBWSxJQUFJO0NBQzVCO0NBRUEsTUFBTSxRQUFRLFFBQXNCO0VBQ2xDLE1BQU0sWUFBWSxNQUFNLE1BQU07RUFDOUIsTUFBTSxXQUFXO0VBQ2pCLE1BQU0sWUFBWSxPQUFPLFNBQVM7RUFDbEMsTUFBTSxVQUFVLHNCQUFzQixJQUFJO0NBQzVDO0NBRUEsTUFBTSxVQUFVLHNCQUFzQixJQUFJO0NBQzFDLE9BQU87QUFDVCxDQUFDLElBQ0QsVUFBUyxPQUFPLFdBQVcscUJBQXFCLE1BQU0sT0FBTyxDQUFDLENBQ2hFLENBQUMsQ0FBQyxLQUFLLE9BQU8sY0FBYyxPQUFPLEtBQUssQ0FBQyxDQUMzQyIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJhbmltYXRpb25GcmFtZVRpY2tzLnRzIl0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEVmZmVjdCwgUXVldWUsIFN0cmVhbSB9IGZyb20gJ2VmZmVjdCdcblxuLyoqXG4gKiBBIGNvbGQgU3RyZWFtIHRoYXQgZW1pdHMgdGhlIGVsYXBzZWQgbWlsbGlzZWNvbmRzIG9uIGV2ZXJ5XG4gKiBgcmVxdWVzdEFuaW1hdGlvbkZyYW1lYCB0aWNrLiBFYWNoIHN1YnNjcmliZXIgb3ducyBpdHMgYW5pbWF0aW9uIGZyYW1lIGxvb3AsXG4gKiBhbmQgZW5kaW5nIHRoZSBTdHJlYW0gY2FuY2VscyB0aGUgcGVuZGluZyBmcmFtZS5cbiAqXG4gKiBUaGUgYnJvd3NlciBwYXVzZXMgYHJlcXVlc3RBbmltYXRpb25GcmFtZWAgd2hlbiB0aGUgdGFiIGlzIGhpZGRlbiwgc28gdGhlXG4gKiBmaXJzdCBlbGFwc2VkIHZhbHVlIGFmdGVyIGl0IGJlY29tZXMgdmlzaWJsZSBtYXkgYmUgbGFyZ2UuIENhcCB0aGUgdmFsdWUgaW5cbiAqIHRoZSBTdWJzY3JpcHRpb24gaGFuZGxlciB3aGVuIHRoZSB1cGRhdGUgdXNlcyBpdCBmb3IgbW90aW9uIG9yIHBoeXNpY3MuXG4gKlxuICogQGV4YW1wbGVcbiAqIGBgYHRzXG4gKiBjb25zdCBFeGFtcGxlS2V5ID0gU3ltYm9sKCdFeGFtcGxlJylcbiAqIGNvbnN0IEV4YW1wbGVCbG9jayA9IEJsb2NrLm1ha2UoJ0V4YW1wbGUnLCB7XG4gKiAgIGtleTogRXhhbXBsZUtleSxcbiAqICAgTW9kZWwsXG4gKiAgIE1lc3NhZ2UsXG4gKiAgIEluaXRBcmdzOiBTY2hlbWEuVHVwbGUoW10pLFxuICogfSlcbiAqIGNvbnN0IHN1YnNjcmlwdGlvbnMgPSBFeGFtcGxlQmxvY2subWFrZVN1YnNjcmlwdGlvbnMoZW50cnkgPT4gKHtcbiAqICAgZnJhbWU6IGVudHJ5KFxuICogICAgICdBbmltYXRpb25GcmFtZVRpY2tzJyxcbiAqICAgICB7IGlzQWN0aXZlOiBTY2hlbWEuQm9vbGVhbiB9LFxuICogICAgIHtcbiAqICAgICAgIG1lc3NhZ2VzOiBbTWVzc2FnZS5UaWNrZWRdLFxuICogICAgICAgbW9kZWxUb0RlcGVuZGVuY2llczogbW9kZWwgPT4gKHsgaXNBY3RpdmU6IG1vZGVsLmlzQWN0aXZlIH0pLFxuICogICAgICAgaGFuZGxlcjogZnVuY3Rpb24qICgpIHtcbiAqICAgICAgICAgcmV0dXJuICh7IGlzQWN0aXZlIH0pID0+XG4gKiAgICAgICAgICAgaXNBY3RpdmVcbiAqICAgICAgICAgICAgID8gRG9tLmFuaW1hdGlvbkZyYW1lVGlja3MucGlwZShcbiAqICAgICAgICAgICAgICAgICBTdHJlYW0ubWFwKGRlbHRhVGltZSA9PiBNZXNzYWdlLlRpY2tlZCh7IGRlbHRhVGltZSB9KSksXG4gKiAgICAgICAgICAgICAgIClcbiAqICAgICAgICAgICAgIDogU3RyZWFtLmVtcHR5XG4gKiAgICAgICB9LFxuICogICAgIH0sXG4gKiAgICksXG4gKiB9KSlcbiAqXG4gKiBjb25zdCBFZmZlY3RzTGF5ZXIgPSBzdWJzY3JpcHRpb25zLmZyYW1lLmxheWVyXG4gKiBgYGBcbiAqL1xuZXhwb3J0IGNvbnN0IGFuaW1hdGlvbkZyYW1lVGlja3M6IFN0cmVhbS5TdHJlYW08bnVtYmVyPiA9XG4gIFN0cmVhbS5jYWxsYmFjazxudW1iZXI+KHF1ZXVlID0+XG4gICAgRWZmZWN0LmFjcXVpcmVSZWxlYXNlKFxuICAgICAgRWZmZWN0LnN5bmMoKCkgPT4ge1xuICAgICAgICBjb25zdCBzdGF0ZSA9IHtcbiAgICAgICAgICBmcmFtZUlkOiAwLFxuICAgICAgICAgIGxhc3RUaW1lOiBwZXJmb3JtYW5jZS5ub3coKSxcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IHRpY2sgPSAobm93OiBudW1iZXIpOiB2b2lkID0+IHtcbiAgICAgICAgICBjb25zdCBkZWx0YVRpbWUgPSBub3cgLSBzdGF0ZS5sYXN0VGltZVxuICAgICAgICAgIHN0YXRlLmxhc3RUaW1lID0gbm93XG4gICAgICAgICAgUXVldWUub2ZmZXJVbnNhZmUocXVldWUsIGRlbHRhVGltZSlcbiAgICAgICAgICBzdGF0ZS5mcmFtZUlkID0gcmVxdWVzdEFuaW1hdGlvbkZyYW1lKHRpY2spXG4gICAgICAgIH1cblxuICAgICAgICBzdGF0ZS5mcmFtZUlkID0gcmVxdWVzdEFuaW1hdGlvbkZyYW1lKHRpY2spXG4gICAgICAgIHJldHVybiBzdGF0ZVxuICAgICAgfSksXG4gICAgICBzdGF0ZSA9PiBFZmZlY3Quc3luYygoKSA9PiBjYW5jZWxBbmltYXRpb25GcmFtZShzdGF0ZS5mcmFtZUlkKSksXG4gICAgKS5waXBlKEVmZmVjdC5mbGF0TWFwKCgpID0+IEVmZmVjdC5uZXZlcikpLFxuICApXG4iXX0=