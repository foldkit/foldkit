import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/@fs/Users/devinjameson/.codex/worktrees/block-completion-record/foldkit-unified-recovery-20261103/packages/foldkit/src/runtime/renderer.ts");import { Array, Cause, Context, Effect, Exit, Option, Predicate } from "/node_modules/.vite/deps/effect.js?v=61507815";
import { FOLDKIT_MOUNT_KEY, __beginRender as beginHtmlRender, __beginReplayRender as beginReplayHtmlRender, __clearRuntime as clearHtmlRuntime, __createBoundaryRegistry as createHtmlBoundaryRegistry, __endReplayRender as endReplayHtmlRender, __flushReplayUnmountsAfterPatchFailure as flushReplayUnmountsAfterPatchFailure, __setRuntime as setHtmlRuntime } from "/@fs/Users/devinjameson/.codex/worktrees/block-completion-record/foldkit-unified-recovery-20261103/packages/foldkit/src/html/index.ts";
import { __hydrateVNode } from "/@fs/Users/devinjameson/.codex/worktrees/block-completion-record/foldkit-unified-recovery-20261103/packages/foldkit/src/hydrate.ts";
import { FOLDKIT_APP_ATTRIBUTE } from "/@fs/Users/devinjameson/.codex/worktrees/block-completion-record/foldkit-unified-recovery-20261103/packages/foldkit/src/hydrationMarker.ts";
import { MountRegistrationTypeId, MountRuntime, MountTracker } from "/@fs/Users/devinjameson/.codex/worktrees/block-completion-record/foldkit-unified-recovery-20261103/packages/foldkit/src/mount/index.ts";
import { __patchVNode, __recoverVNodeAfterPatchFailure } from "/@fs/Users/devinjameson/.codex/worktrees/block-completion-record/foldkit-unified-recovery-20261103/packages/foldkit/src/vdom.ts";
import { noOpDispatch, renderCrashView } from "/@fs/Users/devinjameson/.codex/worktrees/block-completion-record/foldkit-unified-recovery-20261103/packages/foldkit/src/runtime/crashUI.ts";
import { Dispatch } from "/@fs/Users/devinjameson/.codex/worktrees/block-completion-record/foldkit-unified-recovery-20261103/packages/foldkit/src/runtime/dispatch.ts";
import { applyDocumentMetadata } from "/@fs/Users/devinjameson/.codex/worktrees/block-completion-record/foldkit-unified-recovery-20261103/packages/foldkit/src/runtime/documentMetadata.ts";
import { measureSlowPhase, reportSlowPhase } from "/@fs/Users/devinjameson/.codex/worktrees/block-completion-record/foldkit-unified-recovery-20261103/packages/foldkit/src/runtime/slowPhase.ts";
import { __decideViewTransition, __silenceViewTransitionRejections } from "/@fs/Users/devinjameson/.codex/worktrees/block-completion-record/foldkit-unified-recovery-20261103/packages/foldkit/src/runtime/viewTransition.ts";
/**
* Builds the render side of one runtime: the current vnode and, when
* hydrating, the server-rendered root the first render adopts, the crash
* renderer, the `Dispatch` service the view binds handlers to, the
* synchronous render that runs the view and patches the DOM, the render
* frame that runs in `requestAnimationFrame`, and the View Transition
* that frame may run inside. It also registers the teardown finalizer
* that patches the tree away and restores the container, so build it
* before forking the perpetual fibers: scope finalizers run
* last-registered first, and the container must be restored only after
* those fibers are interrupted.
*/
export const makeRenderer = ({ status, container, view, htmlBuilder, manageDocument, crash, buildId, initModel, maybeHydrationRoot, maybeSlowView, maybeSlowPatch, duplicateIdScanner, maybeResolvedViewTransition, commitNotifier, mounts, runtimeContext, readLiveModel, messageQueue, devToolsIntegration }) => Effect.gen(function* () {
	const { enqueueMessage, enqueueMessageEffect, drainPendingMessages, drainDeferredNow, resetDrainBudget, isAnyMessageDeferred } = messageQueue;
	const { mountTracker, mountRuntime, drainMountEvents, readViewState, setViewState, isPausedNow, resumeDevTools, attachRenderedMounts } = devToolsIntegration;
	const settlePendingCommit = () => {
		if (commitNotifier.service.isCommitPending()) {
			commitNotifier.notifyCommitted();
		}
	};
	// NOTE: `isRenderFrameScheduled` clears when the frame callback
	// starts, which on the View Transition path is before the patch runs.
	// `commitNotifier` tracks the patch itself, so `Render.afterCommit`
	// waits for the commit rather than for the frame that scheduled it.
	let isRenderFrameScheduled = false;
	// NOTE: resume clears the DevTools store's pause flag before its frame
	// patches the live view. This distinguishes that intentional repaint
	// from an ordinary frame that was already queued when jumpTo installed
	// the historical view.
	let isLiveViewRestorePending = false;
	let isRenderFrameArmed = false;
	let maybeArmRenderFrameChannel = null;
	yield* Effect.addFinalizer(() => Effect.sync(() => {
		if (maybeArmRenderFrameChannel !== null) {
			maybeArmRenderFrameChannel.port1.close();
			maybeArmRenderFrameChannel.port2.close();
			maybeArmRenderFrameChannel = null;
		}
	}));
	// NOTE: the Model behind the DOM currently on screen, which is what a
	// View Transition animates away from. Seeded with `initModel` because
	// the init render paints it, and advanced only where a render actually
	// commits. The `viewTransition` predicate never runs before a Message
	// has dirtied the Model, and the init render completes behind the boot
	// barrier, so this is always the model of a paint that happened.
	let lastRenderedModel = initModel;
	// NOTE: the transition the browser is still animating, if any. Held so
	// the runtime can skip it: when a later frame supersedes it, when the
	// runtime crashes, and at teardown, where the browser would otherwise
	// animate over a released container. Declared above `crashWith`, which
	// calls the skip and can run as early as the init render.
	let maybePendingViewTransition = Option.none();
	const skipPendingViewTransition = () => {
		if (Option.isSome(maybePendingViewTransition)) {
			const { value: pendingViewTransition } = maybePendingViewTransition;
			// NOTE: cleared first. An implementation that runs the update
			// callback synchronously would otherwise re-enter this.
			maybePendingViewTransition = Option.none();
			pendingViewTransition.update.isInvalidated = true;
			try {
				pendingViewTransition.handle.skipTransition();
			} catch {}
		}
	};
	// NOTE: the current vnode is plain closure state. The frame reads and
	// writes it directly; the cold paths that run inside Effects (crash
	// rendering, the dispose finalizer, the replay render) read the same
	// slot synchronously, so no Ref is needed.
	const vnodeSlot = { maybeCurrentVNode: Option.none() };
	const patchRuntimeVNode = (maybeCurrentVNode, nextVNode, seen) => {
		try {
			return __patchVNode(maybeCurrentVNode, nextVNode, container, seen, (patchedVNode) => {
				vnodeSlot.maybeCurrentVNode = Option.some(patchedVNode);
			});
		} catch (error) {
			try {
				const maybeRecoveryVNode = vnodeSlot.maybeCurrentVNode;
				if (Option.isSome(maybeRecoveryVNode)) {
					vnodeSlot.maybeCurrentVNode = Option.some(__recoverVNodeAfterPatchFailure(maybeRecoveryVNode.value));
				}
			} finally {
				flushReplayUnmountsAfterPatchFailure();
			}
			throw error;
		}
	};
	// NOTE: consumed by the first render only. Set when this boot found
	// an adoptable server-rendered root; the first patch then goes
	// through `__hydrateVNode` instead of replacing the container.
	let pendingHydrationRoot = Option.getOrNull(maybeHydrationRoot);
	// NOTE: registered before any perpetual fiber is forked so it runs
	// after they are interrupted (scope finalizers are LIFO). Patching to
	// an empty tree fires snabbdom destroy hooks, which is what releases
	// Mounts; swapping the placeholder for the original container leaves
	// the host DOM as it was before the first render, ready for a fresh
	// embed of the same container. Gated on interruption: that is the
	// dispose path. A runtime that stops because it crashed completes
	// normally after rendering the crash view, and the crash view must
	// stay visible.
	yield* Effect.addFinalizer((exit) => Effect.gen(function* () {
		if (Exit.hasInterrupts(exit)) {
			const maybeCurrentVNode = vnodeSlot.maybeCurrentVNode;
			yield* Option.match(maybeCurrentVNode, {
				onNone: () => Effect.void,
				onSome: (currentVNode) => Effect.sync(() => {
					const placeholderNode = __patchVNode(Option.some(currentVNode), null, container).elm;
					if (placeholderNode && placeholderNode.parentNode) {
						placeholderNode.parentNode.replaceChild(container, placeholderNode);
						container.replaceChildren();
					}
				})
			});
		}
		yield* mountRuntime.interruptFibers;
	}));
	// NOTE: shared by every crash path: the init render, the plain
	// message drain and render frame (which reach it through
	// `Effect.runFork` from their catch blocks), and the Command and
	// Subscription fibers (a Command's Effect and a Subscription's
	// Stream are typed with a `never` error channel, so a cause
	// escaping one is an unrecoverable defect). Each path catches its
	// own cause so a failure surfaces as the crash view instead of
	// dying silently and leaving the DOM frozen at the last successful
	// render. The first crash wins: concurrent Command fibers can fail,
	// and only one should report and render.
	const crashWith = (cause, maybeMessage) => Effect.sync(() => {
		if (status.isCrashed) {
			return;
		}
		status.isCrashed = true;
		messageQueue.drainPendingMessages();
		// NOTE: the crash view should appear at once, not animate in from
		// a snapshot of the state that crashed.
		skipPendingViewTransition();
		const model = readLiveModel();
		const squashed = Cause.squash(cause);
		const error = squashed instanceof Error ? squashed : new Error(String(squashed));
		renderCrashView({
			error,
			model,
			message: maybeMessage
		}, crash, container, vnodeSlot, manageDocument);
		settlePendingCommit();
	});
	// NOTE: `maybeLastDirtyMessage` holds the most recent dirtying Message,
	// so slow render-phase callbacks during high-rate bursts attribute to
	// the last Message in the frame batch, not the specific one that pushed
	// the view past threshold. Acceptable for a debug callback; full
	// attribution would require correlating each message with its render
	// contribution, which isn't worth the complexity.
	let maybeLastDirtyMessage = Option.none();
	const setLastDirtyMessage = (message) => {
		maybeLastDirtyMessage = Option.some(message);
	};
	const dispatchSync = (message, isCurrent) => {
		/* eslint-disable-next-line @typescript-eslint/consistent-type-assertions */
		enqueueMessage(message, isCurrent);
	};
	const dispatchAsync = (message, isCurrent) => enqueueMessageEffect(message, isCurrent);
	const dispatch = {
		dispatchAsync,
		dispatchSync
	};
	// NOTE: One boundary registry per runtime instance, shared
	// across renders so Block wrap blocks registered by
	// h.block persist between renders. The render function calls
	// `beginHtmlRender` at the start of each pass; wraps for
	// unmounted Blocks (e.g. an entry removed from a list) are
	// dropped from the registry via snabbdom `postdestroy` hooks
	// attached by `h.block` to each child vnode.
	const boundaryRegistry = createHtmlBoundaryRegistry();
	const registeredMounts = new Set(mounts.map((mount) => mount[MountRegistrationTypeId]));
	const mountValidationVisits = new Set();
	const assertLayeredMountsAreRegistered = (root) => {
		if (root === null) {
			return;
		}
		let missing;
		const walk = (node) => {
			const { children } = node;
			if (children !== undefined && Array.isArrayNonEmpty(children)) {
				if (mountValidationVisits.has(node)) {
					return;
				}
				mountValidationVisits.add(node);
			}
			/* eslint-disable-next-line @typescript-eslint/consistent-type-assertions */
			const marker = node.data?.[FOLDKIT_MOUNT_KEY];
			const registration = marker?.[MountRegistrationTypeId];
			if (marker !== undefined && registration !== undefined && !registeredMounts.has(registration)) {
				missing ??= new Map();
				missing.set(registration, marker.name);
			}
			if (children !== undefined) {
				for (const child of children) {
					if (!Predicate.isString(child)) {
						walk(child);
					}
				}
			}
		};
		try {
			walk(root);
		} finally {
			mountValidationVisits.clear();
		}
		if (missing === undefined) {
			return;
		}
		const names = globalThis.Array.from(missing.values()).sort();
		throw new Error(`[foldkit] The rendered view contains Layer-backed Mounts that were not registered: ${names.join(", ")}. ` + "Register each Mount Definition in the owning Composition's mounts field.");
	};
	// NOTE: callers set `isRenderingFrame` before calling this and clear
	// it after. Without it, a Message dispatched while the patch is still
	// running would run update against a half-patched DOM. For a replay,
	// `render` also calls `beginReplayHtmlRender` first, so the old
	// tree's unmount callbacks don't dispatch into live history.
	const renderSync = (model, maybeMessage, dispatchService, renderContext, renderMode) => {
		const maybeLiveRender = Option.liftPredicate(renderMode, (mode) => mode === "Live");
		const maybeLiveSlowView = Option.flatMap(maybeLiveRender, () => maybeSlowView);
		const maybeLiveSlowPatch = Option.flatMap(maybeLiveRender, () => maybeSlowPatch);
		const [nextDocument, maybeViewDuration] = measureSlowPhase(maybeLiveSlowView, () => {
			beginHtmlRender(boundaryRegistry);
			setHtmlRuntime(dispatchService.dispatchSync, renderContext, boundaryRegistry, renderMode);
			try {
				return view(model, htmlBuilder);
			} finally {
				clearHtmlRuntime();
			}
		});
		const { body: nextVNode } = nextDocument;
		assertLayeredMountsAreRegistered(nextVNode);
		reportSlowPhase(maybeLiveSlowView, maybeViewDuration, (durationMs, thresholdMs) => ({
			_tag: "View",
			model,
			message: maybeMessage,
			durationMs,
			thresholdMs
		}));
		const { maybeCurrentVNode } = vnodeSlot;
		const [patchedVNode, maybePatchDuration] = measureSlowPhase(maybeLiveSlowPatch, () => {
			if (Option.isNone(maybeCurrentVNode) && pendingHydrationRoot !== null) {
				const hydrationRoot = pendingHydrationRoot;
				pendingHydrationRoot = null;
				// NOTE: strip the stamp before the patch, not after, so the
				// patch is the sole owner of the root's attributes. It has
				// already served its purpose of locating the root, and
				// removing it after would delete a `data-foldkit-app` the view
				// itself declares, which a later equal-vnode patch would not
				// restore. Removing it here also stops a later boot on the same
				// container (a dispose-then-embed remount) from re-detecting
				// this now-consumed root as hydratable.
				hydrationRoot.removeAttribute(FOLDKIT_APP_ATTRIBUTE);
				// An empty id reaches the adoption step's own check as a
				// value that matches nothing. Boot already refused a
				// hydration without an id, so this stands in only for a
				// caller that reached here another way.
				return __hydrateVNode(hydrationRoot, nextVNode, boundaryRegistry.dedupeSeen, buildId ?? "");
			}
			return patchRuntimeVNode(maybeCurrentVNode, nextVNode, boundaryRegistry.dedupeSeen);
		});
		vnodeSlot.maybeCurrentVNode = Option.some(patchedVNode);
		reportSlowPhase(maybeLiveSlowPatch, maybePatchDuration, (durationMs, thresholdMs) => ({
			_tag: "Patch",
			model,
			message: maybeMessage,
			durationMs,
			thresholdMs
		}));
		if (manageDocument) {
			applyDocumentMetadata(nextDocument, patchedVNode.elm);
		}
		if (import.meta.hot) {
			duplicateIdScanner?.schedule(patchedVNode.elm);
		}
	};
	// NOTE: `dispatchService` defaults to live dispatch but is overridable
	// so a time-travel render can bind both declarative handlers and newly
	// acquired Mounts to `noOpDispatch`. A live Mount keeps its dispatcher
	// across replay, while a replay-created Mount stays muted until a live
	// resume patch releases it and starts the live action. This preserves
	// valid async results from live Mounts without granting a historical
	// acquisition access to the live Model.
	const render = (model, maybeMessage, dispatchService = dispatch, renderMode = "Live") => Effect.gen(function* () {
		status.isRenderingFrame = true;
		const renderContext = Context.add(Context.add(Context.add(runtimeContext, Dispatch, dispatchService), MountTracker, mountTracker), MountRuntime, mountRuntime);
		if (renderMode === "Replay") {
			beginReplayHtmlRender();
		}
		renderSync(model, maybeMessage, dispatchService, renderContext, renderMode);
	}).pipe(Effect.ensuring(Effect.sync(() => {
		status.isRenderingFrame = false;
		endReplayHtmlRender();
		drainPendingMessages();
	})));
	const liveRenderContext = Context.add(Context.add(Context.add(runtimeContext, Dispatch, dispatch), MountTracker, mountTracker), MountRuntime, mountRuntime);
	// NOTE: rendering before a deferred drain resumes would restore stale
	// controlled input values. Disposed or crashed runtimes use the frame guards.
	const isLiveModelBehindQueue = () => isAnyMessageDeferred() && !status.isRuntimeDisposed && !status.isCrashed;
	// NOTE: the render, Mount drain, DevTools attribution, and
	// patch-time-buffer flush. Shared by the plain path (called directly)
	// and the View Transition path (called from the transition's update
	// callback), which run identical work; only whether they run inside
	// `document.startViewTransition` differs. `isRenderingFrame` gates the
	// buffering of Messages dispatched by patch-time hooks, so it must
	// wrap the actual patch, which on the transition path happens inside
	// the callback, not when the frame is scheduled.
	const runRenderFrameBody = () => {
		status.isRenderingFrame = true;
		// NOTE: captured before the patch, because `drainPendingMessages`
		// below can advance the live Model again before the next frame reads
		// it. What this frame painted is what the next transition animates
		// away from.
		const renderedModel = readLiveModel();
		const isResuming = readViewState() === "Paused";
		if (isResuming) {
			// NOTE: Messages accumulated while a historical view owned the DOM
			// did not cause this repaint. A Message arriving during the patch
			// can repopulate this field when the buffered queue drains.
			maybeLastDirtyMessage = Option.none();
		}
		try {
			renderSync(readLiveModel(), maybeLastDirtyMessage, dispatch, liveRenderContext, "Live");
			// NOTE: after the patch, so a render that threw leaves this on the
			// Model still on screen, and before `drainPendingMessages` below,
			// whose handlers can advance the live Model again.
			lastRenderedModel = renderedModel;
			// NOTE: resume clears the store's pause flag before this frame.
			// Publish Live only after the live DOM has been installed.
			setViewState("Live");
			attachRenderedMounts();
		} catch (error) {
			Effect.runFork(crashWith(Cause.die(error), maybeLastDirtyMessage));
		} finally {
			status.isRenderingFrame = false;
		}
		// NOTE: Messages dispatched by patch-time hooks (for example,
		// OnUnmount destroys, or Mount emissions) were buffered while the
		// frame held the stack; they process now, after the patch has
		// committed and the frame's Mount events are attributed.
		drainPendingMessages();
		// NOTE: last, so a waiter resumed by the commit observes the same
		// DOM and the same processed-Message ordering it saw when
		// `afterCommit` counted frames.
		settlePendingCommit();
	};
	// NOTE: starts a View Transition around this frame's render when the
	// `viewTransition` predicate matches, returning `true` when it did.
	// `startViewTransition` invokes its update callback asynchronously
	// after snapshotting the old DOM, so the callback reads the live Model
	// and `maybeLastDirtyMessage` fresh (the plain loop may have advanced
	// the model while the browser suppressed rendering) and re-checks the
	// disposal and crash guards, which can flip while the transition is
	// pending. The unconfigured path never reaches this function; the
	// `Option.isNone` check in `renderFramePlain` returns first, so a
	// runtime without `viewTransition` allocates no per-frame callback.
	const startFrameViewTransition = (resolved) => {
		if (readViewState() === "Paused") {
			return false;
		}
		if (resolved.reducedMotionQuery.matches) {
			return false;
		}
		if (Option.isNone(maybeLastDirtyMessage)) {
			return false;
		}
		const maybeDecision = __decideViewTransition(resolved.decide, {
			previousModel: lastRenderedModel,
			model: readLiveModel(),
			message: maybeLastDirtyMessage.value
		});
		if (Option.isNone(maybeDecision)) {
			return false;
		}
		// NOTE: invalidate an older transition before this one takes
		// ownership of the latest live repaint. The browser may still call
		// the older update callback, but its invalidation guard leaves the
		// DOM and commit notifier to this transition.
		skipPendingViewTransition();
		try {
			const update = {
				isInvalidated: false,
				didRun: false
			};
			const handle = resolved.startViewTransition(() => {
				if (update.isInvalidated || update.didRun) {
					return;
				}
				update.didRun = true;
				// NOTE: a drain may have been deferred since the preceding frame
				// started the transition. Leave the DOM unchanged until it catches up.
				if (isLiveModelBehindQueue()) {
					skipPendingViewTransition();
					scheduleRenderFrame();
					return;
				}
				// NOTE: the view state closes the resume window after the
				// store is live but before its plain frame has restored the live
				// DOM. A transition invalidated by jumpTo stays invalid forever,
				// so its callback cannot repaint inside the stale transition
				// even if it arrives after resume has published `Live`.
				if (status.isRuntimeDisposed || status.isCrashed || isPausedNow() || readViewState() === "Paused") {
					settlePendingCommit();
					return;
				}
				runRenderFrameBody();
			}, maybeDecision.value.maybeTypes);
			maybePendingViewTransition = Option.some({
				handle,
				update
			});
			__silenceViewTransitionRejections(handle);
			return true;
		} catch {
			// NOTE: an escaping throw would leave the rAF callback without a
			// patch and without settling the commit notifier, parking every
			// `Render.afterCommit` on this frame forever.
			return false;
		}
	};
	// NOTE: every path out of a scheduled frame settles the commit
	// notifier, whether or not it patched. A frame abandoned silently
	// would strand any `Render.afterCommit` registered against it, and
	// the Dom helpers that gate on it would never run their DOM work.
	const renderFramePlain = () => {
		// NOTE: a frame proves the browser regained control after a budget yield.
		if (isLiveModelBehindQueue()) {
			drainDeferredNow();
		}
		// NOTE: retain the scheduled frame's pending commit while the drain waits.
		if (isLiveModelBehindQueue()) {
			requestAnimationFrame(renderFramePlain);
			return;
		}
		isRenderFrameArmed = false;
		if (!isRenderFrameScheduled) {
			return;
		}
		isRenderFrameScheduled = false;
		const isRestoringLiveView = isLiveViewRestorePending;
		isLiveViewRestorePending = false;
		// NOTE: a frame scheduled before disposal fires after it; a
		// disposed runtime must not repaint the released container.
		if (status.isRuntimeDisposed) {
			settlePendingCommit();
			return;
		}
		// NOTE: a frame is running, so the browser got control back; the
		// drain budget starts fresh.
		resetDrainBudget();
		// NOTE: a Message that dirtied the model can also be the one
		// whose Command crashed the runtime. Without this guard the
		// next animation frame would render the live view over the
		// crash view.
		if (status.isCrashed) {
			settlePendingCommit();
			return;
		}
		if (isPausedNow()) {
			settlePendingCommit();
			return;
		}
		if (readViewState() === "Paused" && !isRestoringLiveView) {
			settlePendingCommit();
			return;
		}
		// NOTE: the unconfigured path pays one `Option.isNone` check and
		// renders directly, allocating no per-frame callback. Only a
		// runtime configured with `viewTransition` reaches
		// `startFrameViewTransition`, which decides per frame whether to
		// wrap the render in `document.startViewTransition`. When it does,
		// the render runs later, inside the transition's update callback.
		if (Option.isNone(maybeResolvedViewTransition)) {
			runRenderFrameBody();
			armNextRenderFrame();
			return;
		}
		if (!startFrameViewTransition(maybeResolvedViewTransition.value)) {
			runRenderFrameBody();
		}
		armNextRenderFrame();
	};
	// NOTE: requesting from a task after this frame places the render after
	// the next tick that an animation-frame Subscription already requested.
	// An unchanged frame returns without arming another callback.
	const armNextRenderFrame = () => {
		if (status.isRuntimeDisposed || status.isCrashed) {
			return;
		}
		if (maybeArmRenderFrameChannel === null) {
			maybeArmRenderFrameChannel = new MessageChannel();
			maybeArmRenderFrameChannel.port2.onmessage = () => {
				if (isRenderFrameArmed || isRenderFrameScheduled || status.isRuntimeDisposed || status.isCrashed) {
					return;
				}
				isRenderFrameArmed = true;
				requestAnimationFrame(renderFramePlain);
			};
		}
		maybeArmRenderFrameChannel.port1.postMessage(null);
	};
	// NOTE: render frames run as plain JavaScript inside the
	// requestAnimationFrame callback. Messages arriving between frames mark
	// at most one pending frame; the callback renders once with the latest
	// model.
	const scheduleRenderFrame = (isRestoringLiveView = false) => {
		if (isRestoringLiveView) {
			isLiveViewRestorePending = true;
		}
		if (isRenderFrameScheduled) {
			return;
		}
		isRenderFrameScheduled = true;
		commitNotifier.markCommitPending();
		if (isRenderFrameArmed) {
			return;
		}
		requestAnimationFrame(renderFramePlain);
	};
	const devToolsRenderBridge = {
		// NOTE: passes `noOpDispatch` so declarative handlers and Mounts
		// acquired by the replay cannot reach the live Model. Their
		// fibers stay alive and can observe view-state changes while the
		// historical view owns them. If resume reuses such an element,
		// OnMount releases the replay acquisition before starting the
		// live action. Also discards mount events fired during the render
		// so they don't get attributed to the next user-initiated dispatch.
		renderReplay: (model) => Effect.gen(function* () {
			/* eslint-disable-next-line @typescript-eslint/consistent-type-assertions */
			const replayedModel = model;
			const previousRenderedModel = lastRenderedModel;
			// NOTE: a Mount surviving from the live view must observe
			// Paused before the historical patch can expose different
			// DOM. Mounts inserted by that patch capture this state when
			// acquired, so asynchronous setup cannot skip Paused even if
			// it consumes the Stream only after the live view returns.
			setViewState("Paused");
			// NOTE: a transition still animating belongs to the live
			// state this replay is about to paint over. Left running it
			// animates a dead snapshot across the replayed DOM.
			skipPendingViewTransition();
			const replayRenderExit = yield* Effect.exit(render(replayedModel, Option.none(), noOpDispatch, "Replay"));
			if (Exit.isFailure(replayRenderExit)) {
				drainMountEvents();
				if (isPausedNow()) {
					// NOTE: the failed patch may already have changed the
					// DOM. Repaint the Model at the store's previous paused
					// index before returning the failure. If that Model no
					// longer renders either, resume the store so its normal
					// live frame becomes the single recovery path.
					const rollbackExit = yield* Effect.exit(render(previousRenderedModel, Option.none(), noOpDispatch, "Replay"));
					drainMountEvents();
					if (Exit.isFailure(rollbackExit)) {
						yield* resumeDevTools;
					}
				} else {
					// NOTE: a failed first jump leaves the store live. Keep
					// Mounts Paused through the recovery patch, which
					// publishes Live only after the live DOM is restored.
					yield* Effect.sync(() => scheduleRenderFrame(true));
				}
				return yield* Effect.failCause(replayRenderExit.cause);
			}
			drainMountEvents();
			// NOTE: a replay paints a past Model, so it owns the DOM on
			// screen until the next live frame. Leaving
			// `lastRenderedModel` on the pre-pause Model would hand the
			// `viewTransition` predicate a `previousModel` describing a
			// DOM that no longer exists, and the frame `resume`
			// schedules would animate the wrong direction out of the
			// wrong snapshot.
			lastRenderedModel = replayedModel;
			// NOTE: the Message that dirtied the pre-pause frame does not
			// describe this repaint. Clearing it means the frame `resume`
			// schedules renders plainly, matching the documented rule
			// that time-travel never animates.
			maybeLastDirtyMessage = Option.none();
		}),
		// NOTE: `resume` calls this after a jumpTo render attached DOM
		// listeners to `noOpDispatch`. Scheduling a frame renders the
		// live model with live dispatch and rebinds listeners.
		markRenderPending: Effect.sync(() => scheduleRenderFrame(true))
	};
	return {
		crashWith,
		render,
		setLastDirtyMessage,
		scheduleRenderFrame,
		skipPendingViewTransition,
		devToolsRenderBridge
	};
});

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FDRSxPQUNBLE9BQ0EsU0FDQSxRQUNBLE1BQ0EsUUFDQSxpQkFFSztBQUVQLFNBR0UsbUJBR0EsaUJBQWlCLGlCQUNqQix1QkFBdUIsdUJBQ3ZCLGtCQUFrQixrQkFDbEIsNEJBQTRCLDRCQUM1QixxQkFBcUIscUJBQ3JCLDBDQUEwQyxzQ0FDMUMsZ0JBQWdCLHNCQUNYO0FBQ1AsU0FBUyxzQkFBc0I7QUFDL0IsU0FBUyw2QkFBNkI7QUFDdEMsU0FHRSx5QkFDQSxjQUNBLG9CQUNLO0FBRVAsU0FFRSxjQUNBLHVDQUNLO0FBQ1AsU0FHRSxjQUNBLHVCQUNLO0FBS1AsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyw2QkFBNkI7QUFJdEMsU0FJRSxrQkFDQSx1QkFDSztBQUNQLFNBSUUsd0JBQ0EseUNBQ0s7Ozs7Ozs7Ozs7Ozs7QUEwRFAsT0FBTyxNQUFNLGdCQUFnQyxFQUMzQyxRQUNBLFdBQ0EsTUFDQSxhQUNBLGdCQUNBLE9BQ0EsU0FDQSxXQUNBLG9CQUNBLGVBQ0EsZ0JBQ0Esb0JBQ0EsNkJBQ0EsZ0JBQ0EsUUFDQSxnQkFDQSxlQUNBLGNBQ0EsMEJBNEJBLE9BQU8sSUFBSSxhQUFhO0NBQ3RCLE1BQU0sRUFDSixnQkFDQSxzQkFDQSxzQkFDQSxrQkFDQSxrQkFDQSx5QkFDRTtDQUNKLE1BQU0sRUFDSixjQUNBLGNBQ0Esa0JBQ0EsZUFDQSxjQUNBLGFBQ0EsZ0JBQ0EseUJBQ0U7Q0FFSixNQUFNLDRCQUFrQztFQUN0QyxJQUFJLGVBQWUsUUFBUSxnQkFBZ0IsR0FBRztHQUM1QyxlQUFlLGdCQUFnQjtFQUNqQztDQUNGOzs7OztDQU1BLElBQUkseUJBQXlCOzs7OztDQUs3QixJQUFJLDJCQUEyQjtDQUMvQixJQUFJLHFCQUFxQjtDQUN6QixJQUFJLDZCQUFvRDtDQUV4RCxPQUFPLE9BQU8sbUJBQ1osT0FBTyxXQUFXO0VBQ2hCLElBQUksK0JBQStCLE1BQU07R0FDdkMsMkJBQTJCLE1BQU0sTUFBTTtHQUN2QywyQkFBMkIsTUFBTSxNQUFNO0dBQ3ZDLDZCQUE2QjtFQUMvQjtDQUNGLENBQUMsQ0FDSDs7Ozs7OztDQVFBLElBQUksb0JBQTJCOzs7Ozs7Q0FPL0IsSUFBSSw2QkFBNkIsT0FBTyxLQUE0QjtDQUVwRSxNQUFNLGtDQUF3QztFQUM1QyxJQUFJLE9BQU8sT0FBTywwQkFBMEIsR0FBRztHQUM3QyxNQUFNLEVBQUUsT0FBTywwQkFBMEI7OztHQUd6Qyw2QkFBNkIsT0FBTyxLQUFLO0dBQ3pDLHNCQUFzQixPQUFPLGdCQUFnQjtHQUM3QyxJQUFJO0lBQ0Ysc0JBQXNCLE9BQU8sZUFBZTtHQUM5QyxRQUFRLENBR1I7RUFDRjtDQUNGOzs7OztDQU1BLE1BQU0sWUFBdUIsRUFBRSxtQkFBbUIsT0FBTyxLQUFLLEVBQUU7Q0FFaEUsTUFBTSxxQkFDSixtQkFDQSxXQUNBLFNBQ1U7RUFDVixJQUFJO0dBQ0YsT0FBTyxhQUNMLG1CQUNBLFdBQ0EsV0FDQSxPQUNBLGlCQUFnQjtJQUNkLFVBQVUsb0JBQW9CLE9BQU8sS0FBSyxZQUFZO0dBQ3hELENBQ0Y7RUFDRixTQUFTLE9BQU87R0FDZCxJQUFJO0lBQ0YsTUFBTSxxQkFBcUIsVUFBVTtJQUNyQyxJQUFJLE9BQU8sT0FBTyxrQkFBa0IsR0FBRztLQUNyQyxVQUFVLG9CQUFvQixPQUFPLEtBQ25DLGdDQUFnQyxtQkFBbUIsS0FBSyxDQUMxRDtJQUNGO0dBQ0YsVUFBVTtJQUNSLHFDQUFxQztHQUN2QztHQUNBLE1BQU07RUFDUjtDQUNGOzs7O0NBS0EsSUFBSSx1QkFDRixPQUFPLFVBQVUsa0JBQWtCOzs7Ozs7Ozs7O0NBV3JDLE9BQU8sT0FBTyxjQUFhLFNBQ3pCLE9BQU8sSUFBSSxhQUFhO0VBQ3RCLElBQUksS0FBSyxjQUFjLElBQUksR0FBRztHQUM1QixNQUFNLG9CQUFvQixVQUFVO0dBQ3BDLE9BQU8sT0FBTyxNQUFNLG1CQUFtQjtJQUNyQyxjQUFjLE9BQU87SUFDckIsU0FBUSxpQkFDTixPQUFPLFdBQVc7S0FDaEIsTUFBTSxrQkFBa0IsYUFDdEIsT0FBTyxLQUFLLFlBQVksR0FDeEIsTUFDQSxTQUNGLENBQUMsQ0FBQztLQUNGLElBQUksbUJBQW1CLGdCQUFnQixZQUFZO01BQ2pELGdCQUFnQixXQUFXLGFBQ3pCLFdBQ0EsZUFDRjtNQUNBLFVBQVUsZ0JBQWdCO0tBQzVCO0lBQ0YsQ0FBQztHQUNMLENBQUM7RUFDSDtFQUVBLE9BQU8sYUFBYTtDQUN0QixDQUFDLENBQ0g7Ozs7Ozs7Ozs7O0NBWUEsTUFBTSxhQUNKLE9BQ0EsaUJBRUEsT0FBTyxXQUFXO0VBQ2hCLElBQUksT0FBTyxXQUFXO0dBQ3BCO0VBQ0Y7RUFDQSxPQUFPLFlBQVk7RUFDbkIsYUFBYSxxQkFBcUI7OztFQUdsQywwQkFBMEI7RUFDMUIsTUFBTSxRQUFRLGNBQWM7RUFDNUIsTUFBTSxXQUFXLE1BQU0sT0FBTyxLQUFLO0VBQ25DLE1BQU0sUUFDSixvQkFBb0IsUUFBUSxXQUFXLElBQUksTUFBTSxPQUFPLFFBQVEsQ0FBQztFQUNuRSxnQkFDRTtHQUFFO0dBQU87R0FBTyxTQUFTO0VBQWEsR0FDdEMsT0FDQSxXQUNBLFdBQ0EsY0FDRjtFQUNBLG9CQUFvQjtDQUN0QixDQUFDOzs7Ozs7O0NBUUgsSUFBSSx3QkFBd0IsT0FBTyxLQUFjO0NBRWpELE1BQU0sdUJBQXVCLFlBQTJCO0VBQ3RELHdCQUF3QixPQUFPLEtBQUssT0FBTztDQUM3QztDQUVBLE1BQU0sZ0JBQ0osU0FDQSxjQUNTOztFQUVULGVBQWUsU0FBb0IsU0FBUztDQUM5QztDQUVBLE1BQU0saUJBQ0osU0FDQSxjQUdBLHFCQUFxQixTQUFvQixTQUFTO0NBRXBELE1BQU0sV0FBVztFQUFFO0VBQWU7Q0FBYTs7Ozs7Ozs7Q0FTL0MsTUFBTSxtQkFBcUMsMkJBQTJCO0NBQ3RFLE1BQU0sbUJBQW1CLElBQUksSUFDM0IsT0FBTyxLQUFJLFVBQVMsTUFBTSx3QkFBd0IsQ0FDcEQ7Q0FFQSxNQUFNLHdCQUF3QixJQUFJLElBQVc7Q0FFN0MsTUFBTSxvQ0FBb0MsU0FBNkI7RUFDckUsSUFBSSxTQUFTLE1BQU07R0FDakI7RUFDRjtFQUVBLElBQUk7RUFDSixNQUFNLFFBQVEsU0FBc0I7R0FDbEMsTUFBTSxFQUFFLGFBQWE7R0FDckIsSUFBSSxhQUFhLGFBQWEsTUFBTSxnQkFBZ0IsUUFBUSxHQUFHO0lBQzdELElBQUksc0JBQXNCLElBQUksSUFBSSxHQUFHO0tBQ25DO0lBQ0Y7SUFDQSxzQkFBc0IsSUFBSSxJQUFJO0dBQ2hDOztHQUdBLE1BQU0sU0FBUyxLQUFLLE9BQU87R0FHM0IsTUFBTSxlQUFlLFNBQVM7R0FDOUIsSUFDRSxXQUFXLGFBQ1gsaUJBQWlCLGFBQ2pCLENBQUMsaUJBQWlCLElBQUksWUFBWSxHQUNsQztJQUNBLFlBQVksSUFBSSxJQUFvQjtJQUNwQyxRQUFRLElBQUksY0FBYyxPQUFPLElBQUk7R0FDdkM7R0FFQSxJQUFJLGFBQWEsV0FBVztJQUMxQixLQUFLLE1BQU0sU0FBUyxVQUFVO0tBQzVCLElBQUksQ0FBQyxVQUFVLFNBQVMsS0FBSyxHQUFHO01BQzlCLEtBQUssS0FBSztLQUNaO0lBQ0Y7R0FDRjtFQUNGO0VBQ0EsSUFBSTtHQUNGLEtBQUssSUFBSTtFQUNYLFVBQVU7R0FDUixzQkFBc0IsTUFBTTtFQUM5QjtFQUVBLElBQUksWUFBWSxXQUFXO0dBQ3pCO0VBQ0Y7RUFFQSxNQUFNLFFBQVEsV0FBVyxNQUFNLEtBQUssUUFBUSxPQUFPLENBQUMsQ0FBQyxDQUFDLEtBQUs7RUFDM0QsTUFBTSxJQUFJLE1BQ1Isc0ZBQXNGLE1BQU0sS0FBSyxJQUFJLEVBQUUsTUFDckcsMEVBQ0o7Q0FDRjs7Ozs7O0NBT0EsTUFBTSxjQUNKLE9BQ0EsY0FDQSxpQkFDQSxlQUNBLGVBQ1M7RUFDVCxNQUFNLGtCQUFrQixPQUFPLGNBQzdCLGFBQ0EsU0FBUSxTQUFTLE1BQ25CO0VBQ0EsTUFBTSxvQkFBb0IsT0FBTyxRQUMvQix1QkFDTSxhQUNSO0VBQ0EsTUFBTSxxQkFBcUIsT0FBTyxRQUNoQyx1QkFDTSxjQUNSO0VBQ0EsTUFBTSxDQUFDLGNBQWMscUJBQXFCLGlCQUN4Qyx5QkFDTTtHQUNKLGdCQUFnQixnQkFBZ0I7R0FDaEMsZUFDRSxnQkFBZ0IsY0FDaEIsZUFDQSxrQkFDQSxVQUNGO0dBRUEsSUFBSTtJQUNGLE9BQU8sS0FBSyxPQUFPLFdBQVc7R0FDaEMsVUFBVTtJQUNSLGlCQUFpQjtHQUNuQjtFQUNGLENBQ0Y7RUFDQSxNQUFNLEVBQUUsTUFBTSxjQUFjO0VBQzVCLGlDQUFpQyxTQUFTO0VBRTFDLGdCQUNFLG1CQUNBLG9CQUNDLFlBQVksaUJBQWlCO0dBQzVCLE1BQU07R0FDTjtHQUNBLFNBQVM7R0FDVDtHQUNBO0VBQ0YsRUFDRjtFQUVBLE1BQU0sRUFBRSxzQkFBc0I7RUFFOUIsTUFBTSxDQUFDLGNBQWMsc0JBQXNCLGlCQUN6QywwQkFDTTtHQUNKLElBQ0UsT0FBTyxPQUFPLGlCQUFpQixLQUMvQix5QkFBeUIsTUFDekI7SUFDQSxNQUFNLGdCQUFnQjtJQUN0Qix1QkFBdUI7Ozs7Ozs7OztJQVN2QixjQUFjLGdCQUFnQixxQkFBcUI7Ozs7O0lBS25ELE9BQU8sZUFDTCxlQUNBLFdBQ0EsaUJBQWlCLFlBQ2pCLFdBQVcsRUFDYjtHQUNGO0dBQ0EsT0FBTyxrQkFDTCxtQkFDQSxXQUNBLGlCQUFpQixVQUNuQjtFQUNGLENBQ0Y7RUFDQSxVQUFVLG9CQUFvQixPQUFPLEtBQUssWUFBWTtFQUV0RCxnQkFDRSxvQkFDQSxxQkFDQyxZQUFZLGlCQUFpQjtHQUM1QixNQUFNO0dBQ047R0FDQSxTQUFTO0dBQ1Q7R0FDQTtFQUNGLEVBQ0Y7RUFFQSxJQUFJLGdCQUFnQjtHQUNsQixzQkFBc0IsY0FBYyxhQUFhLEdBQUc7RUFDdEQ7RUFFQSxJQUFJLFlBQVksS0FBSztHQUNuQixvQkFBb0IsU0FBUyxhQUFhLEdBQUc7RUFDL0M7Q0FDRjs7Ozs7Ozs7Q0FTQSxNQUFNLFVBQ0osT0FDQSxjQUNBLGtCQUEyQyxVQUMzQyxhQUF5QixXQUV6QixPQUFPLElBQUksYUFBYTtFQUN0QixPQUFPLG1CQUFtQjtFQUMxQixNQUFNLGdCQUFnQixRQUFRLElBQzVCLFFBQVEsSUFDTixRQUFRLElBQUksZ0JBQWdCLFVBQVUsZUFBZSxHQUNyRCxjQUNBLFlBQ0YsR0FDQSxjQUNBLFlBQ0Y7RUFDQSxJQUFJLGVBQWUsVUFBVTtHQUMzQixzQkFBc0I7RUFDeEI7RUFDQSxXQUNFLE9BQ0EsY0FDQSxpQkFDQSxlQUNBLFVBQ0Y7Q0FDRixDQUFDLENBQUMsQ0FBQyxLQUNELE9BQU8sU0FDTCxPQUFPLFdBQVc7RUFDaEIsT0FBTyxtQkFBbUI7RUFDMUIsb0JBQW9CO0VBQ3BCLHFCQUFxQjtDQUN2QixDQUFDLENBQ0gsQ0FDRjtDQUVGLE1BQU0sb0JBQW9CLFFBQVEsSUFDaEMsUUFBUSxJQUNOLFFBQVEsSUFBSSxnQkFBZ0IsVUFBVSxRQUFRLEdBQzlDLGNBQ0EsWUFDRixHQUNBLGNBQ0EsWUFDRjs7O0NBSUEsTUFBTSwrQkFDSixxQkFBcUIsS0FBSyxDQUFDLE9BQU8scUJBQXFCLENBQUMsT0FBTzs7Ozs7Ozs7O0NBVWpFLE1BQU0sMkJBQWlDO0VBQ3JDLE9BQU8sbUJBQW1COzs7OztFQUsxQixNQUFNLGdCQUFnQixjQUFjO0VBQ3BDLE1BQU0sYUFBYSxjQUFjLE1BQU07RUFDdkMsSUFBSSxZQUFZOzs7O0dBSWQsd0JBQXdCLE9BQU8sS0FBSztFQUN0QztFQUNBLElBQUk7R0FDRixXQUNFLGNBQWMsR0FDZCx1QkFDQSxVQUNBLG1CQUNBLE1BQ0Y7Ozs7R0FJQSxvQkFBb0I7OztHQUdwQixhQUFhLE1BQU07R0FDbkIscUJBQXFCO0VBQ3ZCLFNBQVMsT0FBTztHQUNkLE9BQU8sUUFBUSxVQUFVLE1BQU0sSUFBSSxLQUFLLEdBQUcscUJBQXFCLENBQUM7RUFDbkUsVUFBVTtHQUNSLE9BQU8sbUJBQW1CO0VBQzVCOzs7OztFQUtBLHFCQUFxQjs7OztFQUlyQixvQkFBb0I7Q0FDdEI7Ozs7Ozs7Ozs7O0NBWUEsTUFBTSw0QkFDSixhQUNZO0VBQ1osSUFBSSxjQUFjLE1BQU0sVUFBVTtHQUNoQyxPQUFPO0VBQ1Q7RUFDQSxJQUFJLFNBQVMsbUJBQW1CLFNBQVM7R0FDdkMsT0FBTztFQUNUO0VBQ0EsSUFBSSxPQUFPLE9BQU8scUJBQXFCLEdBQUc7R0FDeEMsT0FBTztFQUNUO0VBQ0EsTUFBTSxnQkFBZ0IsdUJBQXVCLFNBQVMsUUFBUTtHQUM1RCxlQUFlO0dBQ2YsT0FBTyxjQUFjO0dBQ3JCLFNBQVMsc0JBQXNCO0VBQ2pDLENBQUM7RUFDRCxJQUFJLE9BQU8sT0FBTyxhQUFhLEdBQUc7R0FDaEMsT0FBTztFQUNUOzs7OztFQUtBLDBCQUEwQjtFQUMxQixJQUFJO0dBQ0YsTUFBTSxTQUFTO0lBQ2IsZUFBZTtJQUNmLFFBQVE7R0FDVjtHQUNBLE1BQU0sU0FBUyxTQUFTLDBCQUEwQjtJQUNoRCxJQUFJLE9BQU8saUJBQWlCLE9BQU8sUUFBUTtLQUN6QztJQUNGO0lBQ0EsT0FBTyxTQUFTOzs7SUFJaEIsSUFBSSx1QkFBdUIsR0FBRztLQUM1QiwwQkFBMEI7S0FDMUIsb0JBQW9CO0tBQ3BCO0lBQ0Y7Ozs7OztJQU1BLElBQ0UsT0FBTyxxQkFDUCxPQUFPLGFBQ1AsWUFBWSxLQUNaLGNBQWMsTUFBTSxVQUNwQjtLQUNBLG9CQUFvQjtLQUNwQjtJQUNGO0lBQ0EsbUJBQW1CO0dBQ3JCLEdBQUcsY0FBYyxNQUFNLFVBQVU7R0FDakMsNkJBQTZCLE9BQU8sS0FBSztJQUFFO0lBQVE7R0FBTyxDQUFDO0dBQzNELGtDQUFrQyxNQUFNO0dBQ3hDLE9BQU87RUFDVCxRQUFROzs7O0dBSU4sT0FBTztFQUNUO0NBQ0Y7Ozs7O0NBTUEsTUFBTSx5QkFBK0I7O0VBRW5DLElBQUksdUJBQXVCLEdBQUc7R0FDNUIsaUJBQWlCO0VBQ25COztFQUVBLElBQUksdUJBQXVCLEdBQUc7R0FDNUIsc0JBQXNCLGdCQUFnQjtHQUN0QztFQUNGO0VBQ0EscUJBQXFCO0VBQ3JCLElBQUksQ0FBQyx3QkFBd0I7R0FDM0I7RUFDRjtFQUNBLHlCQUF5QjtFQUN6QixNQUFNLHNCQUFzQjtFQUM1QiwyQkFBMkI7OztFQUczQixJQUFJLE9BQU8sbUJBQW1CO0dBQzVCLG9CQUFvQjtHQUNwQjtFQUNGOzs7RUFHQSxpQkFBaUI7Ozs7O0VBS2pCLElBQUksT0FBTyxXQUFXO0dBQ3BCLG9CQUFvQjtHQUNwQjtFQUNGO0VBQ0EsSUFBSSxZQUFZLEdBQUc7R0FDakIsb0JBQW9CO0dBQ3BCO0VBQ0Y7RUFDQSxJQUFJLGNBQWMsTUFBTSxZQUFZLENBQUMscUJBQXFCO0dBQ3hELG9CQUFvQjtHQUNwQjtFQUNGOzs7Ozs7O0VBT0EsSUFBSSxPQUFPLE9BQU8sMkJBQTJCLEdBQUc7R0FDOUMsbUJBQW1CO0dBQ25CLG1CQUFtQjtHQUNuQjtFQUNGO0VBQ0EsSUFBSSxDQUFDLHlCQUF5Qiw0QkFBNEIsS0FBSyxHQUFHO0dBQ2hFLG1CQUFtQjtFQUNyQjtFQUNBLG1CQUFtQjtDQUNyQjs7OztDQUtBLE1BQU0sMkJBQWlDO0VBQ3JDLElBQUksT0FBTyxxQkFBcUIsT0FBTyxXQUFXO0dBQ2hEO0VBQ0Y7RUFFQSxJQUFJLCtCQUErQixNQUFNO0dBQ3ZDLDZCQUE2QixJQUFJLGVBQWU7R0FDaEQsMkJBQTJCLE1BQU0sa0JBQWtCO0lBQ2pELElBQ0Usc0JBQ0EsMEJBQ0EsT0FBTyxxQkFDUCxPQUFPLFdBQ1A7S0FDQTtJQUNGO0lBRUEscUJBQXFCO0lBQ3JCLHNCQUFzQixnQkFBZ0I7R0FDeEM7RUFDRjtFQUVBLDJCQUEyQixNQUFNLFlBQVksSUFBSTtDQUNuRDs7Ozs7Q0FNQSxNQUFNLHVCQUNKLHNCQUErQixVQUN0QjtFQUNULElBQUkscUJBQXFCO0dBQ3ZCLDJCQUEyQjtFQUM3QjtFQUNBLElBQUksd0JBQXdCO0dBQzFCO0VBQ0Y7RUFDQSx5QkFBeUI7RUFDekIsZUFBZSxrQkFBa0I7RUFDakMsSUFBSSxvQkFBb0I7R0FDdEI7RUFDRjtFQUNBLHNCQUFzQixnQkFBZ0I7Q0FDeEM7Q0FFQSxNQUFNLHVCQUE2Qzs7Ozs7Ozs7RUFRakQsZUFBYyxVQUNaLE9BQU8sSUFBSSxhQUFhOztHQUV0QixNQUFNLGdCQUFnQjtHQUN0QixNQUFNLHdCQUF3Qjs7Ozs7O0dBTTlCLGFBQWEsUUFBUTs7OztHQUlyQiwwQkFBMEI7R0FDMUIsTUFBTSxtQkFBbUIsT0FBTyxPQUFPLEtBQ3JDLE9BQU8sZUFBZSxPQUFPLEtBQUssR0FBRyxjQUFjLFFBQVEsQ0FDN0Q7R0FDQSxJQUFJLEtBQUssVUFBVSxnQkFBZ0IsR0FBRztJQUNwQyxpQkFBaUI7SUFDakIsSUFBSSxZQUFZLEdBQUc7Ozs7OztLQU1qQixNQUFNLGVBQWUsT0FBTyxPQUFPLEtBQ2pDLE9BQ0UsdUJBQ0EsT0FBTyxLQUFLLEdBQ1osY0FDQSxRQUNGLENBQ0Y7S0FDQSxpQkFBaUI7S0FDakIsSUFBSSxLQUFLLFVBQVUsWUFBWSxHQUFHO01BQ2hDLE9BQU87S0FDVDtJQUNGLE9BQU87Ozs7S0FJTCxPQUFPLE9BQU8sV0FBVyxvQkFBb0IsSUFBSSxDQUFDO0lBQ3BEO0lBQ0EsT0FBTyxPQUFPLE9BQU8sVUFBVSxpQkFBaUIsS0FBSztHQUN2RDtHQUNBLGlCQUFpQjs7Ozs7Ozs7R0FRakIsb0JBQW9COzs7OztHQUtwQix3QkFBd0IsT0FBTyxLQUFLO0VBQ3RDLENBQUM7Ozs7RUFJSCxtQkFBbUIsT0FBTyxXQUFXLG9CQUFvQixJQUFJLENBQUM7Q0FDaEU7Q0FFQSxPQUFPO0VBQ0w7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0Y7QUFDRixDQUFDIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbInJlbmRlcmVyLnRzIl0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIEFycmF5LFxuICBDYXVzZSxcbiAgQ29udGV4dCxcbiAgRWZmZWN0LFxuICBFeGl0LFxuICBPcHRpb24sXG4gIFByZWRpY2F0ZSxcbiAgdHlwZSBTY29wZSxcbn0gZnJvbSAnZWZmZWN0J1xuXG5pbXBvcnQge1xuICB0eXBlIEJvdW5kYXJ5UmVnaXN0cnksXG4gIHR5cGUgRG9jdW1lbnQsXG4gIEZPTERLSVRfTU9VTlRfS0VZLFxuICB0eXBlIEZvbGRraXRNb3VudE1hcmtlcixcbiAgdHlwZSBIdG1sQnVpbGRlcixcbiAgX19iZWdpblJlbmRlciBhcyBiZWdpbkh0bWxSZW5kZXIsXG4gIF9fYmVnaW5SZXBsYXlSZW5kZXIgYXMgYmVnaW5SZXBsYXlIdG1sUmVuZGVyLFxuICBfX2NsZWFyUnVudGltZSBhcyBjbGVhckh0bWxSdW50aW1lLFxuICBfX2NyZWF0ZUJvdW5kYXJ5UmVnaXN0cnkgYXMgY3JlYXRlSHRtbEJvdW5kYXJ5UmVnaXN0cnksXG4gIF9fZW5kUmVwbGF5UmVuZGVyIGFzIGVuZFJlcGxheUh0bWxSZW5kZXIsXG4gIF9fZmx1c2hSZXBsYXlVbm1vdW50c0FmdGVyUGF0Y2hGYWlsdXJlIGFzIGZsdXNoUmVwbGF5VW5tb3VudHNBZnRlclBhdGNoRmFpbHVyZSxcbiAgX19zZXRSdW50aW1lIGFzIHNldEh0bWxSdW50aW1lLFxufSBmcm9tICcuLi9odG1sL2luZGV4LmpzJ1xuaW1wb3J0IHsgX19oeWRyYXRlVk5vZGUgfSBmcm9tICcuLi9oeWRyYXRlLmpzJ1xuaW1wb3J0IHsgRk9MREtJVF9BUFBfQVRUUklCVVRFIH0gZnJvbSAnLi4vaHlkcmF0aW9uTWFya2VyLmpzJ1xuaW1wb3J0IHtcbiAgdHlwZSBBbnlNb3VudEhhbmRsZXIsXG4gIHR5cGUgTGF5ZXJlZE1vdW50RGVmaW5pdGlvbixcbiAgTW91bnRSZWdpc3RyYXRpb25UeXBlSWQsXG4gIE1vdW50UnVudGltZSxcbiAgTW91bnRUcmFja2VyLFxufSBmcm9tICcuLi9tb3VudC9pbmRleC5qcydcbmltcG9ydCB0eXBlIHsgQ29tbWl0Tm90aWZpZXIgfSBmcm9tICcuLi9yZW5kZXIvY29tbWl0LmpzJ1xuaW1wb3J0IHtcbiAgVk5vZGUsXG4gIF9fcGF0Y2hWTm9kZSxcbiAgX19yZWNvdmVyVk5vZGVBZnRlclBhdGNoRmFpbHVyZSxcbn0gZnJvbSAnLi4vdmRvbS5qcydcbmltcG9ydCB7XG4gIHR5cGUgQ3Jhc2hDb25maWcsXG4gIHR5cGUgVk5vZGVTbG90LFxuICBub09wRGlzcGF0Y2gsXG4gIHJlbmRlckNyYXNoVmlldyxcbn0gZnJvbSAnLi9jcmFzaFVJLmpzJ1xuaW1wb3J0IHR5cGUge1xuICBEZXZUb29sc0ludGVncmF0aW9uLFxuICBEZXZUb29sc1JlbmRlckJyaWRnZSxcbn0gZnJvbSAnLi9kZXZUb29sc0ludGVncmF0aW9uLmpzJ1xuaW1wb3J0IHsgRGlzcGF0Y2ggfSBmcm9tICcuL2Rpc3BhdGNoLmpzJ1xuaW1wb3J0IHsgYXBwbHlEb2N1bWVudE1ldGFkYXRhIH0gZnJvbSAnLi9kb2N1bWVudE1ldGFkYXRhLmpzJ1xuaW1wb3J0IHR5cGUgeyBEdXBsaWNhdGVJZFNjYW5uZXIgfSBmcm9tICcuL2R1cGxpY2F0ZUlkU2Nhbm5lci5qcydcbmltcG9ydCB0eXBlIHsgTWVzc2FnZVF1ZXVlIH0gZnJvbSAnLi9tZXNzYWdlUXVldWUuanMnXG5pbXBvcnQgdHlwZSB7IFJ1bnRpbWVTdGF0dXMgfSBmcm9tICcuL3J1bnRpbWVTdGF0dXMuanMnXG5pbXBvcnQge1xuICB0eXBlIFJlc29sdmVkU2xvd1BoYXNlQ29uZmlnLFxuICB0eXBlIFNsb3dQYXRjaENvbnRleHQsXG4gIHR5cGUgU2xvd1ZpZXdDb250ZXh0LFxuICBtZWFzdXJlU2xvd1BoYXNlLFxuICByZXBvcnRTbG93UGhhc2UsXG59IGZyb20gJy4vc2xvd1BoYXNlLmpzJ1xuaW1wb3J0IHtcbiAgdHlwZSBTdGFydFZpZXdUcmFuc2l0aW9uLFxuICB0eXBlIFZpZXdUcmFuc2l0aW9uQ29uZmlnLFxuICB0eXBlIFZpZXdUcmFuc2l0aW9uSGFuZGxlLFxuICBfX2RlY2lkZVZpZXdUcmFuc2l0aW9uLFxuICBfX3NpbGVuY2VWaWV3VHJhbnNpdGlvblJlamVjdGlvbnMsXG59IGZyb20gJy4vdmlld1RyYW5zaXRpb24uanMnXG5cbi8qKiBUaGUgYHZpZXdUcmFuc2l0aW9uYCBjb25maWcgcmVzb2x2ZWQgYWdhaW5zdCB0aGUgcnVubmluZyBicm93c2VyOiB0aGVcbiAqICBwcmVkaWNhdGUsIHRoZSBmZWF0dXJlLWRldGVjdGVkIGBzdGFydFZpZXdUcmFuc2l0aW9uYCwgYW5kIHRoZSBjYWNoZWRcbiAqICByZWR1Y2VkLW1vdGlvbiBxdWVyeS4gQWJzZW50ICh0aGUgcnVudGltZSBob2xkcyBgT3B0aW9uLm5vbmUoKWApIHdoZW4gdGhlXG4gKiAgYXBwIGRpZCBub3QgY29uZmlndXJlIGB2aWV3VHJhbnNpdGlvbmAgb3IgdGhlIGJyb3dzZXIgbGFja3MgdGhlIEFQSS4gKi9cbmV4cG9ydCB0eXBlIFJlc29sdmVkVmlld1RyYW5zaXRpb248TW9kZWwsIE1lc3NhZ2U+ID0gUmVhZG9ubHk8e1xuICBkZWNpZGU6IFZpZXdUcmFuc2l0aW9uQ29uZmlnPE1vZGVsLCBNZXNzYWdlPlxuICBzdGFydFZpZXdUcmFuc2l0aW9uOiBTdGFydFZpZXdUcmFuc2l0aW9uXG4gIHJlZHVjZWRNb3Rpb25RdWVyeTogTWVkaWFRdWVyeUxpc3Rcbn0+XG5cbnR5cGUgUmVuZGVyTW9kZSA9ICdMaXZlJyB8ICdSZXBsYXknXG5cbnR5cGUgUGVuZGluZ1ZpZXdUcmFuc2l0aW9uID0gUmVhZG9ubHk8e1xuICBoYW5kbGU6IFZpZXdUcmFuc2l0aW9uSGFuZGxlXG4gIHVwZGF0ZToge1xuICAgIGlzSW52YWxpZGF0ZWQ6IGJvb2xlYW5cbiAgICBkaWRSdW46IGJvb2xlYW5cbiAgfVxufT5cblxuLyoqXG4gKiBXaGF0IHRoZSBib290IGNsb3N1cmUgdXNlcyBmcm9tIHRoZSByZW5kZXIgc2lkZS4gYGNyYXNoV2l0aGAgcGFpbnRzIHRoZVxuICogY3Jhc2ggdmlldyBhbmQgc3RvcHMgdGhlIHJ1bnRpbWUsIGByZW5kZXJgIHJ1bnMgb25lIGxpdmUgcmVuZGVyICh0aGUgYm9vdFxuICogY2FsbHMgaXQgZm9yIHRoZSBmaXJzdCBwYWludCksIGBzZXRMYXN0RGlydHlNZXNzYWdlYCByZWNvcmRzIHRoZSBNZXNzYWdlXG4gKiB0aGUgbmV4dCBmcmFtZSBpcyBhdHRyaWJ1dGVkIHRvLCBgc2NoZWR1bGVSZW5kZXJGcmFtZWAgYXNrcyBmb3IgYSBmcmFtZSxcbiAqIGBza2lwUGVuZGluZ1ZpZXdUcmFuc2l0aW9uYCBjdXRzIHNob3J0IGEgdHJhbnNpdGlvbiB0aGUgYnJvd3NlciBpcyBzdGlsbFxuICogYW5pbWF0aW5nLCBhbmQgYGRldlRvb2xzUmVuZGVyQnJpZGdlYCBpcyB3aGF0IHRoZSBEZXZUb29scyBzdG9yZSBuZWVkcyB0b1xuICogcmVwYWludCBkdXJpbmcgdGltZSB0cmF2ZWwuXG4gKi9cbmV4cG9ydCB0eXBlIFJlbmRlcmVyPE1vZGVsLCBNZXNzYWdlPiA9IFJlYWRvbmx5PHtcbiAgY3Jhc2hXaXRoOiAoXG4gICAgY2F1c2U6IENhdXNlLkNhdXNlPG5ldmVyPixcbiAgICBtYXliZU1lc3NhZ2U6IE9wdGlvbi5PcHRpb248TWVzc2FnZT4sXG4gICkgPT4gRWZmZWN0LkVmZmVjdDx2b2lkPlxuICByZW5kZXI6IChcbiAgICBtb2RlbDogTW9kZWwsXG4gICAgbWF5YmVNZXNzYWdlOiBPcHRpb24uT3B0aW9uPE1lc3NhZ2U+LFxuICApID0+IEVmZmVjdC5FZmZlY3Q8dm9pZD5cbiAgc2V0TGFzdERpcnR5TWVzc2FnZTogKG1lc3NhZ2U6IE1lc3NhZ2UpID0+IHZvaWRcbiAgc2NoZWR1bGVSZW5kZXJGcmFtZTogKCkgPT4gdm9pZFxuICBza2lwUGVuZGluZ1ZpZXdUcmFuc2l0aW9uOiAoKSA9PiB2b2lkXG4gIGRldlRvb2xzUmVuZGVyQnJpZGdlOiBEZXZUb29sc1JlbmRlckJyaWRnZVxufT5cblxuLyoqXG4gKiBCdWlsZHMgdGhlIHJlbmRlciBzaWRlIG9mIG9uZSBydW50aW1lOiB0aGUgY3VycmVudCB2bm9kZSBhbmQsIHdoZW5cbiAqIGh5ZHJhdGluZywgdGhlIHNlcnZlci1yZW5kZXJlZCByb290IHRoZSBmaXJzdCByZW5kZXIgYWRvcHRzLCB0aGUgY3Jhc2hcbiAqIHJlbmRlcmVyLCB0aGUgYERpc3BhdGNoYCBzZXJ2aWNlIHRoZSB2aWV3IGJpbmRzIGhhbmRsZXJzIHRvLCB0aGVcbiAqIHN5bmNocm9ub3VzIHJlbmRlciB0aGF0IHJ1bnMgdGhlIHZpZXcgYW5kIHBhdGNoZXMgdGhlIERPTSwgdGhlIHJlbmRlclxuICogZnJhbWUgdGhhdCBydW5zIGluIGByZXF1ZXN0QW5pbWF0aW9uRnJhbWVgLCBhbmQgdGhlIFZpZXcgVHJhbnNpdGlvblxuICogdGhhdCBmcmFtZSBtYXkgcnVuIGluc2lkZS4gSXQgYWxzbyByZWdpc3RlcnMgdGhlIHRlYXJkb3duIGZpbmFsaXplclxuICogdGhhdCBwYXRjaGVzIHRoZSB0cmVlIGF3YXkgYW5kIHJlc3RvcmVzIHRoZSBjb250YWluZXIsIHNvIGJ1aWxkIGl0XG4gKiBiZWZvcmUgZm9ya2luZyB0aGUgcGVycGV0dWFsIGZpYmVyczogc2NvcGUgZmluYWxpemVycyBydW5cbiAqIGxhc3QtcmVnaXN0ZXJlZCBmaXJzdCwgYW5kIHRoZSBjb250YWluZXIgbXVzdCBiZSByZXN0b3JlZCBvbmx5IGFmdGVyXG4gKiB0aG9zZSBmaWJlcnMgYXJlIGludGVycnVwdGVkLlxuICovXG5leHBvcnQgY29uc3QgbWFrZVJlbmRlcmVyID0gPE1vZGVsLCBNZXNzYWdlPih7XG4gIHN0YXR1cyxcbiAgY29udGFpbmVyLFxuICB2aWV3LFxuICBodG1sQnVpbGRlcixcbiAgbWFuYWdlRG9jdW1lbnQsXG4gIGNyYXNoLFxuICBidWlsZElkLFxuICBpbml0TW9kZWwsXG4gIG1heWJlSHlkcmF0aW9uUm9vdCxcbiAgbWF5YmVTbG93VmlldyxcbiAgbWF5YmVTbG93UGF0Y2gsXG4gIGR1cGxpY2F0ZUlkU2Nhbm5lcixcbiAgbWF5YmVSZXNvbHZlZFZpZXdUcmFuc2l0aW9uLFxuICBjb21taXROb3RpZmllcixcbiAgbW91bnRzLFxuICBydW50aW1lQ29udGV4dCxcbiAgcmVhZExpdmVNb2RlbCxcbiAgbWVzc2FnZVF1ZXVlLFxuICBkZXZUb29sc0ludGVncmF0aW9uLFxufTogUmVhZG9ubHk8e1xuICBzdGF0dXM6IFJ1bnRpbWVTdGF0dXNcbiAgY29udGFpbmVyOiBIVE1MRWxlbWVudFxuICB2aWV3OiAobW9kZWw6IE1vZGVsLCBoOiBIdG1sQnVpbGRlcjxNZXNzYWdlLCBBbnlNb3VudEhhbmRsZXI+KSA9PiBEb2N1bWVudFxuICBodG1sQnVpbGRlcjogSHRtbEJ1aWxkZXI8TWVzc2FnZSwgQW55TW91bnRIYW5kbGVyPlxuICBtYW5hZ2VEb2N1bWVudDogYm9vbGVhblxuICBjcmFzaDogQ3Jhc2hDb25maWc8TW9kZWwsIE1lc3NhZ2U+IHwgdW5kZWZpbmVkXG4gIGJ1aWxkSWQ6IHN0cmluZyB8IHVuZGVmaW5lZFxuICBpbml0TW9kZWw6IE1vZGVsXG4gIG1heWJlSHlkcmF0aW9uUm9vdDogT3B0aW9uLk9wdGlvbjxIVE1MRWxlbWVudD5cbiAgbWF5YmVTbG93VmlldzogT3B0aW9uLk9wdGlvbjxcbiAgICBSZXNvbHZlZFNsb3dQaGFzZUNvbmZpZzxTbG93Vmlld0NvbnRleHQ8TW9kZWwsIE1lc3NhZ2U+PlxuICA+XG4gIG1heWJlU2xvd1BhdGNoOiBPcHRpb24uT3B0aW9uPFxuICAgIFJlc29sdmVkU2xvd1BoYXNlQ29uZmlnPFNsb3dQYXRjaENvbnRleHQ8TW9kZWwsIE1lc3NhZ2U+PlxuICA+XG4gIGR1cGxpY2F0ZUlkU2Nhbm5lcjogRHVwbGljYXRlSWRTY2FubmVyIHwgdW5kZWZpbmVkXG4gIG1heWJlUmVzb2x2ZWRWaWV3VHJhbnNpdGlvbjogT3B0aW9uLk9wdGlvbjxcbiAgICBSZXNvbHZlZFZpZXdUcmFuc2l0aW9uPE1vZGVsLCBNZXNzYWdlPlxuICA+XG4gIGNvbW1pdE5vdGlmaWVyOiBDb21taXROb3RpZmllclxuICBtb3VudHM6IFJlYWRvbmx5QXJyYXk8TGF5ZXJlZE1vdW50RGVmaW5pdGlvbj5cbiAgcnVudGltZUNvbnRleHQ6IENvbnRleHQuQ29udGV4dDxuZXZlcj5cbiAgcmVhZExpdmVNb2RlbDogKCkgPT4gTW9kZWxcbiAgbWVzc2FnZVF1ZXVlOiBNZXNzYWdlUXVldWU8TWVzc2FnZSwgdW5rbm93bj5cbiAgZGV2VG9vbHNJbnRlZ3JhdGlvbjogRGV2VG9vbHNJbnRlZ3JhdGlvbjxNb2RlbCwgTWVzc2FnZT5cbn0+KTogRWZmZWN0LkVmZmVjdDxSZW5kZXJlcjxNb2RlbCwgTWVzc2FnZT4sIG5ldmVyLCBTY29wZS5TY29wZT4gPT5cbiAgRWZmZWN0LmdlbihmdW5jdGlvbiogKCkge1xuICAgIGNvbnN0IHtcbiAgICAgIGVucXVldWVNZXNzYWdlLFxuICAgICAgZW5xdWV1ZU1lc3NhZ2VFZmZlY3QsXG4gICAgICBkcmFpblBlbmRpbmdNZXNzYWdlcyxcbiAgICAgIGRyYWluRGVmZXJyZWROb3csXG4gICAgICByZXNldERyYWluQnVkZ2V0LFxuICAgICAgaXNBbnlNZXNzYWdlRGVmZXJyZWQsXG4gICAgfSA9IG1lc3NhZ2VRdWV1ZVxuICAgIGNvbnN0IHtcbiAgICAgIG1vdW50VHJhY2tlcixcbiAgICAgIG1vdW50UnVudGltZSxcbiAgICAgIGRyYWluTW91bnRFdmVudHMsXG4gICAgICByZWFkVmlld1N0YXRlLFxuICAgICAgc2V0Vmlld1N0YXRlLFxuICAgICAgaXNQYXVzZWROb3csXG4gICAgICByZXN1bWVEZXZUb29scyxcbiAgICAgIGF0dGFjaFJlbmRlcmVkTW91bnRzLFxuICAgIH0gPSBkZXZUb29sc0ludGVncmF0aW9uXG5cbiAgICBjb25zdCBzZXR0bGVQZW5kaW5nQ29tbWl0ID0gKCk6IHZvaWQgPT4ge1xuICAgICAgaWYgKGNvbW1pdE5vdGlmaWVyLnNlcnZpY2UuaXNDb21taXRQZW5kaW5nKCkpIHtcbiAgICAgICAgY29tbWl0Tm90aWZpZXIubm90aWZ5Q29tbWl0dGVkKClcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBOT1RFOiBgaXNSZW5kZXJGcmFtZVNjaGVkdWxlZGAgY2xlYXJzIHdoZW4gdGhlIGZyYW1lIGNhbGxiYWNrXG4gICAgLy8gc3RhcnRzLCB3aGljaCBvbiB0aGUgVmlldyBUcmFuc2l0aW9uIHBhdGggaXMgYmVmb3JlIHRoZSBwYXRjaCBydW5zLlxuICAgIC8vIGBjb21taXROb3RpZmllcmAgdHJhY2tzIHRoZSBwYXRjaCBpdHNlbGYsIHNvIGBSZW5kZXIuYWZ0ZXJDb21taXRgXG4gICAgLy8gd2FpdHMgZm9yIHRoZSBjb21taXQgcmF0aGVyIHRoYW4gZm9yIHRoZSBmcmFtZSB0aGF0IHNjaGVkdWxlZCBpdC5cbiAgICBsZXQgaXNSZW5kZXJGcmFtZVNjaGVkdWxlZCA9IGZhbHNlXG4gICAgLy8gTk9URTogcmVzdW1lIGNsZWFycyB0aGUgRGV2VG9vbHMgc3RvcmUncyBwYXVzZSBmbGFnIGJlZm9yZSBpdHMgZnJhbWVcbiAgICAvLyBwYXRjaGVzIHRoZSBsaXZlIHZpZXcuIFRoaXMgZGlzdGluZ3Vpc2hlcyB0aGF0IGludGVudGlvbmFsIHJlcGFpbnRcbiAgICAvLyBmcm9tIGFuIG9yZGluYXJ5IGZyYW1lIHRoYXQgd2FzIGFscmVhZHkgcXVldWVkIHdoZW4ganVtcFRvIGluc3RhbGxlZFxuICAgIC8vIHRoZSBoaXN0b3JpY2FsIHZpZXcuXG4gICAgbGV0IGlzTGl2ZVZpZXdSZXN0b3JlUGVuZGluZyA9IGZhbHNlXG4gICAgbGV0IGlzUmVuZGVyRnJhbWVBcm1lZCA9IGZhbHNlXG4gICAgbGV0IG1heWJlQXJtUmVuZGVyRnJhbWVDaGFubmVsOiBNZXNzYWdlQ2hhbm5lbCB8IG51bGwgPSBudWxsXG5cbiAgICB5aWVsZCogRWZmZWN0LmFkZEZpbmFsaXplcigoKSA9PlxuICAgICAgRWZmZWN0LnN5bmMoKCkgPT4ge1xuICAgICAgICBpZiAobWF5YmVBcm1SZW5kZXJGcmFtZUNoYW5uZWwgIT09IG51bGwpIHtcbiAgICAgICAgICBtYXliZUFybVJlbmRlckZyYW1lQ2hhbm5lbC5wb3J0MS5jbG9zZSgpXG4gICAgICAgICAgbWF5YmVBcm1SZW5kZXJGcmFtZUNoYW5uZWwucG9ydDIuY2xvc2UoKVxuICAgICAgICAgIG1heWJlQXJtUmVuZGVyRnJhbWVDaGFubmVsID0gbnVsbFxuICAgICAgICB9XG4gICAgICB9KSxcbiAgICApXG5cbiAgICAvLyBOT1RFOiB0aGUgTW9kZWwgYmVoaW5kIHRoZSBET00gY3VycmVudGx5IG9uIHNjcmVlbiwgd2hpY2ggaXMgd2hhdCBhXG4gICAgLy8gVmlldyBUcmFuc2l0aW9uIGFuaW1hdGVzIGF3YXkgZnJvbS4gU2VlZGVkIHdpdGggYGluaXRNb2RlbGAgYmVjYXVzZVxuICAgIC8vIHRoZSBpbml0IHJlbmRlciBwYWludHMgaXQsIGFuZCBhZHZhbmNlZCBvbmx5IHdoZXJlIGEgcmVuZGVyIGFjdHVhbGx5XG4gICAgLy8gY29tbWl0cy4gVGhlIGB2aWV3VHJhbnNpdGlvbmAgcHJlZGljYXRlIG5ldmVyIHJ1bnMgYmVmb3JlIGEgTWVzc2FnZVxuICAgIC8vIGhhcyBkaXJ0aWVkIHRoZSBNb2RlbCwgYW5kIHRoZSBpbml0IHJlbmRlciBjb21wbGV0ZXMgYmVoaW5kIHRoZSBib290XG4gICAgLy8gYmFycmllciwgc28gdGhpcyBpcyBhbHdheXMgdGhlIG1vZGVsIG9mIGEgcGFpbnQgdGhhdCBoYXBwZW5lZC5cbiAgICBsZXQgbGFzdFJlbmRlcmVkTW9kZWw6IE1vZGVsID0gaW5pdE1vZGVsXG5cbiAgICAvLyBOT1RFOiB0aGUgdHJhbnNpdGlvbiB0aGUgYnJvd3NlciBpcyBzdGlsbCBhbmltYXRpbmcsIGlmIGFueS4gSGVsZCBzb1xuICAgIC8vIHRoZSBydW50aW1lIGNhbiBza2lwIGl0OiB3aGVuIGEgbGF0ZXIgZnJhbWUgc3VwZXJzZWRlcyBpdCwgd2hlbiB0aGVcbiAgICAvLyBydW50aW1lIGNyYXNoZXMsIGFuZCBhdCB0ZWFyZG93biwgd2hlcmUgdGhlIGJyb3dzZXIgd291bGQgb3RoZXJ3aXNlXG4gICAgLy8gYW5pbWF0ZSBvdmVyIGEgcmVsZWFzZWQgY29udGFpbmVyLiBEZWNsYXJlZCBhYm92ZSBgY3Jhc2hXaXRoYCwgd2hpY2hcbiAgICAvLyBjYWxscyB0aGUgc2tpcCBhbmQgY2FuIHJ1biBhcyBlYXJseSBhcyB0aGUgaW5pdCByZW5kZXIuXG4gICAgbGV0IG1heWJlUGVuZGluZ1ZpZXdUcmFuc2l0aW9uID0gT3B0aW9uLm5vbmU8UGVuZGluZ1ZpZXdUcmFuc2l0aW9uPigpXG5cbiAgICBjb25zdCBza2lwUGVuZGluZ1ZpZXdUcmFuc2l0aW9uID0gKCk6IHZvaWQgPT4ge1xuICAgICAgaWYgKE9wdGlvbi5pc1NvbWUobWF5YmVQZW5kaW5nVmlld1RyYW5zaXRpb24pKSB7XG4gICAgICAgIGNvbnN0IHsgdmFsdWU6IHBlbmRpbmdWaWV3VHJhbnNpdGlvbiB9ID0gbWF5YmVQZW5kaW5nVmlld1RyYW5zaXRpb25cbiAgICAgICAgLy8gTk9URTogY2xlYXJlZCBmaXJzdC4gQW4gaW1wbGVtZW50YXRpb24gdGhhdCBydW5zIHRoZSB1cGRhdGVcbiAgICAgICAgLy8gY2FsbGJhY2sgc3luY2hyb25vdXNseSB3b3VsZCBvdGhlcndpc2UgcmUtZW50ZXIgdGhpcy5cbiAgICAgICAgbWF5YmVQZW5kaW5nVmlld1RyYW5zaXRpb24gPSBPcHRpb24ubm9uZSgpXG4gICAgICAgIHBlbmRpbmdWaWV3VHJhbnNpdGlvbi51cGRhdGUuaXNJbnZhbGlkYXRlZCA9IHRydWVcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBwZW5kaW5nVmlld1RyYW5zaXRpb24uaGFuZGxlLnNraXBUcmFuc2l0aW9uKClcbiAgICAgICAgfSBjYXRjaCB7XG4gICAgICAgICAgLy8gTk9URTogc2tpcHBpbmcgcnVucyBvbiB0ZWFyZG93biBhbmQgY3Jhc2ggcGF0aHMsIHNvIGEgcmVmdXNhbFxuICAgICAgICAgIC8vIG11c3Qgbm90IHByb3BhZ2F0ZSBpbnRvIHRoZW0uXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBOT1RFOiB0aGUgY3VycmVudCB2bm9kZSBpcyBwbGFpbiBjbG9zdXJlIHN0YXRlLiBUaGUgZnJhbWUgcmVhZHMgYW5kXG4gICAgLy8gd3JpdGVzIGl0IGRpcmVjdGx5OyB0aGUgY29sZCBwYXRocyB0aGF0IHJ1biBpbnNpZGUgRWZmZWN0cyAoY3Jhc2hcbiAgICAvLyByZW5kZXJpbmcsIHRoZSBkaXNwb3NlIGZpbmFsaXplciwgdGhlIHJlcGxheSByZW5kZXIpIHJlYWQgdGhlIHNhbWVcbiAgICAvLyBzbG90IHN5bmNocm9ub3VzbHksIHNvIG5vIFJlZiBpcyBuZWVkZWQuXG4gICAgY29uc3Qgdm5vZGVTbG90OiBWTm9kZVNsb3QgPSB7IG1heWJlQ3VycmVudFZOb2RlOiBPcHRpb24ubm9uZSgpIH1cblxuICAgIGNvbnN0IHBhdGNoUnVudGltZVZOb2RlID0gKFxuICAgICAgbWF5YmVDdXJyZW50Vk5vZGU6IE9wdGlvbi5PcHRpb248Vk5vZGU+LFxuICAgICAgbmV4dFZOb2RlOiBWTm9kZSB8IG51bGwsXG4gICAgICBzZWVuPzogU2V0PG9iamVjdD4sXG4gICAgKTogVk5vZGUgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgcmV0dXJuIF9fcGF0Y2hWTm9kZShcbiAgICAgICAgICBtYXliZUN1cnJlbnRWTm9kZSxcbiAgICAgICAgICBuZXh0Vk5vZGUsXG4gICAgICAgICAgY29udGFpbmVyLFxuICAgICAgICAgIHNlZW4sXG4gICAgICAgICAgcGF0Y2hlZFZOb2RlID0+IHtcbiAgICAgICAgICAgIHZub2RlU2xvdC5tYXliZUN1cnJlbnRWTm9kZSA9IE9wdGlvbi5zb21lKHBhdGNoZWRWTm9kZSlcbiAgICAgICAgICB9LFxuICAgICAgICApXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvbnN0IG1heWJlUmVjb3ZlcnlWTm9kZSA9IHZub2RlU2xvdC5tYXliZUN1cnJlbnRWTm9kZVxuICAgICAgICAgIGlmIChPcHRpb24uaXNTb21lKG1heWJlUmVjb3ZlcnlWTm9kZSkpIHtcbiAgICAgICAgICAgIHZub2RlU2xvdC5tYXliZUN1cnJlbnRWTm9kZSA9IE9wdGlvbi5zb21lKFxuICAgICAgICAgICAgICBfX3JlY292ZXJWTm9kZUFmdGVyUGF0Y2hGYWlsdXJlKG1heWJlUmVjb3ZlcnlWTm9kZS52YWx1ZSksXG4gICAgICAgICAgICApXG4gICAgICAgICAgfVxuICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgIGZsdXNoUmVwbGF5VW5tb3VudHNBZnRlclBhdGNoRmFpbHVyZSgpXG4gICAgICAgIH1cbiAgICAgICAgdGhyb3cgZXJyb3JcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBOT1RFOiBjb25zdW1lZCBieSB0aGUgZmlyc3QgcmVuZGVyIG9ubHkuIFNldCB3aGVuIHRoaXMgYm9vdCBmb3VuZFxuICAgIC8vIGFuIGFkb3B0YWJsZSBzZXJ2ZXItcmVuZGVyZWQgcm9vdDsgdGhlIGZpcnN0IHBhdGNoIHRoZW4gZ29lc1xuICAgIC8vIHRocm91Z2ggYF9faHlkcmF0ZVZOb2RlYCBpbnN0ZWFkIG9mIHJlcGxhY2luZyB0aGUgY29udGFpbmVyLlxuICAgIGxldCBwZW5kaW5nSHlkcmF0aW9uUm9vdDogSFRNTEVsZW1lbnQgfCBudWxsID1cbiAgICAgIE9wdGlvbi5nZXRPck51bGwobWF5YmVIeWRyYXRpb25Sb290KVxuXG4gICAgLy8gTk9URTogcmVnaXN0ZXJlZCBiZWZvcmUgYW55IHBlcnBldHVhbCBmaWJlciBpcyBmb3JrZWQgc28gaXQgcnVuc1xuICAgIC8vIGFmdGVyIHRoZXkgYXJlIGludGVycnVwdGVkIChzY29wZSBmaW5hbGl6ZXJzIGFyZSBMSUZPKS4gUGF0Y2hpbmcgdG9cbiAgICAvLyBhbiBlbXB0eSB0cmVlIGZpcmVzIHNuYWJiZG9tIGRlc3Ryb3kgaG9va3MsIHdoaWNoIGlzIHdoYXQgcmVsZWFzZXNcbiAgICAvLyBNb3VudHM7IHN3YXBwaW5nIHRoZSBwbGFjZWhvbGRlciBmb3IgdGhlIG9yaWdpbmFsIGNvbnRhaW5lciBsZWF2ZXNcbiAgICAvLyB0aGUgaG9zdCBET00gYXMgaXQgd2FzIGJlZm9yZSB0aGUgZmlyc3QgcmVuZGVyLCByZWFkeSBmb3IgYSBmcmVzaFxuICAgIC8vIGVtYmVkIG9mIHRoZSBzYW1lIGNvbnRhaW5lci4gR2F0ZWQgb24gaW50ZXJydXB0aW9uOiB0aGF0IGlzIHRoZVxuICAgIC8vIGRpc3Bvc2UgcGF0aC4gQSBydW50aW1lIHRoYXQgc3RvcHMgYmVjYXVzZSBpdCBjcmFzaGVkIGNvbXBsZXRlc1xuICAgIC8vIG5vcm1hbGx5IGFmdGVyIHJlbmRlcmluZyB0aGUgY3Jhc2ggdmlldywgYW5kIHRoZSBjcmFzaCB2aWV3IG11c3RcbiAgICAvLyBzdGF5IHZpc2libGUuXG4gICAgeWllbGQqIEVmZmVjdC5hZGRGaW5hbGl6ZXIoZXhpdCA9PlxuICAgICAgRWZmZWN0LmdlbihmdW5jdGlvbiogKCkge1xuICAgICAgICBpZiAoRXhpdC5oYXNJbnRlcnJ1cHRzKGV4aXQpKSB7XG4gICAgICAgICAgY29uc3QgbWF5YmVDdXJyZW50Vk5vZGUgPSB2bm9kZVNsb3QubWF5YmVDdXJyZW50Vk5vZGVcbiAgICAgICAgICB5aWVsZCogT3B0aW9uLm1hdGNoKG1heWJlQ3VycmVudFZOb2RlLCB7XG4gICAgICAgICAgICBvbk5vbmU6ICgpID0+IEVmZmVjdC52b2lkLFxuICAgICAgICAgICAgb25Tb21lOiBjdXJyZW50Vk5vZGUgPT5cbiAgICAgICAgICAgICAgRWZmZWN0LnN5bmMoKCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IHBsYWNlaG9sZGVyTm9kZSA9IF9fcGF0Y2hWTm9kZShcbiAgICAgICAgICAgICAgICAgIE9wdGlvbi5zb21lKGN1cnJlbnRWTm9kZSksXG4gICAgICAgICAgICAgICAgICBudWxsLFxuICAgICAgICAgICAgICAgICAgY29udGFpbmVyLFxuICAgICAgICAgICAgICAgICkuZWxtXG4gICAgICAgICAgICAgICAgaWYgKHBsYWNlaG9sZGVyTm9kZSAmJiBwbGFjZWhvbGRlck5vZGUucGFyZW50Tm9kZSkge1xuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXJOb2RlLnBhcmVudE5vZGUucmVwbGFjZUNoaWxkKFxuICAgICAgICAgICAgICAgICAgICBjb250YWluZXIsXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyTm9kZSxcbiAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgIGNvbnRhaW5lci5yZXBsYWNlQ2hpbGRyZW4oKVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfSksXG4gICAgICAgICAgfSlcbiAgICAgICAgfVxuXG4gICAgICAgIHlpZWxkKiBtb3VudFJ1bnRpbWUuaW50ZXJydXB0RmliZXJzXG4gICAgICB9KSxcbiAgICApXG5cbiAgICAvLyBOT1RFOiBzaGFyZWQgYnkgZXZlcnkgY3Jhc2ggcGF0aDogdGhlIGluaXQgcmVuZGVyLCB0aGUgcGxhaW5cbiAgICAvLyBtZXNzYWdlIGRyYWluIGFuZCByZW5kZXIgZnJhbWUgKHdoaWNoIHJlYWNoIGl0IHRocm91Z2hcbiAgICAvLyBgRWZmZWN0LnJ1bkZvcmtgIGZyb20gdGhlaXIgY2F0Y2ggYmxvY2tzKSwgYW5kIHRoZSBDb21tYW5kIGFuZFxuICAgIC8vIFN1YnNjcmlwdGlvbiBmaWJlcnMgKGEgQ29tbWFuZCdzIEVmZmVjdCBhbmQgYSBTdWJzY3JpcHRpb24nc1xuICAgIC8vIFN0cmVhbSBhcmUgdHlwZWQgd2l0aCBhIGBuZXZlcmAgZXJyb3IgY2hhbm5lbCwgc28gYSBjYXVzZVxuICAgIC8vIGVzY2FwaW5nIG9uZSBpcyBhbiB1bnJlY292ZXJhYmxlIGRlZmVjdCkuIEVhY2ggcGF0aCBjYXRjaGVzIGl0c1xuICAgIC8vIG93biBjYXVzZSBzbyBhIGZhaWx1cmUgc3VyZmFjZXMgYXMgdGhlIGNyYXNoIHZpZXcgaW5zdGVhZCBvZlxuICAgIC8vIGR5aW5nIHNpbGVudGx5IGFuZCBsZWF2aW5nIHRoZSBET00gZnJvemVuIGF0IHRoZSBsYXN0IHN1Y2Nlc3NmdWxcbiAgICAvLyByZW5kZXIuIFRoZSBmaXJzdCBjcmFzaCB3aW5zOiBjb25jdXJyZW50IENvbW1hbmQgZmliZXJzIGNhbiBmYWlsLFxuICAgIC8vIGFuZCBvbmx5IG9uZSBzaG91bGQgcmVwb3J0IGFuZCByZW5kZXIuXG4gICAgY29uc3QgY3Jhc2hXaXRoID0gKFxuICAgICAgY2F1c2U6IENhdXNlLkNhdXNlPG5ldmVyPixcbiAgICAgIG1heWJlTWVzc2FnZTogT3B0aW9uLk9wdGlvbjxNZXNzYWdlPixcbiAgICApOiBFZmZlY3QuRWZmZWN0PHZvaWQ+ID0+XG4gICAgICBFZmZlY3Quc3luYygoKSA9PiB7XG4gICAgICAgIGlmIChzdGF0dXMuaXNDcmFzaGVkKSB7XG4gICAgICAgICAgcmV0dXJuXG4gICAgICAgIH1cbiAgICAgICAgc3RhdHVzLmlzQ3Jhc2hlZCA9IHRydWVcbiAgICAgICAgbWVzc2FnZVF1ZXVlLmRyYWluUGVuZGluZ01lc3NhZ2VzKClcbiAgICAgICAgLy8gTk9URTogdGhlIGNyYXNoIHZpZXcgc2hvdWxkIGFwcGVhciBhdCBvbmNlLCBub3QgYW5pbWF0ZSBpbiBmcm9tXG4gICAgICAgIC8vIGEgc25hcHNob3Qgb2YgdGhlIHN0YXRlIHRoYXQgY3Jhc2hlZC5cbiAgICAgICAgc2tpcFBlbmRpbmdWaWV3VHJhbnNpdGlvbigpXG4gICAgICAgIGNvbnN0IG1vZGVsID0gcmVhZExpdmVNb2RlbCgpXG4gICAgICAgIGNvbnN0IHNxdWFzaGVkID0gQ2F1c2Uuc3F1YXNoKGNhdXNlKVxuICAgICAgICBjb25zdCBlcnJvciA9XG4gICAgICAgICAgc3F1YXNoZWQgaW5zdGFuY2VvZiBFcnJvciA/IHNxdWFzaGVkIDogbmV3IEVycm9yKFN0cmluZyhzcXVhc2hlZCkpXG4gICAgICAgIHJlbmRlckNyYXNoVmlldyhcbiAgICAgICAgICB7IGVycm9yLCBtb2RlbCwgbWVzc2FnZTogbWF5YmVNZXNzYWdlIH0sXG4gICAgICAgICAgY3Jhc2gsXG4gICAgICAgICAgY29udGFpbmVyLFxuICAgICAgICAgIHZub2RlU2xvdCxcbiAgICAgICAgICBtYW5hZ2VEb2N1bWVudCxcbiAgICAgICAgKVxuICAgICAgICBzZXR0bGVQZW5kaW5nQ29tbWl0KClcbiAgICAgIH0pXG5cbiAgICAvLyBOT1RFOiBgbWF5YmVMYXN0RGlydHlNZXNzYWdlYCBob2xkcyB0aGUgbW9zdCByZWNlbnQgZGlydHlpbmcgTWVzc2FnZSxcbiAgICAvLyBzbyBzbG93IHJlbmRlci1waGFzZSBjYWxsYmFja3MgZHVyaW5nIGhpZ2gtcmF0ZSBidXJzdHMgYXR0cmlidXRlIHRvXG4gICAgLy8gdGhlIGxhc3QgTWVzc2FnZSBpbiB0aGUgZnJhbWUgYmF0Y2gsIG5vdCB0aGUgc3BlY2lmaWMgb25lIHRoYXQgcHVzaGVkXG4gICAgLy8gdGhlIHZpZXcgcGFzdCB0aHJlc2hvbGQuIEFjY2VwdGFibGUgZm9yIGEgZGVidWcgY2FsbGJhY2s7IGZ1bGxcbiAgICAvLyBhdHRyaWJ1dGlvbiB3b3VsZCByZXF1aXJlIGNvcnJlbGF0aW5nIGVhY2ggbWVzc2FnZSB3aXRoIGl0cyByZW5kZXJcbiAgICAvLyBjb250cmlidXRpb24sIHdoaWNoIGlzbid0IHdvcnRoIHRoZSBjb21wbGV4aXR5LlxuICAgIGxldCBtYXliZUxhc3REaXJ0eU1lc3NhZ2UgPSBPcHRpb24ubm9uZTxNZXNzYWdlPigpXG5cbiAgICBjb25zdCBzZXRMYXN0RGlydHlNZXNzYWdlID0gKG1lc3NhZ2U6IE1lc3NhZ2UpOiB2b2lkID0+IHtcbiAgICAgIG1heWJlTGFzdERpcnR5TWVzc2FnZSA9IE9wdGlvbi5zb21lKG1lc3NhZ2UpXG4gICAgfVxuXG4gICAgY29uc3QgZGlzcGF0Y2hTeW5jID0gKFxuICAgICAgbWVzc2FnZTogdW5rbm93bixcbiAgICAgIGlzQ3VycmVudD86ICgpID0+IGJvb2xlYW4sXG4gICAgKTogdm9pZCA9PiB7XG4gICAgICAvKiBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L2NvbnNpc3RlbnQtdHlwZS1hc3NlcnRpb25zICovXG4gICAgICBlbnF1ZXVlTWVzc2FnZShtZXNzYWdlIGFzIE1lc3NhZ2UsIGlzQ3VycmVudClcbiAgICB9XG5cbiAgICBjb25zdCBkaXNwYXRjaEFzeW5jID0gKFxuICAgICAgbWVzc2FnZTogdW5rbm93bixcbiAgICAgIGlzQ3VycmVudD86ICgpID0+IGJvb2xlYW4sXG4gICAgKTogRWZmZWN0LkVmZmVjdDx2b2lkPiA9PlxuICAgICAgLyogZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9jb25zaXN0ZW50LXR5cGUtYXNzZXJ0aW9ucyAqL1xuICAgICAgZW5xdWV1ZU1lc3NhZ2VFZmZlY3QobWVzc2FnZSBhcyBNZXNzYWdlLCBpc0N1cnJlbnQpXG5cbiAgICBjb25zdCBkaXNwYXRjaCA9IHsgZGlzcGF0Y2hBc3luYywgZGlzcGF0Y2hTeW5jIH1cblxuICAgIC8vIE5PVEU6IE9uZSBib3VuZGFyeSByZWdpc3RyeSBwZXIgcnVudGltZSBpbnN0YW5jZSwgc2hhcmVkXG4gICAgLy8gYWNyb3NzIHJlbmRlcnMgc28gQmxvY2sgd3JhcCBibG9ja3MgcmVnaXN0ZXJlZCBieVxuICAgIC8vIGguYmxvY2sgcGVyc2lzdCBiZXR3ZWVuIHJlbmRlcnMuIFRoZSByZW5kZXIgZnVuY3Rpb24gY2FsbHNcbiAgICAvLyBgYmVnaW5IdG1sUmVuZGVyYCBhdCB0aGUgc3RhcnQgb2YgZWFjaCBwYXNzOyB3cmFwcyBmb3JcbiAgICAvLyB1bm1vdW50ZWQgQmxvY2tzIChlLmcuIGFuIGVudHJ5IHJlbW92ZWQgZnJvbSBhIGxpc3QpIGFyZVxuICAgIC8vIGRyb3BwZWQgZnJvbSB0aGUgcmVnaXN0cnkgdmlhIHNuYWJiZG9tIGBwb3N0ZGVzdHJveWAgaG9va3NcbiAgICAvLyBhdHRhY2hlZCBieSBgaC5ibG9ja2AgdG8gZWFjaCBjaGlsZCB2bm9kZS5cbiAgICBjb25zdCBib3VuZGFyeVJlZ2lzdHJ5OiBCb3VuZGFyeVJlZ2lzdHJ5ID0gY3JlYXRlSHRtbEJvdW5kYXJ5UmVnaXN0cnkoKVxuICAgIGNvbnN0IHJlZ2lzdGVyZWRNb3VudHMgPSBuZXcgU2V0KFxuICAgICAgbW91bnRzLm1hcChtb3VudCA9PiBtb3VudFtNb3VudFJlZ2lzdHJhdGlvblR5cGVJZF0pLFxuICAgIClcblxuICAgIGNvbnN0IG1vdW50VmFsaWRhdGlvblZpc2l0cyA9IG5ldyBTZXQ8Vk5vZGU+KClcblxuICAgIGNvbnN0IGFzc2VydExheWVyZWRNb3VudHNBcmVSZWdpc3RlcmVkID0gKHJvb3Q6IFZOb2RlIHwgbnVsbCk6IHZvaWQgPT4ge1xuICAgICAgaWYgKHJvb3QgPT09IG51bGwpIHtcbiAgICAgICAgcmV0dXJuXG4gICAgICB9XG5cbiAgICAgIGxldCBtaXNzaW5nOiBNYXA8b2JqZWN0LCBzdHJpbmc+IHwgdW5kZWZpbmVkXG4gICAgICBjb25zdCB3YWxrID0gKG5vZGU6IFZOb2RlKTogdm9pZCA9PiB7XG4gICAgICAgIGNvbnN0IHsgY2hpbGRyZW4gfSA9IG5vZGVcbiAgICAgICAgaWYgKGNoaWxkcmVuICE9PSB1bmRlZmluZWQgJiYgQXJyYXkuaXNBcnJheU5vbkVtcHR5KGNoaWxkcmVuKSkge1xuICAgICAgICAgIGlmIChtb3VudFZhbGlkYXRpb25WaXNpdHMuaGFzKG5vZGUpKSB7XG4gICAgICAgICAgICByZXR1cm5cbiAgICAgICAgICB9XG4gICAgICAgICAgbW91bnRWYWxpZGF0aW9uVmlzaXRzLmFkZChub2RlKVxuICAgICAgICB9XG5cbiAgICAgICAgLyogZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9jb25zaXN0ZW50LXR5cGUtYXNzZXJ0aW9ucyAqL1xuICAgICAgICBjb25zdCBtYXJrZXIgPSBub2RlLmRhdGE/LltGT0xES0lUX01PVU5UX0tFWV0gYXNcbiAgICAgICAgICB8IEZvbGRraXRNb3VudE1hcmtlclxuICAgICAgICAgIHwgdW5kZWZpbmVkXG4gICAgICAgIGNvbnN0IHJlZ2lzdHJhdGlvbiA9IG1hcmtlcj8uW01vdW50UmVnaXN0cmF0aW9uVHlwZUlkXVxuICAgICAgICBpZiAoXG4gICAgICAgICAgbWFya2VyICE9PSB1bmRlZmluZWQgJiZcbiAgICAgICAgICByZWdpc3RyYXRpb24gIT09IHVuZGVmaW5lZCAmJlxuICAgICAgICAgICFyZWdpc3RlcmVkTW91bnRzLmhhcyhyZWdpc3RyYXRpb24pXG4gICAgICAgICkge1xuICAgICAgICAgIG1pc3NpbmcgPz89IG5ldyBNYXA8b2JqZWN0LCBzdHJpbmc+KClcbiAgICAgICAgICBtaXNzaW5nLnNldChyZWdpc3RyYXRpb24sIG1hcmtlci5uYW1lKVxuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGNoaWxkcmVuICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICBmb3IgKGNvbnN0IGNoaWxkIG9mIGNoaWxkcmVuKSB7XG4gICAgICAgICAgICBpZiAoIVByZWRpY2F0ZS5pc1N0cmluZyhjaGlsZCkpIHtcbiAgICAgICAgICAgICAgd2FsayhjaGlsZClcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHRyeSB7XG4gICAgICAgIHdhbGsocm9vdClcbiAgICAgIH0gZmluYWxseSB7XG4gICAgICAgIG1vdW50VmFsaWRhdGlvblZpc2l0cy5jbGVhcigpXG4gICAgICB9XG5cbiAgICAgIGlmIChtaXNzaW5nID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgcmV0dXJuXG4gICAgICB9XG5cbiAgICAgIGNvbnN0IG5hbWVzID0gZ2xvYmFsVGhpcy5BcnJheS5mcm9tKG1pc3NpbmcudmFsdWVzKCkpLnNvcnQoKVxuICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICBgW2ZvbGRraXRdIFRoZSByZW5kZXJlZCB2aWV3IGNvbnRhaW5zIExheWVyLWJhY2tlZCBNb3VudHMgdGhhdCB3ZXJlIG5vdCByZWdpc3RlcmVkOiAke25hbWVzLmpvaW4oJywgJyl9LiBgICtcbiAgICAgICAgICBcIlJlZ2lzdGVyIGVhY2ggTW91bnQgRGVmaW5pdGlvbiBpbiB0aGUgb3duaW5nIENvbXBvc2l0aW9uJ3MgbW91bnRzIGZpZWxkLlwiLFxuICAgICAgKVxuICAgIH1cblxuICAgIC8vIE5PVEU6IGNhbGxlcnMgc2V0IGBpc1JlbmRlcmluZ0ZyYW1lYCBiZWZvcmUgY2FsbGluZyB0aGlzIGFuZCBjbGVhclxuICAgIC8vIGl0IGFmdGVyLiBXaXRob3V0IGl0LCBhIE1lc3NhZ2UgZGlzcGF0Y2hlZCB3aGlsZSB0aGUgcGF0Y2ggaXMgc3RpbGxcbiAgICAvLyBydW5uaW5nIHdvdWxkIHJ1biB1cGRhdGUgYWdhaW5zdCBhIGhhbGYtcGF0Y2hlZCBET00uIEZvciBhIHJlcGxheSxcbiAgICAvLyBgcmVuZGVyYCBhbHNvIGNhbGxzIGBiZWdpblJlcGxheUh0bWxSZW5kZXJgIGZpcnN0LCBzbyB0aGUgb2xkXG4gICAgLy8gdHJlZSdzIHVubW91bnQgY2FsbGJhY2tzIGRvbid0IGRpc3BhdGNoIGludG8gbGl2ZSBoaXN0b3J5LlxuICAgIGNvbnN0IHJlbmRlclN5bmMgPSAoXG4gICAgICBtb2RlbDogTW9kZWwsXG4gICAgICBtYXliZU1lc3NhZ2U6IE9wdGlvbi5PcHRpb248TWVzc2FnZT4sXG4gICAgICBkaXNwYXRjaFNlcnZpY2U6IHR5cGVvZiBEaXNwYXRjaC5TZXJ2aWNlLFxuICAgICAgcmVuZGVyQ29udGV4dDogQ29udGV4dC5Db250ZXh0PG5ldmVyPixcbiAgICAgIHJlbmRlck1vZGU6IFJlbmRlck1vZGUsXG4gICAgKTogdm9pZCA9PiB7XG4gICAgICBjb25zdCBtYXliZUxpdmVSZW5kZXIgPSBPcHRpb24ubGlmdFByZWRpY2F0ZShcbiAgICAgICAgcmVuZGVyTW9kZSxcbiAgICAgICAgbW9kZSA9PiBtb2RlID09PSAnTGl2ZScsXG4gICAgICApXG4gICAgICBjb25zdCBtYXliZUxpdmVTbG93VmlldyA9IE9wdGlvbi5mbGF0TWFwKFxuICAgICAgICBtYXliZUxpdmVSZW5kZXIsXG4gICAgICAgICgpID0+IG1heWJlU2xvd1ZpZXcsXG4gICAgICApXG4gICAgICBjb25zdCBtYXliZUxpdmVTbG93UGF0Y2ggPSBPcHRpb24uZmxhdE1hcChcbiAgICAgICAgbWF5YmVMaXZlUmVuZGVyLFxuICAgICAgICAoKSA9PiBtYXliZVNsb3dQYXRjaCxcbiAgICAgIClcbiAgICAgIGNvbnN0IFtuZXh0RG9jdW1lbnQsIG1heWJlVmlld0R1cmF0aW9uXSA9IG1lYXN1cmVTbG93UGhhc2UoXG4gICAgICAgIG1heWJlTGl2ZVNsb3dWaWV3LFxuICAgICAgICAoKSA9PiB7XG4gICAgICAgICAgYmVnaW5IdG1sUmVuZGVyKGJvdW5kYXJ5UmVnaXN0cnkpXG4gICAgICAgICAgc2V0SHRtbFJ1bnRpbWUoXG4gICAgICAgICAgICBkaXNwYXRjaFNlcnZpY2UuZGlzcGF0Y2hTeW5jLFxuICAgICAgICAgICAgcmVuZGVyQ29udGV4dCxcbiAgICAgICAgICAgIGJvdW5kYXJ5UmVnaXN0cnksXG4gICAgICAgICAgICByZW5kZXJNb2RlLFxuICAgICAgICAgIClcblxuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICByZXR1cm4gdmlldyhtb2RlbCwgaHRtbEJ1aWxkZXIpXG4gICAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgIGNsZWFySHRtbFJ1bnRpbWUoKVxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgIClcbiAgICAgIGNvbnN0IHsgYm9keTogbmV4dFZOb2RlIH0gPSBuZXh0RG9jdW1lbnRcbiAgICAgIGFzc2VydExheWVyZWRNb3VudHNBcmVSZWdpc3RlcmVkKG5leHRWTm9kZSlcblxuICAgICAgcmVwb3J0U2xvd1BoYXNlPFNsb3dWaWV3Q29udGV4dDxNb2RlbCwgTWVzc2FnZT4+KFxuICAgICAgICBtYXliZUxpdmVTbG93VmlldyxcbiAgICAgICAgbWF5YmVWaWV3RHVyYXRpb24sXG4gICAgICAgIChkdXJhdGlvbk1zLCB0aHJlc2hvbGRNcykgPT4gKHtcbiAgICAgICAgICBfdGFnOiAnVmlldycsXG4gICAgICAgICAgbW9kZWwsXG4gICAgICAgICAgbWVzc2FnZTogbWF5YmVNZXNzYWdlLFxuICAgICAgICAgIGR1cmF0aW9uTXMsXG4gICAgICAgICAgdGhyZXNob2xkTXMsXG4gICAgICAgIH0pLFxuICAgICAgKVxuXG4gICAgICBjb25zdCB7IG1heWJlQ3VycmVudFZOb2RlIH0gPSB2bm9kZVNsb3RcblxuICAgICAgY29uc3QgW3BhdGNoZWRWTm9kZSwgbWF5YmVQYXRjaER1cmF0aW9uXSA9IG1lYXN1cmVTbG93UGhhc2UoXG4gICAgICAgIG1heWJlTGl2ZVNsb3dQYXRjaCxcbiAgICAgICAgKCkgPT4ge1xuICAgICAgICAgIGlmIChcbiAgICAgICAgICAgIE9wdGlvbi5pc05vbmUobWF5YmVDdXJyZW50Vk5vZGUpICYmXG4gICAgICAgICAgICBwZW5kaW5nSHlkcmF0aW9uUm9vdCAhPT0gbnVsbFxuICAgICAgICAgICkge1xuICAgICAgICAgICAgY29uc3QgaHlkcmF0aW9uUm9vdCA9IHBlbmRpbmdIeWRyYXRpb25Sb290XG4gICAgICAgICAgICBwZW5kaW5nSHlkcmF0aW9uUm9vdCA9IG51bGxcbiAgICAgICAgICAgIC8vIE5PVEU6IHN0cmlwIHRoZSBzdGFtcCBiZWZvcmUgdGhlIHBhdGNoLCBub3QgYWZ0ZXIsIHNvIHRoZVxuICAgICAgICAgICAgLy8gcGF0Y2ggaXMgdGhlIHNvbGUgb3duZXIgb2YgdGhlIHJvb3QncyBhdHRyaWJ1dGVzLiBJdCBoYXNcbiAgICAgICAgICAgIC8vIGFscmVhZHkgc2VydmVkIGl0cyBwdXJwb3NlIG9mIGxvY2F0aW5nIHRoZSByb290LCBhbmRcbiAgICAgICAgICAgIC8vIHJlbW92aW5nIGl0IGFmdGVyIHdvdWxkIGRlbGV0ZSBhIGBkYXRhLWZvbGRraXQtYXBwYCB0aGUgdmlld1xuICAgICAgICAgICAgLy8gaXRzZWxmIGRlY2xhcmVzLCB3aGljaCBhIGxhdGVyIGVxdWFsLXZub2RlIHBhdGNoIHdvdWxkIG5vdFxuICAgICAgICAgICAgLy8gcmVzdG9yZS4gUmVtb3ZpbmcgaXQgaGVyZSBhbHNvIHN0b3BzIGEgbGF0ZXIgYm9vdCBvbiB0aGUgc2FtZVxuICAgICAgICAgICAgLy8gY29udGFpbmVyIChhIGRpc3Bvc2UtdGhlbi1lbWJlZCByZW1vdW50KSBmcm9tIHJlLWRldGVjdGluZ1xuICAgICAgICAgICAgLy8gdGhpcyBub3ctY29uc3VtZWQgcm9vdCBhcyBoeWRyYXRhYmxlLlxuICAgICAgICAgICAgaHlkcmF0aW9uUm9vdC5yZW1vdmVBdHRyaWJ1dGUoRk9MREtJVF9BUFBfQVRUUklCVVRFKVxuICAgICAgICAgICAgLy8gQW4gZW1wdHkgaWQgcmVhY2hlcyB0aGUgYWRvcHRpb24gc3RlcCdzIG93biBjaGVjayBhcyBhXG4gICAgICAgICAgICAvLyB2YWx1ZSB0aGF0IG1hdGNoZXMgbm90aGluZy4gQm9vdCBhbHJlYWR5IHJlZnVzZWQgYVxuICAgICAgICAgICAgLy8gaHlkcmF0aW9uIHdpdGhvdXQgYW4gaWQsIHNvIHRoaXMgc3RhbmRzIGluIG9ubHkgZm9yIGFcbiAgICAgICAgICAgIC8vIGNhbGxlciB0aGF0IHJlYWNoZWQgaGVyZSBhbm90aGVyIHdheS5cbiAgICAgICAgICAgIHJldHVybiBfX2h5ZHJhdGVWTm9kZShcbiAgICAgICAgICAgICAgaHlkcmF0aW9uUm9vdCxcbiAgICAgICAgICAgICAgbmV4dFZOb2RlLFxuICAgICAgICAgICAgICBib3VuZGFyeVJlZ2lzdHJ5LmRlZHVwZVNlZW4sXG4gICAgICAgICAgICAgIGJ1aWxkSWQgPz8gJycsXG4gICAgICAgICAgICApXG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybiBwYXRjaFJ1bnRpbWVWTm9kZShcbiAgICAgICAgICAgIG1heWJlQ3VycmVudFZOb2RlLFxuICAgICAgICAgICAgbmV4dFZOb2RlLFxuICAgICAgICAgICAgYm91bmRhcnlSZWdpc3RyeS5kZWR1cGVTZWVuLFxuICAgICAgICAgIClcbiAgICAgICAgfSxcbiAgICAgIClcbiAgICAgIHZub2RlU2xvdC5tYXliZUN1cnJlbnRWTm9kZSA9IE9wdGlvbi5zb21lKHBhdGNoZWRWTm9kZSlcblxuICAgICAgcmVwb3J0U2xvd1BoYXNlPFNsb3dQYXRjaENvbnRleHQ8TW9kZWwsIE1lc3NhZ2U+PihcbiAgICAgICAgbWF5YmVMaXZlU2xvd1BhdGNoLFxuICAgICAgICBtYXliZVBhdGNoRHVyYXRpb24sXG4gICAgICAgIChkdXJhdGlvbk1zLCB0aHJlc2hvbGRNcykgPT4gKHtcbiAgICAgICAgICBfdGFnOiAnUGF0Y2gnLFxuICAgICAgICAgIG1vZGVsLFxuICAgICAgICAgIG1lc3NhZ2U6IG1heWJlTWVzc2FnZSxcbiAgICAgICAgICBkdXJhdGlvbk1zLFxuICAgICAgICAgIHRocmVzaG9sZE1zLFxuICAgICAgICB9KSxcbiAgICAgIClcblxuICAgICAgaWYgKG1hbmFnZURvY3VtZW50KSB7XG4gICAgICAgIGFwcGx5RG9jdW1lbnRNZXRhZGF0YShuZXh0RG9jdW1lbnQsIHBhdGNoZWRWTm9kZS5lbG0pXG4gICAgICB9XG5cbiAgICAgIGlmIChpbXBvcnQubWV0YS5ob3QpIHtcbiAgICAgICAgZHVwbGljYXRlSWRTY2FubmVyPy5zY2hlZHVsZShwYXRjaGVkVk5vZGUuZWxtKVxuICAgICAgfVxuICAgIH1cblxuICAgIC8vIE5PVEU6IGBkaXNwYXRjaFNlcnZpY2VgIGRlZmF1bHRzIHRvIGxpdmUgZGlzcGF0Y2ggYnV0IGlzIG92ZXJyaWRhYmxlXG4gICAgLy8gc28gYSB0aW1lLXRyYXZlbCByZW5kZXIgY2FuIGJpbmQgYm90aCBkZWNsYXJhdGl2ZSBoYW5kbGVycyBhbmQgbmV3bHlcbiAgICAvLyBhY3F1aXJlZCBNb3VudHMgdG8gYG5vT3BEaXNwYXRjaGAuIEEgbGl2ZSBNb3VudCBrZWVwcyBpdHMgZGlzcGF0Y2hlclxuICAgIC8vIGFjcm9zcyByZXBsYXksIHdoaWxlIGEgcmVwbGF5LWNyZWF0ZWQgTW91bnQgc3RheXMgbXV0ZWQgdW50aWwgYSBsaXZlXG4gICAgLy8gcmVzdW1lIHBhdGNoIHJlbGVhc2VzIGl0IGFuZCBzdGFydHMgdGhlIGxpdmUgYWN0aW9uLiBUaGlzIHByZXNlcnZlc1xuICAgIC8vIHZhbGlkIGFzeW5jIHJlc3VsdHMgZnJvbSBsaXZlIE1vdW50cyB3aXRob3V0IGdyYW50aW5nIGEgaGlzdG9yaWNhbFxuICAgIC8vIGFjcXVpc2l0aW9uIGFjY2VzcyB0byB0aGUgbGl2ZSBNb2RlbC5cbiAgICBjb25zdCByZW5kZXIgPSAoXG4gICAgICBtb2RlbDogTW9kZWwsXG4gICAgICBtYXliZU1lc3NhZ2U6IE9wdGlvbi5PcHRpb248TWVzc2FnZT4sXG4gICAgICBkaXNwYXRjaFNlcnZpY2U6IHR5cGVvZiBEaXNwYXRjaC5TZXJ2aWNlID0gZGlzcGF0Y2gsXG4gICAgICByZW5kZXJNb2RlOiBSZW5kZXJNb2RlID0gJ0xpdmUnLFxuICAgICkgPT5cbiAgICAgIEVmZmVjdC5nZW4oZnVuY3Rpb24qICgpIHtcbiAgICAgICAgc3RhdHVzLmlzUmVuZGVyaW5nRnJhbWUgPSB0cnVlXG4gICAgICAgIGNvbnN0IHJlbmRlckNvbnRleHQgPSBDb250ZXh0LmFkZChcbiAgICAgICAgICBDb250ZXh0LmFkZChcbiAgICAgICAgICAgIENvbnRleHQuYWRkKHJ1bnRpbWVDb250ZXh0LCBEaXNwYXRjaCwgZGlzcGF0Y2hTZXJ2aWNlKSxcbiAgICAgICAgICAgIE1vdW50VHJhY2tlcixcbiAgICAgICAgICAgIG1vdW50VHJhY2tlcixcbiAgICAgICAgICApLFxuICAgICAgICAgIE1vdW50UnVudGltZSxcbiAgICAgICAgICBtb3VudFJ1bnRpbWUsXG4gICAgICAgIClcbiAgICAgICAgaWYgKHJlbmRlck1vZGUgPT09ICdSZXBsYXknKSB7XG4gICAgICAgICAgYmVnaW5SZXBsYXlIdG1sUmVuZGVyKClcbiAgICAgICAgfVxuICAgICAgICByZW5kZXJTeW5jKFxuICAgICAgICAgIG1vZGVsLFxuICAgICAgICAgIG1heWJlTWVzc2FnZSxcbiAgICAgICAgICBkaXNwYXRjaFNlcnZpY2UsXG4gICAgICAgICAgcmVuZGVyQ29udGV4dCxcbiAgICAgICAgICByZW5kZXJNb2RlLFxuICAgICAgICApXG4gICAgICB9KS5waXBlKFxuICAgICAgICBFZmZlY3QuZW5zdXJpbmcoXG4gICAgICAgICAgRWZmZWN0LnN5bmMoKCkgPT4ge1xuICAgICAgICAgICAgc3RhdHVzLmlzUmVuZGVyaW5nRnJhbWUgPSBmYWxzZVxuICAgICAgICAgICAgZW5kUmVwbGF5SHRtbFJlbmRlcigpXG4gICAgICAgICAgICBkcmFpblBlbmRpbmdNZXNzYWdlcygpXG4gICAgICAgICAgfSksXG4gICAgICAgICksXG4gICAgICApXG5cbiAgICBjb25zdCBsaXZlUmVuZGVyQ29udGV4dCA9IENvbnRleHQuYWRkKFxuICAgICAgQ29udGV4dC5hZGQoXG4gICAgICAgIENvbnRleHQuYWRkKHJ1bnRpbWVDb250ZXh0LCBEaXNwYXRjaCwgZGlzcGF0Y2gpLFxuICAgICAgICBNb3VudFRyYWNrZXIsXG4gICAgICAgIG1vdW50VHJhY2tlcixcbiAgICAgICksXG4gICAgICBNb3VudFJ1bnRpbWUsXG4gICAgICBtb3VudFJ1bnRpbWUsXG4gICAgKVxuXG4gICAgLy8gTk9URTogcmVuZGVyaW5nIGJlZm9yZSBhIGRlZmVycmVkIGRyYWluIHJlc3VtZXMgd291bGQgcmVzdG9yZSBzdGFsZVxuICAgIC8vIGNvbnRyb2xsZWQgaW5wdXQgdmFsdWVzLiBEaXNwb3NlZCBvciBjcmFzaGVkIHJ1bnRpbWVzIHVzZSB0aGUgZnJhbWUgZ3VhcmRzLlxuICAgIGNvbnN0IGlzTGl2ZU1vZGVsQmVoaW5kUXVldWUgPSAoKTogYm9vbGVhbiA9PlxuICAgICAgaXNBbnlNZXNzYWdlRGVmZXJyZWQoKSAmJiAhc3RhdHVzLmlzUnVudGltZURpc3Bvc2VkICYmICFzdGF0dXMuaXNDcmFzaGVkXG5cbiAgICAvLyBOT1RFOiB0aGUgcmVuZGVyLCBNb3VudCBkcmFpbiwgRGV2VG9vbHMgYXR0cmlidXRpb24sIGFuZFxuICAgIC8vIHBhdGNoLXRpbWUtYnVmZmVyIGZsdXNoLiBTaGFyZWQgYnkgdGhlIHBsYWluIHBhdGggKGNhbGxlZCBkaXJlY3RseSlcbiAgICAvLyBhbmQgdGhlIFZpZXcgVHJhbnNpdGlvbiBwYXRoIChjYWxsZWQgZnJvbSB0aGUgdHJhbnNpdGlvbidzIHVwZGF0ZVxuICAgIC8vIGNhbGxiYWNrKSwgd2hpY2ggcnVuIGlkZW50aWNhbCB3b3JrOyBvbmx5IHdoZXRoZXIgdGhleSBydW4gaW5zaWRlXG4gICAgLy8gYGRvY3VtZW50LnN0YXJ0Vmlld1RyYW5zaXRpb25gIGRpZmZlcnMuIGBpc1JlbmRlcmluZ0ZyYW1lYCBnYXRlcyB0aGVcbiAgICAvLyBidWZmZXJpbmcgb2YgTWVzc2FnZXMgZGlzcGF0Y2hlZCBieSBwYXRjaC10aW1lIGhvb2tzLCBzbyBpdCBtdXN0XG4gICAgLy8gd3JhcCB0aGUgYWN0dWFsIHBhdGNoLCB3aGljaCBvbiB0aGUgdHJhbnNpdGlvbiBwYXRoIGhhcHBlbnMgaW5zaWRlXG4gICAgLy8gdGhlIGNhbGxiYWNrLCBub3Qgd2hlbiB0aGUgZnJhbWUgaXMgc2NoZWR1bGVkLlxuICAgIGNvbnN0IHJ1blJlbmRlckZyYW1lQm9keSA9ICgpOiB2b2lkID0+IHtcbiAgICAgIHN0YXR1cy5pc1JlbmRlcmluZ0ZyYW1lID0gdHJ1ZVxuICAgICAgLy8gTk9URTogY2FwdHVyZWQgYmVmb3JlIHRoZSBwYXRjaCwgYmVjYXVzZSBgZHJhaW5QZW5kaW5nTWVzc2FnZXNgXG4gICAgICAvLyBiZWxvdyBjYW4gYWR2YW5jZSB0aGUgbGl2ZSBNb2RlbCBhZ2FpbiBiZWZvcmUgdGhlIG5leHQgZnJhbWUgcmVhZHNcbiAgICAgIC8vIGl0LiBXaGF0IHRoaXMgZnJhbWUgcGFpbnRlZCBpcyB3aGF0IHRoZSBuZXh0IHRyYW5zaXRpb24gYW5pbWF0ZXNcbiAgICAgIC8vIGF3YXkgZnJvbS5cbiAgICAgIGNvbnN0IHJlbmRlcmVkTW9kZWwgPSByZWFkTGl2ZU1vZGVsKClcbiAgICAgIGNvbnN0IGlzUmVzdW1pbmcgPSByZWFkVmlld1N0YXRlKCkgPT09ICdQYXVzZWQnXG4gICAgICBpZiAoaXNSZXN1bWluZykge1xuICAgICAgICAvLyBOT1RFOiBNZXNzYWdlcyBhY2N1bXVsYXRlZCB3aGlsZSBhIGhpc3RvcmljYWwgdmlldyBvd25lZCB0aGUgRE9NXG4gICAgICAgIC8vIGRpZCBub3QgY2F1c2UgdGhpcyByZXBhaW50LiBBIE1lc3NhZ2UgYXJyaXZpbmcgZHVyaW5nIHRoZSBwYXRjaFxuICAgICAgICAvLyBjYW4gcmVwb3B1bGF0ZSB0aGlzIGZpZWxkIHdoZW4gdGhlIGJ1ZmZlcmVkIHF1ZXVlIGRyYWlucy5cbiAgICAgICAgbWF5YmVMYXN0RGlydHlNZXNzYWdlID0gT3B0aW9uLm5vbmUoKVxuICAgICAgfVxuICAgICAgdHJ5IHtcbiAgICAgICAgcmVuZGVyU3luYyhcbiAgICAgICAgICByZWFkTGl2ZU1vZGVsKCksXG4gICAgICAgICAgbWF5YmVMYXN0RGlydHlNZXNzYWdlLFxuICAgICAgICAgIGRpc3BhdGNoLFxuICAgICAgICAgIGxpdmVSZW5kZXJDb250ZXh0LFxuICAgICAgICAgICdMaXZlJyxcbiAgICAgICAgKVxuICAgICAgICAvLyBOT1RFOiBhZnRlciB0aGUgcGF0Y2gsIHNvIGEgcmVuZGVyIHRoYXQgdGhyZXcgbGVhdmVzIHRoaXMgb24gdGhlXG4gICAgICAgIC8vIE1vZGVsIHN0aWxsIG9uIHNjcmVlbiwgYW5kIGJlZm9yZSBgZHJhaW5QZW5kaW5nTWVzc2FnZXNgIGJlbG93LFxuICAgICAgICAvLyB3aG9zZSBoYW5kbGVycyBjYW4gYWR2YW5jZSB0aGUgbGl2ZSBNb2RlbCBhZ2Fpbi5cbiAgICAgICAgbGFzdFJlbmRlcmVkTW9kZWwgPSByZW5kZXJlZE1vZGVsXG4gICAgICAgIC8vIE5PVEU6IHJlc3VtZSBjbGVhcnMgdGhlIHN0b3JlJ3MgcGF1c2UgZmxhZyBiZWZvcmUgdGhpcyBmcmFtZS5cbiAgICAgICAgLy8gUHVibGlzaCBMaXZlIG9ubHkgYWZ0ZXIgdGhlIGxpdmUgRE9NIGhhcyBiZWVuIGluc3RhbGxlZC5cbiAgICAgICAgc2V0Vmlld1N0YXRlKCdMaXZlJylcbiAgICAgICAgYXR0YWNoUmVuZGVyZWRNb3VudHMoKVxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgRWZmZWN0LnJ1bkZvcmsoY3Jhc2hXaXRoKENhdXNlLmRpZShlcnJvciksIG1heWJlTGFzdERpcnR5TWVzc2FnZSkpXG4gICAgICB9IGZpbmFsbHkge1xuICAgICAgICBzdGF0dXMuaXNSZW5kZXJpbmdGcmFtZSA9IGZhbHNlXG4gICAgICB9XG4gICAgICAvLyBOT1RFOiBNZXNzYWdlcyBkaXNwYXRjaGVkIGJ5IHBhdGNoLXRpbWUgaG9va3MgKGZvciBleGFtcGxlLFxuICAgICAgLy8gT25Vbm1vdW50IGRlc3Ryb3lzLCBvciBNb3VudCBlbWlzc2lvbnMpIHdlcmUgYnVmZmVyZWQgd2hpbGUgdGhlXG4gICAgICAvLyBmcmFtZSBoZWxkIHRoZSBzdGFjazsgdGhleSBwcm9jZXNzIG5vdywgYWZ0ZXIgdGhlIHBhdGNoIGhhc1xuICAgICAgLy8gY29tbWl0dGVkIGFuZCB0aGUgZnJhbWUncyBNb3VudCBldmVudHMgYXJlIGF0dHJpYnV0ZWQuXG4gICAgICBkcmFpblBlbmRpbmdNZXNzYWdlcygpXG4gICAgICAvLyBOT1RFOiBsYXN0LCBzbyBhIHdhaXRlciByZXN1bWVkIGJ5IHRoZSBjb21taXQgb2JzZXJ2ZXMgdGhlIHNhbWVcbiAgICAgIC8vIERPTSBhbmQgdGhlIHNhbWUgcHJvY2Vzc2VkLU1lc3NhZ2Ugb3JkZXJpbmcgaXQgc2F3IHdoZW5cbiAgICAgIC8vIGBhZnRlckNvbW1pdGAgY291bnRlZCBmcmFtZXMuXG4gICAgICBzZXR0bGVQZW5kaW5nQ29tbWl0KClcbiAgICB9XG5cbiAgICAvLyBOT1RFOiBzdGFydHMgYSBWaWV3IFRyYW5zaXRpb24gYXJvdW5kIHRoaXMgZnJhbWUncyByZW5kZXIgd2hlbiB0aGVcbiAgICAvLyBgdmlld1RyYW5zaXRpb25gIHByZWRpY2F0ZSBtYXRjaGVzLCByZXR1cm5pbmcgYHRydWVgIHdoZW4gaXQgZGlkLlxuICAgIC8vIGBzdGFydFZpZXdUcmFuc2l0aW9uYCBpbnZva2VzIGl0cyB1cGRhdGUgY2FsbGJhY2sgYXN5bmNocm9ub3VzbHlcbiAgICAvLyBhZnRlciBzbmFwc2hvdHRpbmcgdGhlIG9sZCBET00sIHNvIHRoZSBjYWxsYmFjayByZWFkcyB0aGUgbGl2ZSBNb2RlbFxuICAgIC8vIGFuZCBgbWF5YmVMYXN0RGlydHlNZXNzYWdlYCBmcmVzaCAodGhlIHBsYWluIGxvb3AgbWF5IGhhdmUgYWR2YW5jZWRcbiAgICAvLyB0aGUgbW9kZWwgd2hpbGUgdGhlIGJyb3dzZXIgc3VwcHJlc3NlZCByZW5kZXJpbmcpIGFuZCByZS1jaGVja3MgdGhlXG4gICAgLy8gZGlzcG9zYWwgYW5kIGNyYXNoIGd1YXJkcywgd2hpY2ggY2FuIGZsaXAgd2hpbGUgdGhlIHRyYW5zaXRpb24gaXNcbiAgICAvLyBwZW5kaW5nLiBUaGUgdW5jb25maWd1cmVkIHBhdGggbmV2ZXIgcmVhY2hlcyB0aGlzIGZ1bmN0aW9uOyB0aGVcbiAgICAvLyBgT3B0aW9uLmlzTm9uZWAgY2hlY2sgaW4gYHJlbmRlckZyYW1lUGxhaW5gIHJldHVybnMgZmlyc3QsIHNvIGFcbiAgICAvLyBydW50aW1lIHdpdGhvdXQgYHZpZXdUcmFuc2l0aW9uYCBhbGxvY2F0ZXMgbm8gcGVyLWZyYW1lIGNhbGxiYWNrLlxuICAgIGNvbnN0IHN0YXJ0RnJhbWVWaWV3VHJhbnNpdGlvbiA9IChcbiAgICAgIHJlc29sdmVkOiBSZXNvbHZlZFZpZXdUcmFuc2l0aW9uPE1vZGVsLCBNZXNzYWdlPixcbiAgICApOiBib29sZWFuID0+IHtcbiAgICAgIGlmIChyZWFkVmlld1N0YXRlKCkgPT09ICdQYXVzZWQnKSB7XG4gICAgICAgIHJldHVybiBmYWxzZVxuICAgICAgfVxuICAgICAgaWYgKHJlc29sdmVkLnJlZHVjZWRNb3Rpb25RdWVyeS5tYXRjaGVzKSB7XG4gICAgICAgIHJldHVybiBmYWxzZVxuICAgICAgfVxuICAgICAgaWYgKE9wdGlvbi5pc05vbmUobWF5YmVMYXN0RGlydHlNZXNzYWdlKSkge1xuICAgICAgICByZXR1cm4gZmFsc2VcbiAgICAgIH1cbiAgICAgIGNvbnN0IG1heWJlRGVjaXNpb24gPSBfX2RlY2lkZVZpZXdUcmFuc2l0aW9uKHJlc29sdmVkLmRlY2lkZSwge1xuICAgICAgICBwcmV2aW91c01vZGVsOiBsYXN0UmVuZGVyZWRNb2RlbCxcbiAgICAgICAgbW9kZWw6IHJlYWRMaXZlTW9kZWwoKSxcbiAgICAgICAgbWVzc2FnZTogbWF5YmVMYXN0RGlydHlNZXNzYWdlLnZhbHVlLFxuICAgICAgfSlcbiAgICAgIGlmIChPcHRpb24uaXNOb25lKG1heWJlRGVjaXNpb24pKSB7XG4gICAgICAgIHJldHVybiBmYWxzZVxuICAgICAgfVxuICAgICAgLy8gTk9URTogaW52YWxpZGF0ZSBhbiBvbGRlciB0cmFuc2l0aW9uIGJlZm9yZSB0aGlzIG9uZSB0YWtlc1xuICAgICAgLy8gb3duZXJzaGlwIG9mIHRoZSBsYXRlc3QgbGl2ZSByZXBhaW50LiBUaGUgYnJvd3NlciBtYXkgc3RpbGwgY2FsbFxuICAgICAgLy8gdGhlIG9sZGVyIHVwZGF0ZSBjYWxsYmFjaywgYnV0IGl0cyBpbnZhbGlkYXRpb24gZ3VhcmQgbGVhdmVzIHRoZVxuICAgICAgLy8gRE9NIGFuZCBjb21taXQgbm90aWZpZXIgdG8gdGhpcyB0cmFuc2l0aW9uLlxuICAgICAgc2tpcFBlbmRpbmdWaWV3VHJhbnNpdGlvbigpXG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCB1cGRhdGUgPSB7XG4gICAgICAgICAgaXNJbnZhbGlkYXRlZDogZmFsc2UsXG4gICAgICAgICAgZGlkUnVuOiBmYWxzZSxcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBoYW5kbGUgPSByZXNvbHZlZC5zdGFydFZpZXdUcmFuc2l0aW9uKCgpID0+IHtcbiAgICAgICAgICBpZiAodXBkYXRlLmlzSW52YWxpZGF0ZWQgfHwgdXBkYXRlLmRpZFJ1bikge1xuICAgICAgICAgICAgcmV0dXJuXG4gICAgICAgICAgfVxuICAgICAgICAgIHVwZGF0ZS5kaWRSdW4gPSB0cnVlXG5cbiAgICAgICAgICAvLyBOT1RFOiBhIGRyYWluIG1heSBoYXZlIGJlZW4gZGVmZXJyZWQgc2luY2UgdGhlIHByZWNlZGluZyBmcmFtZVxuICAgICAgICAgIC8vIHN0YXJ0ZWQgdGhlIHRyYW5zaXRpb24uIExlYXZlIHRoZSBET00gdW5jaGFuZ2VkIHVudGlsIGl0IGNhdGNoZXMgdXAuXG4gICAgICAgICAgaWYgKGlzTGl2ZU1vZGVsQmVoaW5kUXVldWUoKSkge1xuICAgICAgICAgICAgc2tpcFBlbmRpbmdWaWV3VHJhbnNpdGlvbigpXG4gICAgICAgICAgICBzY2hlZHVsZVJlbmRlckZyYW1lKClcbiAgICAgICAgICAgIHJldHVyblxuICAgICAgICAgIH1cbiAgICAgICAgICAvLyBOT1RFOiB0aGUgdmlldyBzdGF0ZSBjbG9zZXMgdGhlIHJlc3VtZSB3aW5kb3cgYWZ0ZXIgdGhlXG4gICAgICAgICAgLy8gc3RvcmUgaXMgbGl2ZSBidXQgYmVmb3JlIGl0cyBwbGFpbiBmcmFtZSBoYXMgcmVzdG9yZWQgdGhlIGxpdmVcbiAgICAgICAgICAvLyBET00uIEEgdHJhbnNpdGlvbiBpbnZhbGlkYXRlZCBieSBqdW1wVG8gc3RheXMgaW52YWxpZCBmb3JldmVyLFxuICAgICAgICAgIC8vIHNvIGl0cyBjYWxsYmFjayBjYW5ub3QgcmVwYWludCBpbnNpZGUgdGhlIHN0YWxlIHRyYW5zaXRpb25cbiAgICAgICAgICAvLyBldmVuIGlmIGl0IGFycml2ZXMgYWZ0ZXIgcmVzdW1lIGhhcyBwdWJsaXNoZWQgYExpdmVgLlxuICAgICAgICAgIGlmIChcbiAgICAgICAgICAgIHN0YXR1cy5pc1J1bnRpbWVEaXNwb3NlZCB8fFxuICAgICAgICAgICAgc3RhdHVzLmlzQ3Jhc2hlZCB8fFxuICAgICAgICAgICAgaXNQYXVzZWROb3coKSB8fFxuICAgICAgICAgICAgcmVhZFZpZXdTdGF0ZSgpID09PSAnUGF1c2VkJ1xuICAgICAgICAgICkge1xuICAgICAgICAgICAgc2V0dGxlUGVuZGluZ0NvbW1pdCgpXG4gICAgICAgICAgICByZXR1cm5cbiAgICAgICAgICB9XG4gICAgICAgICAgcnVuUmVuZGVyRnJhbWVCb2R5KClcbiAgICAgICAgfSwgbWF5YmVEZWNpc2lvbi52YWx1ZS5tYXliZVR5cGVzKVxuICAgICAgICBtYXliZVBlbmRpbmdWaWV3VHJhbnNpdGlvbiA9IE9wdGlvbi5zb21lKHsgaGFuZGxlLCB1cGRhdGUgfSlcbiAgICAgICAgX19zaWxlbmNlVmlld1RyYW5zaXRpb25SZWplY3Rpb25zKGhhbmRsZSlcbiAgICAgICAgcmV0dXJuIHRydWVcbiAgICAgIH0gY2F0Y2gge1xuICAgICAgICAvLyBOT1RFOiBhbiBlc2NhcGluZyB0aHJvdyB3b3VsZCBsZWF2ZSB0aGUgckFGIGNhbGxiYWNrIHdpdGhvdXQgYVxuICAgICAgICAvLyBwYXRjaCBhbmQgd2l0aG91dCBzZXR0bGluZyB0aGUgY29tbWl0IG5vdGlmaWVyLCBwYXJraW5nIGV2ZXJ5XG4gICAgICAgIC8vIGBSZW5kZXIuYWZ0ZXJDb21taXRgIG9uIHRoaXMgZnJhbWUgZm9yZXZlci5cbiAgICAgICAgcmV0dXJuIGZhbHNlXG4gICAgICB9XG4gICAgfVxuXG4gICAgLy8gTk9URTogZXZlcnkgcGF0aCBvdXQgb2YgYSBzY2hlZHVsZWQgZnJhbWUgc2V0dGxlcyB0aGUgY29tbWl0XG4gICAgLy8gbm90aWZpZXIsIHdoZXRoZXIgb3Igbm90IGl0IHBhdGNoZWQuIEEgZnJhbWUgYWJhbmRvbmVkIHNpbGVudGx5XG4gICAgLy8gd291bGQgc3RyYW5kIGFueSBgUmVuZGVyLmFmdGVyQ29tbWl0YCByZWdpc3RlcmVkIGFnYWluc3QgaXQsIGFuZFxuICAgIC8vIHRoZSBEb20gaGVscGVycyB0aGF0IGdhdGUgb24gaXQgd291bGQgbmV2ZXIgcnVuIHRoZWlyIERPTSB3b3JrLlxuICAgIGNvbnN0IHJlbmRlckZyYW1lUGxhaW4gPSAoKTogdm9pZCA9PiB7XG4gICAgICAvLyBOT1RFOiBhIGZyYW1lIHByb3ZlcyB0aGUgYnJvd3NlciByZWdhaW5lZCBjb250cm9sIGFmdGVyIGEgYnVkZ2V0IHlpZWxkLlxuICAgICAgaWYgKGlzTGl2ZU1vZGVsQmVoaW5kUXVldWUoKSkge1xuICAgICAgICBkcmFpbkRlZmVycmVkTm93KClcbiAgICAgIH1cbiAgICAgIC8vIE5PVEU6IHJldGFpbiB0aGUgc2NoZWR1bGVkIGZyYW1lJ3MgcGVuZGluZyBjb21taXQgd2hpbGUgdGhlIGRyYWluIHdhaXRzLlxuICAgICAgaWYgKGlzTGl2ZU1vZGVsQmVoaW5kUXVldWUoKSkge1xuICAgICAgICByZXF1ZXN0QW5pbWF0aW9uRnJhbWUocmVuZGVyRnJhbWVQbGFpbilcbiAgICAgICAgcmV0dXJuXG4gICAgICB9XG4gICAgICBpc1JlbmRlckZyYW1lQXJtZWQgPSBmYWxzZVxuICAgICAgaWYgKCFpc1JlbmRlckZyYW1lU2NoZWR1bGVkKSB7XG4gICAgICAgIHJldHVyblxuICAgICAgfVxuICAgICAgaXNSZW5kZXJGcmFtZVNjaGVkdWxlZCA9IGZhbHNlXG4gICAgICBjb25zdCBpc1Jlc3RvcmluZ0xpdmVWaWV3ID0gaXNMaXZlVmlld1Jlc3RvcmVQZW5kaW5nXG4gICAgICBpc0xpdmVWaWV3UmVzdG9yZVBlbmRpbmcgPSBmYWxzZVxuICAgICAgLy8gTk9URTogYSBmcmFtZSBzY2hlZHVsZWQgYmVmb3JlIGRpc3Bvc2FsIGZpcmVzIGFmdGVyIGl0OyBhXG4gICAgICAvLyBkaXNwb3NlZCBydW50aW1lIG11c3Qgbm90IHJlcGFpbnQgdGhlIHJlbGVhc2VkIGNvbnRhaW5lci5cbiAgICAgIGlmIChzdGF0dXMuaXNSdW50aW1lRGlzcG9zZWQpIHtcbiAgICAgICAgc2V0dGxlUGVuZGluZ0NvbW1pdCgpXG4gICAgICAgIHJldHVyblxuICAgICAgfVxuICAgICAgLy8gTk9URTogYSBmcmFtZSBpcyBydW5uaW5nLCBzbyB0aGUgYnJvd3NlciBnb3QgY29udHJvbCBiYWNrOyB0aGVcbiAgICAgIC8vIGRyYWluIGJ1ZGdldCBzdGFydHMgZnJlc2guXG4gICAgICByZXNldERyYWluQnVkZ2V0KClcbiAgICAgIC8vIE5PVEU6IGEgTWVzc2FnZSB0aGF0IGRpcnRpZWQgdGhlIG1vZGVsIGNhbiBhbHNvIGJlIHRoZSBvbmVcbiAgICAgIC8vIHdob3NlIENvbW1hbmQgY3Jhc2hlZCB0aGUgcnVudGltZS4gV2l0aG91dCB0aGlzIGd1YXJkIHRoZVxuICAgICAgLy8gbmV4dCBhbmltYXRpb24gZnJhbWUgd291bGQgcmVuZGVyIHRoZSBsaXZlIHZpZXcgb3ZlciB0aGVcbiAgICAgIC8vIGNyYXNoIHZpZXcuXG4gICAgICBpZiAoc3RhdHVzLmlzQ3Jhc2hlZCkge1xuICAgICAgICBzZXR0bGVQZW5kaW5nQ29tbWl0KClcbiAgICAgICAgcmV0dXJuXG4gICAgICB9XG4gICAgICBpZiAoaXNQYXVzZWROb3coKSkge1xuICAgICAgICBzZXR0bGVQZW5kaW5nQ29tbWl0KClcbiAgICAgICAgcmV0dXJuXG4gICAgICB9XG4gICAgICBpZiAocmVhZFZpZXdTdGF0ZSgpID09PSAnUGF1c2VkJyAmJiAhaXNSZXN0b3JpbmdMaXZlVmlldykge1xuICAgICAgICBzZXR0bGVQZW5kaW5nQ29tbWl0KClcbiAgICAgICAgcmV0dXJuXG4gICAgICB9XG4gICAgICAvLyBOT1RFOiB0aGUgdW5jb25maWd1cmVkIHBhdGggcGF5cyBvbmUgYE9wdGlvbi5pc05vbmVgIGNoZWNrIGFuZFxuICAgICAgLy8gcmVuZGVycyBkaXJlY3RseSwgYWxsb2NhdGluZyBubyBwZXItZnJhbWUgY2FsbGJhY2suIE9ubHkgYVxuICAgICAgLy8gcnVudGltZSBjb25maWd1cmVkIHdpdGggYHZpZXdUcmFuc2l0aW9uYCByZWFjaGVzXG4gICAgICAvLyBgc3RhcnRGcmFtZVZpZXdUcmFuc2l0aW9uYCwgd2hpY2ggZGVjaWRlcyBwZXIgZnJhbWUgd2hldGhlciB0b1xuICAgICAgLy8gd3JhcCB0aGUgcmVuZGVyIGluIGBkb2N1bWVudC5zdGFydFZpZXdUcmFuc2l0aW9uYC4gV2hlbiBpdCBkb2VzLFxuICAgICAgLy8gdGhlIHJlbmRlciBydW5zIGxhdGVyLCBpbnNpZGUgdGhlIHRyYW5zaXRpb24ncyB1cGRhdGUgY2FsbGJhY2suXG4gICAgICBpZiAoT3B0aW9uLmlzTm9uZShtYXliZVJlc29sdmVkVmlld1RyYW5zaXRpb24pKSB7XG4gICAgICAgIHJ1blJlbmRlckZyYW1lQm9keSgpXG4gICAgICAgIGFybU5leHRSZW5kZXJGcmFtZSgpXG4gICAgICAgIHJldHVyblxuICAgICAgfVxuICAgICAgaWYgKCFzdGFydEZyYW1lVmlld1RyYW5zaXRpb24obWF5YmVSZXNvbHZlZFZpZXdUcmFuc2l0aW9uLnZhbHVlKSkge1xuICAgICAgICBydW5SZW5kZXJGcmFtZUJvZHkoKVxuICAgICAgfVxuICAgICAgYXJtTmV4dFJlbmRlckZyYW1lKClcbiAgICB9XG5cbiAgICAvLyBOT1RFOiByZXF1ZXN0aW5nIGZyb20gYSB0YXNrIGFmdGVyIHRoaXMgZnJhbWUgcGxhY2VzIHRoZSByZW5kZXIgYWZ0ZXJcbiAgICAvLyB0aGUgbmV4dCB0aWNrIHRoYXQgYW4gYW5pbWF0aW9uLWZyYW1lIFN1YnNjcmlwdGlvbiBhbHJlYWR5IHJlcXVlc3RlZC5cbiAgICAvLyBBbiB1bmNoYW5nZWQgZnJhbWUgcmV0dXJucyB3aXRob3V0IGFybWluZyBhbm90aGVyIGNhbGxiYWNrLlxuICAgIGNvbnN0IGFybU5leHRSZW5kZXJGcmFtZSA9ICgpOiB2b2lkID0+IHtcbiAgICAgIGlmIChzdGF0dXMuaXNSdW50aW1lRGlzcG9zZWQgfHwgc3RhdHVzLmlzQ3Jhc2hlZCkge1xuICAgICAgICByZXR1cm5cbiAgICAgIH1cblxuICAgICAgaWYgKG1heWJlQXJtUmVuZGVyRnJhbWVDaGFubmVsID09PSBudWxsKSB7XG4gICAgICAgIG1heWJlQXJtUmVuZGVyRnJhbWVDaGFubmVsID0gbmV3IE1lc3NhZ2VDaGFubmVsKClcbiAgICAgICAgbWF5YmVBcm1SZW5kZXJGcmFtZUNoYW5uZWwucG9ydDIub25tZXNzYWdlID0gKCkgPT4ge1xuICAgICAgICAgIGlmIChcbiAgICAgICAgICAgIGlzUmVuZGVyRnJhbWVBcm1lZCB8fFxuICAgICAgICAgICAgaXNSZW5kZXJGcmFtZVNjaGVkdWxlZCB8fFxuICAgICAgICAgICAgc3RhdHVzLmlzUnVudGltZURpc3Bvc2VkIHx8XG4gICAgICAgICAgICBzdGF0dXMuaXNDcmFzaGVkXG4gICAgICAgICAgKSB7XG4gICAgICAgICAgICByZXR1cm5cbiAgICAgICAgICB9XG5cbiAgICAgICAgICBpc1JlbmRlckZyYW1lQXJtZWQgPSB0cnVlXG4gICAgICAgICAgcmVxdWVzdEFuaW1hdGlvbkZyYW1lKHJlbmRlckZyYW1lUGxhaW4pXG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgbWF5YmVBcm1SZW5kZXJGcmFtZUNoYW5uZWwucG9ydDEucG9zdE1lc3NhZ2UobnVsbClcbiAgICB9XG5cbiAgICAvLyBOT1RFOiByZW5kZXIgZnJhbWVzIHJ1biBhcyBwbGFpbiBKYXZhU2NyaXB0IGluc2lkZSB0aGVcbiAgICAvLyByZXF1ZXN0QW5pbWF0aW9uRnJhbWUgY2FsbGJhY2suIE1lc3NhZ2VzIGFycml2aW5nIGJldHdlZW4gZnJhbWVzIG1hcmtcbiAgICAvLyBhdCBtb3N0IG9uZSBwZW5kaW5nIGZyYW1lOyB0aGUgY2FsbGJhY2sgcmVuZGVycyBvbmNlIHdpdGggdGhlIGxhdGVzdFxuICAgIC8vIG1vZGVsLlxuICAgIGNvbnN0IHNjaGVkdWxlUmVuZGVyRnJhbWUgPSAoXG4gICAgICBpc1Jlc3RvcmluZ0xpdmVWaWV3OiBib29sZWFuID0gZmFsc2UsXG4gICAgKTogdm9pZCA9PiB7XG4gICAgICBpZiAoaXNSZXN0b3JpbmdMaXZlVmlldykge1xuICAgICAgICBpc0xpdmVWaWV3UmVzdG9yZVBlbmRpbmcgPSB0cnVlXG4gICAgICB9XG4gICAgICBpZiAoaXNSZW5kZXJGcmFtZVNjaGVkdWxlZCkge1xuICAgICAgICByZXR1cm5cbiAgICAgIH1cbiAgICAgIGlzUmVuZGVyRnJhbWVTY2hlZHVsZWQgPSB0cnVlXG4gICAgICBjb21taXROb3RpZmllci5tYXJrQ29tbWl0UGVuZGluZygpXG4gICAgICBpZiAoaXNSZW5kZXJGcmFtZUFybWVkKSB7XG4gICAgICAgIHJldHVyblxuICAgICAgfVxuICAgICAgcmVxdWVzdEFuaW1hdGlvbkZyYW1lKHJlbmRlckZyYW1lUGxhaW4pXG4gICAgfVxuXG4gICAgY29uc3QgZGV2VG9vbHNSZW5kZXJCcmlkZ2U6IERldlRvb2xzUmVuZGVyQnJpZGdlID0ge1xuICAgICAgLy8gTk9URTogcGFzc2VzIGBub09wRGlzcGF0Y2hgIHNvIGRlY2xhcmF0aXZlIGhhbmRsZXJzIGFuZCBNb3VudHNcbiAgICAgIC8vIGFjcXVpcmVkIGJ5IHRoZSByZXBsYXkgY2Fubm90IHJlYWNoIHRoZSBsaXZlIE1vZGVsLiBUaGVpclxuICAgICAgLy8gZmliZXJzIHN0YXkgYWxpdmUgYW5kIGNhbiBvYnNlcnZlIHZpZXctc3RhdGUgY2hhbmdlcyB3aGlsZSB0aGVcbiAgICAgIC8vIGhpc3RvcmljYWwgdmlldyBvd25zIHRoZW0uIElmIHJlc3VtZSByZXVzZXMgc3VjaCBhbiBlbGVtZW50LFxuICAgICAgLy8gT25Nb3VudCByZWxlYXNlcyB0aGUgcmVwbGF5IGFjcXVpc2l0aW9uIGJlZm9yZSBzdGFydGluZyB0aGVcbiAgICAgIC8vIGxpdmUgYWN0aW9uLiBBbHNvIGRpc2NhcmRzIG1vdW50IGV2ZW50cyBmaXJlZCBkdXJpbmcgdGhlIHJlbmRlclxuICAgICAgLy8gc28gdGhleSBkb24ndCBnZXQgYXR0cmlidXRlZCB0byB0aGUgbmV4dCB1c2VyLWluaXRpYXRlZCBkaXNwYXRjaC5cbiAgICAgIHJlbmRlclJlcGxheTogbW9kZWwgPT5cbiAgICAgICAgRWZmZWN0LmdlbihmdW5jdGlvbiogKCkge1xuICAgICAgICAgIC8qIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvY29uc2lzdGVudC10eXBlLWFzc2VydGlvbnMgKi9cbiAgICAgICAgICBjb25zdCByZXBsYXllZE1vZGVsID0gbW9kZWwgYXMgTW9kZWxcbiAgICAgICAgICBjb25zdCBwcmV2aW91c1JlbmRlcmVkTW9kZWwgPSBsYXN0UmVuZGVyZWRNb2RlbFxuICAgICAgICAgIC8vIE5PVEU6IGEgTW91bnQgc3Vydml2aW5nIGZyb20gdGhlIGxpdmUgdmlldyBtdXN0IG9ic2VydmVcbiAgICAgICAgICAvLyBQYXVzZWQgYmVmb3JlIHRoZSBoaXN0b3JpY2FsIHBhdGNoIGNhbiBleHBvc2UgZGlmZmVyZW50XG4gICAgICAgICAgLy8gRE9NLiBNb3VudHMgaW5zZXJ0ZWQgYnkgdGhhdCBwYXRjaCBjYXB0dXJlIHRoaXMgc3RhdGUgd2hlblxuICAgICAgICAgIC8vIGFjcXVpcmVkLCBzbyBhc3luY2hyb25vdXMgc2V0dXAgY2Fubm90IHNraXAgUGF1c2VkIGV2ZW4gaWZcbiAgICAgICAgICAvLyBpdCBjb25zdW1lcyB0aGUgU3RyZWFtIG9ubHkgYWZ0ZXIgdGhlIGxpdmUgdmlldyByZXR1cm5zLlxuICAgICAgICAgIHNldFZpZXdTdGF0ZSgnUGF1c2VkJylcbiAgICAgICAgICAvLyBOT1RFOiBhIHRyYW5zaXRpb24gc3RpbGwgYW5pbWF0aW5nIGJlbG9uZ3MgdG8gdGhlIGxpdmVcbiAgICAgICAgICAvLyBzdGF0ZSB0aGlzIHJlcGxheSBpcyBhYm91dCB0byBwYWludCBvdmVyLiBMZWZ0IHJ1bm5pbmcgaXRcbiAgICAgICAgICAvLyBhbmltYXRlcyBhIGRlYWQgc25hcHNob3QgYWNyb3NzIHRoZSByZXBsYXllZCBET00uXG4gICAgICAgICAgc2tpcFBlbmRpbmdWaWV3VHJhbnNpdGlvbigpXG4gICAgICAgICAgY29uc3QgcmVwbGF5UmVuZGVyRXhpdCA9IHlpZWxkKiBFZmZlY3QuZXhpdChcbiAgICAgICAgICAgIHJlbmRlcihyZXBsYXllZE1vZGVsLCBPcHRpb24ubm9uZSgpLCBub09wRGlzcGF0Y2gsICdSZXBsYXknKSxcbiAgICAgICAgICApXG4gICAgICAgICAgaWYgKEV4aXQuaXNGYWlsdXJlKHJlcGxheVJlbmRlckV4aXQpKSB7XG4gICAgICAgICAgICBkcmFpbk1vdW50RXZlbnRzKClcbiAgICAgICAgICAgIGlmIChpc1BhdXNlZE5vdygpKSB7XG4gICAgICAgICAgICAgIC8vIE5PVEU6IHRoZSBmYWlsZWQgcGF0Y2ggbWF5IGFscmVhZHkgaGF2ZSBjaGFuZ2VkIHRoZVxuICAgICAgICAgICAgICAvLyBET00uIFJlcGFpbnQgdGhlIE1vZGVsIGF0IHRoZSBzdG9yZSdzIHByZXZpb3VzIHBhdXNlZFxuICAgICAgICAgICAgICAvLyBpbmRleCBiZWZvcmUgcmV0dXJuaW5nIHRoZSBmYWlsdXJlLiBJZiB0aGF0IE1vZGVsIG5vXG4gICAgICAgICAgICAgIC8vIGxvbmdlciByZW5kZXJzIGVpdGhlciwgcmVzdW1lIHRoZSBzdG9yZSBzbyBpdHMgbm9ybWFsXG4gICAgICAgICAgICAgIC8vIGxpdmUgZnJhbWUgYmVjb21lcyB0aGUgc2luZ2xlIHJlY292ZXJ5IHBhdGguXG4gICAgICAgICAgICAgIGNvbnN0IHJvbGxiYWNrRXhpdCA9IHlpZWxkKiBFZmZlY3QuZXhpdChcbiAgICAgICAgICAgICAgICByZW5kZXIoXG4gICAgICAgICAgICAgICAgICBwcmV2aW91c1JlbmRlcmVkTW9kZWwsXG4gICAgICAgICAgICAgICAgICBPcHRpb24ubm9uZSgpLFxuICAgICAgICAgICAgICAgICAgbm9PcERpc3BhdGNoLFxuICAgICAgICAgICAgICAgICAgJ1JlcGxheScsXG4gICAgICAgICAgICAgICAgKSxcbiAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICBkcmFpbk1vdW50RXZlbnRzKClcbiAgICAgICAgICAgICAgaWYgKEV4aXQuaXNGYWlsdXJlKHJvbGxiYWNrRXhpdCkpIHtcbiAgICAgICAgICAgICAgICB5aWVsZCogcmVzdW1lRGV2VG9vbHNcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgLy8gTk9URTogYSBmYWlsZWQgZmlyc3QganVtcCBsZWF2ZXMgdGhlIHN0b3JlIGxpdmUuIEtlZXBcbiAgICAgICAgICAgICAgLy8gTW91bnRzIFBhdXNlZCB0aHJvdWdoIHRoZSByZWNvdmVyeSBwYXRjaCwgd2hpY2hcbiAgICAgICAgICAgICAgLy8gcHVibGlzaGVzIExpdmUgb25seSBhZnRlciB0aGUgbGl2ZSBET00gaXMgcmVzdG9yZWQuXG4gICAgICAgICAgICAgIHlpZWxkKiBFZmZlY3Quc3luYygoKSA9PiBzY2hlZHVsZVJlbmRlckZyYW1lKHRydWUpKVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIHlpZWxkKiBFZmZlY3QuZmFpbENhdXNlKHJlcGxheVJlbmRlckV4aXQuY2F1c2UpXG4gICAgICAgICAgfVxuICAgICAgICAgIGRyYWluTW91bnRFdmVudHMoKVxuICAgICAgICAgIC8vIE5PVEU6IGEgcmVwbGF5IHBhaW50cyBhIHBhc3QgTW9kZWwsIHNvIGl0IG93bnMgdGhlIERPTSBvblxuICAgICAgICAgIC8vIHNjcmVlbiB1bnRpbCB0aGUgbmV4dCBsaXZlIGZyYW1lLiBMZWF2aW5nXG4gICAgICAgICAgLy8gYGxhc3RSZW5kZXJlZE1vZGVsYCBvbiB0aGUgcHJlLXBhdXNlIE1vZGVsIHdvdWxkIGhhbmQgdGhlXG4gICAgICAgICAgLy8gYHZpZXdUcmFuc2l0aW9uYCBwcmVkaWNhdGUgYSBgcHJldmlvdXNNb2RlbGAgZGVzY3JpYmluZyBhXG4gICAgICAgICAgLy8gRE9NIHRoYXQgbm8gbG9uZ2VyIGV4aXN0cywgYW5kIHRoZSBmcmFtZSBgcmVzdW1lYFxuICAgICAgICAgIC8vIHNjaGVkdWxlcyB3b3VsZCBhbmltYXRlIHRoZSB3cm9uZyBkaXJlY3Rpb24gb3V0IG9mIHRoZVxuICAgICAgICAgIC8vIHdyb25nIHNuYXBzaG90LlxuICAgICAgICAgIGxhc3RSZW5kZXJlZE1vZGVsID0gcmVwbGF5ZWRNb2RlbFxuICAgICAgICAgIC8vIE5PVEU6IHRoZSBNZXNzYWdlIHRoYXQgZGlydGllZCB0aGUgcHJlLXBhdXNlIGZyYW1lIGRvZXMgbm90XG4gICAgICAgICAgLy8gZGVzY3JpYmUgdGhpcyByZXBhaW50LiBDbGVhcmluZyBpdCBtZWFucyB0aGUgZnJhbWUgYHJlc3VtZWBcbiAgICAgICAgICAvLyBzY2hlZHVsZXMgcmVuZGVycyBwbGFpbmx5LCBtYXRjaGluZyB0aGUgZG9jdW1lbnRlZCBydWxlXG4gICAgICAgICAgLy8gdGhhdCB0aW1lLXRyYXZlbCBuZXZlciBhbmltYXRlcy5cbiAgICAgICAgICBtYXliZUxhc3REaXJ0eU1lc3NhZ2UgPSBPcHRpb24ubm9uZSgpXG4gICAgICAgIH0pLFxuICAgICAgLy8gTk9URTogYHJlc3VtZWAgY2FsbHMgdGhpcyBhZnRlciBhIGp1bXBUbyByZW5kZXIgYXR0YWNoZWQgRE9NXG4gICAgICAvLyBsaXN0ZW5lcnMgdG8gYG5vT3BEaXNwYXRjaGAuIFNjaGVkdWxpbmcgYSBmcmFtZSByZW5kZXJzIHRoZVxuICAgICAgLy8gbGl2ZSBtb2RlbCB3aXRoIGxpdmUgZGlzcGF0Y2ggYW5kIHJlYmluZHMgbGlzdGVuZXJzLlxuICAgICAgbWFya1JlbmRlclBlbmRpbmc6IEVmZmVjdC5zeW5jKCgpID0+IHNjaGVkdWxlUmVuZGVyRnJhbWUodHJ1ZSkpLFxuICAgIH1cblxuICAgIHJldHVybiB7XG4gICAgICBjcmFzaFdpdGgsXG4gICAgICByZW5kZXIsXG4gICAgICBzZXRMYXN0RGlydHlNZXNzYWdlLFxuICAgICAgc2NoZWR1bGVSZW5kZXJGcmFtZSxcbiAgICAgIHNraXBQZW5kaW5nVmlld1RyYW5zaXRpb24sXG4gICAgICBkZXZUb29sc1JlbmRlckJyaWRnZSxcbiAgICB9XG4gIH0pXG4iXX0=