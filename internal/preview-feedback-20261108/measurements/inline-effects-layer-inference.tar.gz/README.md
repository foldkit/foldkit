# Inline EffectsLayer inference comparison

This packet freezes one TypeScript 7 source-check comparison for Foldkit's
ordinary record-form `Block.makeLayer` completion.

The two fixtures are byte-identical except for the local handler Layer:

- `fixtures/inline-effects-layer.rejected.ts` keeps
  `EffectsLayer: Layer.merge(RecordBefore.layer, RecordAfter.layer)` inline.
- `fixtures/named-effects-layer.accepted.ts` binds that same expression to
  `const EffectsLayer` and uses the shorthand property.

Init and update remain inline in both fixtures. There are no annotations,
explicit generics, casts, custom Effect constructors, validator changes or
runtime implementation changes.

## Exact result

The checker copied the authenticated package source to a temporary directory,
substituted each frozen fixture at its original package path, and invoked the
same TypeScript 7.1.0-beta compiler with the package's unchanged source
configuration.

- Inline: exit 2. The primary diagnostic is TS2769 at the record-form
  `makeLayer` call. The later Story diagnostic is a cascade from the rejected
  Layer.
- Named EffectsLayer: exit 0 with empty stdout and stderr.

`run-receipt.json` records statuses and log hashes. `input-receipt.json`
records Node, compiler, configuration, fixture and source identities.
`source-files.sha256` authenticates all 662 package source inputs other than
the substituted fixture itself.

The first two checker preparations did not reach a valid comparison because
the temporary package was missing, respectively, its package-local
`node_modules` resolution and its ESM package metadata. Their raw outputs are
retained under `setup-failure-*`; neither is presented as compiler evidence.

## Reproduction

From the authenticated repository source on the original host:

```sh
/Users/devinjameson/.vite-plus/js_runtime/node/26.13.0/bin/node \
  /private/tmp/foldkit-inline-effects-layer-inference-20261108/check.mjs \
  /Users/devinjameson/.codex/worktrees/block-completion-record/foldkit-unified-recovery-20261103
```

The checker validates its inputs before compiling, writes both variants'
stdout, stderr and statuses under `results/`, checks the expected
accepted/rejected boundary, and removes its temporary source copy.

## Scope

This is one source-check comparison on the frozen Foldkit source and compiler.
It does not establish a universal TypeScript rule, runtime behavior or
performance result.
