import { spawnSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import {
  cpSync,
  mkdtempSync,
  mkdirSync,
  readFileSync,
  rmSync,
  symlinkSync,
  writeFileSync,
} from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const packetRoot = path.dirname(fileURLToPath(import.meta.url))
const repoRoot = process.argv[2]
if (!repoRoot) throw new Error('usage: node check.mjs <repo-root>')

const receipt = JSON.parse(
  readFileSync(path.join(packetRoot, 'input-receipt.json'), 'utf8'),
)
const sha256 = file =>
  createHash('sha256').update(readFileSync(file)).digest('hex')
const verifyHash = (file, expected) => {
  const actual = sha256(file)
  if (actual !== expected) {
    throw new Error(`hash mismatch for ${file}: ${actual} !== ${expected}`)
  }
}

verifyHash(receipt.node.executable, receipt.node.sha256)
verifyHash(
  path.join(repoRoot, receipt.compiler.entry),
  receipt.compiler.sha256,
)
for (const [file, expected] of Object.entries(receipt.configs)) {
  verifyHash(path.join(repoRoot, file), expected)
}
for (const fixture of Object.values(receipt.fixtures)) {
  verifyHash(path.join(packetRoot, fixture.path), fixture.sha256)
}
for (const line of readFileSync(
  path.join(packetRoot, receipt.sourceManifest.path),
  'utf8',
).trim().split('\n')) {
  const [expected, file] = line.split('  ')
  verifyHash(path.join(repoRoot, file), expected)
}

const workRoot = mkdtempSync(path.join(os.tmpdir(), 'foldkit-layer-inference-'))
const results = {}
try {
  mkdirSync(path.join(workRoot, 'packages/foldkit'), { recursive: true })
  cpSync(
    path.join(repoRoot, 'packages/foldkit/src'),
    path.join(workRoot, 'packages/foldkit/src'),
    { recursive: true },
  )
  for (const file of [
    'tsconfig.base.json',
    'package.json',
    'packages/foldkit/package.json',
    'packages/foldkit/tsconfig.json',
    'packages/foldkit/tsconfig.base.json',
  ]) {
    const destination = path.join(workRoot, file)
    mkdirSync(path.dirname(destination), { recursive: true })
    cpSync(path.join(repoRoot, file), destination)
  }
  symlinkSync(path.join(repoRoot, 'node_modules'), path.join(workRoot, 'node_modules'))
  symlinkSync(
    path.join(repoRoot, 'packages/foldkit/node_modules'),
    path.join(workRoot, 'packages/foldkit/node_modules'),
  )

  for (const [name, fixture] of Object.entries(receipt.fixtures)) {
    cpSync(
      path.join(packetRoot, fixture.path),
      path.join(workRoot, receipt.relativeTarget),
    )
    const startedAt = new Date().toISOString()
    const result = spawnSync(
      receipt.node.executable,
      [
        path.join(repoRoot, receipt.compiler.entry),
        '-p',
        path.join(workRoot, 'packages/foldkit/tsconfig.json'),
        '--noEmit',
        '--pretty',
        'false',
      ],
      {
        cwd: workRoot,
        encoding: 'utf8',
        maxBuffer: 16 * 1024 * 1024,
      },
    )
    const status = result.status ?? 1
    const stdout = result.stdout ?? ''
    const stderr = result.stderr ?? ''
    writeFileSync(path.join(packetRoot, `results/${name}.stdout.log`), stdout)
    writeFileSync(path.join(packetRoot, `results/${name}.stderr.log`), stderr)
    writeFileSync(path.join(packetRoot, `results/${name}.status.txt`), `${status}\n`)
    results[name] = {
      startedAt,
      finishedAt: new Date().toISOString(),
      status,
      stdoutBytes: Buffer.byteLength(stdout),
      stdoutSha256: createHash('sha256').update(stdout).digest('hex'),
      stderrBytes: Buffer.byteLength(stderr),
      stderrSha256: createHash('sha256').update(stderr).digest('hex'),
    }
  }
} finally {
  rmSync(workRoot, { recursive: true, force: true })
}

const accepted =
  results.named.status === 0 &&
  results.named.stdoutBytes === 0 &&
  results.named.stderrBytes === 0
const rejected =
  results.inline.status !== 0 &&
  readFileSync(path.join(packetRoot, 'results/inline.stdout.log'), 'utf8')
    .includes('connectedComposition.test.ts') &&
  readFileSync(path.join(packetRoot, 'results/inline.stdout.log'), 'utf8')
    .includes('No overload matches this call')
if (!accepted || !rejected) {
  throw new Error(
    `unexpected comparison: named accepted=${accepted}, inline rejected=${rejected}`,
  )
}

writeFileSync(
  path.join(packetRoot, 'run-receipt.json'),
  `${JSON.stringify({
    schemaVersion: 1,
    status: 'pass',
    comparison: {
      namedEffectsLayer: 'accepted',
      inlineEffectsLayer: 'rejected',
    },
    results,
  }, null, 2)}\n`,
)
