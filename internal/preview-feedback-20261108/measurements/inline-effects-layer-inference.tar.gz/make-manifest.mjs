import { createHash } from 'node:crypto'
import {
  readdirSync,
  readFileSync,
  writeFileSync,
} from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const root = path.dirname(fileURLToPath(import.meta.url))
const output = 'final-files.sha256'
const files = []
const visit = directory => {
  for (const entry of readdirSync(directory, { withFileTypes: true })) {
    const resolved = path.join(directory, entry.name)
    const relative = path.relative(root, resolved)
    if (relative === output) continue
    if (entry.isDirectory()) visit(resolved)
    else if (entry.isFile()) files.push(relative)
  }
}
visit(root)
files.sort()
const manifest = files.map(file => {
  const hash = createHash('sha256')
    .update(readFileSync(path.join(root, file)))
    .digest('hex')
  return `${hash}  ${file}`
})
writeFileSync(path.join(root, output), `${manifest.join('\n')}\n`)
