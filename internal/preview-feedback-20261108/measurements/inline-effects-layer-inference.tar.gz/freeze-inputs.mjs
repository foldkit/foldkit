import { execFileSync } from 'node:child_process'
import {
  createHash,
} from 'node:crypto'
import {
  readdirSync,
  readFileSync,
  statSync,
  writeFileSync,
} from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const packetRoot = path.dirname(fileURLToPath(import.meta.url))
const repoRoot = process.argv[2]
if (!repoRoot) throw new Error('usage: node freeze-inputs.mjs <repo-root>')

const relativeTarget =
  'packages/foldkit/src/update/connectedComposition.test.ts'
const nodeExecutable =
  '/Users/devinjameson/.vite-plus/js_runtime/node/26.13.0/bin/node'
const tscEntry =
  'node_modules/.pnpm/typescript@7.1.0-beta/node_modules/typescript/bin/tsc'
const compilerRuntimeFiles = [
  'node_modules/.pnpm/typescript@7.1.0-beta/node_modules/typescript/lib/tsc.js',
  'node_modules/.pnpm/typescript@7.1.0-beta/node_modules/typescript/lib/getExePath.js',
  'node_modules/.pnpm/typescript@7.1.0-beta/node_modules/typescript/package.json',
  'node_modules/.pnpm/@typescript+typescript-darwin-arm64@7.1.0-beta/node_modules/@typescript/typescript-darwin-arm64/lib/tsc',
  'node_modules/.pnpm/@typescript+typescript-darwin-arm64@7.1.0-beta/node_modules/@typescript/typescript-darwin-arm64/package.json',
]

const sha256 = file =>
  createHash('sha256').update(readFileSync(file)).digest('hex')

const filesUnder = directory => {
  const files = []
  const visit = current => {
    for (const entry of readdirSync(current, { withFileTypes: true })) {
      const resolved = path.join(current, entry.name)
      if (entry.isDirectory()) visit(resolved)
      else if (entry.isFile()) files.push(resolved)
    }
  }
  visit(directory)
  return files
}

const sourceFiles = filesUnder(path.join(repoRoot, 'packages/foldkit/src'))
  .map(file => path.relative(repoRoot, file))
  .filter(file => file !== relativeTarget)
  .sort()
const sourceManifest = sourceFiles
  .map(file => `${sha256(path.join(repoRoot, file))}  ${file}`)
  .join('\n')
writeFileSync(
  path.join(packetRoot, 'source-files.sha256'),
  `${sourceManifest}\n`,
)

const command = (...args) =>
  execFileSync(args[0], args.slice(1), {
    cwd: repoRoot,
    encoding: 'utf8',
  }).trim()

const fixtures = {
  inline: 'fixtures/inline-effects-layer.rejected.ts',
  named: 'fixtures/named-effects-layer.accepted.ts',
}
const receipt = {
  schemaVersion: 1,
  observedHead: command('git', 'rev-parse', 'HEAD'),
  observedHeadTree: command('git', 'rev-parse', 'HEAD^{tree}'),
  relativeTarget,
  node: {
    executable: nodeExecutable,
    sha256: sha256(nodeExecutable),
    version: command(nodeExecutable, '--version'),
  },
  compiler: {
    entry: tscEntry,
    sha256: sha256(path.join(repoRoot, tscEntry)),
    version: command(nodeExecutable, path.join(repoRoot, tscEntry), '--version'),
    runtimeFiles: Object.fromEntries(
      compilerRuntimeFiles.map(file => [
        file,
        sha256(path.join(repoRoot, file)),
      ]),
    ),
  },
  configs: Object.fromEntries(
    [
      'tsconfig.base.json',
      'packages/foldkit/tsconfig.json',
      'packages/foldkit/tsconfig.base.json',
      'packages/foldkit/package.json',
      'package.json',
      'pnpm-lock.yaml',
    ].map(file => [file, sha256(path.join(repoRoot, file))]),
  ),
  fixtures: Object.fromEntries(
    Object.entries(fixtures).map(([name, file]) => [
      name,
      {
        path: file,
        bytes: statSync(path.join(packetRoot, file)).size,
        sha256: sha256(path.join(packetRoot, file)),
      },
    ]),
  ),
  sourceManifest: {
    path: 'source-files.sha256',
    entries: sourceFiles.length,
  },
}
writeFileSync(
  path.join(packetRoot, 'input-receipt.json'),
  `${JSON.stringify(receipt, null, 2)}\n`,
)
