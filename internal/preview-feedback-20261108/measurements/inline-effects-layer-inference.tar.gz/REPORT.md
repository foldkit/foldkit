# Recommendation

Keep the public runtime regression in ordinary record-completion form and name
its local `EffectsLayer`. That single organization change is sufficient for
the frozen TypeScript 7 source check; whole-body staging is not required.

Do not change automatic child acquisition, weaken validators, add casts or
replace the record with a custom Effect constructor for this fixture.

## Tested encodings

The final frozen comparison directly executes these two encodings:

| Encoding | Result |
| --- | --- |
| Init inline, update inline, `Layer.merge` inline | Rejected at `makeLayer` |
| Init inline, update inline, named `EffectsLayer` | Accepted |

Earlier bounded in-memory probes on the same source also tested the following
organization variants:

| Named values | Result |
| --- | --- |
| Init only | Rejected |
| Update only | Rejected |
| Init and update | Rejected |
| EffectsLayer only | Accepted |
| Init and EffectsLayer | Accepted |
| Update and EffectsLayer | Accepted |
| Init, update and EffectsLayer | Accepted |
| Whole implementation record | Accepted |

Those exploratory variants locate the boundary but are not relabeled as final
frozen compiler runs. The final packet intentionally retains only the smallest
inline-versus-named comparison.

The result is specific to the authenticated source/compiler/input combination.
It is evidence of a contextual/dependent-validation inference boundary in this
fixture, not a claim that naming an EffectsLayer is necessary or sufficient
for every TypeScript program.
