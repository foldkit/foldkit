# Transient Effect lint channel warning

## Scope and outcome

The normal push gate for HTML-definition commit
`977b57321fe1b402a3ce38b97178481e1321c56a` stopped once during the broad
Effect lint invocation. `effecttsgo(any-unknown-in-error-context)` reported
that both the error and requirements channels of the `Story.withBlock` call in
`packages/foldkit/declaration-tests/update-composition/consume.ts:13` were
`any`.

The warning is not reproducible and does not describe the real source or
emitted contract. No source, declaration fixture, lint configuration, or
generated package output was changed in response.

Exact retained logs:

- Failed push log:
  `/private/tmp/foldkit-html-diagnostics-push-effect-lint-warning.log`
- Unchanged full broad-control log (exit 0, intentionally empty):
  `/private/tmp/foldkit-effect-lint-full-control.log`
- Focused channel-control log (exit 0, intentionally empty):
  `/private/tmp/foldkit-effect-lint-channel-control.log`

The failed command was the repository's unchanged Effect lint command:

```text
effect-tsgo patch --no-typescript --oxlint && oxlint --config .oxlintrc.effect.json --disable-nested-config --deny-warnings packages examples scripts
```

It emitted two warnings at columns 30 and 14 on line 13, then stopped the push
before any remote update.

## Exact channel evidence

Independent TypeScript inspection in both supported modes found:

```text
typeof acquiredCalls = Effect.Effect<string, never, never>
Success = string
Error = never
Services = never
```

The dedicated source-path project
`packages/foldkit/declaration-tests/tsconfig.update-composition.source.json`
had 15 roots, 454 program files, and zero diagnostics. A matching package-dist
program with the source `paths` mapping removed had 15 roots, 428 program
files, and zero diagnostics. Temporary checks through the package-default
resolution also passed and were removed in `finally`; they proved Success is
exactly `string`, Error and Services are exactly `never`, and neither channel
matches the standard `0 extends 1 & T` `IsAny` test.

The existing fixture's `NoExtraServices` assertion remains unchanged.

## Declaration identity

The declarations that determine `Story.withBlock`, selected Block facts, and
Layer channels are byte-identical to the prior `3f0a41b927` baseline:

| Declaration | SHA-256 |
| --- | --- |
| `dist/experimental/layered/testing/withBlock.d.ts` | `4333d3c81c55cc0d360bd5fca76427cb1bd788d91f2484820368632088214c84` |
| `dist/story/public.d.ts` | `48f48f0400cff8cd8d6eff2b3b6d5f10ccb2a143b4473b7d860a40a95df7944c` |
| `dist/runtime/rootBlock.d.ts` | `b8a32c597a0f2f214ccf2ee8a3fd074c2d306ac8c056eb007dc9be8903793fea` |
| `dist/experimental/constructed/contract.d.ts` | `7ec40d11bbaca57002d3863028b86cf9ddecf4e17ea7ebc75a433ae5023bbe3a` |
| `dist/experimental/contracted/contract.d.ts` | `56650d87efaee09cc164310fabe223694e2ebcc7488bca98f8e2880d88800a4a` |

The HTML declaration changed only in one private emitted binding: the old
`Data.taggedEnum` destructure named every ordinary Attribute constructor,
whereas the candidate retains only raw `Prop` and `OnCustomEvent`. The current
file is 3,535 bytes smaller, not broader:

| HTML declaration | Bytes | SHA-256 |
| --- | ---: | --- |
| `3f0a41b927` baseline `dist/html/index.d.ts` | 104,141 | `a0a9c395a8e1228a33dcb38c6844d3672690f088078eda2f6484b6a08c26335d` |
| current candidate `dist/html/index.d.ts` | 100,606 | `bc4e64d169e78b5affc1b896e56d8c8ed0c8806553fed8ff401403660cdd6004` |

No relevant public Story, Block, Layer, or Effect signature changed.

## Reproduction matrix

All controls below exited 0 with no diagnostics after the single failed push:

| Control | Project/thread characteristic |
| --- | --- |
| Exact `consume.ts` Effect lint | Automatic project selection, default threads |
| Whole `update-composition` directory | Automatic project selection, default threads |
| `consume.ts` followed by `src/html/index.ts` | Two relevant file groups, default threads |
| `src/html/index.ts` followed by `consume.ts` | Reversed CLI order, default threads |
| All `packages/foldkit/declaration-tests` | Broad declaration-fixture set, default threads |
| All Foldkit declaration tests plus `src/html/index.ts` | Automatic project selection, `--threads=1` |
| Full unchanged `packages examples scripts` invocation | Same broad command as failed push, default threads |
| Dedicated update-composition source typecheck | Explicit nonstandard source project |
| Temporary package-default exact-channel assertions | Default package resolution; removed afterward |

The low-cost controls therefore did not establish file-order, HTML-source,
fixture-volume, or parallel-thread reproduction.

## Project-selection observation

`update-composition` has the nonstandard project
`tsconfig.update-composition.source.json`, but it has no conventional
`tsconfig.json`. Automatic discovery walks up to `packages/foldkit/tsconfig.json`,
whose `include` is only `src`. The broad Oxlint/tsgo invocation therefore has
to handle these declaration fixtures through fallback or inferred-project
behavior rather than automatically selecting their dedicated source project.

That is a real infrastructure fragility, but the available evidence does not
prove it caused this warning: focused automatic selection, broad automatic
selection, single-threaded selection, and an unchanged full rerun all pass.

## Supported next steps

1. Make no source or fixture change for this isolated warning. In particular,
   do not add a broad annotation or cast, weaken graph/channel checks, disable
   the rule, or special-case this call.
2. Retry the normal unchanged push gate. This is the smallest action supported
   by the current evidence.
3. If the warning recurs, retain structured diagnostics together with the
   exact lint file list, CLI order, thread count, tool versions, package-output
   hashes, and whether the same invocation immediately passes on retry.
4. Only after a stable reproduction, investigate project ownership
   systematically for declaration fixtures (for example, conventional lint
   projects or explicit batching). Do not add a one-off `tsconfig.json` merely
   to silence this fixture without proving the ownership boundary is causal.

Classification: observed non-reproducible type-aware lint warning from broad
checker state; not a demonstrated production, public API, declaration, or
source-type regression.
