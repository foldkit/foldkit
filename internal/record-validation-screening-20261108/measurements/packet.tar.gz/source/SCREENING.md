# Record-only validation screening result

## Decision

Reject the candidate before emitted-consumer expansion or language-service
timing. It is sound under the focused proof, but its compiler savings are too
small to plausibly explain or materially improve the retained multi-second
editor diagnostic cost.

No budget, public API, consumer annotation, emitted-consumer fixture, LSP
harness, or shared repository source was changed for this screening.

## Identities

- Baseline commit: `c3ffef0cedd9401359105076038b867502960ea4`
- Baseline tree: `a2d925ca9fe2dfbbc3d509647627aa9f1079c4b1`
- Candidate patch SHA-256:
  `340fe8c000ffb4f501c5291baab58cda9d63434e93ad05dd8cca81cb46310e93`
- Node executable SHA-256:
  `533bd644c5ae0e0ea3a80e433aad16b817447ccba1e1eea701875eac80cb75d4`
- TS7 CLI SHA-256:
  `2219f428a7e55aaf1f7ad85b9b0f0cf5078aeb76ccc9a7c6036c92d48f492ffd`
- Compiler version: `7.1.0-beta`

Baseline source hashes:

- constructed authoring: `5088aabcf38940ffadc819e8a5d408ecd081500bb85973584684d8c3a976716b`
- unified completion: `2409184de1e4efb8bfe55badf4be269f937b0195d8eff4578e8f3f2efd191cc9`
- family completion: `9b8e2e199ac0decbe17ff0e7474e97cc16fcae0e248238a0004d887c42395291`

Candidate source hashes:

- constructed authoring: `f70b015f53132c6fbe8bf40427dc324f544fe99eb09002f55d4693b755e3ce8b`
- unified completion: `1363af4d17195ab33e5b0f18a4dcc49052ddbff5f2f818b844138f4ca7e7ea93`
- family completion: `10fdff0b4a99d991005dba7185b7c23525947d6d4b914562c1efd49c97d4011a`

## Private build and resolution gate

Both trees started without `packages/foldkit/dist` and built their own package
output from their own local `packages/foldkit/src`. Their `node_modules` links
point only to the shared installed dependency graph; neither build read the
shared root's Foldkit `dist` as its package source.

Each build emitted 1,167 files. The full manifests differ only in these six
expected type artifacts:

- `experimental/constructed/authoring.d.ts` and its map;
- `experimental/contracted/unified.d.ts` and its map;
- `experimental/contracted/familyLayer.d.ts` and its map.

Every emitted JavaScript file is byte-identical. Baseline manifest SHA-256 is
`84e924513ab5df4e0a6d0b28f135105b867e6d9413d43ef70f3a2b33edf7c724`;
candidate manifest SHA-256 is
`6e2d282112df8687c7acd760f3f8dd1e64010741c5a89b9dff37449d8c09be48`.

No UI package or Website declaration graph was used as candidate evidence.
Because the candidate failed the counter screening gate, no source-free
emitted proof was attempted and no claim is made about mixed package/UI
resolution.

## Nine unchanged compiler workloads

Both runs passed all existing ceilings. Seven workloads were byte-for-byte
identical in their reported instantiation, type, and symbol counts. The only
differences were:

| Workload | Baseline instantiations | Candidate instantiations | Baseline types | Candidate types | Baseline symbols | Candidate symbols |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| machine-search | 69,291 | 69,291 | 12,994 | 12,994 | 43,820 | 43,821 |
| layered-composition-6 | 2,706,693 | 2,704,948 | 336,346 | 336,342 | 238,978 | 238,975 |

The relevant layered workload saves 1,745 instantiations, or about 0.064% of
its baseline, and four types, or about 0.001%. `machine-search` gains one
symbol. This is negligible relative to duplicate-control uncertainty and the
observed multi-second editor path. It does not justify the cost or risk of
further emitted/LSP experiments.

Counter logs:

- baseline SHA-256:
  `f0e5aa94e947b18591e95eb5dcced83fd1614eeab6cf4a026773c5508ea9c14d`
- candidate SHA-256:
  `af735801911054497f5f017cc469f761257b72bef6e5edd6b8d51c39a4f8e0e1`

## Proof boundary

The focused source-alias fixture and 20 runtime tests passed before screening.
Those checks establish the candidate's bounded semantic plausibility; they do
not turn the negligible compiler delta into editor evidence. The two malformed
widened-Binding controls remain retained and labeled as setup failures because
public Composition validation rejected them before record completion.

The next useful investigation is not a broader version of this candidate. It
is the already-proposed per-child or cumulative child-Layer discriminating
probe, which can identify which realistic imported Layer declaration actually
drives graph expansion before another type-only experiment is selected.
