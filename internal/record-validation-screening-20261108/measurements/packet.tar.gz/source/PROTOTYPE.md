# Record-only completion validation prototype

## Provenance and scope

- Baseline commit: `c3ffef0cedd9401359105076038b867502960ea4`
- Baseline tree: `a2d925ca9fe2dfbbc3d509647627aa9f1079c4b1`
- Baseline copy: `/private/tmp/foldkit-record-validation-prototype-baseline-20261108`
- Candidate copy: `/private/tmp/foldkit-record-validation-prototype-20261108`
- Source diff: `prototype.patch`
- Shared repository changes: none

This spike changes only the validation selected by the three record completion
overloads: ordinary `Block.makeLayer`, family `makeLayer`, and the resolved
family provider. Their custom Effect constructor overloads remain on the
original validation path. No public package export, consumer annotation,
runtime implementation, requirement ceiling, or framework error is changed.

The focused source-alias fixture and two narrow runtime files have now run.
No formatter, build, emitted-declaration check, compiler-performance gate,
language-service measurement, or benchmark command has run in this spike.

## Checked invariant

Record completion rejects authored `children`, obtains the exact init
Composition through `planComposition`, and calls `acquireCompositionChildren`
with that Composition's registered Bindings. Each registered Binding's
`construct` returns an `ExecutableConnection<Contract, Placement>`. The
Binding's public `connect` overload used by `AcquiredConstructorBody` has that
same `ExecutableConnection<Contract, Placement>` as its compact return type.
The runtime also rejects non-original Binding constructors and non-Effect or
non-object acquisition results.

Therefore, for an exact record-only Binding inventory,
`InvalidConnections<Body>` compares a child array that Foldkit itself generated
from the same `connect` return types. The candidate omits only that repeated
identity comparison. It retains:

- plan source and graph validation;
- canonical Block owner, Model Schema, Message Schema, and OutMessage Schema;
- `MissingConnections<Body>` placement coverage;
- Binding policy, placement, host handler, local Mount, operations, handler,
  Error, and Service validation through `ImplementationRecipeValidation`;
- the full original missing/invalid connection validation for custom Effect
  constructors.

Keeping `MissingConnections` is necessary. `BindingsFromSpecs` deliberately has
a fallback for a Binding inventory widened to `AnyBinding & BindingParent`.
That broad type retains a placement string but not exact `connect`, constructor,
or iterator Error/Service evidence. `AcquiredConstructorBody` consequently
would produce `never[]`; the missing-placement comparison remains the final
record guard. The ordinary public authoring path currently rejects that broad
inventory earlier because its policy evidence is unavailable, and the fixture
records that reachable upstream rejection without unreachable later calls.

The remaining soundness boundary would fail if record completion ever accepted
an authored or transformed child array, if `construct` stopped returning the
same connection contract declared by `connect`, or if arbitrary Bindings could
enter the registered source without the existing original-constructor runtime
checks. Those conditions are currently checked in source; this optimization
must be revisited if any of them changes.

## Candidate patch

1. Factor the existing completion-channel validation tail into
   `ValidateConstructorImplementation` without changing it.
2. Add internal `ValidateRecord`, which preserves the original union,
   plan-source, canonical-contract, missing-placement, and implementation
   validation but omits the generated connection-identity comparison.
3. Select `ValidateRecord` only from the three record overloads after
   `AcquiredConstructorBody<Record>` has generated its child type.
4. Retain the actual upstream Composition rejection for a widened Binding
   inventory, and add declaration controls proving that custom Effect
   constructors still reject both missing registered children and a foreign
   same-Model child.
5. Add exact Error and Service equality checks between the generated-record
   and manual-Effect paths.

Existing record-completion fixtures already reject authored `children`,
`bindings`, and `operations`; foreign Block plans; crossed graphs and views;
wrong host-handler owners; and invalid Error/Service channels. They also cover
imported, inline, local, conditional, view-bearing, family, and family-provider
positive records. The same emitted suite retains provider-union, graph, host,
and published-Mount negative cases around the unchanged outer validators.

## Proof plan after an explicit slot grant

Use the repository's installed dependencies through private spike-local links,
then record the exact executable and compiler hashes before running anything.

1. Run the focused TS7 source fixture:

   ```sh
   /Users/devinjameson/.vite-plus/js_runtime/node/26.13.0/bin/node packages/foldkit/node_modules/typescript/bin/tsc -p packages/foldkit/declaration-tests/tsconfig.record-completion.source.json
   ```

2. Run the focused runtime suites for generated acquisition and record
   completion:

   ```sh
   cd packages/foldkit
   /Users/devinjameson/.vite-plus/js_runtime/node/26.13.0/bin/node node_modules/vitest/vitest.mjs run --config vitest.config.ts src/experimental/contracted/recordCompletion.test.ts src/experimental/contracted/acquireChildren.test.ts
   ```

3. Run two source-fixture mutation controls:

   - temporarily route the custom Effect overload through `ValidateRecord`;
     the foreign-child `@ts-expect-error` directive must become unused while
     the missing-child directive remains enforced;
   - temporarily remove the canonical-contract comparison from
     `ValidateRecord` and reveal the foreign-Block diagnostic. The call remains
     rejected through another unchanged validation boundary, demonstrating
     redundant owner protection rather than an isolating mutation.

   Restore the candidate bytes and rerun the focused source fixture.

4. Build only the private Foldkit package, then run the existing emitted and
   relocated declaration checker. Its `record-completion` case must pass source
   acceptance, rejected wiring, external emission, and relocated TS7/TS6
   consumption. Preserve the candidate declaration diff and verify that no new
   package subpath export was added.

5. Run all nine unchanged Block type-performance fixtures. Reject the
   candidate if any existing ceiling changes require relaxation. Record exact
   baseline/candidate instantiation, type, and symbol counts rather than only a
   pass/fail result.

6. Only in a separately granted quiet window, compare exact-commit baseline
   and candidate emitted-package language-service runs with the repaired strict
   semantic guards. Use the real Website Layer source and at least
   `root-inputs`, `child-layers`, `unprovided`, and `full`; retain source hashes,
   executable hashes, diagnostics, memory, and cleanup. Do not relabel a source
   alias run as package-declaration evidence.

7. Before interpreting an aggregate result, add read-only one-child-at-a-time
   or cumulative child-Layer controls for the twelve realistic Website child
   Layers. The retained profile shows broad relation/allocation work, not that
   this specific comparison is dominant. Adopt only if the candidate produces
   a repeatable reduction beyond duplicate-control spread while all semantic
   and compiler controls remain exact.

## Evidence limit

The retained profiles justify this as the smallest prospective experiment, not
as an established optimization. `child-layers` was much slower than
`root-inputs`, but the profile does not isolate `MissingConnections` or
`InvalidConnections`, and prior named completion projection work produced only
negligible compiler-count changes. A null or noisy A/B result should reject this
candidate and move to the per-child discriminating probe rather than widening
the special case.

## Focused proof result

- The TS7 source-alias record-completion fixture passes after narrowing the
  erased-Binding case to its real upstream `makeComposition` rejection.
- `recordCompletion.test.ts` and `acquireChildren.test.ts` pass: 2 files,
  20 tests.
- Routing the ordinary custom Effect overload through `ValidateRecord` makes
  only the foreign-child rejection directive unused; the missing-child control
  remains enforced. The candidate byte was restored.
- Removing `ValidateRecord`'s canonical-contract comparison does not admit the
  foreign record; revealing the directive shows the call is still rejected as
  `never` through another unchanged boundary. The candidate byte was restored.
- Both malformed widened-record setup attempts are preserved separately. They
  were rejected earlier by Composition Message/policy/init validation and are
  not evidence against the record candidate.
