# Record validation screening evidence

This packet preserves a bounded, rejected type-performance experiment against
Foldkit commit `c3ffef0cedd9401359105076038b867502960ea4` (tree
`a2d925ca9fe2dfbbc3d509647627aa9f1079c4b1`). It is repository-ready for
`internal/record-validation-screening-20261108` but has not been copied into the
repository.

Start with `report.md`. Reproduction commands and source/link caveats are in
`REPRODUCE.md`; exact identities are in `receipt.json`. `files.sha256`
authenticates every payload file except itself.

The conclusion is rejection: retaining `MissingConnections` while skipping
only record-generated `InvalidConnections` saved 1,745 instantiations and four
Types in the relevant layered workload. That is negligible. No emitted or
relocated consumer proof and no language-service measurement was run or is
claimed.

The two widened-Binding attempts under `controls/` are retained as malformed
control setup failures. Public Composition validation rejected both before
record completion. They do not establish a reachable public unsoundness.

