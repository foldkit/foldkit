# Reproduction

## Verify the packet

From the extracted packet root:

```sh
shasum -a 256 -c files.sha256
gzip -dc declarations/dist-baseline.sha256.gz | shasum -a 256
gzip -dc declarations/dist-candidate.sha256.gz | shasum -a 256
```

The decompressed hashes must match `receipt.json`. Paths inside the compressed
manifests are repository-relative (`packages/foldkit/dist/...`), so they remain
valid after extraction even though the original private workspaces had absolute
paths under `/private/tmp`.

## Recreate the two source trees

```sh
git archive c3ffef0cedd9401359105076038b867502960ea4 | tar -x -C BASELINE
cp -R BASELINE/. CANDIDATE/
patch -d CANDIDATE -p4 < source/prototype.patch
```

`prototype.patch` was produced by a recursive diff whose labels contain the
original absolute private paths. `-p4` removes the leading path plus
`private/tmp/<workspace-name>` and applies repository-relative paths. The
original packet path was
`/private/tmp/foldkit-record-validation-screening-repository-20261108`; after
copy or extraction, run every verification command from the new packet root.
Verify the resulting source hashes in `receipt.json` before running checks.

Provide each tree with the same pinned installed dependency graph. Do not use a
shared Foldkit `dist` as evidence. The original spike used read-only links to
the repository's installed `node_modules`, then built each tree's own
`packages/foldkit/dist` from an initially absent directory.

## Focused checks

Run from the candidate root with Node SHA-256
`533bd644c5ae0e0ea3a80e433aad16b817447ccba1e1eea701875eac80cb75d4`
and TS7 CLI SHA-256
`2219f428a7e55aaf1f7ad85b9b0f0cf5078aeb76ccc9a7c6036c92d48f492ffd`:

```sh
NODE packages/foldkit/node_modules/typescript/bin/tsc \
  -p packages/foldkit/declaration-tests/tsconfig.record-completion.source.json

cd packages/foldkit
NODE node_modules/vitest/vitest.mjs run --config vitest.config.ts \
  src/experimental/contracted/recordCompletion.test.ts \
  src/experimental/contracted/acquireChildren.test.ts
```

The first command is intentionally a source-alias fixture.

## Build and counters

Build each tree separately:

```sh
NODE packages/foldkit/node_modules/typescript/bin/tsc \
  -b packages/foldkit/tsconfig.build.json
```

Then run in each tree:

```sh
NODE packages/foldkit/scripts/check-block-type-performance.ts
```

Compare the complete output to `compiler/`. Do not update budgets. This packet
ends at the counter screening decision; it contains no recipe or authorization
to infer emitted-package or LSP results that were never run.

