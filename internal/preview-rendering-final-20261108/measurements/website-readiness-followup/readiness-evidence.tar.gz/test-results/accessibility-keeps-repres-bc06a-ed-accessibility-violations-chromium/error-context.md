# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: accessibility.spec.ts >> keeps representative UI demos free of automated accessibility violations
- Location: e2e/accessibility.spec.ts:60:1

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  locator('[data-foldkit-build]')
Expected: 0
Received: 1
Timeout:  5000ms

Call log:
  - Expect "toHaveCount" locator('[data-foldkit-build]') with timeout 5000ms
  - waiting for locator('[data-foldkit-build]')
    14 × locator resolved to 1 element
       - unexpected value "1"

```

# Page snapshot

```yaml
- generic [ref=e2]:
  - link "Skip to main content" [ref=e3] [cursor=pointer]:
    - /url: "#main-content"
  - banner [ref=e4]:
    - generic [ref=e5]:
      - generic [ref=e6]:
        - link "Foldkit Beta" [ref=e7] [cursor=pointer]:
          - /url: /
          - img "Foldkit" [ref=e8]
          - generic "Beta" [ref=e9]
        - navigation "Primary" [ref=e10]:
          - link "Docs" [ref=e11] [cursor=pointer]:
            - /url: /core/architecture
          - link "Blog" [ref=e12] [cursor=pointer]:
            - /url: /blog
      - generic [ref=e13]:
        - button "Search documentation" [ref=e14] [cursor=pointer]:
          - generic [aria-hidden] [ref=e17]: ⌘K
        - generic [ref=e19]:
          - link "GitHub" [ref=e20] [cursor=pointer]:
            - /url: https://github.com/foldkit/foldkit
          - link "Discord" [ref=e23] [cursor=pointer]:
            - /url: https://discord.gg/kav8VNxqGm
          - link "X" [ref=e26] [cursor=pointer]:
            - /url: https://x.com/devinjameson
          - link "npm" [ref=e29] [cursor=pointer]:
            - /url: https://www.npmjs.com/package/foldkit
        - 'button "Theme: System" [ref=e34] [cursor=pointer]'
  - generic:
    - textbox [aria-hidden]
  - generic [ref=e37]:
    - complementary "Documentation sidebar" [ref=e38]:
      - navigation "Documentation" [ref=e39]:
        - list [ref=e40]:
          - listitem [ref=e41]:
            - link "Get Started" [ref=e42] [cursor=pointer]:
              - /url: /get-started
          - listitem [ref=e43]:
            - button "Introduction" [ref=e45] [cursor=pointer]
          - listitem [ref=e51]:
            - button "Core" [ref=e53] [cursor=pointer]
          - listitem [ref=e59]:
            - button "Comparisons" [ref=e61] [cursor=pointer]
          - listitem [ref=e67]:
            - button "Patterns" [ref=e69] [cursor=pointer]
          - listitem [ref=e75]:
            - button "Tooling" [ref=e77] [cursor=pointer]
          - listitem [ref=e83]:
            - button "FAQ" [ref=e85] [cursor=pointer]
          - listitem [ref=e91]:
            - generic [ref=e92]:
              - button "Foldkit UI" [disabled] [expanded] [ref=e93]
              - generic [ref=e97]:
                - list [ref=e99]:
                  - listitem [ref=e100]:
                    - link "Overview" [ref=e101] [cursor=pointer]:
                      - /url: /ui/overview
                  - listitem [ref=e102]:
                    - link "Selection Blocks" [ref=e103] [cursor=pointer]:
                      - /url: /ui/selection-blocks
                - list [ref=e105]:
                  - listitem [ref=e106]:
                    - link "Anchor" [ref=e107] [cursor=pointer]:
                      - /url: /ui/anchor
                  - listitem [ref=e108]:
                    - link "Animation" [ref=e109] [cursor=pointer]:
                      - /url: /ui/animation
                  - listitem [ref=e110]:
                    - link "Button" [ref=e111] [cursor=pointer]:
                      - /url: /ui/button
                  - listitem [ref=e112]:
                    - link "Calendar" [ref=e113] [cursor=pointer]:
                      - /url: /ui/calendar
                  - listitem [ref=e114]:
                    - link "Checkbox" [ref=e115] [cursor=pointer]:
                      - /url: /ui/checkbox
                  - listitem [ref=e116]:
                    - link "Combobox" [ref=e117] [cursor=pointer]:
                      - /url: /ui/combobox
                  - listitem [ref=e118]:
                    - link "Date Picker" [ref=e119] [cursor=pointer]:
                      - /url: /ui/date-picker
                  - listitem [ref=e120]:
                    - link "Dialog" [ref=e121] [cursor=pointer]:
                      - /url: /ui/dialog
                  - listitem [ref=e122]:
                    - link "Disclosure" [ref=e123] [cursor=pointer]:
                      - /url: /ui/disclosure
                  - listitem [ref=e124]:
                    - link "Drag and Drop" [ref=e125] [cursor=pointer]:
                      - /url: /ui/drag-and-drop
                  - listitem [ref=e126]:
                    - link "Fieldset" [ref=e127] [cursor=pointer]:
                      - /url: /ui/fieldset
                  - listitem [ref=e128]:
                    - link "File Drop" [ref=e129] [cursor=pointer]:
                      - /url: /ui/file-drop
                  - listitem [ref=e130]:
                    - link "Hover Intent" [ref=e131] [cursor=pointer]:
                      - /url: /ui/hover-intent
                  - listitem [ref=e132]:
                    - link "Input" [ref=e133] [cursor=pointer]:
                      - /url: /ui/input
                  - listitem [ref=e134]:
                    - link "Listbox" [ref=e135] [cursor=pointer]:
                      - /url: /ui/listbox
                  - listitem [ref=e136]:
                    - link "Menu" [ref=e137] [cursor=pointer]:
                      - /url: /ui/menu
                  - listitem [ref=e138]:
                    - link "Meter" [ref=e139] [cursor=pointer]:
                      - /url: /ui/meter
                  - listitem [ref=e140]:
                    - link "Nav" [ref=e141] [cursor=pointer]:
                      - /url: /ui/nav
                  - listitem [ref=e142]:
                    - link "Popover" [ref=e143] [cursor=pointer]:
                      - /url: /ui/popover
                  - listitem [ref=e144]:
                    - link "Progress" [ref=e145] [cursor=pointer]:
                      - /url: /ui/progress
                  - listitem [ref=e146]:
                    - link "Radio Group" [ref=e147] [cursor=pointer]:
                      - /url: /ui/radio-group
                  - listitem [ref=e148]:
                    - link "Select" [ref=e149] [cursor=pointer]:
                      - /url: /ui/select
                  - listitem [ref=e150]:
                    - link "Slider" [ref=e151] [cursor=pointer]:
                      - /url: /ui/slider
                  - listitem [ref=e152]:
                    - link "Switch" [ref=e153] [cursor=pointer]:
                      - /url: /ui/switch
                  - listitem [ref=e154]:
                    - link "Tabs" [ref=e155] [cursor=pointer]:
                      - /url: /ui/tabs
                  - listitem [ref=e156]:
                    - link "Textarea" [ref=e157] [cursor=pointer]:
                      - /url: /ui/textarea
                  - listitem [ref=e158]:
                    - link "Toast" [ref=e159] [cursor=pointer]:
                      - /url: /ui/toast
                  - listitem [ref=e160]:
                    - link "Tooltip" [ref=e161] [cursor=pointer]:
                      - /url: /ui/tooltip
                  - listitem [ref=e162]:
                    - link "Virtual List" [ref=e163] [cursor=pointer]:
                      - /url: /ui/virtual-list
          - listitem [ref=e164]:
            - button "AI" [ref=e166] [cursor=pointer]
          - listitem [ref=e172]:
            - button "Testing" [ref=e174] [cursor=pointer]
          - listitem [ref=e180]:
            - button "Best Practices" [ref=e182] [cursor=pointer]
          - listitem [ref=e188]:
            - button "Examples" [ref=e190] [cursor=pointer]
          - listitem [ref=e196]:
            - button "API Reference" [ref=e198] [cursor=pointer]
    - main [ref=e204]:
      - generic [ref=e205]:
        - generic [ref=e206]:
          - heading "Drag and Drop" [level=1] [ref=e207]
          - generic [ref=e208]:
            - heading "Overview" [level=2] [ref=e209]
            - link "Copy link to Overview" [ref=e210] [cursor=pointer]:
              - /url: "#overview"
          - paragraph [ref=e213]: Sortable lists and cross-container movement with pointer tracking, keyboard navigation, collision detection, auto-scrolling, and screen reader announcements.
          - generic [ref=e214]:
            - heading "Integration Model" [level=3] [ref=e215]
            - link "Copy link to Integration Model" [ref=e216] [cursor=pointer]:
              - /url: "#integration-model"
          - paragraph [ref=e219]:
            - text: DragAndDrop is different from other Foldkit UI components in two ways. First, it doesn’t have a
            - code [ref=e220]: view()
            - text: function. Instead, you spread
            - code [ref=e221]: draggable()
            - text: and
            - code [ref=e222]: droppable()
            - text: attributes onto your own elements. Second, its update function can return
            - code [ref=e223]: Reordered
            - text: and
            - code [ref=e224]: Cancelled
            - text: through the optional
            - code [ref=e225]: outMessage
            - text: field. You handle those OutMessages to decide how to reorder your data.
          - paragraph [ref=e226]:
            - text: "Integration requires four pieces: a"
            - code [ref=e227]: DragAndDropBlock.Model
            - text: field in your Model, one Binding created with
            - code [ref=e228]: ParentBlock.makeRequiredFieldBinding(DragAndDropBlock, config)
            - text: and selected through
            - code [ref=e229]: "withOutMessagePolicy({ fold })"
            - text: ", that Binding included in the parent’s"
            - code [ref=e230]: bindings
            - text: ", and an embedded view whose"
            - code [ref=e231]: toView
            - text: callback receives bound
            - code [ref=e232]: draggable
            - text: ","
            - code [ref=e233]: droppable
            - text: ", and"
            - code [ref=e234]: sortable
            - text: attribute helpers. The parent chooses all markup and spreads the supplied child attributes directly.
          - generic [ref=e235]:
            - paragraph [ref=e236]:
              - generic [ref=e239]: See it in an app
            - paragraph [ref=e241]:
              - text: Check out how DragAndDrop is wired up in the
              - link "kanban example" [ref=e242] [cursor=pointer]:
                - /url: https://github.com/foldkit/foldkit/tree/main/examples/kanban/src
              - text: or the
              - link "UI showcase" [ref=e243] [cursor=pointer]:
                - /url: https://github.com/foldkit/foldkit/blob/main/examples/ui-showcase/src/blocks/ui/view/dragAndDrop.ts
              - text: .
          - generic [ref=e244]:
            - heading "Examples" [level=2] [ref=e245]
            - link "Copy link to Examples" [ref=e246] [cursor=pointer]:
              - /url: "#examples"
          - generic [ref=e249]:
            - heading "Demo" [level=3] [ref=e250]
            - link "Copy link to Demo" [ref=e251] [cursor=pointer]:
              - /url: "#demo"
          - paragraph [ref=e254]:
            - text: The snippet below shows a minimal sortable list with all four integration pieces. For a full example with persistence, cross-container moves, and add-card forms, see the
            - link "Kanban example" [ref=e255] [cursor=pointer]:
              - /url: /example-apps/kanban
            - text: .
          - region "Demo" [ref=e256]:
            - generic [ref=e259]:
              - generic [ref=e260]:
                - generic [ref=e261]: Backlog
                - listbox "Backlog" [ref=e262]:
                  - option "Design API" [ref=e263]
                  - option "Write tests" [ref=e264]
                  - option "Build docs" [ref=e265]
              - generic [ref=e266]:
                - generic [ref=e267]: Done
                - listbox "Done" [ref=e268]:
                  - option "Set up repo" [ref=e269]
                  - option "Add CI" [ref=e270]
          - figure "Drag and drop" [ref=e272]:
            - generic [ref=e273]:
              - generic [ref=e274]: Drag and drop
              - generic [ref=e275]:
                - status [ref=e276]
                - button "Copy Drag and drop to clipboard" [ref=e277] [cursor=pointer]
            - generic [ref=e280]:
              - code [ref=e287]:
                - generic [ref=e288]: "import { Array, Layer, Schema } from 'effect'"
                - generic [ref=e289]: "import { Block } from 'foldkit'"
                - generic [ref=e290]: "import { defineMessageUnion } from 'foldkit/message'"
                - generic [ref=e291]: "import { DragAndDrop } from '@foldkit/ui'"
                - generic [ref=e292]: "// Add a field to your Model for the DragAndDrop Block plus the items being sorted:"
                - generic [ref=e293]: "const Model = Schema.Struct({"
                - generic [ref=e294]: "items: Schema.Array("
                - generic [ref=e295]: "Schema.Struct({ id: Schema.String, label: Schema.String }),"
                - generic [ref=e296]: ),
                - generic [ref=e297]: "dragAndDrop: DragAndDrop.DragAndDropBlock.Model,"
                - generic [ref=e298]: // ...your other fields
                - generic [ref=e299]: "})"
                - generic [ref=e300]: type Model = typeof Model.Type
                - generic [ref=e301]: // This excerpt has no parent-owned facts. The Composition derives delivery.
                - generic [ref=e302]: "const Message = defineMessageUnion({})"
                - generic [ref=e303]: type Message = typeof Message.Type
                - generic [ref=e304]: "declare const reorder: ("
                - generic [ref=e305]: "items: Model['items'],"
                - generic [ref=e306]: "itemId: string,"
                - generic [ref=e307]: "fromIndex: number,"
                - generic [ref=e308]: "toIndex: number,"
                - generic [ref=e309]: ) => Model['items']
                - generic [ref=e310]: export const SortableListKey = Symbol('SortableList')
                - generic [ref=e311]: "export const SortableListBlock = Block.make('SortableList', {"
                - generic [ref=e312]: "key: SortableListKey,"
                - generic [ref=e313]: "InitArgs: Schema.Tuple([]),"
                - generic [ref=e314]: Model,
                - generic [ref=e315]: Message,
                - generic [ref=e316]: "})"
                - generic [ref=e317]: "const {"
                - generic [ref=e318]: makeFieldsStep,
                - generic [ref=e319]: makeNoopStep,
                - generic [ref=e320]: makeOutMessageFold,
                - generic [ref=e321]: makeRequiredFieldBinding,
                - generic [ref=e322]: makeComposition,
                - generic [ref=e323]: "} = SortableListBlock"
                - generic [ref=e324]: "// At module scope, fold the OutMessage into your own Model. `Reordered`"
                - generic [ref=e325]: // carries the move so you can apply it to your own list. Each arm returns an
                - generic [ref=e326]: // Update.Step over the parent Model, which already has the next DragAndDrop
                - generic [ref=e327]: // Model written back. The parent Block checks the complete child union
                - generic [ref=e328]: "// and infers each parent Step:"
                - generic [ref=e329]: // The Binding retains the child contract; construction supplies its implementation.
                - generic [ref=e330]: const DragAndDropBinding = makeRequiredFieldBinding(
                - generic [ref=e331]: DragAndDrop.DragAndDropBlock,
                - generic [ref=e332]: "{"
                - generic [ref=e333]: "field: 'dragAndDrop',"
                - generic [ref=e334]: "init: { contextToArgs: () => [{ id: 'sortable-list' }] },"
                - generic [ref=e335]: "},"
                - generic [ref=e336]: ").withOutMessagePolicy({"
                - generic [ref=e337]: "fold: makeOutMessageFold(DragAndDrop.DragAndDropBlock, {"
                - generic [ref=e338]: "Reordered: ({ itemId, fromIndex, toIndex }) =>"
                - generic [ref=e339]: "makeFieldsStep(() => ({"
                - generic [ref=e340]: // reorder is your own function that moves the item
                - generic [ref=e341]: "items: items => reorder(items, itemId, fromIndex, toIndex),"
                - generic [ref=e342]: "})),"
                - generic [ref=e343]: "// The child has emitted `Cancelled`. In this arm the parent can update"
                - generic [ref=e344]: // its own state or dispatch its own Commands, for example revert an
                - generic [ref=e345]: // optimistic UI change, log analytics, or trigger a downstream Command.
                - generic [ref=e346]: "StartedKeyboardDrag: makeNoopStep,"
                - generic [ref=e347]: "ChangedKeyboardTarget: makeNoopStep,"
                - generic [ref=e348]: "Cancelled: makeNoopStep,"
                - generic [ref=e349]: "}),"
                - generic [ref=e350]: "})"
                - generic [ref=e351]: "const SortableListComposition = makeComposition({"
                - generic [ref=e352]: "bindings: [DragAndDropBinding],"
                - generic [ref=e353]: "})"
                - generic [ref=e354]: // Initialize the fields the parent owns. The Composition initializes the
                - generic [ref=e355]: // bound DragAndDrop Model with the Binding's unique id.
                - generic [ref=e356]: "const init = SortableListComposition.makeInit(() => ({"
                - generic [ref=e357]: "model: {"
                - generic [ref=e358]: "items: ["
                - generic [ref=e359]: "{ id: '1', label: 'First' },"
                - generic [ref=e360]: "{ id: '2', label: 'Second' },"
                - generic [ref=e361]: "{ id: '3', label: 'Third' },"
                - generic [ref=e362]: "],"
                - generic [ref=e363]: // ...your other fields
                - generic [ref=e364]: "},"
                - generic [ref=e365]: "}))"
                - generic [ref=e366]: "const update = SortableListComposition.makeUpdate({})"
                - generic [ref=e367]: "// Registering `DragAndDropBinding` in `bindings` collects its document-level Subscriptions."
                - generic [ref=e368]: // Inside your view function, embed the behavior-only Block and lay out its
                - generic [ref=e369]: "// draggable and droppable attribute bundles in `toView`:"
                - generic [ref=e370]: const view = SortableListComposition.makeView((model, h) =>
                - generic [ref=e371]: h.block(
                - generic [ref=e372]: "DragAndDropBinding.embedView({"
                - generic [ref=e373]: "slotId: 'sortable-list',"
                - generic [ref=e374]: "model: model.dragAndDrop,"
                - generic [ref=e375]: "viewInputs: {"
                - generic [ref=e376]: "toView: ({ draggable, droppable }) =>"
                - generic [ref=e377]: h.ul(
                - generic [ref=e378]: "["
                - generic [ref=e379]: ...droppable('list', 'Sortable items'),
                - generic [ref=e380]: h.Class('flex flex-col gap-2'),
                - generic [ref=e381]: "],"
                - generic [ref=e382]: Array.map(model.items, (item, index) =>
                - generic [ref=e383]: h.li(
                - generic [ref=e384]: "["
                - generic [ref=e385]: "...draggable({"
                - generic [ref=e386]: "itemId: item.id,"
                - generic [ref=e387]: "containerId: 'list',"
                - generic [ref=e388]: index,
                - generic [ref=e389]: "}),"
                - generic [ref=e390]: h.Class('p-3 rounded-lg border cursor-grab'),
                - generic [ref=e391]: "],"
                - generic [ref=e392]: "[h.span([], [item.label])],"
                - generic [ref=e393]: ),
                - generic [ref=e394]: ),
                - generic [ref=e395]: ),
                - generic [ref=e396]: "},"
                - generic [ref=e397]: "}),"
                - generic [ref=e398]: ),
                - generic [ref=e399]: )
                - generic [ref=e400]: "export const layer = SortableListBlock.makeLayer({"
                - generic [ref=e401]: init,
                - generic [ref=e402]: update,
                - generic [ref=e403]: view,
                - generic [ref=e404]: "}).pipe(Layer.provide(DragAndDrop.layer))"
              - button "Show code" [ref=e405] [cursor=pointer]
          - generic [ref=e406]:
            - heading "Styling" [level=2] [ref=e407]
            - link "Copy link to Styling" [ref=e408] [cursor=pointer]:
              - /url: "#styling"
          - paragraph [ref=e411]:
            - text: DragAndDrop is fully headless. You render all items, containers, and ghost elements. Use
            - code [ref=e412]: isDragging()
            - text: and
            - code [ref=e413]: maybeDraggedItemId()
            - text: to conditionally style items during drag (e.g. reduced opacity on the source, a drop placeholder at the target).
          - 'region "Table: Attribute, Condition" [ref=e414]':
            - table [ref=e415]:
              - rowgroup [ref=e416]:
                - row [ref=e417]:
                  - columnheader "Attribute" [ref=e418]
                  - columnheader "Condition" [ref=e419]
              - rowgroup [ref=e420]:
                - row [ref=e421]:
                  - cell [ref=e422]:
                    - code [ref=e423]: data-draggable-id
                  - cell "Set on draggable items with the item ID." [ref=e424]
                - row [ref=e425]:
                  - cell [ref=e426]:
                    - code [ref=e427]: data-sortable-id
                  - cell "Set on sortable items with the item ID." [ref=e428]
                - row [ref=e429]:
                  - cell [ref=e430]:
                    - code [ref=e431]: data-droppable-id
                  - cell "Set on drop containers with the container ID." [ref=e432]
          - generic [ref=e433]:
            - heading "Keyboard Interaction" [level=2] [ref=e434]
            - link "Copy link to Keyboard Interaction" [ref=e435] [cursor=pointer]:
              - /url: "#keyboard-interaction"
          - paragraph [ref=e438]: DragAndDrop supports full keyboard navigation. Space/Enter activates drag mode, arrow keys move the item, Tab/Shift+Tab moves between containers, and Escape cancels.
          - 'region "Table: Key, Description" [ref=e439]':
            - table [ref=e440]:
              - rowgroup [ref=e441]:
                - row [ref=e442]:
                  - columnheader "Key" [ref=e443]
                  - columnheader "Description" [ref=e444]
              - rowgroup [ref=e445]:
                - row [ref=e446]:
                  - cell [ref=e447]:
                    - code [ref=e448]: Space / Enter
                  - cell "Starts a keyboard drag on the focused item." [ref=e449]
                - row [ref=e450]:
                  - cell [ref=e451]:
                    - code [ref=e452]: Arrow Up / Down
                  - cell "Moves the item within its container (vertical orientation)." [ref=e453]
                - row [ref=e454]:
                  - cell [ref=e455]:
                    - code [ref=e456]: Arrow Left / Right
                  - cell "Moves the item within its container (horizontal orientation)." [ref=e457]
                - row [ref=e458]:
                  - cell [ref=e459]:
                    - code [ref=e460]: Tab / Shift+Tab
                  - cell "Moves the item to the next / previous container." [ref=e461]
                - row [ref=e462]:
                  - cell [ref=e463]:
                    - code [ref=e464]: Space / Enter
                  - cell "Drops the dragged item at its current position." [ref=e465]
                - row [ref=e466]:
                  - cell [ref=e467]:
                    - code [ref=e468]: Escape
                  - cell "Cancels the drag and returns the item to its original position." [ref=e469]
          - generic [ref=e470]:
            - heading "Accessibility" [level=2] [ref=e471]
            - link "Copy link to Accessibility" [ref=e472] [cursor=pointer]:
              - /url: "#accessibility"
          - paragraph [ref=e475]:
            - text: Draggable items receive
            - code [ref=e476]: role="option"
            - text: with
            - code [ref=e477]: aria-roledescription="draggable"
            - text: . Drop containers receive
            - code [ref=e478]: role="listbox"
            - text: . The parent owns a live region and its announcement text. Handle
            - code [ref=e479]: StartedKeyboardDrag
            - text: ","
            - code [ref=e480]: ChangedKeyboardTarget
            - text: ","
            - code [ref=e481]: Reordered
            - text: ", and"
            - code [ref=e482]: Cancelled
            - text: in the Binding OutMessage policy. Keep its writer focused on storing the child Model.
            - code [ref=e483]: ChangedKeyboardTarget
            - text: describes a proposed keyboard position; the parent applies the actual move after
            - code [ref=e484]: Reordered
            - text: . Announce the optimistic placement when the parent accepts it, and announce rollback separately if persistence fails.
          - generic [ref=e485]:
            - heading "Testing" [level=2] [ref=e486]
            - link "Copy link to Testing" [ref=e487] [cursor=pointer]:
              - /url: "#testing"
          - paragraph [ref=e490]:
            - text: In
            - link "Story tests" [ref=e491] [cursor=pointer]:
              - /url: /testing/story
            - text: ", use"
            - code [ref=e492]: DragAndDrop.test
            - text: "to resolve keyboard drag Commands:"
          - list [ref=e493]:
            - listitem [ref=e494]:
              - paragraph [ref=e495]:
                - code [ref=e496]: "DragAndDrop.test.settleFocus({ itemId })"
                - text: resolves the item's focus after a drop or cancellation.
            - listitem [ref=e497]:
              - paragraph [ref=e498]:
                - code [ref=e499]: "DragAndDrop.test.resolveKeyboardMove({ itemId, targetContainerId, targetIndex })"
                - text: supplies a target container and index for an arrow-key move, then resolves the item's focus.
          - paragraph [ref=e500]:
            - text: Those forms test the acquired DragAndDrop implementation. In a parent Story, also pass the exact
            - code [ref=e501]: binding
            - text: so the helper resolves that embedded occurrence. Pass its
            - code [ref=e502]: key
            - text: as well when the Binding is keyed. The scoped keyboard move helper verifies the pending move's item and complete invocation arguments before it supplies the result. Binding selection matches the composed path suffix. If an enclosing Binding repeats that path, isolate one ancestor occurrence in the Story; the helper rejects the ambiguity.
          - paragraph [ref=e503]:
            - text: Keyboard move results carry the originating
            - code [ref=e504]: keyboardDragGeneration
            - text: . The Story helper copies it from the selected pending Command. Custom handlers and tests constructing
            - code [ref=e505]: CompletedResolveKeyboardMove
            - text: directly must preserve that invocation's generation; a result from an earlier drag cannot move or focus a restarted interaction, including a new drag of the same item.
          - generic [ref=e506]:
            - heading "API Reference" [level=2] [ref=e507]
            - link "Copy link to API Reference" [ref=e508] [cursor=pointer]:
              - /url: "#api-reference"
          - generic [ref=e511]:
            - heading "InitConfig" [level=3] [ref=e512]
            - link "Copy link to InitConfig" [ref=e513] [cursor=pointer]:
              - /url: "#init-config"
          - paragraph [ref=e516]:
            - text: Configuration passed to the DragAndDrop Binding's child initializer. Scoped tests pass the same config to
            - code [ref=e517]: Story.init(...)
            - text: or
            - code [ref=e518]: Scene.init(...)
            - text: and provide the component implementation Layer.
          - 'region "Table: Name, Type, Default, Description" [ref=e519]':
            - table [ref=e520]:
              - rowgroup [ref=e521]:
                - row [ref=e522]:
                  - columnheader "Name" [ref=e523]
                  - columnheader "Type" [ref=e524]
                  - columnheader "Default" [ref=e525]
                  - columnheader "Description" [ref=e526]
              - rowgroup [ref=e527]:
                - row [ref=e528]:
                  - cell [ref=e529]:
                    - code [ref=e530]: id
                  - cell [ref=e531]:
                    - code [ref=e532]: string
                  - cell "—" [ref=e533]
                  - cell "Unique ID for the drag-and-drop instance." [ref=e534]
                - row [ref=e535]:
                  - cell [ref=e536]:
                    - code [ref=e537]: orientation
                  - cell [ref=e538]:
                    - code [ref=e539]: "'Vertical' | 'Horizontal'"
                  - cell [ref=e540]:
                    - code [ref=e541]: "'Vertical'"
                  - cell "Item flow direction. Controls arrow key mapping." [ref=e542]
                - row [ref=e543]:
                  - cell [ref=e544]:
                    - code [ref=e545]: activationThreshold
                  - cell [ref=e546]:
                    - code [ref=e547]: number
                  - cell [ref=e548]:
                    - code [ref=e549]: "5"
                  - cell "Minimum pointer movement in pixels before a drag activates. Prevents accidental drags from clicks." [ref=e550]
          - generic [ref=e551]:
            - heading "View Helpers" [level=3] [ref=e552]
            - link "Copy link to View Helpers" [ref=e553] [cursor=pointer]:
              - /url: "#view-helpers"
          - paragraph [ref=e556]: Functions for attaching drag-and-drop behavior to your elements and reading drag state.
          - 'region "Table: Name, Type, Default, Description" [ref=e557]':
            - table [ref=e558]:
              - rowgroup [ref=e559]:
                - row [ref=e560]:
                  - columnheader "Name" [ref=e561]
                  - columnheader "Type" [ref=e562]
                  - columnheader "Default" [ref=e563]
                  - columnheader "Description" [ref=e564]
              - rowgroup [ref=e565]:
                - row [ref=e566]:
                  - cell [ref=e567]:
                    - code [ref=e568]: draggable(config)
                  - cell [ref=e569]:
                    - code [ref=e570]: ReadonlyArray<Attribute>
                  - cell "—" [ref=e571]
                  - cell "Spread onto draggable items. Attaches pointer-down, keyboard activation, and ARIA attributes. The embedded view supplies this bound helper. Config requires itemId, containerId, and index; the Block captures its own Model and dispatcher." [ref=e572]
                - row [ref=e573]:
                  - cell [ref=e574]:
                    - code [ref=e575]: droppable(containerId, label?)
                  - cell [ref=e576]:
                    - code [ref=e577]: ReadonlyArray<Attribute>
                  - cell "—" [ref=e578]
                  - cell "Spread onto drop containers. Attaches the container ID for collision detection and optional ARIA label." [ref=e579]
                - row [ref=e580]:
                  - cell [ref=e581]:
                    - code [ref=e582]: sortable(itemId)
                  - cell [ref=e583]:
                    - code [ref=e584]: ReadonlyArray<Attribute>
                  - cell "—" [ref=e585]
                  - cell "Spread onto items that are both draggable and sortable targets." [ref=e586]
                - row [ref=e587]:
                  - cell [ref=e588]:
                    - code [ref=e589]: ghostStyle(model)
                  - cell [ref=e590]:
                    - code [ref=e591]: Option<CSSProperties>
                  - cell "—" [ref=e592]
                  - cell "Returns positioning styles for a ghost element that follows the pointer during drag. Use with Option.match to conditionally render." [ref=e593]
                - row [ref=e594]:
                  - cell [ref=e595]:
                    - code [ref=e596]: isDragging(model)
                  - cell [ref=e597]:
                    - code [ref=e598]: boolean
                  - cell "—" [ref=e599]
                  - cell "Whether a drag is currently in progress." [ref=e600]
                - row [ref=e601]:
                  - cell [ref=e602]:
                    - code [ref=e603]: maybeDraggedItemId(model)
                  - cell [ref=e604]:
                    - code [ref=e605]: Option<string>
                  - cell "—" [ref=e606]
                  - cell "The ID of the item being dragged, if any." [ref=e607]
                - row [ref=e608]:
                  - cell [ref=e609]:
                    - code [ref=e610]: maybeDropTarget(model)
                  - cell [ref=e611]:
                    - code [ref=e612]: Option<DropTarget>
                  - cell "—" [ref=e613]
                  - cell "The current drop target (containerId + index), if any." [ref=e614]
          - generic [ref=e615]:
            - heading "OutMessage" [level=3] [ref=e616]
            - link "Copy link to OutMessage" [ref=e617] [cursor=pointer]:
              - /url: "#out-message"
          - paragraph [ref=e620]:
            - text: Messages emitted to the parent through the optional
            - code [ref=e621]: outMessage
            - text: field. Handle the OutMessage in the Binding’s selected
            - code [ref=e622]: fold
            - text: policy.
          - 'region "Table: Name, Type, Default, Description" [ref=e623]':
            - table [ref=e624]:
              - rowgroup [ref=e625]:
                - row [ref=e626]:
                  - columnheader "Name" [ref=e627]
                  - columnheader "Type" [ref=e628]
                  - columnheader "Default" [ref=e629]
                  - columnheader "Description" [ref=e630]
              - rowgroup [ref=e631]:
                - row [ref=e632]:
                  - cell [ref=e633]:
                    - code [ref=e634]: StartedKeyboardDrag
                  - cell [ref=e635]:
                    - code [ref=e636]: "{ itemId, containerId, index }"
                  - cell "—" [ref=e637]
                  - cell "Emitted when keyboard drag mode starts. The parent can announce pickup instructions." [ref=e638]
                - row [ref=e639]:
                  - cell [ref=e640]:
                    - code [ref=e641]: ChangedKeyboardTarget
                  - cell [ref=e642]:
                    - code [ref=e643]: "{ itemId, fromContainerId, fromIndex, toContainerId, toIndex }"
                  - cell "—" [ref=e644]
                  - cell [ref=e645]:
                    - text: Emitted only when the keyboard target changes. The
                    - code [ref=e646]: from
                    - text: fields describe the previous target. The child Model already contains the new target; item data has not been reordered. Focus Commands retain their existing behavior, including at a movement boundary.
                - row [ref=e647]:
                  - cell [ref=e648]:
                    - code [ref=e649]: Reordered
                  - cell [ref=e650]:
                    - code [ref=e651]: "{ itemId, fromContainerId, fromIndex, toContainerId, toIndex }"
                  - cell "—" [ref=e652]
                  - cell [ref=e653]:
                    - text: Emitted when a drag completes with a valid drop target. The parent removes the source item, then inserts it at
                    - code [ref=e654]: toIndex
                    - text: in the destination. Pointer and keyboard drops use this source-excluded index; cross-container indexes count the destination normally. A drop that leaves the item in place still emits
                    - code [ref=e655]: Reordered
                    - text: . Handle it in the Binding’s selected fold policy.
                - row [ref=e656]:
                  - cell [ref=e657]:
                    - code [ref=e658]: Cancelled
                  - cell [ref=e659]:
                    - code [ref=e660]: "{}"
                  - cell "—" [ref=e661]
                  - cell "Emitted when an active drag is cancelled via Escape or a pointer release without a valid drop target. No reorder should be applied." [ref=e662]
        - navigation "Page navigation" [ref=e664]:
          - link "Previous Disclosure" [ref=e665] [cursor=pointer]:
            - /url: /ui/disclosure
            - generic [ref=e666]: Previous
            - generic [ref=e667]: ←Disclosure
          - link "Next Fieldset" [ref=e668] [cursor=pointer]:
            - /url: /ui/fieldset
            - generic [ref=e669]: Next
            - generic [ref=e670]: Fieldset→
      - generic [ref=e672]:
        - paragraph [ref=e673]: Stay in the update loop.
        - paragraph [ref=e674]: New releases, patterns, and the occasional deep dive.
        - generic [ref=e675]:
          - textbox "Email address" [ref=e677]:
            - /placeholder: you@example.com
          - button "Subscribe" [ref=e678] [cursor=pointer]
        - separator [ref=e679]
        - generic [ref=e680]:
          - paragraph [ref=e681]:
            - text: Built with
            - link "Foldkit" [ref=e682] [cursor=pointer]:
              - /url: https://github.com/foldkit/foldkit/tree/main/packages/website/src/composition/composition.ts
            - text: .
          - paragraph [ref=e683]: © 2026 Devin Jameson
          - navigation "Site information" [ref=e684]:
            - link "About" [ref=e685] [cursor=pointer]:
              - /url: /about
            - link "Contact" [ref=e686] [cursor=pointer]:
              - /url: /contact
            - link "Privacy" [ref=e687] [cursor=pointer]:
              - /url: /privacy
            - link "Content API" [ref=e688] [cursor=pointer]:
              - /url: /api
    - complementary [ref=e689]:
      - heading [level=3] [aria-hidden] [ref=e690]: On this page
      - navigation "Table of contents" [ref=e691]:
        - list [ref=e692]:
          - listitem [ref=e693]:
            - link "Overview" [ref=e694] [cursor=pointer]:
              - /url: "#overview"
          - listitem [ref=e695]:
            - link "Integration Model" [ref=e696] [cursor=pointer]:
              - /url: "#integration-model"
          - listitem [ref=e697]:
            - link "Examples" [ref=e698] [cursor=pointer]:
              - /url: "#examples"
          - listitem [ref=e699]:
            - link "Demo" [ref=e700] [cursor=pointer]:
              - /url: "#demo"
          - listitem [ref=e701]:
            - link "Styling" [ref=e702] [cursor=pointer]:
              - /url: "#styling"
          - listitem [ref=e703]:
            - link "Keyboard Interaction" [ref=e704] [cursor=pointer]:
              - /url: "#keyboard-interaction"
          - listitem [ref=e705]:
            - link "Accessibility" [ref=e706] [cursor=pointer]:
              - /url: "#accessibility"
          - listitem [ref=e707]:
            - link "Testing" [ref=e708] [cursor=pointer]:
              - /url: "#testing"
          - listitem [ref=e709]:
            - link "API Reference" [ref=e710] [cursor=pointer]:
              - /url: "#api-reference"
          - listitem [ref=e711]:
            - link "InitConfig" [ref=e712] [cursor=pointer]:
              - /url: "#init-config"
          - listitem [ref=e713]:
            - link "View Helpers" [ref=e714] [cursor=pointer]:
              - /url: "#view-helpers"
          - listitem [ref=e715]:
            - link "OutMessage" [ref=e716] [cursor=pointer]:
              - /url: "#out-message"
```

# Test source

```ts
  1   | import AxeBuilder from '@axe-core/playwright'
  2   | import { expect, test } from '@playwright/test'
  3   | import type { Locator, Page } from '@playwright/test'
  4   | 
  5   | const accessibilityTags = [
  6   |   'wcag2a',
  7   |   'wcag2aa',
  8   |   'wcag21a',
  9   |   'wcag21aa',
  10  |   'wcag22a',
  11  |   'wcag22aa',
  12  | ]
  13  | 
  14  | const expectNoAccessibilityViolations = async (page: Page) => {
  15  |   const results = await new AxeBuilder({ page })
  16  |     .withTags(accessibilityTags)
  17  |     .analyze()
  18  | 
  19  |   expect(results.violations).toEqual([])
  20  | }
  21  | 
  22  | const expectFullyVisible = async (locator: Locator) => {
  23  |   await expect
  24  |     .poll(() =>
  25  |       locator.evaluate(element => {
  26  |         const box = element.getBoundingClientRect()
  27  |         const elementAtCenter = document.elementFromPoint(
  28  |           box.left + box.width / 2,
  29  |           box.top + box.height / 2,
  30  |         )
  31  | 
  32  |         return (
  33  |           box.top >= 0 &&
  34  |           box.bottom <= window.innerHeight &&
  35  |           elementAtCenter !== null &&
  36  |           element.contains(elementAtCenter)
  37  |         )
  38  |       }),
  39  |     )
  40  |     .toBe(true)
  41  | }
  42  | 
  43  | const waitForClientRuntime = async (page: Page) => {
> 44  |   await expect(page.locator('[data-foldkit-build]')).toHaveCount(0)
      |                                                      ^ Error: expect(locator).toHaveCount(expected) failed
  45  |   await expect(page.locator('[data-browser-environment-loaded]')).toHaveCount(1)
  46  | }
  47  | 
  48  | const waitForRuntimeEffects = async (page: Page) => {
  49  |   await page.evaluate(
  50  |     () =>
  51  |       new Promise<void>(resolve =>
  52  |         requestAnimationFrame(() => requestAnimationFrame(() => resolve())),
  53  |       ),
  54  |   )
  55  | }
  56  | 
  57  | const isWithinInertSubtree = (locator: Locator): Promise<boolean> =>
  58  |   locator.evaluate(element => element.closest('[inert]') !== null)
  59  | 
  60  | test('keeps representative UI demos free of automated accessibility violations', async ({
  61  |   page,
  62  | }) => {
  63  |   for (const path of ['/ui/drag-and-drop', '/ui/virtual-list']) {
  64  |     await page.goto(path)
  65  |     await waitForClientRuntime(page)
  66  |     await expectNoAccessibilityViolations(page)
  67  |   }
  68  | 
  69  |   await page.goto('/ui/dialog')
  70  |   await waitForClientRuntime(page)
  71  |   await page.getByRole('button', { name: 'Open Dialog', exact: true }).click()
  72  |   await expect(
  73  |     page.getByRole('dialog', { name: 'Confirm Action' }),
  74  |   ).toBeVisible()
  75  |   await expectNoAccessibilityViolations(page)
  76  | })
  77  | 
  78  | test('keeps code snippets accessible while collapsed and expanded', async ({
  79  |   page,
  80  | }) => {
  81  |   for (const colorScheme of ['light', 'dark'] as const) {
  82  |     await page.emulateMedia({ colorScheme })
  83  |     await page.goto('/core/model')
  84  |     await waitForClientRuntime(page)
  85  | 
  86  |     const figure = page.getByRole('figure', { name: 'Model state union' })
  87  |     const toggle = figure.getByRole('button', { name: /^(Show|Hide) code$/ })
  88  |     const panel = figure.locator('[id$="-panel"]')
  89  |     const panelVisibilityWrapper = panel.locator('..')
  90  |     const shortFigure = page.getByRole('figure', {
  91  |       name: 'Counter Model',
  92  |       exact: true,
  93  |     })
  94  | 
  95  |     await expect(figure).toHaveCount(1)
  96  |     await expect(shortFigure).toHaveCount(1)
  97  |     await expect(
  98  |       shortFigure.getByRole('button', { name: /^(Show|Hide) code$/ }),
  99  |     ).toHaveCount(0)
  100 |     await expect(
  101 |       shortFigure.getByRole('button', {
  102 |         name: 'Copy Counter Model to clipboard',
  103 |       }),
  104 |     ).toBeVisible()
  105 |     await expect(
  106 |       figure.getByRole('button', {
  107 |         name: 'Copy Model state union to clipboard',
  108 |       }),
  109 |     ).toHaveAttribute('type', 'button')
  110 |     await expect(toggle).toHaveAccessibleName('Show code')
  111 |     await expect(toggle).toHaveAttribute('aria-expanded', 'false')
  112 |     await expect(panelVisibilityWrapper).toHaveAttribute('inert', '')
  113 |     await expect(panelVisibilityWrapper).toHaveAttribute('aria-hidden', 'true')
  114 |     await expectNoAccessibilityViolations(page)
  115 | 
  116 |     await toggle.focus()
  117 |     const scrollYBeforeExpand = await page.evaluate(() => window.scrollY)
  118 |     await toggle.press('Enter')
  119 |     await expect(toggle).toHaveAccessibleName('Hide code')
  120 |     await expect(toggle).toHaveAttribute('aria-expanded', 'true')
  121 |     await expect(toggle).toHaveAttribute(
  122 |       'aria-controls',
  123 |       await panel.evaluate(element => element.id),
  124 |     )
  125 |     await expect(panelVisibilityWrapper).not.toHaveAttribute('inert', '')
  126 |     await expect(panelVisibilityWrapper).not.toHaveAttribute(
  127 |       'aria-hidden',
  128 |       'true',
  129 |     )
  130 |     await expect(toggle).toBeFocused()
  131 |     await expectFullyVisible(toggle)
  132 |     await expect(toggle.locator('..')).toHaveCSS('position', 'sticky')
  133 |     await expect
  134 |       .poll(() => page.evaluate(() => window.scrollY))
  135 |       .toBe(scrollYBeforeExpand)
  136 |     await expectNoAccessibilityViolations(page)
  137 | 
  138 |     await toggle.press('Space')
  139 |     await expect(toggle).toHaveAccessibleName('Show code')
  140 |     await expect(toggle).toHaveAttribute('aria-expanded', 'false')
  141 |     await expect(toggle).toBeFocused()
  142 |     await expectFullyVisible(toggle)
  143 |   }
  144 | })
```