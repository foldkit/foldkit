import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import { join } from 'node:path'

import {
  assertFrozenCandidate,
  assertReceiptLineage,
  fileFacts,
  immutableInputs,
  loadAssetReceipt,
  loadConfig,
  loadReferenceAuthority,
  writeJsonExclusive,
} from '/private/tmp/foldkit-final-rendering-protocol-20261108/orchestration-v4/common.mjs'
import { assertAnalysisInputFacts, verifyV4 } from './verify-core.mjs'

const { config, configFacts } = loadConfig(process.argv[2])
const frozen = assertFrozenCandidate(config, configFacts)
const assets = loadAssetReceipt(config, configFacts, frozen)
const reference = loadReferenceAuthority(config, configFacts, frozen, assets)
const coverageRoot = join(config.evidenceRoot, 'coverage')
const receiptPath = join(coverageRoot, 'receipt.json')
const analysisPath = join(coverageRoot, 'analysis.json')
const preflightPath = join(config.evidenceRoot, 'preflight/receipt.json')
const receipt = JSON.parse(readFileSync(receiptPath, 'utf8'))
const analysis = JSON.parse(readFileSync(analysisPath, 'utf8'))
const preflightFacts = fileFacts(preflightPath)
assert.equal(receipt.status, 'complete')
assert.equal(receipt.browserAndServerClosed, true)
assert.equal(analysis.status, 'complete')
assertReceiptLineage(receipt, {
  configFacts,
  candidateFreeze: frozen.facts,
  currentImmutableInputs: immutableInputs(config),
  assetReceipt: assets.facts,
  referenceAuthority: reference.facts,
  preflightReceipt: preflightFacts,
})
assertReceiptLineage(analysis, {
  configFacts,
  candidateFreeze: frozen.facts,
  currentImmutableInputs: immutableInputs(config),
  assetReceipt: assets.facts,
  referenceAuthority: reference.facts,
  coverageReceipt: fileFacts(receiptPath),
})
for (const result of receipt.results) {
  assert.equal(result.asset.sha256, result.asset.servedSha256)
  assert.equal(result.asset.sha256, result.asset.executedSha256)
  assert.deepEqual(result.finalDom, { hasNewTodo: true, todoCount: 0 })
  assert.deepEqual(result.counts, {
    sync: 400,
    timeout: 0,
    animation_frame: result.owner === 'main' ? 400 : 600,
    microtask: 0,
    promise: 0,
  })
}
assertAnalysisInputFacts(analysis, receipt)
const proof = verifyV4(reference.receipt, analysis, {
  publishedAnalysisPath: join(
    config.repoEvidenceRoot,
    'analysis/source-matched-analysis-final.json.gz',
  ),
  authorityFacts: reference.facts,
})
const guard = {
  ...proof,
  interpretation: `${proof.interpretation} Functional/DOM/callback guards and full receipt lineage also passed in the fresh v4 chain.`,
  config: configFacts,
  candidateFreeze: frozen.facts,
  immutableInputs: immutableInputs(config),
  assetReceipt: assets.facts,
  referenceAuthority: reference.facts,
  preflightReceipt: preflightFacts,
  captureReceipt: fileFacts(receiptPath),
  analysis: fileFacts(analysisPath),
}
const guardPath = '/private/tmp/foldkit-v5-status-review/actual-6f-verify-coverage-guard.json'
writeJsonExclusive(guardPath, guard)
process.stdout.write(`${JSON.stringify(guard, null, 2)}\n`)
