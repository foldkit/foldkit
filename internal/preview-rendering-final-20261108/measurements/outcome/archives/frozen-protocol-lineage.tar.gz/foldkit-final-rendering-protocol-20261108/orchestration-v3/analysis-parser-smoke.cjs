const assert = require('node:assert/strict')
const { createHash } = require('node:crypto')
const { createRequire } = require('node:module')
const {
  existsSync,
  readFileSync,
  realpathSync,
  writeFileSync,
} = require('node:fs')
const { dirname, join, resolve } = require('node:path')

const candidateRoot = resolve(process.argv[2] ?? process.cwd())
const aliasRoot = realpathSync(join(candidateRoot, 'node_modules/typescript'))
const aliasEntry = join(aliasRoot, 'lib/typescript.js')
const requireFromAlias = createRequire(join(aliasRoot, 'package.json'))
const runtimePackagePath = requireFromAlias.resolve('@typescript/old/package.json')
const runtimeRoot = dirname(runtimePackagePath)
const runtimeEntry = join(runtimeRoot, 'lib/typescript.js')
const ts = require(aliasEntry)
const runtimePackage = JSON.parse(readFileSync(runtimePackagePath, 'utf8'))
assert.equal(ts.version, runtimePackage.version)
assert.equal(ts.version, '6.0.3')

const sha256 = value => createHash('sha256').update(value).digest('hex')
const fileFacts = path => {
  const bytes = readFileSync(path)
  return { path, bytes: bytes.length, sha256: sha256(bytes) }
}
const enclosingName = (sourcePath, line, column) => {
  const content = readFileSync(sourcePath, 'utf8')
  const sourceFile = ts.createSourceFile(
    sourcePath,
    content,
    ts.ScriptTarget.Latest,
    true,
  )
  const functions = []
  const visit = (node, parents) => {
    let names = parents
    if (ts.isFunctionLike(node) && node.body) {
      let name = node.name?.getText(sourceFile)
      let owner = node
      if (
        ts.isVariableDeclaration(node.parent) ||
        ts.isPropertyAssignment(node.parent) ||
        ts.isMethodDeclaration(node.parent)
      ) {
        name = node.parent.name?.getText(sourceFile) ?? name
        owner = node.parent
      }
      names = name ? [...parents, name] : parents
      const start = owner.getStart(sourceFile)
      const startLocation = sourceFile.getLineAndCharacterOfPosition(start)
      const endLocation = sourceFile.getLineAndCharacterOfPosition(owner.end)
      functions.push({
        start,
        end: owner.end,
        line: startLocation.line + 1,
        endLine: endLocation.line + 1,
        column: startLocation.character,
        name: names.join('.'),
      })
    }
    ts.forEachChild(node, child => visit(child, names))
  }
  visit(sourceFile, [])
  const offset = sourceFile.getPositionOfLineAndCharacter(line - 1, column)
  const containing = functions
    .filter(item => item.start <= offset && offset < item.end)
    .sort((left, right) => left.end - left.start)[0]
  const lineContaining = functions
    .filter(item => item.line <= line && line <= item.endLine)
    .sort((left, right) => left.end - left.start)[0]
  const declaredOnMappedLine = functions
    .filter(item => item.line === line)
    .sort((left, right) => left.end - left.start)[0]
  const closest = declaredOnMappedLine ?? lineContaining
  if (
    closest &&
    (!containing || closest.end - closest.start < containing.end - containing.start)
  ) {
    return closest.name
  }
  return containing?.name
}

const cases = [
  {
    source: 'packages/foldkit/src/runtime/renderer.ts',
    line: 481,
    column: 8,
    expected: 'makeRenderer.renderSync',
  },
  {
    source: 'packages/foldkit/src/runtime/renderer.ts',
    line: 652,
    column: 43,
    expected: 'makeRenderer.runRenderFrameBody',
  },
  {
    source: 'packages/foldkit/src/runtime/renderer.ts',
    line: 782,
    column: 41,
    expected: 'makeRenderer.renderFramePlain',
  },
  {
    source: 'packages/foldkit/src/block/delivery.ts',
    line: 1370,
    column: 25,
    expected: 'createCompositionUpdate.makeUpdateFromCases.dualDispatch',
  },
  {
    source: 'internal/lustre-benchmark/src/todo.ts',
    line: 71,
    column: 23,
    expected: 'update',
  },
].map(testCase => {
  const sourcePath = join(candidateRoot, testCase.source)
  const actual = enclosingName(sourcePath, testCase.line, testCase.column)
  assert.equal(actual, testCase.expected, `${testCase.source}:${testCase.line}:${testCase.column}`)
  return { ...testCase, actual, sourceFacts: fileFacts(sourcePath) }
})

const receipt = {
  schemaVersion: 1,
  status: 'pass',
  interpretation: 'Offline real TypeScript compiler-API parser smoke against current source positions; no compiler, build, browser, coverage capture or timing process.',
  candidateRoot: realpathSync(candidateRoot),
  typescript: {
    version: ts.version,
    aliasRoot,
    aliasEntry: fileFacts(aliasEntry),
    runtimeRoot,
    runtimePackage: fileFacts(runtimePackagePath),
    runtimeEntry: fileFacts(runtimeEntry),
  },
  cases,
}
const output = join(__dirname, 'analysis-parser-smoke-v3.json')
const serialized = `${JSON.stringify(receipt, null, 2)}\n`
if (existsSync(output)) {
  assert.equal(readFileSync(output, 'utf8'), serialized, 'Retained parser smoke differs')
} else {
  writeFileSync(output, serialized, { flag: 'wx' })
}
process.stdout.write(`${JSON.stringify({ output, typescript: ts.version, cases: cases.length }, null, 2)}\n`)
