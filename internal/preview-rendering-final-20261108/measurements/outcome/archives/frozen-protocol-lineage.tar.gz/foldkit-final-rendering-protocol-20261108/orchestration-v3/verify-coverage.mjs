import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import { join } from 'node:path'
import { gunzipSync } from 'node:zlib'

import {
  assertFrozenCandidate,
  assertReceiptLineage,
  fileFacts,
  immutableInputs,
  loadAssetReceipt,
  loadConfig,
  scriptRoot,
  writeJsonExclusive,
} from './common.mjs'
import {
  assertExactLogicalInventory,
  assertExactPositionedInventory,
  assertUniqueExactRow,
  assertUniqueExactPositionedCountRow,
} from './coverage-guards.mjs'

const { config, configFacts } = loadConfig(process.argv[2])
const frozen = assertFrozenCandidate(config, configFacts)
const assets = loadAssetReceipt(config, configFacts, frozen)
const root = join(config.evidenceRoot, 'coverage')
const receiptPath = join(root, 'receipt.json')
const analysisPath = join(root, 'analysis.json')
const receipt = JSON.parse(readFileSync(receiptPath, 'utf8'))
const analysis = JSON.parse(readFileSync(analysisPath, 'utf8'))
const authenticatedReferencePath = join(
  config.repoEvidenceRoot,
  'analysis/source-matched-analysis-final.json.gz',
)
const authenticatedReference = JSON.parse(
  gunzipSync(readFileSync(authenticatedReferencePath)),
)
const cadenceReferencePath = join(
  scriptRoot,
  '../cadence-guard/counts/analysis.json',
)
const cadenceReference = JSON.parse(readFileSync(cadenceReferencePath, 'utf8'))
assert.equal(receipt.status, 'complete')
assert.equal(receipt.browserAndServerClosed, true)
assert.equal(analysis.status, 'complete')
const preflightPath = join(config.evidenceRoot, 'preflight/receipt.json')
const preflightFacts = fileFacts(preflightPath)
assertReceiptLineage(receipt, {
  configFacts,
  candidateFreeze: frozen.facts,
  currentImmutableInputs: immutableInputs(config),
  assetReceipt: assets.facts,
  preflightReceipt: preflightFacts,
})
assertReceiptLineage(analysis, {
  configFacts,
  candidateFreeze: frozen.facts,
  currentImmutableInputs: immutableInputs(config),
  assetReceipt: assets.facts,
  coverageReceipt: fileFacts(receiptPath),
})

for (const result of receipt.results) {
  assert.equal(result.asset.sha256, result.asset.servedSha256)
  assert.equal(result.asset.sha256, result.asset.executedSha256)
  assert.deepEqual(result.finalDom, { hasNewTodo: true, todoCount: 0 })
  assert.deepEqual(result.counts, {
    sync: 400,
    timeout: 0,
    animation_frame: result.owner === 'main' ? 400 : 600,
    microtask: 0,
    promise: 0,
  })
}

const by = (owner, variant) =>
  analysis.results.find(result => result.owner === owner && result.variant === variant)
    ?? assert.fail(`Missing ${owner} ${variant}`)
const compact = rows => rows
  .map(({ source, name, sourceLine, sourceColumn, count }) => ({
    source,
    name,
    sourceLine,
    sourceColumn,
    count,
  }))
  .sort((left, right) => JSON.stringify(left).localeCompare(JSON.stringify(right)))
const rows = (result, predicate) => compact(result.relevantFunctions.filter(predicate))
const logicalRows = (result, predicate) => result.relevantFunctions
  .filter(predicate)
  .map(({ source, name, count }) => ({ source, name, count }))
  .sort((left, right) => JSON.stringify(left).localeCompare(JSON.stringify(right)))
const referenceBy = (owner, variant) => {
  const slot = owner === 'main'
    ? `foldkit-main${variant === 'optimised' ? '-optimised' : ''}`
    : `foldkit-preview-final${variant === 'optimised' ? '-optimised' : ''}`
  return authenticatedReference.coverageResults.find(result => result.slot === slot)
    ?? assert.fail(`Missing authenticated reference ${slot}`)
}
const cadenceReferenceBy = variant => {
  const result = cadenceReference.results.find(result => result.name === `cadence-${variant}`)
    ?? assert.fail(`Missing cadence owner reference ${variant}`)
  return {
    relevantFunctions: result.relevantFunctions.map(row => ({
      ...row,
      sourceLine: row.line,
      sourceColumn: row.column,
    })),
  }
}
const exactPairs = []
const frameworkWrappers = []
for (const variant of ['optimised', 'naive']) {
  const main = by('main', variant)
  const current = by('current', variant)

  const applicationPredicate = row =>
    /internal\/lustre-benchmark\/src\/(?:todo|view\.optimised)\.ts$/.test(row.source ?? '') &&
    !(row.source.endsWith('/todo.ts') && row.name === 'update')
  const mainApplication = rows(main, applicationPredicate)
  const currentApplication = rows(current, applicationPredicate)
  const referenceMain = referenceBy('main', variant)
  const referenceCurrent = referenceBy('current', variant)
  const referenceCadenceCurrent = cadenceReferenceBy(variant)
  assert.deepEqual(
    mainApplication,
    rows(referenceMain, applicationPredicate),
    `${variant} exact-main positioned application rows differ from authenticated reference`,
  )
  assert.deepEqual(
    currentApplication,
    rows(referenceCurrent, applicationPredicate),
    `${variant} current positioned application rows differ from authenticated reference`,
  )
  assert.deepEqual(
    logicalRows(current, applicationPredicate),
    logicalRows(main, applicationPredicate),
    `${variant} unchanged application handlers/descendant views differ`,
  )

  const lazyPredicate = row =>
    row.source === 'packages/foldkit/src/html/lazy.ts' &&
    row.name !== 'trackedBoundaryOccurrencesAreCurrent'
  const mainLazy = rows(main, lazyPredicate)
  const currentLazy = rows(current, lazyPredicate)
  assert.deepEqual(
    mainLazy,
    rows(referenceMain, lazyPredicate),
    `${variant} exact-main positioned html/lazy rows differ from authenticated reference`,
  )
  assert.deepEqual(
    currentLazy,
    rows(referenceCurrent, lazyPredicate),
    `${variant} current positioned html/lazy rows differ from authenticated reference`,
  )
  assert.deepEqual(
    logicalRows(current, lazyPredicate),
    logicalRows(main, lazyPredicate),
    `${variant} unchanged html/lazy functions differ`,
  )

  const expected = variant === 'optimised'
    ? { build: 3906, normalize: 3906, visit: 31248, updateChildren: 3387 }
    : { build: 132125, normalize: 132125, visit: 160063, updateChildren: 131606 }
  for (const [result, reference, owner] of [
    [main, referenceMain, 'main'],
    [current, referenceCurrent, 'current'],
  ]) {
    for (const [source, name] of [
      ['packages/foldkit/src/html/index.ts', 'buildVNodeData'],
      ['packages/foldkit/src/html/index.ts', 'buildElement'],
      ['packages/foldkit/src/html/index.ts', 'copyChildrenDroppingEmpty'],
      ['packages/foldkit/src/vdom.ts', 'visit'],
      ['packages/foldkit/src/snabbdom/init.ts', 'init.patch'],
      ['packages/foldkit/src/snabbdom/init.ts', 'init.updateChildren'],
    ]) {
      assertExactPositionedInventory(
        result,
        reference,
        source,
        name,
        `${variant} ${owner} ${source} ${name}`,
      )
    }
  }
  assertUniqueExactRow(
    main,
    'packages/foldkit/src/html/index.ts',
    'buildVNodeData',
    expected.build,
    `${variant} main buildVNodeData`,
  )
  assertUniqueExactRow(current, 'packages/foldkit/src/html/index.ts', 'buildVNodeData', expected.build, `${variant} current buildVNodeData`)
  assertUniqueExactRow(main, 'packages/foldkit/src/html/index.ts', 'buildElement', expected.build, `${variant} main buildElement`)
  assertUniqueExactRow(current, 'packages/foldkit/src/html/index.ts', 'buildElement', expected.build, `${variant} current buildElement`)
  assertUniqueExactRow(main, 'packages/foldkit/src/html/index.ts', 'copyChildrenDroppingEmpty', expected.normalize, `${variant} main normalization`)
  assertUniqueExactRow(current, 'packages/foldkit/src/html/index.ts', 'copyChildrenDroppingEmpty', expected.normalize, `${variant} current normalization`)
  assertUniqueExactRow(main, 'packages/foldkit/src/vdom.ts', 'visit', expected.visit, `${variant} main VNode visit`)
  assertUniqueExactRow(current, 'packages/foldkit/src/vdom.ts', 'visit', expected.visit, `${variant} current VNode visit`)
  assertUniqueExactRow(main, 'packages/foldkit/src/snabbdom/init.ts', 'init.updateChildren', expected.updateChildren, `${variant} main updateChildren`)
  assertUniqueExactRow(current, 'packages/foldkit/src/snabbdom/init.ts', 'init.updateChildren', expected.updateChildren, `${variant} current updateChildren`)
  assertExactPositionedInventory(main, referenceMain, 'packages/foldkit/src/runtime/renderer.ts', 'makeRenderer.renderSync', `${variant} main renderSync`)
  assertExactPositionedInventory(main, referenceMain, 'packages/foldkit/src/runtime/renderer.ts', 'makeRenderer.runRenderFrameBody', `${variant} main frame body`)
  assertExactPositionedInventory(current, referenceCadenceCurrent, 'packages/foldkit/src/runtime/renderer.ts', 'makeRenderer.renderSync', `${variant} current owner-reference renderSync`)
  assertExactPositionedInventory(current, referenceCadenceCurrent, 'packages/foldkit/src/runtime/renderer.ts', 'makeRenderer.runRenderFrameBody', `${variant} current owner-reference frame body`)
  assertExactLogicalInventory(current, main, 'packages/foldkit/src/runtime/renderer.ts', 'makeRenderer.runRenderFrameBody', `${variant} shared frame body`)
  assertUniqueExactRow(main, 'packages/foldkit/src/runtime/renderer.ts', 'makeRenderer.runRenderFrameBody', 400, `${variant} main frame body`)
  assertUniqueExactPositionedCountRow(current, referenceCadenceCurrent, 'packages/foldkit/src/runtime/renderer.ts', 'makeRenderer.runRenderFrameBody', 400, `${variant} current frame body`)
  assertExactPositionedInventory(main, referenceMain, 'internal/lustre-benchmark/src/todo.ts', 'update', `${variant} main Todo dispatcher inventory`)
  assertUniqueExactPositionedCountRow(main, referenceMain, 'internal/lustre-benchmark/src/todo.ts', 'update', 400, `${variant} main Todo dispatcher`)
  assertExactPositionedInventory(current, referenceCurrent, 'packages/foldkit/src/block/delivery.ts', 'createCompositionUpdate.makeUpdateFromCases.dualDispatch', `${variant} current exact dispatcher inventory`)
  assertUniqueExactPositionedCountRow(
    current,
    referenceCurrent,
    'packages/foldkit/src/block/delivery.ts',
    'createCompositionUpdate.makeUpdateFromCases.dualDispatch',
    400,
    `${variant} current exact dispatcher`,
  )
  assertExactPositionedInventory(current, referenceCadenceCurrent, 'packages/foldkit/src/runtime/renderer.ts', 'makeRenderer.renderFramePlain', `${variant} current cadence callback inventory`)
  assertUniqueExactPositionedCountRow(
    current,
    referenceCadenceCurrent,
    'packages/foldkit/src/runtime/renderer.ts',
    'makeRenderer.renderFramePlain',
    600,
    `${variant} current cadence callback entry`,
  )
  if (variant === 'optimised') {
    assertUniqueExactRow(main, 'packages/foldkit/src/html/lazy.ts', 'argsEqual', 26739, 'optimised main argsEqual')
    assertUniqueExactRow(current, 'packages/foldkit/src/html/lazy.ts', 'argsEqual', 26739, 'optimised current argsEqual')
    assertUniqueExactRow(main, 'packages/foldkit/src/html/lazy.ts', 'resolveOrCache', 26844, 'optimised main resolveOrCache')
    assertUniqueExactRow(current, 'packages/foldkit/src/html/lazy.ts', 'resolveOrCache', 26844, 'optimised current resolveOrCache')
  }

  const wrapperPredicate = row => row.count > 0 && (
    /packages\/foldkit\/src\/(?:block\/|runtime\/program|struct\/)/.test(row.source ?? '') ||
    row.name === 'trackedBoundaryOccurrencesAreCurrent' ||
    row.name.includes('assertLayeredMountsAreRegistered') ||
    row.name === 'makeRenderer.renderFramePlain'
  )
  frameworkWrappers.push({ variant, rows: rows(current, wrapperPredicate) })
  exactPairs.push({
    variant,
    unchangedApplicationRows: mainApplication.length,
    unchangedLazyRows: mainLazy.length,
    expectedSharedWork: expected,
  })
}

const guard = {
  schemaVersion: 1,
  status: 'pass',
  interpretation: 'Exact source-matched equality passed for every unchanged application handler, descendant-view and html/lazy row within optimized and naive pairs. Shared VNode/render/DOM work counts also passed. Current architecture wrappers are named separately, not waived as view-default changes.',
  config: configFacts,
  candidateFreeze: frozen.facts,
  immutableInputs: immutableInputs(config),
  assetReceipt: assets.facts,
  preflightReceipt: preflightFacts,
  captureReceipt: fileFacts(receiptPath),
  analysis: fileFacts(analysisPath),
  authenticatedReference: fileFacts(authenticatedReferencePath),
  cadenceOwnerReference: fileFacts(cadenceReferencePath),
  exactPairs,
  frameworkWrappers,
  measurementScope: 'Coverage count evidence only. Ordinary harness instrumentation does not wrap MessageChannel.port.onmessage; no cadence arming-task CPU inclusion is claimed.',
}
const guardPath = join(root, 'guard-receipt.json')
writeJsonExclusive(guardPath, guard)
process.stdout.write(`${JSON.stringify(guard, null, 2)}\n`)
