const assert = require('node:assert/strict')
const { createHash } = require('node:crypto')
const { cpSync, mkdirSync, readFileSync, writeFileSync } = require('node:fs')
const { dirname, join, resolve } = require('node:path')

const config = JSON.parse(readFileSync(resolve(process.argv[2]), 'utf8'))
const sha256 = value => createHash('sha256').update(value).digest('hex')
const facts = path => {
  const bytes = readFileSync(path)
  return { path, bytes: bytes.length, sha256: sha256(bytes) }
}
const sourceReceiptPath = join(config.sourceRoot, 'counts/receipt.json')
const receipt = JSON.parse(readFileSync(sourceReceiptPath, 'utf8'))
assert.equal(receipt.status, 'complete')
assert.equal(receipt.browserAndServerClosed, true)
const files = []
const copy = (source, destination) => {
  mkdirSync(dirname(destination), { recursive: true })
  cpSync(source, destination, { errorOnExist: true, force: false })
  files.push({ source: facts(source), stored: facts(destination) })
  assert.equal(files.at(-1).source.sha256, files.at(-1).stored.sha256)
}
copy(sourceReceiptPath, join(config.outputRoot, 'counts/receipt.json'))
for (const result of receipt.results) {
  const sourceJavaScript = join(
    config.sourceRoot,
    `maps/${result.variant}/assets/${result.asset.file}`,
  )
  const sourceMap = `${sourceJavaScript}.map`
  const sourceCapture = join(config.sourceRoot, `counts/${result.captureFile}`)
  assert.equal(facts(sourceJavaScript).sha256, result.asset.sha256)
  assert.equal(facts(sourceMap).sha256, result.map.sha256)
  assert.equal(facts(sourceCapture).sha256, result.captureSha256)
  copy(sourceJavaScript, join(config.outputRoot, `maps/${result.variant}/assets/${result.asset.file}`))
  copy(sourceMap, join(config.outputRoot, `maps/${result.variant}/assets/${result.asset.file}.map`))
  copy(sourceCapture, join(config.outputRoot, `counts/${result.captureFile}`))
}
const output = {
  schemaVersion: 1,
  status: 'complete',
  interpretation: 'Durable byte-identical cadence source/reference packet; no browser, build, coverage capture, or timing process.',
  sourceReceipt: facts(sourceReceiptPath),
  files,
}
writeFileSync(config.outputReceipt, `${JSON.stringify(output, null, 2)}\n`, { flag: 'wx' })
process.stdout.write(`${JSON.stringify({ outputReceipt: config.outputReceipt, files: files.length }, null, 2)}\n`)
