import assert from 'node:assert/strict'

export const positioned = rows => rows
  .map(({ source, name, sourceLine, sourceColumn, count }) => ({
    source,
    name,
    sourceLine,
    sourceColumn,
    count,
  }))
  .sort((left, right) => JSON.stringify(left).localeCompare(JSON.stringify(right)))

export const logical = rows => rows
  .map(({ source, name, count }) => ({ source, name, count }))
  .sort((left, right) => JSON.stringify(left).localeCompare(JSON.stringify(right)))

export const matchingRows = (result, source, name, includeDescendants = false) =>
  result.relevantFunctions.filter(row =>
    row.source === source &&
    (row.name === name || (includeDescendants && row.name.startsWith(`${name}.`))))

export const assertExactPositionedInventory = (
  result,
  reference,
  source,
  name,
  label,
  includeDescendants = false,
) => {
  const actualRows = positioned(matchingRows(result, source, name, includeDescendants))
  const expectedRows = positioned(matchingRows(reference, source, name, includeDescendants))
  assert(expectedRows.length > 0, `${label}: authenticated inventory is empty`)
  assert.deepEqual(actualRows, expectedRows, `${label}: positioned inventory differs`)
  return actualRows
}

export const assertUniqueExactPositionedCountRow = (
  result,
  reference,
  source,
  name,
  count,
  label,
) => {
  const actual = positioned(matchingRows(result, source, name).filter(row => row.count === count))
  const expected = positioned(matchingRows(reference, source, name).filter(row => row.count === count))
  assert.equal(actual.length, 1, `${label}: expected one actual exact-count row`)
  assert.equal(expected.length, 1, `${label}: expected one authority exact-count row`)
  assert.deepEqual(actual[0], expected[0], `${label}: positioned exact-count row differs`)
  return actual[0]
}

export const assertExactPositiveLogicalEquality = (leftRows, rightRows, label) => {
  const left = logical(leftRows.filter(row => row.count > 0))
  const right = logical(rightRows.filter(row => row.count > 0))
  assert(left.length > 0, `${label}: positive inventory is empty`)
  assert.deepEqual(left, right, `${label}: positive logical inventory differs`)
  return left
}

const rowKey = row => JSON.stringify({
  source: row.source,
  name: row.name,
  sourceLine: row.sourceLine,
  sourceColumn: row.sourceColumn,
  count: row.count,
})
export const exactDifference = (leftRows, rightRows) => {
  const right = new Map(positioned(rightRows).map(row => [rowKey(row), row]))
  return positioned(leftRows).filter(row => !right.has(rowKey(row)))
}

export const assertExactZeroDelta = (
  currentRows,
  mainRows,
  expectedCurrentOnly,
  expectedMainOnly,
  label,
) => {
  const currentZero = currentRows.filter(row => row.count === 0)
  const mainZero = mainRows.filter(row => row.count === 0)
  const currentOnly = exactDifference(currentZero, mainZero)
  const mainOnly = exactDifference(mainZero, currentZero)
  assert.deepEqual(currentOnly, positioned(expectedCurrentOnly), `${label}: current-only zero delta differs`)
  assert.deepEqual(mainOnly, positioned(expectedMainOnly), `${label}: main-only zero delta differs`)
  return { currentOnly, mainOnly }
}

export const assertInputLineage = (actual, expected, label) =>
  assert.deepEqual(actual, expected, `${label}: reference lineage differs`)

