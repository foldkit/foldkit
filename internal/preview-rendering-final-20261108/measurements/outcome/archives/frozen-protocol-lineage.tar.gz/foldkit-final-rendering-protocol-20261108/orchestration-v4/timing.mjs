import assert from 'node:assert/strict'
import { execFileSync, spawn } from 'node:child_process'
import {
  appendFileSync,
  existsSync,
  mkdirSync,
  readFileSync,
  writeFileSync,
} from 'node:fs'
import { createServer } from 'node:net'
import { cpus, freemem, loadavg, platform, release, totalmem, uptime } from 'node:os'
import { join } from 'node:path'

import {
  assertFrozenCandidate,
  assertGrant,
  assertReceiptLineage,
  createHarness,
  fileFacts,
  immutableInputs,
  loadAssetReceipt,
  loadConfig,
  slots,
  writeJson,
} from './common.mjs'

const { config, configFacts } = loadConfig(process.argv[2])
assertGrant('TIMING_SLOT_GRANTED')
assertGrant('QUIET_WINDOW_CONFIRMED')
const frozen = assertFrozenCandidate(config, configFacts)
const assets = loadAssetReceipt(config, configFacts, frozen)
const preflightPath = join(config.evidenceRoot, 'preflight/receipt.json')
const coverageGuardPath = join(config.evidenceRoot, 'coverage/guard-receipt.json')
const preflight = JSON.parse(readFileSync(preflightPath, 'utf8'))
const coverageGuard = JSON.parse(readFileSync(coverageGuardPath, 'utf8'))
assert.equal(preflight.status, 'complete')
assert.equal(preflight.browserAndServerClosed, true)
assert.equal(coverageGuard.status, 'pass')
const currentImmutableInputs = immutableInputs(config)
const preflightFacts = fileFacts(preflightPath)
const coverageReceiptFacts = fileFacts(join(config.evidenceRoot, 'coverage/receipt.json'))
const coverageAnalysisFacts = fileFacts(join(config.evidenceRoot, 'coverage/analysis.json'))
const coverageGuardFacts = fileFacts(coverageGuardPath)
assertReceiptLineage(preflight, {
  configFacts,
  candidateFreeze: frozen.facts,
  currentImmutableInputs,
  assetReceipt: assets.facts,
})
assertReceiptLineage(coverageGuard, {
  configFacts,
  candidateFreeze: frozen.facts,
  currentImmutableInputs,
  assetReceipt: assets.facts,
  preflightReceipt: preflightFacts,
  coverageReceipt: coverageReceiptFacts,
  coverageAnalysis: coverageAnalysisFacts,
})

const output = join(config.evidenceRoot, 'timing')
assert.equal(existsSync(output), false, `Refusing to overwrite ${output}`)
mkdirSync(output, { recursive: true })
const harness = createHarness(config, configFacts, frozen, join(output, 'harness'))
const port = config.ports.timing
const runCount = 12

const host = () => ({
  capturedAt: new Date().toISOString(),
  platform: `${platform()} ${release()}`,
  cpuModels: [...new Set(cpus().map(cpu => cpu.model))],
  logicalCpus: cpus().length,
  totalMemory: totalmem(),
  freeMemory: freemem(),
  loadAverage: loadavg(),
  uptimeSeconds: uptime(),
})
const browserProcesses = () =>
  execFileSync('ps', ['-axo', 'pid=,command='], { encoding: 'utf8' })
    .split('\n')
    .map(line => line.trim())
    .filter(line => line.includes('Google Chrome for Testing'))
const portAvailable = hostName => new Promise(resolve => {
  const server = createServer()
  server.once('error', () => resolve(false))
  server.listen(port, hostName, () => server.close(() => resolve(true)))
})

assert.equal(await portAvailable('127.0.0.1'), true)
assert.equal(await portAvailable('::1'), true)
const processesBefore = browserProcesses()
assert.deepEqual(processesBefore, [], 'Pinned Chromium is already running')

const stdoutPath = join(output, 'timing.stdout.log')
const stderrPath = join(output, 'timing.stderr.log')
writeFileSync(stdoutPath, '', { flag: 'wx' })
writeFileSync(stderrPath, '', { flag: 'wx' })
const receiptPath = join(output, 'receipt.json')
const receipt = {
  schemaVersion: 1,
  status: 'running',
  startedAt: new Date().toISOString(),
  interpretation: 'One ordinary six-slot harness callback/event-work batch. Optimized is primary; naive secondary. No added profiling/coverage/tracing and no automatic retry.',
  measurementScope: 'Standard harness instrumentation measures synchronous event work plus wrapped timeout/rAF/microtask/Promise callbacks. It does not wrap MessageChannel.port.onmessage, so no cadence arming-task CPU inclusion is claimed. Idle rAF callback time remains included.',
  quietWindowConfirmed: true,
  config: configFacts,
  candidateFreeze: frozen.facts,
  assetReceipt: assets.facts,
  preflightReceipt: preflightFacts,
  coverageGuard: coverageGuardFacts,
  immutableInputs: currentImmutableInputs,
  port,
  runCount,
  slots,
  cyclicOrdinalVisitsPerSlot: runCount / slots.length,
  hostBefore: host(),
  browserProcessesBefore: processesBefore,
  cleanup: {
    portAvailableOnIpv4: false,
    portAvailableOnIpv6: false,
    browserProcessesAfter: undefined,
  },
  limitations: [
    'Per-round output contains only totals rounded to 0.1 ms.',
    'Bucket times are independently computed summary medians, not per-run records.',
    'Counts are only the seventh result object retained by the unchanged driver for each slot.',
  ],
}
writeJson(receiptPath, receipt)

const child = spawn(config.node, [join(config.officialDriverRoot, 'run.mjs')], {
  cwd: config.officialDriverRoot,
  env: {
    ...process.env,
    CI: '1',
    LANG: 'C.UTF-8',
    LC_ALL: 'C.UTF-8',
    NO_COLOR: '1',
    HARNESS_DIR: harness,
    IMPLS: slots.map(slot => slot.name).join(','),
    RUNS: String(runCount),
    PORT: String(port),
    FOLDKIT_BENCH_CHROMIUM: config.chromium,
  },
  stdio: ['ignore', 'pipe', 'pipe'],
})
let stdout = ''
let stderr = ''
child.stdout.on('data', chunk => {
  stdout += chunk
  appendFileSync(stdoutPath, chunk)
  process.stdout.write(chunk)
})
child.stderr.on('data', chunk => {
  stderr += chunk
  appendFileSync(stderrPath, chunk)
  process.stderr.write(chunk)
})
const childOutcome = await new Promise(resolve => {
  let settled = false
  const finish = value => {
    if (!settled) {
      settled = true
      resolve(value)
    }
  }
  child.once('error', error => finish({ exitCode: null, error }))
  child.once('exit', code => finish({ exitCode: code }))
})
const exitCode = childOutcome.exitCode

receipt.exitCode = exitCode
receipt.childError = childOutcome.error?.stack
receipt.completedAt = new Date().toISOString()
receipt.hostAfter = host()
receipt.stdout = fileFacts(stdoutPath)
receipt.stderr = fileFacts(stderrPath)
receipt.stderrClassification = 'pending-readback'
receipt.cleanup.portAvailableOnIpv4 = await portAvailable('127.0.0.1')
receipt.cleanup.portAvailableOnIpv6 = await portAvailable('::1')
receipt.cleanup.browserProcessesAfter = browserProcesses()

try {
  assert.equal(exitCode, 0)
  assert.equal(receipt.cleanup.portAvailableOnIpv4, true)
  assert.equal(receipt.cleanup.portAvailableOnIpv6, true)
  assert.deepEqual(receipt.cleanup.browserProcessesAfter, [])
  const samples = [...stdout.matchAll(/^\[round (\d+)\/(\d+)\] ([^:]+): ([0-9.]+)ms$/gm)]
    .map(match => ({
      round: Number(match[1]),
      runCount: Number(match[2]),
      slot: match[3],
      totalMs: Number(match[4]),
    }))
  assert.equal(samples.length, runCount * slots.length)
  for (let roundIndex = 0; roundIndex < runCount; roundIndex += 1) {
    const actual = samples
      .filter(sample => sample.round === roundIndex + 1)
      .map(sample => sample.slot)
    const offset = roundIndex % slots.length
    const expected = [...slots.slice(offset), ...slots.slice(0, offset)].map(slot => slot.name)
    assert.deepEqual(actual, expected)
  }
  const summaries = Object.fromEntries(slots.map(slot => {
    const escaped = slot.name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
    const match = new RegExp(`^${escaped} (\\{.*\\})$`, 'm').exec(stdout)
    assert(match, `Missing summary for ${slot.name}`)
    const summary = JSON.parse(match[1])
    assert.equal(summary.crossOriginIsolated, true)
    assert.equal(summary.counts.sync, 400)
    assert.equal(summary.counts.timeout, 0)
    assert.equal(summary.counts.microtask, 0)
    assert.equal(summary.counts.promise, 0)
    if (slot.owner === 'main') assert.equal(summary.counts.animation_frame, 400)
    else assert([600, 601].includes(summary.counts.animation_frame))
    return [slot.name, summary]
  }))
  receipt.samples = samples
  receipt.summaries = summaries
  receipt.retainedRoundedTotalSamples = samples.length
  receipt.discardedSamples = 0
  receipt.perRunBucketsAvailable = false
  receipt.perRunCountsAvailable = false
  receipt.status = 'capture-complete-pending-readback'
} catch (error) {
  receipt.status = 'failed'
  receipt.error = error instanceof Error ? error.stack : String(error)
  throw error
} finally {
  assertFrozenCandidate(config, configFacts)
  writeJson(receiptPath, receipt)
}

process.stdout.write(`\nTIMING_CAPTURE_RECEIPT ${receiptPath}\n`)

