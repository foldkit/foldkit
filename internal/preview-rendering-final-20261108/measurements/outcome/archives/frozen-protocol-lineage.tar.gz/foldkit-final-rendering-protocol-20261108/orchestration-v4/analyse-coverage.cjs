const assert = require('node:assert/strict')
const { readFileSync, writeFileSync } = require('node:fs')
const { join, resolve } = require('node:path')

const { decodeCoverage, fileFacts, projection, sha256 } = require('./reference-core.cjs')

;(async () => {
const {
  assertFrozenCandidate,
  assertReceiptLineage,
  immutableInputs,
  loadAssetReceipt,
  loadConfig,
  loadReferenceAuthority,
} = await import('./common.mjs')
const configPath = resolve(process.argv[2] ?? assert.fail('Pass config.json'))
const { config, configFacts } = loadConfig(configPath)
const frozen = assertFrozenCandidate(config, configFacts)
const assets = loadAssetReceipt(config, configFacts, frozen)
const reference = loadReferenceAuthority(config, configFacts, frozen, assets)
const root = join(config.evidenceRoot, 'coverage')
const receiptPath = join(root, 'receipt.json')
const receipt = JSON.parse(readFileSync(receiptPath, 'utf8'))
assert.equal(receipt.status, 'complete')
assert.equal(receipt.browserAndServerClosed, true)
const preflightPath = join(config.evidenceRoot, 'preflight/receipt.json')
assertReceiptLineage(receipt, {
  configFacts,
  candidateFreeze: frozen.facts,
  currentImmutableInputs: immutableInputs(config),
  assetReceipt: assets.facts,
  referenceAuthority: reference.facts,
  preflightReceipt: fileFacts(preflightPath),
})
const ts = require(join(config.candidateRoot, 'node_modules/typescript/lib/typescript.js'))
assert.equal(ts.version, '6.0.3')
const results = []
for (const captured of receipt.results) {
  const decoded = decodeCoverage({
    slot: captured.name,
    role: `${captured.owner}-${captured.variant}`,
    javascriptBytes: readFileSync(captured.mapJavaScript.path),
    mapBytes: readFileSync(captured.sourceMap.path),
    captureBytes: readFileSync(captured.capture.path),
    expectedJavascriptSha256: captured.asset.sha256,
    expectedMapSha256: captured.sourceMap.sha256,
    expectedCaptureSha256: captured.capture.sha256,
    expectedFunctionCount: captured.functionCount,
    traceMapping: config.traceMapping,
    ts,
  })
  results.push({
    owner: captured.owner,
    variant: captured.variant,
    inputFacts: {
      javascript: fileFacts(captured.mapJavaScript.path),
      map: fileFacts(captured.sourceMap.path),
      capture: fileFacts(captured.capture.path),
    },
    ...projection(decoded, 'lineAwareName'),
  })
}
const output = {
  schemaVersion: 1,
  status: 'complete',
  interpretation: 'Corrected line-aware source-matched precise-coverage counts only; elapsed values are invalid.',
  config: configFacts,
  candidateFreeze: frozen.facts,
  immutableInputs: immutableInputs(config),
  assetReceipt: assets.facts,
  referenceAuthority: reference.facts,
  captureReceipt: fileFacts(receiptPath),
  parser: {
    entry: fileFacts(join(config.candidateRoot, 'node_modules/typescript/lib/typescript.js')),
    version: ts.version,
  },
  results,
}
const outputPath = join(root, 'analysis.json')
assertFrozenCandidate(config, configFacts)
writeFileSync(outputPath, `${JSON.stringify(output, null, 2)}\n`, { flag: 'wx' })
process.stdout.write(`${JSON.stringify({ outputPath, sha256: sha256(readFileSync(outputPath)) }, null, 2)}\n`)
})().catch(error => {
  process.stderr.write(`${error instanceof Error ? error.stack : String(error)}\n`)
  process.exitCode = 1
})
