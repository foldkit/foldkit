import assert from 'node:assert/strict'
import { gunzipSync } from 'node:zlib'
import {
  existsSync,
  mkdirSync,
  readFileSync,
  realpathSync,
  renameSync,
  writeFileSync,
} from 'node:fs'
import { join } from 'node:path'

import {
  assertFrozenCandidate,
  assertGrant,
  assetReceiptPath,
  copyTreeChecked,
  fileFacts,
  filesUnder,
  findJavaScriptAsset,
  immutableInputs,
  loadConfig,
  ordinaryEnvironment,
  runLogged,
  sha256,
  writeJsonExclusive,
} from './common.mjs'

const { config, configFacts } = loadConfig(process.argv[2])
assertGrant('BUILD_SLOT_GRANTED')
const frozenBefore = assertFrozenCandidate(config, configFacts)
const output = join(config.evidenceRoot, 'assets')
const mapsRoot = join(config.evidenceRoot, 'maps')
assert.equal(existsSync(output), false, `Refusing to overwrite ${output}`)
assert.equal(existsSync(mapsRoot), false, `Refusing to overwrite ${mapsRoot}`)
mkdirSync(output, { recursive: true })
mkdirSync(mapsRoot, { recursive: true })
const logs = join(output, 'logs')

const officialReceiptPath = join(
  config.repoEvidenceRoot,
  'receipts/official-final-artifact-receipt.json.gz',
)
const officialReceiptCompressed = readFileSync(officialReceiptPath)
const officialReceipt = JSON.parse(gunzipSync(officialReceiptCompressed))
assert.equal(officialReceipt.mainCommit, 'a471adb24d750ab9e8d8312edad53ff6f26d961b')
assert.equal(
  officialReceipt.mainSource.gitBlobChecksPassed,
  true,
  'Exact-main source/plugin Git-blob checks must have passed',
)
assert.equal(officialReceipt.baselineReuse.sourceGitBlobChecksPassed, true)
assert.equal(
  sha256(gunzipSync(officialReceiptCompressed)),
  '9e4713466acc76e4f063e257212f209bf8533828c92c36f6eab8cd49a9c2bbde',
)

const expectedMain = {
  naive: officialReceipt.slots['foldkit-main'].files.map(({ file: path, bytes, sha256 }) => ({ path, bytes, sha256 })),
  optimised: officialReceipt.slots['foldkit-main-optimised'].files.map(({ file: path, bytes, sha256 }) => ({ path, bytes, sha256 })),
}
for (const rows of Object.values(expectedMain)) rows.sort((a, b) => a.path.localeCompare(b.path))
assert.deepEqual(filesUnder(config.officialMainNaiveDist), expectedMain.naive)
assert.deepEqual(filesUnder(config.officialMainOptimisedDist), expectedMain.optimised)

const mainRoots = {
  naive: join(output, 'main-naive'),
  optimised: join(output, 'main-optimised'),
}
copyTreeChecked(config.officialMainNaiveDist, mainRoots.naive)
copyTreeChecked(config.officialMainOptimisedDist, mainRoots.optimised)

const commonEnv = ordinaryEnvironment()
const candidate = config.candidateRoot
const benchmarkRoot = join(candidate, 'internal/lustre-benchmark')
const pluginRoot = join(candidate, 'packages/vite-plugin-foldkit')
assert.equal(realpathSync(join(benchmarkRoot, 'node_modules/foldkit')), realpathSync(join(candidate, 'packages/foldkit')))
assert.equal(realpathSync(join(benchmarkRoot, 'node_modules/@foldkit/vite-plugin')), realpathSync(pluginRoot))

runLogged({
  config,
  name: 'clean-plugin',
  args: [config.rimraf, 'dist', 'tsconfig.tsbuildinfo'],
  cwd: pluginRoot,
  env: commonEnv,
  logRoot: logs,
})
runLogged({
  config,
  name: 'build-plugin',
  args: [join(pluginRoot, 'node_modules/typescript/bin/tsc'), '-b', 'tsconfig.json'],
  cwd: pluginRoot,
  env: commonEnv,
  logRoot: logs,
})

const currentRoots = {}
const currentMapRoots = {}
for (const variant of ['naive', 'optimised']) {
  const ordinaryRoot = join(output, `current-${variant}`)
  const mapRoot = join(mapsRoot, `current-${variant}`)
  const variantEnv = variant === 'optimised'
    ? { ...commonEnv, BUILD_VARIANT: 'optimised' }
    : commonEnv
  runLogged({
    config,
    name: `build-current-${variant}`,
    args: [config.vite, 'build', '--mode', 'production', '--outDir', ordinaryRoot],
    cwd: benchmarkRoot,
    env: variantEnv,
    logRoot: logs,
  })
  runLogged({
    config,
    name: `map-current-${variant}`,
    args: [config.vite, 'build', '--mode', 'production', '--sourcemap', 'hidden', '--outDir', mapRoot],
    cwd: benchmarkRoot,
    env: variantEnv,
    logRoot: logs,
  })
  if (variant === 'optimised') {
    for (const root of [ordinaryRoot, mapRoot]) {
      const source = join(root, 'index.optimised.html')
      const target = join(root, 'index.html')
      assert(existsSync(source), source)
      renameSync(source, target)
    }
  }
  const ordinaryAsset = findJavaScriptAsset(ordinaryRoot)
  const mapAsset = findJavaScriptAsset(mapRoot)
  assert.equal(ordinaryAsset.bytes, mapAsset.bytes)
  assert.equal(ordinaryAsset.sha256, mapAsset.sha256, `${variant} hidden-map JavaScript differs`)
  const mapPath = `${mapAsset.absolutePath}.map`
  assert(existsSync(mapPath), mapPath)
  currentRoots[variant] = ordinaryRoot
  currentMapRoots[variant] = {
    root: mapRoot,
    javascript: mapAsset,
    map: fileFacts(mapPath),
  }
}

const retainedMaps = {
  naive: {
    javascript: 'maps/foldkit-main.js.gz',
    map: 'maps/foldkit-main.js.map.gz',
    javascriptSha256: 'd3e37e9f695531f98727dadc3ead8bddd4b0bdb93f52b64029880c3d7a78adb4',
    mapSha256: 'da77296108fbefa88581c14bc2745f1055de0c7e39fa1f93583f7e51ccfd011f',
  },
  optimised: {
    javascript: 'maps/foldkit-main-optimised.js.gz',
    map: 'maps/foldkit-main-optimised.js.map.gz',
    javascriptSha256: '852eddbf31ec2d3274568f1f0d503dfeabc6e181c8d2361489b435b13ce14ded',
    mapSha256: '9d632a69c71bc066080470498aa7eab3bd60388caf1e242dd07542e65bc8710a',
  },
}
const mainMapRoots = {}
for (const [variant, retained] of Object.entries(retainedMaps)) {
  const root = join(mapsRoot, `main-${variant}`)
  mkdirSync(root, { recursive: true })
  const ordinaryAsset = findJavaScriptAsset(mainRoots[variant])
  const javascript = gunzipSync(readFileSync(join(config.repoEvidenceRoot, retained.javascript)))
  const map = gunzipSync(readFileSync(join(config.repoEvidenceRoot, retained.map)))
  assert.equal(sha256(javascript), retained.javascriptSha256)
  assert.equal(sha256(map), retained.mapSha256)
  assert.equal(sha256(javascript), ordinaryAsset.sha256)
  const javascriptPath = join(root, 'asset.js')
  const mapPath = join(root, 'asset.js.map')
  writeFileSync(javascriptPath, javascript, { flag: 'wx' })
  writeFileSync(mapPath, map, { flag: 'wx' })
  mainMapRoots[variant] = {
    root,
    javascript: fileFacts(javascriptPath),
    map: fileFacts(mapPath),
  }
}

const outputFacts = (ordinaryRoot, mapFacts) => ({
  ordinaryRoot,
  ordinaryFiles: filesUnder(ordinaryRoot),
  ordinaryAsset: findJavaScriptAsset(ordinaryRoot),
  mapRoot: mapFacts.root,
  mapJavaScript: fileFacts(
    mapFacts.javascript.absolutePath ?? mapFacts.javascript.path,
  ),
  sourceMap: mapFacts.map,
})
const receipt = {
  schemaVersion: 1,
  status: 'complete',
  createdAt: new Date().toISOString(),
  interpretation: 'Fresh current assets and byte-identical hidden-map twins; audited exact-main assets/maps copied without rebuilding main. No browser or timing.',
  config: configFacts,
  candidateFreeze: frozenBefore.facts,
  immutableInputs: immutableInputs(config),
  officialReceipt: {
    compressed: fileFacts(officialReceiptPath),
    decompressedSha256: sha256(gunzipSync(officialReceiptCompressed)),
    actualMainCommit: officialReceipt.mainCommit,
  },
  outputs: {
    main: {
      naive: outputFacts(mainRoots.naive, mainMapRoots.naive),
      optimised: outputFacts(mainRoots.optimised, mainMapRoots.optimised),
    },
    current: {
      naive: outputFacts(currentRoots.naive, currentMapRoots.naive),
      optimised: outputFacts(currentRoots.optimised, currentMapRoots.optimised),
    },
  },
  pluginDist: filesUnder(join(pluginRoot, 'dist')),
  logs: filesUnder(logs),
}
assertFrozenCandidate(config, configFacts)
writeJsonExclusive(assetReceiptPath(config), receipt)
process.stdout.write(`${JSON.stringify(receipt, null, 2)}\n`)

