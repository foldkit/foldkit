import assert from 'node:assert/strict'
import { spawnSync } from 'node:child_process'
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { pathToFileURL } from 'node:url'

import {
  assertFrozenCandidate,
  assertGrant,
  createHarness,
  fileFacts,
  findJavaScriptAsset,
  immutableInputs,
  loadAssetReceipt,
  loadConfig,
  loadReferenceAuthority,
  sha256,
  slots,
  uniqueSlots,
  writeJson,
} from './common.mjs'

const { config, configFacts } = loadConfig(process.argv[2])
assertGrant('BROWSER_SLOT_GRANTED')
const frozen = assertFrozenCandidate(config, configFacts)
const assets = loadAssetReceipt(config, configFacts, frozen)
const reference = loadReferenceAuthority(config, configFacts, frozen, assets)
const output = join(config.evidenceRoot, 'preflight')
assert.equal(existsSync(output), false, `Refusing to overwrite ${output}`)
mkdirSync(output, { recursive: true })
const harness = createHarness(config, configFacts, frozen, join(output, 'harness'))
const inputs = immutableInputs(config)
const verify = join(config.officialDriverRoot, 'verify.mjs')

const functional = []
const functionalReceiptPath = join(output, 'functional-receipt.json')
const functionalReceipt = { status: 'running', results: functional }
writeJson(functionalReceiptPath, functionalReceipt)
try {
  for (let index = 0; index < slots.length; index += 1) {
    const slot = slots[index]
    const port = config.ports.preflight + index + 1
    const result = spawnSync(config.node, [verify], {
      cwd: config.officialDriverRoot,
      env: {
        ...process.env,
        HARNESS_DIR: harness,
        IMPL: slot.name,
        PORT: String(port),
        FOLDKIT_BENCH_CHROMIUM: config.chromium,
      },
      encoding: 'utf8',
      maxBuffer: 4 * 1024 * 1024,
    })
    const logPath = join(output, `functional-${slot.name}.log`)
    const log = [
      `$ ${config.node} ${verify}`,
      `HARNESS_DIR=${harness}`,
      `IMPL=${slot.name}`,
      `PORT=${port}`,
      `exit=${result.status}`,
      '',
      'stdout:',
      result.stdout ?? '',
      '',
      'stderr:',
      result.stderr ?? '',
      '',
      `error=${result.error?.message ?? ''}`,
    ].join('\n')
    writeFileSync(logPath, log, { flag: 'wx' })
    functional.push({ ...slot, port, exitCode: result.status, log: fileFacts(logPath) })
    writeJson(functionalReceiptPath, functionalReceipt)
    assert.equal(result.status, 0, `${slot.name} functional check failed`)
    assert.match(result.stdout, new RegExp(`VERIFY ${slot.name}: OK`))
  }
  functionalReceipt.status = 'complete'
} catch (error) {
  functionalReceipt.status = 'failed'
  functionalReceipt.error = error instanceof Error ? error.stack : String(error)
  throw error
} finally {
  writeJson(functionalReceiptPath, functionalReceipt)
}

const { chromium } = await import(
  pathToFileURL(join(config.officialDriverRoot, 'node_modules/playwright/index.mjs')).href
)
const { startServer } = await import(
  pathToFileURL(join(config.officialDriverRoot, 'server.mjs')).href
)
const port = config.ports.preflight
const receiptPath = join(output, 'receipt.json')
const receipt = {
  schemaVersion: 1,
  status: 'running',
  interpretation: 'Functional and one-result callback/count guards only. Raw elapsed fields are retained but are not timing evidence.',
  measurementScope: 'Standard harness callback/event instrumentation; no Debugger, CPU profiler, coverage or tracing. MessageChannel.port.onmessage arming-task CPU is not measured.',
  config: configFacts,
  candidateFreeze: frozen.facts,
  assetReceipt: assets.facts,
  referenceAuthority: reference.facts,
  immutableInputs: inputs,
  functional,
  functionalReceipt: fileFacts(functionalReceiptPath),
  port,
  results: [],
  browserAndServerClosed: false,
}
writeJson(receiptPath, receipt)

const server = await startServer(harness, config.officialDriverRoot, port)
let browser
try {
  browser = await chromium.launch({ headless: true, executablePath: config.chromium })
  receipt.chromiumVersion = browser.version()
  const baseUrl = `http://localhost:${port}`
  for (const slot of uniqueSlots) {
    const context = await browser.newContext()
    try {
      await context.route(/unpkg\.com|todomvc\.com/, route =>
        route.fulfill({
          status: 200,
          contentType: 'text/css',
          headers: { 'Cross-Origin-Resource-Policy': 'cross-origin' },
          body: '',
        }),
      )
      const page = await context.newPage()
      let pageError
      page.on('pageerror', error => { pageError ??= error })
      await page.goto(`${baseUrl}/__runner/runner.html`)
      const root = assets.receipt.outputs[slot.owner][slot.variant].ordinaryRoot
      const asset = findJavaScriptAsset(root)
      const assetUrl = `${baseUrl}/priv/implementations/${slot.name}/dist/${asset.path}`
      const response = await context.request.get(assetUrl)
      assert.equal(response.status(), 200)
      const served = await response.body()
      assert.equal(served.length, asset.bytes)
      assert.equal(sha256(served), asset.sha256)

      const result = await page.evaluate(
        ([url, itemCount]) => window.runBenchmark(url, itemCount),
        [`${baseUrl}/priv/implementations/${slot.name}/dist/index.html`, 100],
      )
      assert.equal(pageError, undefined)
      assert.equal(result.crossOriginIsolated, true)
      const expectedAnimationFrame = slot.owner === 'main' ? [400] : [600, 601]
      assert.equal(result.counts.sync, 400)
      assert(expectedAnimationFrame.includes(result.counts.animation_frame))
      assert.equal(result.counts.timeout, 0)
      assert.equal(result.counts.microtask, 0)
      assert.equal(result.counts.promise, 0)
      const finalDom = await page.evaluate(() => {
        const document_ = document.querySelector('#benchmark')?.contentDocument
        return {
          hasNewTodo: Boolean(document_?.querySelector('.new-todo')),
          todoCount: document_?.querySelectorAll('.todo-list > li').length,
        }
      })
      assert.deepEqual(finalDom, { hasNewTodo: true, todoCount: 0 })
      receipt.results.push({
        ...slot,
        asset: { ...asset, servedSha256: sha256(served) },
        result,
        finalDom,
        acceptedAnimationFrameCounts: expectedAnimationFrame,
      })
      writeJson(receiptPath, receipt)
    } finally {
      await context.close()
    }
  }
  receipt.status = 'complete'
} catch (error) {
  receipt.status = 'failed'
  receipt.error = error instanceof Error ? error.stack : String(error)
  throw error
} finally {
  if (browser !== undefined) await browser.close()
  await new Promise((resolve, reject) =>
    server.close(error => (error ? reject(error) : resolve())),
  )
  receipt.browserAndServerClosed = true
  assertFrozenCandidate(config, configFacts)
  writeJson(receiptPath, receipt)
}

process.stdout.write(`${JSON.stringify(receipt, null, 2)}\n`)

