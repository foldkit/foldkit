import { createHash } from 'node:crypto'
import { readFileSync, readdirSync, statSync, writeFileSync } from 'node:fs'
import { dirname, join, relative } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = dirname(fileURLToPath(import.meta.url))
const output = join(root, 'preparation-manifest.json')
const sha256 = value => createHash('sha256').update(value).digest('hex')
const files = []
const visit = path => {
  for (const entry of readdirSync(path, { withFileTypes: true })) {
    const child = join(path, entry.name)
    const name = relative(root, child)
    if (name === 'preparation-manifest.json') continue
    if (entry.isDirectory()) visit(child)
    else if (entry.isFile()) {
      const bytes = readFileSync(child)
      files.push({ path: name, bytes: bytes.length, sha256: sha256(bytes) })
    }
  }
}
visit(root)
files.sort((left, right) => left.path.localeCompare(right.path))
const manifest = {
  schemaVersion: 1,
  status: 'prepared-not-executed',
  createdAt: new Date().toISOString(),
  interpretation: 'Source-only orchestration and preserved cadence evidence. No asset build, browser, coverage, compiler or timing stage was executed by this preparation.',
  files,
}
writeFileSync(output, `${JSON.stringify(manifest, null, 2)}\n`, { flag: 'wx' })
process.stdout.write(`${JSON.stringify({ output, files: files.length, sha256: sha256(readFileSync(output)) }, null, 2)}\n`)
