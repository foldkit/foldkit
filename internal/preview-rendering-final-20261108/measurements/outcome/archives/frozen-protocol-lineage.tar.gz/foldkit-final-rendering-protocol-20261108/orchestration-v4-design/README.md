# Rendering protocol v4 design proof

This directory is an additive, offline-only repair proposal. It does not alter
or reinterpret the frozen v3 captures. No build, browser, coverage capture, or
ordinary timing is launched here.

The reference builder decodes the four authenticated old raw coverage files
twice from the same source-map mapping. The legacy name projection must exactly
reproduce the committed published analysis. The line-aware projection is then
the independent authority for v4. The three relocated `html/index.ts` owners
are shifted by exactly 630 lines only after exact source-map/Git source equality
and complete initializer/body hash equality are established.

The eventual fresh v4 chain must generate and freeze this authority after its
asset stage and before preflight or coverage. A new capture may be compared to
this authority but may never define it.

## Offline proof result

The authoritative design outputs are:

- `reference-authority-v4.json`: complete pre-capture authority. The legacy
  projection exactly reproduces all four committed published inventories. Its
  corrected line-aware projection records the v3 comparator-label drift, the
  exact three-owner `html/index.ts` relocation, corrected cadence-owner rows,
  and a complete classification of every source owner used by the guard.
- `reanalysed-existing-v4.json`: corrected-parser reanalysis of retained raw
  captures. It is validation input only and defines no expected row.
- `guard-proof-v3.json`: one full offline pass over the retained current
  capture using only the independent authority.
- `offline-negative-controls-v4.json`: 34 controls, including the canonical
  authority/full guard and expected failures for legacy-label, raw/map/source,
  initializer/body/delta, outer/nested/zero row, positive-work, closed zero
  delta, position, and downstream-lineage mutations.

Earlier `reference-authority.json`, `reference-authority-v2.json`,
`reference-authority-v3.json`, `guard-proof.json`, and `guard-proof-v2.json`
are retained design iterations, not v4 authority. The first full guard attempt
also exposed and corrected a reference-selection bug: `html/lazy.ts` is
byte-identical between authenticated preview-current and frozen current source.
Its separately positioned owner inventories pass exactly; only cross-owner
logical work is compared because exact-main and preview-current legitimately
have different source positions.
