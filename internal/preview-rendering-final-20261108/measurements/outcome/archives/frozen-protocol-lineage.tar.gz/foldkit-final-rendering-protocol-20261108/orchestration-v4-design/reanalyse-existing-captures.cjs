const assert = require('node:assert/strict')
const { readFileSync, writeFileSync } = require('node:fs')
const { resolve } = require('node:path')

const {
  decodeCoverage,
  fileFacts,
  json,
  projection,
} = require('./reference-core.cjs')

const configPath = resolve(process.argv[2] ?? assert.fail('Pass existing-capture config'))
const config = json(configPath)
const ts = require(config.typescript)
assert.equal(ts.version, '6.0.3')
const results = []

const decodeReceipt = ({ receiptPath, inputs, kind }) => {
  const receipt = json(receiptPath)
  assert.equal(receipt.status, 'complete')
  assert.equal(receipt.browserAndServerClosed, true)
  for (const captured of receipt.results) {
    const key = captured.name ?? `${kind}-${captured.variant}`
    const input = inputs[key] ?? assert.fail(`Missing ${kind} input ${key}`)
    const asset = captured.asset
    const sourceMap = captured.sourceMap ?? captured.map
    const capture = captured.capture ?? {
      path: input.capture,
      bytes: captured.captureBytes,
      sha256: captured.captureSha256,
    }
    const decoded = decodeCoverage({
      slot: key,
      role: input.role,
      javascriptBytes: readFileSync(input.javascript),
      mapBytes: readFileSync(input.map),
      captureBytes: readFileSync(input.capture),
      expectedJavascriptSha256: asset.sha256,
      expectedMapSha256: sourceMap.sha256,
      expectedCaptureSha256: capture.sha256,
      expectedFunctionCount: captured.functionCount,
      traceMapping: config.traceMapping,
      ts,
    })
    results.push({
      kind,
      owner: input.owner,
      variant: input.variant,
      inputFacts: {
        javascript: fileFacts(input.javascript),
        map: fileFacts(input.map),
        capture: fileFacts(input.capture),
      },
      ...projection(decoded, 'lineAwareName'),
    })
  }
}

decodeReceipt({
  receiptPath: config.currentReceipt,
  inputs: config.currentInputs,
  kind: 'current-v3-capture',
})
decodeReceipt({
  receiptPath: config.cadenceReceipt,
  inputs: config.cadenceInputs,
  kind: 'cadence-owner-reference',
})

const output = {
  schemaVersion: 1,
  status: 'pass',
  interpretation: 'Offline v4 line-aware reanalysis of retained raw captures only; no browser, build, coverage capture, or timing process.',
  config: fileFacts(configPath),
  parser: { entry: fileFacts(config.typescript), version: ts.version },
  referenceAuthority: fileFacts(config.referenceAuthority),
  results,
}
writeFileSync(config.output, `${JSON.stringify(output, null, 2)}\n`, { flag: 'wx' })
process.stdout.write(`${JSON.stringify({ output: config.output, facts: fileFacts(config.output) }, null, 2)}\n`)
