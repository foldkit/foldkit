const assert = require('node:assert/strict')
const { readFileSync, writeFileSync } = require('node:fs')
const { dirname, join, resolve } = require('node:path')
const { gunzipSync } = require('node:zlib')

const {
  assertLegacyProjection,
  decodeCoverage,
  fileFacts,
  findOptionalSourceContent,
  findSourceContent,
  initializerFacts,
  json,
  projection,
  readStored,
  relocateOwnerRows,
  sha256,
} = require('./reference-core.cjs')

const configPath = resolve(process.argv[2] ?? assert.fail('Pass v4 authority config'))
const config = json(configPath)
const ts = require(config.typescript)
assert.equal(ts.version, '6.0.3')
const officialManifest = json(config.officialManifest)
const coverageReceipt = json(config.officialCoverageReceipt)
const durableOldCapturesReceipt = json(config.durableOldCapturesReceipt)
assert.equal(durableOldCapturesReceipt.status, 'complete')
assert.equal(
  durableOldCapturesReceipt.officialCoverageReceipt.sha256,
  fileFacts(config.officialCoverageReceipt).sha256,
  'Durable old-capture receipt does not bind the official coverage receipt',
)
const published = JSON.parse(gunzipSync(readFileSync(config.publishedAnalysis)))

const manifestEntry = storedPath => officialManifest.entries.find(
  entry => entry.storedPath === storedPath,
) ?? assert.fail(`Missing official manifest entry ${storedPath}`)
const assertStored = (path, storedPath) => {
  const facts = fileFacts(path)
  const expected = manifestEntry(storedPath)
  assert.equal(facts.bytes, expected.storedBytes, `${storedPath}: stored byte count differs`)
  assert.equal(facts.sha256, expected.storedSha256, `${storedPath}: stored hash differs`)
  return { ...facts, storedPath, sourceSha256: expected.sourceSha256 }
}

const officialInputs = {
  manifest: fileFacts(config.officialManifest),
  coverageReceipt: assertStored(
    config.officialCoverageReceipt,
    'receipts/coverage-receipt.json',
  ),
  publishedAnalysis: assertStored(
    config.publishedAnalysis,
    'analysis/source-matched-analysis-final.json.gz',
  ),
  durableOldCapturesReceipt: fileFacts(config.durableOldCapturesReceipt),
}
const slots = [
  ['foldkit-main-optimised', 'main-optimized', 'foldkit-main-optimised'],
  ['foldkit-preview-final-optimised', 'preview-optimized', 'foldkit-preview-final-optimised'],
  ['foldkit-main', 'main-naive', 'foldkit-main'],
  ['foldkit-preview-final', 'preview-naive', 'foldkit-preview-final'],
]
const dualResults = []
officialInputs.slots = {}
for (const [slot, role, stem] of slots) {
  const captured = coverageReceipt.results.find(result => result.slot === slot)
    ?? assert.fail(`Missing official capture receipt ${slot}`)
  const javascriptPath = join(config.officialEvidenceRoot, `maps/${stem}.js.gz`)
  const mapPath = join(config.officialEvidenceRoot, `maps/${stem}.js.map.gz`)
  const capturePath = join(config.officialRawCoverageRoot, `${captured.captureFile}.gz`)
  const javascript = assertStored(javascriptPath, `maps/${stem}.js.gz`)
  const sourceMap = assertStored(mapPath, `maps/${stem}.js.map.gz`)
  const captureStored = fileFacts(capturePath)
  const durableCapture = durableOldCapturesReceipt.captures.find(item => item.slot === slot)
    ?? assert.fail(`Missing durable old capture ${slot}`)
  assert.equal(captureStored.bytes, durableCapture.storedBytes, `${slot}: stored capture bytes differ`)
  assert.equal(captureStored.sha256, durableCapture.storedSha256, `${slot}: stored capture hash differs`)
  const captureBytes = readStored(capturePath)
  const capture = {
    ...captureStored,
    sourceBytes: captureBytes.length,
    sourceSha256: sha256(captureBytes),
  }
  assert.equal(capture.sourceBytes, captured.captureBytes, `${slot}: raw capture bytes differ`)
  assert.equal(capture.sourceSha256, captured.captureSha256, `${slot}: raw capture hash differs`)
  officialInputs.slots[slot] = { javascript, sourceMap, capture }
  dualResults.push(decodeCoverage({
    slot,
    role,
    javascriptBytes: readStored(javascriptPath),
    mapBytes: readStored(mapPath),
    captureBytes,
    expectedJavascriptSha256: javascript.sourceSha256,
    expectedMapSha256: sourceMap.sourceSha256,
    expectedCaptureSha256: capture.sourceSha256,
    expectedFunctionCount: captured.functionCount,
    traceMapping: config.traceMapping,
    ts,
  }))
}

const legacyResults = dualResults.map(result => projection(result, 'legacyName'))
const lineAwareResults = dualResults.map(result => projection(result, 'lineAwareName'))
const v3ObservedResults = dualResults.map(result => projection(result, 'v3ObservedName'))
assertLegacyProjection(legacyResults, published.coverageResults)

const currentGitSource = readFileSync(config.currentHtmlGitSource, 'utf8')
const currentMapBytesByVariant = new Map()
const currentMapSources = []
for (const [variant, mapPath] of Object.entries(config.currentSourceMaps)) {
  const mapBytes = readFileSync(mapPath)
  currentMapBytesByVariant.set(variant, mapBytes)
  const mapped = findSourceContent(mapBytes, 'packages/foldkit/src/html/index.ts')
  assert.equal(mapped.content, currentGitSource, `${variant}: current map source differs from frozen Git source`)
  currentMapSources.push({
    variant,
    map: fileFacts(mapPath),
    mapSourcePath: mapped.source,
    sourceBytes: Buffer.byteLength(mapped.content),
    sourceSha256: sha256(mapped.content),
  })
}
assert(currentMapSources.length > 0)
for (const item of currentMapSources) {
  assert.equal(item.sourceSha256, sha256(currentGitSource))
}

const oldMapSources = []
for (const [slot, , stem] of slots.filter(([slot]) => slot.startsWith('foldkit-preview-final'))) {
  const mapPath = join(config.officialEvidenceRoot, `maps/${stem}.js.map.gz`)
  const mapped = findSourceContent(readStored(mapPath), 'packages/foldkit/src/html/index.ts')
  oldMapSources.push({
    slot,
    mapSourcePath: mapped.source,
    sourceBytes: Buffer.byteLength(mapped.content),
    sourceSha256: sha256(mapped.content),
    content: mapped.content,
  })
}
assert.equal(oldMapSources[0].content, oldMapSources[1].content, 'Old optimized/naive Html sources differ')
const oldHtmlSource = oldMapSources[0].content
const owners = ['buildVNodeData', 'copyChildrenDroppingEmpty', 'buildElement']
const expectedFingerprints = {
  buildVNodeData: {
    initializerSha256: 'e3584c5e2f2365f3c687308f9d3c0e1b10c33c6037e2fda964c8d3177de7ca7a',
    bodySha256: '3410d787bb45c38e24e4ee9178db9688d2b88e6e45ee56afa4778df21505487c',
    oldLine: 2925,
    currentLine: 3555,
  },
  copyChildrenDroppingEmpty: {
    initializerSha256: '4b6c4b7cb14814c3cf92f934c834a897aae49b7d46500cc3279c4acd0a1106dd',
    bodySha256: '4af7d81646d0f26c738898e599d495596de58cd20a2ecd4cdbc80836a64660be',
    oldLine: 3010,
    currentLine: 3640,
  },
  buildElement: {
    initializerSha256: 'ba9eea5153f9c3f5ac0cbf5576d4330f540281f67bd1253f9159ab0e5f04e11a',
    bodySha256: '20c309e3a8beba8f09d0adc7775bff3f0f4bda1f4b01d64c98dad1f91f20169c',
    oldLine: 3358,
    currentLine: 3988,
  },
}
const fingerprints = {}
const deltas = new Set()
for (const owner of owners) {
  const oldFacts = initializerFacts(ts, oldHtmlSource, owner)
  const currentFacts = initializerFacts(ts, currentGitSource, owner)
  const expected = expectedFingerprints[owner]
  assert.equal(oldFacts.initializerSha256, expected.initializerSha256, `${owner}: old initializer hash differs`)
  assert.equal(currentFacts.initializerSha256, expected.initializerSha256, `${owner}: current initializer hash differs`)
  assert.equal(oldFacts.bodySha256, expected.bodySha256, `${owner}: old body hash differs`)
  assert.equal(currentFacts.bodySha256, expected.bodySha256, `${owner}: current body hash differs`)
  assert.equal(oldFacts.declarationLine, expected.oldLine, `${owner}: old declaration line differs`)
  assert.equal(currentFacts.declarationLine, expected.currentLine, `${owner}: current declaration line differs`)
  assert.equal(oldFacts.declarationColumn, 6, `${owner}: old declaration column differs`)
  assert.equal(currentFacts.declarationColumn, 6, `${owner}: current declaration column differs`)
  const lineDelta = currentFacts.declarationLine - oldFacts.declarationLine
  deltas.add(lineDelta)
  fingerprints[owner] = { old: oldFacts, current: currentFacts, lineDelta }
}
assert.deepEqual([...deltas], [630], 'Html owner relocation is not one exact +630-line shift')

// Inventory every source owner the guard uses before a fresh capture exists.
// Exact-preview sources remain byte-identical. Html/index has the three
// explicitly proven +630 owners above. Renderer authority comes from the
// separately authenticated cadence capture whose source must equal final Git.
const oldMapBytesByVariant = new Map([
  ['optimised', readStored(join(config.officialEvidenceRoot, 'maps/foldkit-preview-final-optimised.js.map.gz'))],
  ['naive', readStored(join(config.officialEvidenceRoot, 'maps/foldkit-preview-final.js.map.gz'))],
])
const sourceOwners = [
  ['src/todo.ts', 'internal/lustre-benchmark/src/todo.ts', 'byte-identical-preview-current'],
  ['src/view.optimised.ts', 'internal/lustre-benchmark/src/view.optimised.ts', 'byte-identical-preview-current'],
  ['packages/foldkit/src/html/lazy.ts', 'packages/foldkit/src/html/lazy.ts', 'byte-identical-preview-current'],
  ['packages/foldkit/src/vdom.ts', 'packages/foldkit/src/vdom.ts', 'byte-identical-preview-current'],
  ['packages/foldkit/src/snabbdom/init.ts', 'packages/foldkit/src/snabbdom/init.ts', 'byte-identical-preview-current'],
  ['packages/foldkit/src/block/delivery.ts', 'packages/foldkit/src/block/delivery.ts', 'byte-identical-preview-current'],
  ['packages/foldkit/src/html/index.ts', 'packages/foldkit/src/html/index.ts', 'three-owner-exact-relocation'],
  ['packages/foldkit/src/runtime/renderer.ts', 'packages/foldkit/src/runtime/renderer.ts', 'cadence-owner-reference'],
]
const guardedSourceInventory = []
for (const [mapSuffix, gitRelativePath, classification] of sourceOwners) {
  const gitPath = join(config.candidateRoot, gitRelativePath)
  const gitSource = readFileSync(gitPath, 'utf8')
  const variants = {}
  for (const variant of ['optimised', 'naive']) {
    const oldMapped = findOptionalSourceContent(oldMapBytesByVariant.get(variant), mapSuffix)
    const currentMapped = findOptionalSourceContent(currentMapBytesByVariant.get(variant), mapSuffix)
    assert.equal(Boolean(currentMapped), Boolean(oldMapped), `${gitRelativePath}: ${variant} owner presence differs`)
    if (!currentMapped) {
      variants[variant] = { present: false }
      continue
    }
    assert.equal(currentMapped.content, gitSource, `${gitRelativePath}: ${variant} current map differs from frozen Git`)
    if (classification === 'byte-identical-preview-current') {
      assert.equal(oldMapped.content, currentMapped.content, `${gitRelativePath}: ${variant} expected byte-identical preview/current source`)
    } else {
      assert.notEqual(oldMapped.content, currentMapped.content, `${gitRelativePath}: ${variant} expected classified source difference`)
    }
    variants[variant] = {
      present: true,
      oldMapSourcePath: oldMapped.source,
      oldPreviewSourceSha256: sha256(oldMapped.content),
      currentMapSourcePath: currentMapped.source,
      currentMapSourceSha256: sha256(currentMapped.content),
    }
  }
  guardedSourceInventory.push({
    mapSuffix,
    gitRelativePath,
    classification,
    variants,
    currentGitSource: fileFacts(gitPath),
  })
}

const cadenceReceipt = json(config.cadenceReceipt)
assert.equal(cadenceReceipt.status, 'complete')
assert.equal(cadenceReceipt.browserAndServerClosed, true)
const cadenceLineAwareReferences = []
const cadenceInputs = { receipt: fileFacts(config.cadenceReceipt), variants: {} }
for (const variant of ['optimised', 'naive']) {
  const captured = cadenceReceipt.results.find(result => result.variant === variant)
    ?? assert.fail(`Missing cadence ${variant}`)
  const input = config.cadenceInputs[variant]
  const javascript = fileFacts(input.javascript)
  const sourceMap = fileFacts(input.map)
  const capture = fileFacts(input.capture)
  assert.equal(javascript.sha256, captured.asset.sha256, `${variant}: cadence JavaScript differs`)
  assert.equal(sourceMap.sha256, captured.map.sha256, `${variant}: cadence map differs`)
  assert.equal(capture.sha256, captured.captureSha256, `${variant}: cadence capture differs`)
  const mappedRenderer = findSourceContent(readFileSync(input.map), 'packages/foldkit/src/runtime/renderer.ts')
  const rendererGit = readFileSync(join(config.candidateRoot, 'packages/foldkit/src/runtime/renderer.ts'), 'utf8')
  assert.equal(mappedRenderer.content, rendererGit, `${variant}: cadence renderer source differs from frozen Git`)
  cadenceInputs.variants[variant] = { javascript, sourceMap, capture }
  const decoded = decodeCoverage({
    slot: `cadence-${variant}`,
    role: `cadence-owner-${variant}`,
    javascriptBytes: readFileSync(input.javascript),
    mapBytes: readFileSync(input.map),
    captureBytes: readFileSync(input.capture),
    expectedJavascriptSha256: javascript.sha256,
    expectedMapSha256: sourceMap.sha256,
    expectedCaptureSha256: capture.sha256,
    expectedFunctionCount: captured.functionCount,
    traceMapping: config.traceMapping,
    ts,
  })
  cadenceLineAwareReferences.push(projection(decoded, 'lineAwareName'))
}

const relocatedPreviewReferences = lineAwareResults
  .filter(result => result.slot.startsWith('foldkit-preview-final'))
  .map(result => relocateOwnerRows(
    result,
    'packages/foldkit/src/html/index.ts',
    owners,
    630,
  ))

const labelDrift = lineAwareResults.map(lineAware => {
  const observed = v3ObservedResults.find(result => result.slot === lineAware.slot)
  const changed = []
  for (let index = 0; index < lineAware.relevantFunctions.length; index += 1) {
    const after = lineAware.relevantFunctions[index]
    const before = observed.relevantFunctions[index]
    if (before.name !== after.name) changed.push({
      source: after.source,
      sourceLine: after.sourceLine,
      sourceColumn: after.sourceColumn,
      count: after.count,
      v3ObservedName: before.name,
      lineAwareName: after.name,
    })
  }
  return { slot: lineAware.slot, changedRows: changed }
})

const authority = {
  schemaVersion: 1,
  status: 'pass',
  interpretation: 'Independent pre-capture v4 owner authority reconstructed from the four authenticated old raw precise-coverage captures and exact maps. Legacy labels reproduce the published inventory; line-aware labels correct parser-only drift. Three Html owner inventories are translated exactly +630 lines only after byte-authenticated map/Git source and complete initializer/body identity checks.',
  config: fileFacts(configPath),
  scripts: {
    builder: fileFacts(__filename),
    core: fileFacts(join(__dirname, 'reference-core.cjs')),
  },
  parser: {
    entry: fileFacts(config.typescript),
    version: ts.version,
  },
  traceMapping: fileFacts(require.resolve(config.traceMapping)),
  officialInputs,
  publishedLegacyProjectionReproduced: true,
  legacyProjection: legacyResults,
  labelDrift,
  lineAwareReferences: lineAwareResults,
  cadenceInputs,
  cadenceLineAwareReferences,
  guardedSourceInventory,
  htmlRelocation: {
    source: 'packages/foldkit/src/html/index.ts',
    oldMapSources: oldMapSources.map(({ content, ...item }) => item),
    currentGitSource: fileFacts(config.currentHtmlGitSource),
    currentMapSources,
    owners,
    fingerprints,
    lineDelta: 630,
    relocatedPreviewReferences,
  },
}
const outputPath = resolve(config.output)
writeFileSync(outputPath, `${JSON.stringify(authority, null, 2)}\n`, { flag: 'wx' })
process.stdout.write(`${JSON.stringify({ outputPath, facts: fileFacts(outputPath) }, null, 2)}\n`)
