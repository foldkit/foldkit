import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { readFileSync, writeFileSync } from 'node:fs'
import { resolve } from 'node:path'

import { assertAuthorityStatic } from './authority-guards-v4.mjs'
import { verifyV4 } from './verify-existing-v4.mjs'

const read = path => JSON.parse(readFileSync(path, 'utf8'))
const authorityPath = process.argv[2]
const analysisPath = process.argv[3]
const publishedPath = process.argv[4]
const outputPath = process.argv[5]
const authority = read(authorityPath)
const analysis = read(analysisPath)
const authorityBytes = readFileSync(authorityPath)
const authorityFacts = {
  path: resolve(authorityPath),
  bytes: authorityBytes.length,
  sha256: createHash('sha256').update(authorityBytes).digest('hex'),
}
const verifierOptions = { publishedAnalysisPath: publishedPath, authorityFacts }
const clone = value => structuredClone(value)
const controls = []
const pass = name => controls.push({ name, status: 'pass' })
const expectFailure = (name, run, pattern) => {
  let error
  try { run() } catch (caught) { error = caught }
  assert(error instanceof Error, `${name} unexpectedly passed`)
  assert.match(error.message, pattern, `${name} failed at an unexpected assertion`)
  controls.push({ name, status: 'expected-failure-observed', message: error.message.split('\n')[0] })
}
const currentResult = (data, owner, variant) => data.results.find(result =>
  result.kind === 'current-v3-capture' && result.owner === owner && result.variant === variant)
  ?? assert.fail(`Missing ${owner} ${variant}`)
const mutateRow = (data, owner, variant, predicate, mutation) => {
  const result = currentResult(data, owner, variant)
  const index = result.relevantFunctions.findIndex(predicate)
  assert.notEqual(index, -1, 'Mutation row not found')
  mutation(result.relevantFunctions, index)
}
const expectVerifyFailure = (name, mutate, pattern = /differs|delta/) => {
  const mutated = clone(analysis)
  mutate(mutated)
  expectFailure(name, () => verifyV4(authority, mutated, verifierOptions), pattern)
}

assertAuthorityStatic(authority, publishedPath)
pass('canonical-static-reference-authority')
verifyV4(authority, analysis, verifierOptions)
pass('canonical-full-v4-guard')

const authorityMutation = (name, mutate, pattern) => {
  const changed = clone(authority)
  mutate(changed)
  expectFailure(name, () => assertAuthorityStatic(changed, publishedPath), pattern)
}
authorityMutation('legacy-projection-label-change-fails', value => {
  value.legacyProjection[0].relevantFunctions[0].name += 'Changed'
}, /legacy projection differs/)
authorityMutation('old-raw-capture-hash-change-fails', value => {
  value.officialInputs.slots['foldkit-main-optimised'].capture.sourceSha256 = 'changed'
}, /raw capture authority differs/)
authorityMutation('old-map-hash-change-fails', value => {
  value.officialInputs.slots['foldkit-main-optimised'].sourceMap.sourceSha256 = 'changed'
}, /decompressed map authority differs/)
authorityMutation('current-map-git-source-change-fails', value => {
  value.guardedSourceInventory.find(row => row.mapSuffix === 'packages/foldkit/src/vdom.ts').currentGitSource.sha256 = 'changed'
}, /Git source differs/)
authorityMutation('naive-owner-map-source-change-fails', value => {
  value.guardedSourceInventory.find(row => row.mapSuffix === 'packages/foldkit/src/vdom.ts').variants.naive.currentMapSourceSha256 = 'changed'
}, /naive map source differs/)
authorityMutation('html-initializer-change-fails', value => {
  value.htmlRelocation.fingerprints.buildVNodeData.current.initializerSha256 = 'changed'
}, /initializer differs/)
authorityMutation('html-body-change-fails', value => {
  value.htmlRelocation.fingerprints.buildVNodeData.current.bodySha256 = 'changed'
}, /body differs/)
authorityMutation('html-delta-change-fails', value => {
  value.htmlRelocation.fingerprints.buildVNodeData.lineDelta = 629
}, /line delta differs/)
authorityMutation('line-aware-nested-label-change-fails', value => {
  const row = value.htmlRelocation.relocatedPreviewReferences[0].relevantFunctions.find(item =>
    item.name === 'buildVNodeData.getSharedPostpatchProps')
  row.name = 'buildVNodeData'
}, /Complete relocated preview reference differs/)
authorityMutation('relocated-owner-position-change-fails', value => {
  const row = value.htmlRelocation.relocatedPreviewReferences[0].relevantFunctions.find(item =>
    item.name === 'buildVNodeData' && item.count === 3906)
  row.sourceLine += 1
}, /Complete relocated preview reference differs/)
authorityMutation('relocated-build-element-count-change-fails', value => {
  const row = value.htmlRelocation.relocatedPreviewReferences[0].relevantFunctions.find(item =>
    item.name === 'buildElement')
  row.count += 1
}, /Complete relocated preview reference differs/)
authorityMutation('relocated-normalize-position-change-fails', value => {
  const row = value.htmlRelocation.relocatedPreviewReferences[0].relevantFunctions.find(item =>
    item.name === 'copyChildrenDroppingEmpty')
  row.sourceLine += 1
}, /Complete relocated preview reference differs/)
authorityMutation('relocated-build-element-owner-change-fails', value => {
  const row = value.htmlRelocation.relocatedPreviewReferences[0].relevantFunctions.find(item =>
    item.name === 'buildElement')
  row.name = 'buildElementChanged'
}, /Complete relocated preview reference differs/)

const applicationPositive = row => row.source.endsWith('/todo.ts') && row.name === 'filterTodos' && row.count > 0
expectVerifyFailure('positive-application-row-added-fails', data => {
  currentResult(data, 'current', 'optimised').relevantFunctions.push({
    source: 'internal/lustre-benchmark/src/todo.ts', name: 'inventedPositive', sourceLine: 999, sourceColumn: 0, count: 1,
  })
}, /positive application inventory differs/)
expectVerifyFailure('positive-application-row-removed-fails', data => {
  mutateRow(data, 'current', 'optimised', applicationPositive, (rows, index) => rows.splice(index, 1))
}, /positive application inventory differs/)
expectVerifyFailure('positive-application-row-count-change-fails', data => {
  mutateRow(data, 'current', 'optimised', applicationPositive, (rows, index) => { rows[index].count += 1 })
}, /positive application inventory differs/)

const expectedZero = row => row.source.endsWith('/todo.ts') && row.name === 'todoItemClass' && row.count === 0
expectVerifyFailure('expected-zero-becomes-positive-fails', data => {
  mutateRow(data, 'current', 'optimised', expectedZero, (rows, index) => { rows[index].count = 1 })
}, /positive application inventory differs|zero delta differs/)
expectVerifyFailure('expected-zero-removed-fails', data => {
  mutateRow(data, 'current', 'optimised', expectedZero, (rows, index) => rows.splice(index, 1))
}, /zero delta differs/)
expectVerifyFailure('expected-zero-moved-fails', data => {
  mutateRow(data, 'current', 'optimised', expectedZero, (rows, index) => { rows[index].sourceLine += 1 })
}, /zero delta differs/)
expectVerifyFailure('unexpected-current-zero-fails', data => {
  currentResult(data, 'current', 'optimised').relevantFunctions.push({
    source: 'internal/lustre-benchmark/src/todo.ts', name: 'unexpectedZero', sourceLine: 998, sourceColumn: 0, count: 0,
  })
}, /zero delta differs/)
expectVerifyFailure('unexpected-main-zero-fails', data => {
  currentResult(data, 'main', 'optimised').relevantFunctions.push({
    source: 'internal/lustre-benchmark/src/todo.ts', name: 'unexpectedMainZero', sourceLine: 998, sourceColumn: 0, count: 0,
  })
}, /main application inventory differs/)
expectVerifyFailure('naive-zero-delta-nonempty-fails', data => {
  currentResult(data, 'current', 'naive').relevantFunctions.push({
    source: 'internal/lustre-benchmark/src/todo.ts', name: 'unexpectedNaiveZero', sourceLine: 998, sourceColumn: 0, count: 0,
  })
}, /zero delta differs/)

const outerBuild = row => row.source === 'packages/foldkit/src/html/index.ts' && row.name === 'buildVNodeData' && row.count === 3906
const nestedBuild = row => row.source === 'packages/foldkit/src/html/index.ts' && row.name === 'buildVNodeData.getSharedPostpatchProps'
const zeroBuild = row => row.source === 'packages/foldkit/src/html/index.ts' && row.name === 'buildVNodeData' && row.count === 0
expectVerifyFailure('html-outer-row-added-fails', data => {
  const result = currentResult(data, 'current', 'optimised')
  result.relevantFunctions.push({ ...result.relevantFunctions.find(outerBuild), sourceColumn: 3 })
}, /positioned inventory differs/)
expectVerifyFailure('html-outer-row-removed-fails', data => {
  mutateRow(data, 'current', 'optimised', outerBuild, (rows, index) => rows.splice(index, 1))
}, /positioned inventory differs/)
expectVerifyFailure('html-outer-row-count-change-fails', data => {
  mutateRow(data, 'current', 'optimised', outerBuild, (rows, index) => { rows[index].count += 1 })
}, /positioned inventory differs/)
expectVerifyFailure('html-nested-row-removed-fails', data => {
  mutateRow(data, 'current', 'optimised', nestedBuild, (rows, index) => rows.splice(index, 1))
}, /positioned inventory differs/)
expectVerifyFailure('html-nested-row-count-change-fails', data => {
  mutateRow(data, 'current', 'optimised', nestedBuild, (rows, index) => { rows[index].count += 1 })
}, /positioned inventory differs/)
expectVerifyFailure('html-zero-row-removed-fails', data => {
  mutateRow(data, 'current', 'optimised', zeroBuild, (rows, index) => rows.splice(index, 1))
}, /positioned inventory differs/)
expectVerifyFailure('html-zero-row-becomes-positive-fails', data => {
  mutateRow(data, 'current', 'optimised', zeroBuild, (rows, index) => { rows[index].count = 1 })
}, /positioned inventory differs/)
expectVerifyFailure('current-positioned-row-moved-fails', data => {
  mutateRow(data, 'current', 'optimised', row =>
    row.source === 'packages/foldkit/src/vdom.ts' && row.name === 'visit',
  (rows, index) => { rows[index].sourceLine += 1 })
}, /positioned inventory differs/)

const changedReferenceLineage = clone(analysis)
changedReferenceLineage.referenceAuthority.sha256 = 'changed'
expectFailure(
  'changed-real-reference-authority-lineage-fails',
  () => verifyV4(authority, changedReferenceLineage, verifierOptions),
  /reference-authority lineage differs/,
)

const receipt = {
  schemaVersion: 1,
  status: 'pass',
  interpretation: 'Offline v4 assertion mutation controls only; no build, browser, coverage capture, or timing process.',
  controls,
}
writeFileSync(outputPath, `${JSON.stringify(receipt, null, 2)}\n`, { flag: 'wx' })
process.stdout.write(`${JSON.stringify({ outputPath, controlCount: controls.length }, null, 2)}\n`)
