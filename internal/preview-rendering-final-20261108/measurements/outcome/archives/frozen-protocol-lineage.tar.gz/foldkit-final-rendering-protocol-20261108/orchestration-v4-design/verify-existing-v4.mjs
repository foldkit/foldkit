import assert from 'node:assert/strict'
import { readFileSync, writeFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import { resolve } from 'node:path'

import {
  assertExactPositiveLogicalEquality,
  assertExactPositionedInventory,
  assertExactZeroDelta,
  assertUniqueExactPositionedCountRow,
  logical,
  positioned,
} from './coverage-guards-v4.mjs'
import { assertAuthorityStatic } from './authority-guards-v4.mjs'

const read = path => JSON.parse(readFileSync(path, 'utf8'))
export const verifyV4 = (
  authority,
  analysis,
  { publishedAnalysisPath, authorityFacts },
) => {
assertAuthorityStatic(authority, publishedAnalysisPath)
assert.deepEqual(analysis.referenceAuthority, authorityFacts, 'Analysis reference-authority lineage differs')
assert.equal(authority.status, 'pass')
assert.equal(analysis.status, 'pass')

const by = (owner, variant) => analysis.results.find(result =>
  result.kind === 'current-v3-capture' &&
  result.owner === owner &&
  result.variant === variant) ?? assert.fail(`Missing current capture ${owner} ${variant}`)
const cadenceBy = variant => authority.cadenceLineAwareReferences.find(
  result => result.slot === `cadence-${variant}`,
) ?? assert.fail(`Missing cadence authority ${variant}`)
const oldBy = (owner, variant) => {
  const slot = owner === 'main'
    ? `foldkit-main${variant === 'optimised' ? '-optimised' : ''}`
    : `foldkit-preview-final${variant === 'optimised' ? '-optimised' : ''}`
  return authority.lineAwareReferences.find(result => result.slot === slot)
    ?? assert.fail(`Missing authority ${slot}`)
}
const relocatedBy = variant => authority.htmlRelocation.relocatedPreviewReferences.find(
  result => result.slot === `foldkit-preview-final${variant === 'optimised' ? '-optimised' : ''}`,
) ?? assert.fail(`Missing relocated authority ${variant}`)

const applicationPredicate = row =>
  /internal\/lustre-benchmark\/src\/(?:todo|view\.optimised)\.ts$/.test(row.source ?? '') &&
  !(row.source.endsWith('/todo.ts') && row.name === 'update')
const lazyPredicate = row =>
  row.source === 'packages/foldkit/src/html/lazy.ts' &&
  row.name !== 'trackedBoundaryOccurrencesAreCurrent'
const expectedOptimisedZero = [
  ['todoItemClass', 222, 23],
  ['nonEditingTodoView', 238, 28],
  ['editingTodoView', 267, 2],
  ['todoItemView', 299, 3],
  ['filterItemView', 328, 3],
  ['view', 341, 21],
].map(([name, sourceLine, sourceColumn]) => ({
  source: 'internal/lustre-benchmark/src/todo.ts',
  name,
  sourceLine,
  sourceColumn,
  count: 0,
}))

const exactPairs = []
for (const variant of ['optimised', 'naive']) {
  const main = by('main', variant)
  const current = by('current', variant)
  const referenceMain = oldBy('main', variant)
  const referenceCurrent = oldBy('current', variant)
  const referenceHtmlCurrent = relocatedBy(variant)
  const cadence = cadenceBy(variant)

  const mainApplication = main.relevantFunctions.filter(applicationPredicate)
  const currentApplication = current.relevantFunctions.filter(applicationPredicate)
  const referenceMainApplication = referenceMain.relevantFunctions.filter(applicationPredicate)
  const referenceCurrentApplication = referenceCurrent.relevantFunctions.filter(applicationPredicate)
  assert.deepEqual(
    positioned(mainApplication),
    positioned(referenceMainApplication),
    `${variant}: main application inventory differs from authority`,
  )
  assert.deepEqual(
    positioned(currentApplication.filter(row => row.count > 0)),
    positioned(referenceCurrentApplication.filter(row => row.count > 0)),
    `${variant}: current positive application inventory differs from authority`,
  )
  assertExactPositiveLogicalEquality(
    currentApplication,
    mainApplication,
    `${variant}: reached application work`,
  )
  const zeroDelta = assertExactZeroDelta(
    currentApplication,
    mainApplication,
    variant === 'optimised' ? expectedOptimisedZero : [],
    [],
    `${variant}: authenticated zero-only application delta`,
  )

  const mainLazy = main.relevantFunctions.filter(lazyPredicate)
  const currentLazy = current.relevantFunctions.filter(lazyPredicate)
  assert.deepEqual(positioned(mainLazy), positioned(referenceMain.relevantFunctions.filter(lazyPredicate)), `${variant}: main lazy inventory differs`)
  assert.deepEqual(positioned(currentLazy), positioned(referenceCurrent.relevantFunctions.filter(lazyPredicate)), `${variant}: current lazy inventory differs`)
  assert.deepEqual(logical(currentLazy), logical(mainLazy), `${variant}: unchanged lazy logical work differs`)

  const expected = variant === 'optimised'
    ? { build: 3906, normalize: 3906, visit: 31248, updateChildren: 3387 }
    : { build: 132125, normalize: 132125, visit: 160063, updateChildren: 131606 }
  for (const [result, reference, owner] of [
    [main, referenceMain, 'main'],
    [current, referenceHtmlCurrent, 'current'],
  ]) {
    for (const [source, name, descendants] of [
      ['packages/foldkit/src/html/index.ts', 'buildVNodeData', true],
      ['packages/foldkit/src/html/index.ts', 'buildElement', true],
      ['packages/foldkit/src/html/index.ts', 'copyChildrenDroppingEmpty', true],
    ]) {
      assertExactPositionedInventory(result, reference, source, name, `${variant} ${owner} ${name}`, descendants)
    }
  }
  for (const [source, name] of [
    ['packages/foldkit/src/vdom.ts', 'visit'],
    ['packages/foldkit/src/snabbdom/init.ts', 'init.patch'],
    ['packages/foldkit/src/snabbdom/init.ts', 'init.updateChildren'],
  ]) {
    assertExactPositionedInventory(main, referenceMain, source, name, `${variant} main ${name}`, true)
    assertExactPositionedInventory(current, referenceCurrent, source, name, `${variant} current ${name}`, true)
  }
  for (const [result, reference, owner] of [
    [main, referenceMain, 'main'],
    [current, referenceHtmlCurrent, 'current'],
  ]) {
    assertUniqueExactPositionedCountRow(result, reference, 'packages/foldkit/src/html/index.ts', 'buildVNodeData', expected.build, `${variant} ${owner} buildVNodeData hot outer`)
    assertUniqueExactPositionedCountRow(result, reference, 'packages/foldkit/src/html/index.ts', 'buildElement', expected.build, `${variant} ${owner} buildElement hot outer`)
    assertUniqueExactPositionedCountRow(result, reference, 'packages/foldkit/src/html/index.ts', 'copyChildrenDroppingEmpty', expected.normalize, `${variant} ${owner} normalization hot outer`)
  }
  assertUniqueExactPositionedCountRow(main, referenceMain, 'packages/foldkit/src/vdom.ts', 'visit', expected.visit, `${variant} main visit`)
  assertUniqueExactPositionedCountRow(current, referenceCurrent, 'packages/foldkit/src/vdom.ts', 'visit', expected.visit, `${variant} current visit`)
  assertUniqueExactPositionedCountRow(main, referenceMain, 'packages/foldkit/src/snabbdom/init.ts', 'init.updateChildren', expected.updateChildren, `${variant} main updateChildren`)
  assertUniqueExactPositionedCountRow(current, referenceCurrent, 'packages/foldkit/src/snabbdom/init.ts', 'init.updateChildren', expected.updateChildren, `${variant} current updateChildren`)

  for (const name of ['makeRenderer.renderSync', 'makeRenderer.runRenderFrameBody']) {
    assertExactPositionedInventory(main, referenceMain, 'packages/foldkit/src/runtime/renderer.ts', name, `${variant} main ${name}`, true)
    assertExactPositionedInventory(current, cadence, 'packages/foldkit/src/runtime/renderer.ts', name, `${variant} current ${name}`, true)
  }
  assertUniqueExactPositionedCountRow(main, referenceMain, 'packages/foldkit/src/runtime/renderer.ts', 'makeRenderer.runRenderFrameBody', 400, `${variant} main frame body`)
  assertUniqueExactPositionedCountRow(current, cadence, 'packages/foldkit/src/runtime/renderer.ts', 'makeRenderer.runRenderFrameBody', 400, `${variant} current frame body`)
  assertExactPositionedInventory(main, referenceMain, 'internal/lustre-benchmark/src/todo.ts', 'update', `${variant} main Todo dispatcher`, true)
  assertUniqueExactPositionedCountRow(main, referenceMain, 'internal/lustre-benchmark/src/todo.ts', 'update', 400, `${variant} main Todo dispatcher`)
  assertExactPositionedInventory(current, referenceCurrent, 'packages/foldkit/src/block/delivery.ts', 'createCompositionUpdate.makeUpdateFromCases.dualDispatch', `${variant} current dispatcher`, true)
  assertUniqueExactPositionedCountRow(current, referenceCurrent, 'packages/foldkit/src/block/delivery.ts', 'createCompositionUpdate.makeUpdateFromCases.dualDispatch', 400, `${variant} current dispatcher`)
  assertExactPositionedInventory(current, cadence, 'packages/foldkit/src/runtime/renderer.ts', 'makeRenderer.renderFramePlain', `${variant} current cadence callback`, true)
  assertUniqueExactPositionedCountRow(current, cadence, 'packages/foldkit/src/runtime/renderer.ts', 'makeRenderer.renderFramePlain', 600, `${variant} current cadence callback`)

  exactPairs.push({
    variant,
    reachedApplicationRows: currentApplication.filter(row => row.count > 0).length,
    zeroDelta,
    lazyRows: currentLazy.length,
    expectedSharedWork: expected,
  })
}

const output = {
  schemaVersion: 1,
  status: 'pass',
  interpretation: 'Offline guard proof against existing retained captures. Expectations come only from the pre-capture old authority, exact +630 Html relocation proof, and corrected cadence owner reference; the checked captures do not define expected rows.',
  exactPairs,
}
return output
}

if (fileURLToPath(import.meta.url) === resolve(process.argv[1])) {
  const authority = read(process.argv[2])
  const analysis = read(process.argv[3])
  const outputPath = process.argv[4]
  const publishedAnalysisPath = process.argv[5]
  const bytes = readFileSync(process.argv[2])
  const { createHash } = await import('node:crypto')
  const authorityFacts = {
    path: resolve(process.argv[2]),
    bytes: bytes.length,
    sha256: createHash('sha256').update(bytes).digest('hex'),
  }
  const output = verifyV4(authority, analysis, { publishedAnalysisPath, authorityFacts })
  writeFileSync(outputPath, `${JSON.stringify(output, null, 2)}\n`, { flag: 'wx' })
  process.stdout.write(`${JSON.stringify(output, null, 2)}\n`)
}
