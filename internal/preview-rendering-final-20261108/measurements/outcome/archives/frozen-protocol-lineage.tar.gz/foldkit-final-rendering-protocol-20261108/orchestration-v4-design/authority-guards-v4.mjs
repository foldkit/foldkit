import assert from 'node:assert/strict'
import { createRequire } from 'node:module'
import { readFileSync } from 'node:fs'
import { gunzipSync } from 'node:zlib'

const require = createRequire(import.meta.url)
const { assertLegacyProjection } = require('./reference-core.cjs')

const captureHashes = {
  'foldkit-main-optimised': '4e8ba03557f6e47b6e4e0ef34e748ac6a94c883763a3f200c17e10d710997061',
  'foldkit-preview-final-optimised': 'ab85f853aad72d225934087f0a79147021447b04b386df084d3653a6540a7702',
  'foldkit-main': '46bc40c6ec78220882f2fb19759113ac0b03199cc1d0f0c224a3b1ea339717bd',
  'foldkit-preview-final': '411213cbaa1518085d2b080b31c39d548d7b8d80cccaba002d4626614d836f0b',
}
const mapSourceHashes = {
  'foldkit-main-optimised': '9d632a69c71bc066080470498aa7eab3bd60388caf1e242dd07542e65bc8710a',
  'foldkit-preview-final-optimised': '5db03026d544dc580995f26f1a69f233066f7c659a4f4c5e1bb6e08d3bf144c6',
  'foldkit-main': 'da77296108fbefa88581c14bc2745f1055de0c7e39fa1f93583f7e51ccfd011f',
  'foldkit-preview-final': '4ded625981064248a1f3ac38e980d563d3dcc1b94da34770cc06afc25dd41616',
}
const sourceInventory = {
  'src/todo.ts': ['byte-identical-preview-current', '6991f372ffe2dac2c3bf6dcc5300b468c7a00da33cd4d034cb780a70f6f6cfc2', '6991f372ffe2dac2c3bf6dcc5300b468c7a00da33cd4d034cb780a70f6f6cfc2', true],
  'src/view.optimised.ts': ['byte-identical-preview-current', 'b2d3560001b4a516c9b3fde3775939d3ef9fdbc6fd6cc9e1e1b83f0992ae5fa4', 'b2d3560001b4a516c9b3fde3775939d3ef9fdbc6fd6cc9e1e1b83f0992ae5fa4', false],
  'packages/foldkit/src/html/lazy.ts': ['byte-identical-preview-current', '8ff8ea6144e5b5e6f4f41e51673b78710c13c1c51f0cc7affda56cfd4ea3926d', '8ff8ea6144e5b5e6f4f41e51673b78710c13c1c51f0cc7affda56cfd4ea3926d', false],
  'packages/foldkit/src/vdom.ts': ['byte-identical-preview-current', 'f09e33f4a33e3e565806680024241f66fdc2bb9727c9285fd39433f3f52724df', 'f09e33f4a33e3e565806680024241f66fdc2bb9727c9285fd39433f3f52724df', true],
  'packages/foldkit/src/snabbdom/init.ts': ['byte-identical-preview-current', '026050ca785b1f1c59e4f0403b3b92e6b20826ab31d6e05501eb4d26a56c6476', '026050ca785b1f1c59e4f0403b3b92e6b20826ab31d6e05501eb4d26a56c6476', true],
  'packages/foldkit/src/block/delivery.ts': ['byte-identical-preview-current', '6e663ed7a2ddfb24e739734cba74271d650de4bfd9604dddacb426e185c6a0b6', '6e663ed7a2ddfb24e739734cba74271d650de4bfd9604dddacb426e185c6a0b6', true],
  'packages/foldkit/src/html/index.ts': ['three-owner-exact-relocation', 'e6e05295d8736d75dce894fad99a509954c44b61ac51dbb2a4ea0ca5d480d1de', '3b2464b443db3614e03dda8e9285fbada713788d906c8c198ab23e7469eb06ac', true],
  'packages/foldkit/src/runtime/renderer.ts': ['cadence-owner-reference', '0cb8fe1490802e526d37be68107b0ea94f3c6636b2785aa2d0273e32aa4b718f', 'f6cfca5de37e6a8fea745d600d3d7bea07ccd4df0afab68c99d683714329e805', true],
}
const fingerprints = {
  buildVNodeData: ['e3584c5e2f2365f3c687308f9d3c0e1b10c33c6037e2fda964c8d3177de7ca7a', '3410d787bb45c38e24e4ee9178db9688d2b88e6e45ee56afa4778df21505487c', 2925, 3555],
  copyChildrenDroppingEmpty: ['4b6c4b7cb14814c3cf92f934c834a897aae49b7d46500cc3279c4acd0a1106dd', '4af7d81646d0f26c738898e599d495596de58cd20a2ecd4cdbc80836a64660be', 3010, 3640],
  buildElement: ['ba9eea5153f9c3f5ac0cbf5576d4330f540281f67bd1253f9159ab0e5f04e11a', '20c309e3a8beba8f09d0adc7775bff3f0f4bda1f4b01d64c98dad1f91f20169c', 3358, 3988],
}

export const assertAuthorityStatic = (authority, publishedAnalysisPath) => {
  assert.equal(authority.status, 'pass')
  assert.equal(authority.parser.version, '6.0.3')
  assert.equal(authority.publishedLegacyProjectionReproduced, true)
  const published = JSON.parse(gunzipSync(readFileSync(publishedAnalysisPath)))
  assertLegacyProjection(authority.legacyProjection, published.coverageResults)
  for (const [slot, expectedCapture] of Object.entries(captureHashes)) {
    const input = authority.officialInputs.slots[slot]
    assert.equal(input.capture.sourceSha256, expectedCapture, `${slot}: raw capture authority differs`)
    assert.equal(input.sourceMap.sourceSha256, mapSourceHashes[slot], `${slot}: decompressed map authority differs`)
  }
  assert.equal(authority.htmlRelocation.lineDelta, 630)
  for (const [name, [initializerSha256, bodySha256, oldLine, currentLine]] of Object.entries(fingerprints)) {
    const facts = authority.htmlRelocation.fingerprints[name]
    for (const side of ['old', 'current']) {
      assert.equal(facts[side].initializerSha256, initializerSha256, `${name}: ${side} initializer differs`)
      assert.equal(facts[side].bodySha256, bodySha256, `${name}: ${side} body differs`)
      assert.equal(facts[side].declarationColumn, 6, `${name}: ${side} column differs`)
    }
    assert.equal(facts.old.declarationLine, oldLine, `${name}: old line differs`)
    assert.equal(facts.current.declarationLine, currentLine, `${name}: current line differs`)
    assert.equal(facts.lineDelta, 630, `${name}: line delta differs`)
  }
  for (const [suffix, [classification, currentHash, oldHash, naivePresent]] of Object.entries(sourceInventory)) {
    const item = authority.guardedSourceInventory.find(row => row.mapSuffix === suffix)
      ?? assert.fail(`Missing guarded source ${suffix}`)
    assert.equal(item.classification, classification, `${suffix}: classification differs`)
    assert.equal(item.currentGitSource.sha256, currentHash, `${suffix}: Git source differs`)
    for (const variant of ['optimised', 'naive']) {
      const expectedPresent = variant === 'optimised' || naivePresent
      assert.equal(item.variants[variant].present, expectedPresent, `${suffix}: ${variant} presence differs`)
      if (!expectedPresent) continue
      assert.equal(item.variants[variant].currentMapSourceSha256, currentHash, `${suffix}: ${variant} map source differs`)
      assert.equal(item.variants[variant].oldPreviewSourceSha256, oldHash, `${suffix}: ${variant} preview source differs`)
    }
  }
  const owners = authority.htmlRelocation.owners
  const recomputedRelocated = authority.lineAwareReferences
    .filter(result => result.slot.startsWith('foldkit-preview-final'))
    .map(result => ({
      ...result,
      relevantFunctions: result.relevantFunctions.map(row => {
        if (
          row.source !== authority.htmlRelocation.source ||
          !owners.some(owner => row.name === owner || row.name.startsWith(`${owner}.`))
        ) return row
        return { ...row, sourceLine: row.sourceLine + authority.htmlRelocation.lineDelta }
      }),
    }))
  assert.deepEqual(
    authority.htmlRelocation.relocatedPreviewReferences,
    recomputedRelocated,
    'Complete relocated preview reference differs from exact recomputation',
  )
  for (const [variant, counts] of Object.entries({
    optimised: [3906, 403, 0],
    naive: [132125, 25749, 0],
  })) {
    const reference = authority.htmlRelocation.relocatedPreviewReferences.find(result =>
      result.slot === `foldkit-preview-final${variant === 'optimised' ? '-optimised' : ''}`)
      ?? assert.fail(`Missing relocated ${variant}`)
    const rows = reference.relevantFunctions
      .filter(row => row.source === 'packages/foldkit/src/html/index.ts' &&
        (row.name === 'buildVNodeData' || row.name.startsWith('buildVNodeData.')))
      .map(({ name, sourceLine, sourceColumn, count }) => ({ name, sourceLine, sourceColumn, count }))
      .sort((left, right) => left.sourceLine - right.sourceLine)
    assert.deepEqual(rows, [
      { name: 'buildVNodeData', sourceLine: 3556, sourceColumn: 2, count: counts[0] },
      { name: 'buildVNodeData.getSharedPostpatchProps', sourceLine: 3579, sourceColumn: 8, count: counts[1] },
      { name: 'buildVNodeData', sourceLine: 3604, sourceColumn: 22, count: counts[2] },
    ], `${variant}: complete relocated buildVNodeData inventory differs`)
  }
  assert(authority.labelDrift.every(item => item.changedRows.length > 0), 'Expected explicit v3 decoder label drift')
  return true
}

export const assertExactLineage = (actual, expected, label) =>
  assert.deepEqual(actual, expected, `${label}: lineage differs`)
