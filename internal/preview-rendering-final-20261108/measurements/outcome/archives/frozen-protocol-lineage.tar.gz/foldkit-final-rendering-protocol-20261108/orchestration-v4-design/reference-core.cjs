const assert = require('node:assert/strict')
const { createHash } = require('node:crypto')
const { readFileSync } = require('node:fs')
const { basename, dirname, join } = require('node:path')
const { gunzipSync } = require('node:zlib')

const sha256 = value => createHash('sha256').update(value).digest('hex')
const fileFacts = path => {
  const bytes = readFileSync(path)
  return { path, bytes: bytes.length, sha256: sha256(bytes) }
}
const compactFacts = ({ bytes, sha256: hash }) => ({ bytes, sha256: hash })
const json = path => JSON.parse(readFileSync(path, 'utf8'))
const readStored = path => path.endsWith('.gz') ? gunzipSync(readFileSync(path)) : readFileSync(path)

const normalizeSource = source => {
  if (!source) return undefined
  for (const marker of ['packages/', 'internal/']) {
    const index = source.lastIndexOf(marker)
    if (index >= 0) return source.slice(index)
  }
  const dependency = source.lastIndexOf('/node_modules/')
  if (dependency >= 0) return source.slice(dependency + 1)
  const benchmark = /(?:^|\/)src\/(todo|view\.optimised|application(?:\.optimised)?|entry(?:\.optimised)?)\.ts$/.exec(source)
  return benchmark ? `internal/lustre-benchmark/src/${benchmark[1]}.ts` : source
}

const isRelevant = source => /(?:internal\/lustre-benchmark\/src\/(?:todo|view\.optimised|application(?:\.optimised)?|entry(?:\.optimised)?)\.ts|packages\/foldkit\/src\/(?:runtime\/(?:renderer|runtime|program)|snabbdom\/init|block\/[^/]+|program\/[^/]+|experimental\/hybrid\/authoring|struct\/index|html\/(?:index|lazy)|vdom)\.ts)/.test(source ?? '')

const createNameResolver = ts => {
  const cache = new Map()
  const sourceFacts = (source, content) => {
    const key = `${source}\0${content}`
    let cached = cache.get(key)
    if (cached) return cached
    const file = ts.createSourceFile(source, content, ts.ScriptTarget.Latest, true)
    const functions = []
    const visit = (node, parents) => {
      let names = parents
      if (ts.isFunctionLike(node) && node.body) {
        let name = node.name?.getText(file)
        let owner = node
        if (
          ts.isVariableDeclaration(node.parent) ||
          ts.isPropertyAssignment(node.parent) ||
          ts.isMethodDeclaration(node.parent)
        ) {
          name = node.parent.name?.getText(file) ?? name
          owner = node.parent
        }
        names = name ? [...parents, name] : parents
        const start = owner.getStart(file)
        const startLocation = file.getLineAndCharacterOfPosition(start)
        const endLocation = file.getLineAndCharacterOfPosition(owner.end)
        functions.push({
          start,
          end: owner.end,
          line: startLocation.line + 1,
          endLine: endLocation.line + 1,
          column: startLocation.character,
          name: names.join('.'),
        })
      }
      ts.forEachChild(node, child => visit(child, names))
    }
    visit(file, [])
    cached = { file, functions }
    cache.set(key, cached)
    return cached
  }
  return (source, content, line, column) => {
    if (!content || line == null || column == null) {
      return { legacyName: undefined, lineAwareName: undefined }
    }
    const cached = sourceFacts(source, content)
    const offset = cached.file.getPositionOfLineAndCharacter(line - 1, column)
    const containing = cached.functions
      .filter(item => item.start <= offset && offset < item.end)
      .sort((left, right) =>
        (left.end - left.start) - (right.end - right.start))[0]
    const lineContaining = cached.functions
      .filter(item => item.line <= line && line <= item.endLine)
      .sort((left, right) =>
        (left.end - left.start) - (right.end - right.start))[0]
    const declaredOnMappedLine = cached.functions
      .filter(item => item.line === line)
      .sort((left, right) =>
        (left.end - left.start) - (right.end - right.start))[0]
    const closest = declaredOnMappedLine ?? lineContaining
    const lineAware = closest && (
      !containing || closest.end - closest.start < containing.end - containing.start
    ) ? closest : containing
    // v3 intended the same line-aware choice, but its three comparators returned
    // only the left operand's width. Preserve that observed decoder separately
    // so the correction is explicit rather than silently relabeling evidence.
    const brokenContaining = cached.functions
      .filter(item => item.start <= offset && offset < item.end)
      .sort((left, right) => left.end - left.start)[0]
    const brokenLineContaining = cached.functions
      .filter(item => item.line <= line && line <= item.endLine)
      .sort((left, right) => left.end - left.start)[0]
    const brokenDeclaredOnMappedLine = cached.functions
      .filter(item => item.line === line)
      .sort((left, right) => left.end - left.start)[0]
    const brokenClosest = brokenDeclaredOnMappedLine ?? brokenLineContaining
    const v3Observed = brokenClosest && (
      !brokenContaining ||
      brokenClosest.end - brokenClosest.start < brokenContaining.end - brokenContaining.start
    ) ? brokenClosest : brokenContaining
    return {
      legacyName: containing?.name,
      lineAwareName: lineAware?.name,
      v3ObservedName: v3Observed?.name,
    }
  }
}

const lowerBound = (mappings, offset) => {
  let low = 0
  let high = mappings.length
  while (low < high) {
    const middle = (low + high) >> 1
    if (mappings[middle].offset < offset) low = middle + 1
    else high = middle
  }
  return low
}

const decodeCoverage = ({
  slot,
  role,
  javascriptBytes,
  mapBytes,
  captureBytes,
  expectedJavascriptSha256,
  expectedMapSha256,
  expectedCaptureSha256,
  expectedFunctionCount,
  traceMapping,
  ts,
}) => {
  assert.equal(sha256(javascriptBytes), expectedJavascriptSha256, `${slot}: JavaScript hash differs`)
  assert.equal(sha256(mapBytes), expectedMapSha256, `${slot}: source-map hash differs`)
  assert.equal(sha256(captureBytes), expectedCaptureSha256, `${slot}: raw capture hash differs`)
  const { TraceMap, decodedMappings } = require(traceMapping)
  const rawMap = JSON.parse(mapBytes)
  const trace = new TraceMap(rawMap)
  const javascript = javascriptBytes.toString('utf8')
  const lineStarts = [0]
  for (let index = 0; index < javascript.length; index += 1) {
    if (javascript.charCodeAt(index) === 10) lineStarts.push(index + 1)
  }
  const mappings = []
  for (const [line, segments] of decodedMappings(trace).entries()) {
    for (const segment of segments) {
      if (segment.length < 4) continue
      mappings.push({
        offset: lineStarts[line] + segment[0],
        source: rawMap.sources[segment[1]],
        normalizedSource: normalizeSource(rawMap.sources[segment[1]]),
        line: segment[2] + 1,
        column: segment[3],
        mappedName: segment.length >= 5 ? rawMap.names?.[segment[4]] : undefined,
        content: rawMap.sourcesContent?.[segment[1]],
      })
    }
  }
  const scripts = JSON.parse(captureBytes)
  assert.equal(scripts.length, 1, `${slot}: expected one precise-coverage script`)
  assert.equal(scripts[0].functions.length, expectedFunctionCount, `${slot}: function count differs`)
  const resolveName = createNameResolver(ts)
  const relevantFunctions = []
  for (const fn of scripts[0].functions) {
    const range = fn.ranges[0]
    let index = lowerBound(mappings, range.startOffset)
    let mapping
    while (index < mappings.length && mappings[index].offset < range.endOffset) {
      if (mappings[index].source) {
        mapping = mappings[index]
        break
      }
      index += 1
    }
    if (!mapping) continue
    const names = resolveName(
      mapping.source,
      mapping.content,
      mapping.line,
      mapping.column,
    )
    const fallback = mapping.mappedName ?? fn.functionName ?? '(anonymous)'
    const row = {
      legacyName: names.legacyName ?? fallback,
      lineAwareName: names.lineAwareName ?? fallback,
      v3ObservedName: names.v3ObservedName ?? fallback,
      generatedName: fn.functionName,
      source: mapping.normalizedSource,
      sourceLine: mapping.line,
      sourceColumn: mapping.column,
      count: range.count,
      generatedStartOffset: range.startOffset,
      generatedEndOffset: range.endOffset,
    }
    if (isRelevant(row.source)) relevantFunctions.push(row)
  }
  return {
    slot,
    role,
    captureSha256: expectedCaptureSha256,
    functionCount: expectedFunctionCount,
    relevantFunctions,
  }
}

const projection = (result, field) => ({
  slot: result.slot,
  role: result.role,
  captureSha256: result.captureSha256,
  functionCount: result.functionCount,
  relevantFunctions: result.relevantFunctions.map(row => ({
    name: row[field],
    generatedName: row.generatedName,
    source: row.source,
    sourceLine: row.sourceLine,
    sourceColumn: row.sourceColumn,
    count: row.count,
    generatedStartOffset: row.generatedStartOffset,
    generatedEndOffset: row.generatedEndOffset,
  })),
})

const findOptionalSourceContent = (mapBytes, suffix) => {
  const map = JSON.parse(mapBytes)
  const matches = map.sources
    .map((source, index) => ({ source, content: map.sourcesContent?.[index] }))
    .filter(item => item.source.endsWith(suffix))
  assert(matches.length <= 1, `Expected at most one source-map source ending ${suffix}`)
  if (matches.length === 0) return undefined
  assert.equal(typeof matches[0].content, 'string', `Missing sourcesContent for ${suffix}`)
  return matches[0]
}
const findSourceContent = (mapBytes, suffix) =>
  findOptionalSourceContent(mapBytes, suffix)
  ?? assert.fail(`Expected one source-map source ending ${suffix}`)

const initializerFacts = (ts, source, name) => {
  const file = ts.createSourceFile('html/index.ts', source, ts.ScriptTarget.Latest, true)
  const matches = []
  const visit = node => {
    if (ts.isVariableDeclaration(node) && node.name.getText(file) === name) matches.push(node)
    ts.forEachChild(node, visit)
  }
  visit(file)
  assert.equal(matches.length, 1, `Expected one ${name} declaration`)
  const declaration = matches[0]
  const initializer = declaration.initializer
  assert(initializer && initializer.body, `${name} must have a body-bearing initializer`)
  const location = file.getLineAndCharacterOfPosition(declaration.name.getStart(file))
  const initializerText = source.slice(initializer.getStart(file), initializer.end)
  const bodyText = source.slice(initializer.body.getStart(file), initializer.body.end)
  return {
    declarationLine: location.line + 1,
    declarationColumn: location.character,
    initializerBytes: Buffer.byteLength(initializerText),
    initializerSha256: sha256(initializerText),
    bodyBytes: Buffer.byteLength(bodyText),
    bodySha256: sha256(bodyText),
  }
}

const positioned = rows => rows
  .map(({ source, name, sourceLine, sourceColumn, count }) => ({
    source,
    name,
    sourceLine,
    sourceColumn,
    count,
  }))
  .sort((left, right) => JSON.stringify(left).localeCompare(JSON.stringify(right)))

const matchingRows = (result, source, name) => result.relevantFunctions
  .filter(row => row.source === source && (row.name === name || row.name.startsWith(`${name}.`)))

const relocateOwnerRows = (result, source, owners, lineDelta) => ({
  ...result,
  relevantFunctions: result.relevantFunctions.map(row => {
    if (
      row.source !== source ||
      !owners.some(owner => row.name === owner || row.name.startsWith(`${owner}.`))
    ) return row
    return { ...row, sourceLine: row.sourceLine + lineDelta }
  }),
})

const assertInputFact = (actual, expected, label) => {
  assert.deepEqual(compactFacts(actual), compactFacts(expected), `${label}: input facts differ`)
}

const assertLegacyProjection = (actualResults, publishedResults) => {
  assert.equal(actualResults.length, publishedResults.length, 'Legacy projection result count differs')
  for (const published of publishedResults) {
    const actual = actualResults.find(result => result.slot === published.slot)
    assert(actual, `Missing reconstructed legacy slot ${published.slot}`)
    assert.deepEqual(actual, published, `${published.slot}: reconstructed legacy projection differs`)
  }
}

const assertExactRows = (actual, expected, source, name, label) => {
  const actualRows = positioned(matchingRows(actual, source, name))
  const expectedRows = positioned(matchingRows(expected, source, name))
  assert(expectedRows.length > 0, `${label}: expected inventory is empty`)
  assert.deepEqual(actualRows, expectedRows, `${label}: positioned inventory differs`)
}

module.exports = {
  assertExactRows,
  assertInputFact,
  assertLegacyProjection,
  compactFacts,
  createNameResolver,
  decodeCoverage,
  fileFacts,
  findSourceContent,
  findOptionalSourceContent,
  initializerFacts,
  json,
  matchingRows,
  normalizeSource,
  positioned,
  projection,
  readStored,
  relocateOwnerRows,
  sha256,
}
