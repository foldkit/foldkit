const assert = require('node:assert/strict')
const { createHash } = require('node:crypto')
const { mkdirSync, readFileSync, writeFileSync } = require('node:fs')
const { basename, join, resolve } = require('node:path')
const { gzipSync } = require('node:zlib')

const config = JSON.parse(readFileSync(resolve(process.argv[2]), 'utf8'))
const receipt = JSON.parse(readFileSync(config.officialCoverageReceipt, 'utf8'))
const sha256 = value => createHash('sha256').update(value).digest('hex')
mkdirSync(config.outputRoot, { recursive: true })
const captures = []
for (const captured of receipt.results) {
  const sourcePath = join(config.rawRoot, captured.captureFile)
  const source = readFileSync(sourcePath)
  assert.equal(source.length, captured.captureBytes, `${captured.slot}: source bytes differ`)
  assert.equal(sha256(source), captured.captureSha256, `${captured.slot}: source hash differs`)
  const storedPath = join(config.outputRoot, `${basename(captured.captureFile)}.gz`)
  const stored = gzipSync(source, { level: 9, mtime: 0 })
  writeFileSync(storedPath, stored, { flag: 'wx' })
  captures.push({
    slot: captured.slot,
    storedPath,
    storedBytes: stored.length,
    storedSha256: sha256(stored),
    sourceBytes: source.length,
    sourceSha256: sha256(source),
  })
}
const output = {
  schemaVersion: 1,
  status: 'complete',
  interpretation: 'Durable deterministic-gzip copies of the four authenticated old raw precise-coverage captures. Stored hashes authenticate transport; decompressed source hashes must match the official coverage receipt.',
  officialCoverageReceipt: {
    path: config.officialCoverageReceipt,
    bytes: readFileSync(config.officialCoverageReceipt).length,
    sha256: sha256(readFileSync(config.officialCoverageReceipt)),
  },
  captures,
}
writeFileSync(config.outputReceipt, `${JSON.stringify(output, null, 2)}\n`, { flag: 'wx' })
process.stdout.write(`${JSON.stringify({ outputReceipt: config.outputReceipt, captures: captures.length }, null, 2)}\n`)
