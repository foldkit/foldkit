import assert from 'node:assert/strict'
import { execFileSync, spawnSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import {
  cpSync,
  existsSync,
  lstatSync,
  mkdirSync,
  readFileSync,
  readdirSync,
  realpathSync,
  statSync,
  symlinkSync,
  writeFileSync,
} from 'node:fs'
import { createRequire } from 'node:module'
import { basename, dirname, join, relative, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

export const scriptRoot = dirname(fileURLToPath(import.meta.url))
export const sha256 = value => createHash('sha256').update(value).digest('hex')
export const fileFacts = path => {
  const bytes = readFileSync(path)
  return { path, bytes: bytes.length, sha256: sha256(bytes) }
}
export const writeJsonExclusive = (path, value) =>
  writeFileSync(path, `${JSON.stringify(value, null, 2)}\n`, { flag: 'wx' })
export const writeJson = (path, value) =>
  writeFileSync(path, `${JSON.stringify(value, null, 2)}\n`)

export const loadConfig = path => {
  assert(path, 'Usage: node <script> /absolute/path/config.json')
  const configPath = resolve(path)
  const config = JSON.parse(readFileSync(configPath, 'utf8'))
  assert.equal(config.schemaVersion, 1)
  for (const key of [
    'candidateRoot',
    'evidenceRoot',
    'repoEvidenceRoot',
    'officialHarnessRoot',
    'officialDriverRoot',
    'officialMainNaiveDist',
    'officialMainOptimisedDist',
    'node',
    'chromium',
    'vite',
    'rimraf',
    'traceMapping',
  ]) {
    assert.equal(typeof config[key], 'string', `Missing config.${key}`)
    config[key] = resolve(config[key])
  }
  return { config, configPath, configFacts: fileFacts(configPath) }
}

export const filesUnder = (root, prefix = '') => {
  const files = []
  const visit = (directory, relativePrefix) => {
    for (const entry of readdirSync(directory, { withFileTypes: true })) {
      const path = join(directory, entry.name)
      const relativePath = join(relativePrefix, entry.name)
      if (entry.isDirectory()) visit(path, relativePath)
      else if (entry.isFile()) {
        files.push({
          path: join(prefix, relativePath),
          bytes: statSync(path).size,
          sha256: fileFacts(path).sha256,
        })
      }
    }
  }
  visit(root, '')
  return files.sort((left, right) => left.path.localeCompare(right.path))
}

const selectedCandidateRoots = [
  'internal/lustre-benchmark/bench',
  'internal/lustre-benchmark/src',
  'internal/lustre-benchmark/index.html',
  'internal/lustre-benchmark/index.optimised.html',
  'internal/lustre-benchmark/package.json',
  'internal/lustre-benchmark/tsconfig.json',
  'internal/lustre-benchmark/vite.config.ts',
  'packages/foldkit/src',
  'packages/foldkit/dist',
  'packages/foldkit/package.json',
  'packages/vite-plugin-foldkit/src',
  'packages/vite-plugin-foldkit/package.json',
  'examples/vite.aliases.ts',
  'package.json',
  'pnpm-lock.yaml',
]

export const candidateFiles = candidateRoot => {
  const files = []
  for (const relativePath of selectedCandidateRoots) {
    const path = join(candidateRoot, relativePath)
    assert(existsSync(path), `Missing frozen candidate input ${path}`)
    if (statSync(path).isDirectory()) files.push(...filesUnder(path, relativePath))
    else files.push({ ...fileFacts(path), path: relativePath })
  }
  return files
    .map(({ path, bytes, sha256: hash }) => ({ path, bytes, sha256: hash }))
    .sort((left, right) => left.path.localeCompare(right.path))
}

const git = (root, args) =>
  execFileSync('git', ['-C', root, ...args], { encoding: 'utf8' }).trim()

export const freezeReceiptPath = config => join(config.evidenceRoot, 'candidate-freeze.json')
export const assertPinnedNode = config => assert.equal(
  realpathSync(process.execPath),
  realpathSync(config.node),
  'Stage is not running under the configured pinned Node executable',
)
export const assertFrozenBindings = ({ receipt, configFacts, currentImmutableInputs }) => {
  assert.deepEqual(configFacts, receipt.config, 'Current config differs from frozen config')
  assert.deepEqual(
    currentImmutableInputs,
    receipt.immutableInputs,
    'Current immutable tool/driver inputs differ from frozen inputs',
  )
}
export const assertReceiptLineage = (
  receipt,
  {
    configFacts,
    candidateFreeze,
    currentImmutableInputs,
    assetReceipt,
    preflightReceipt,
    coverageReceipt,
    coverageAnalysis,
    coverageGuard,
  },
) => {
  assert.deepEqual(receipt.config, configFacts, 'Receipt config lineage mismatch')
  assert.deepEqual(receipt.candidateFreeze, candidateFreeze, 'Receipt freeze lineage mismatch')
  assert.deepEqual(
    receipt.immutableInputs,
    currentImmutableInputs,
    'Receipt immutable-input lineage mismatch',
  )
  if (assetReceipt !== undefined) {
    assert.deepEqual(receipt.assetReceipt, assetReceipt, 'Receipt asset lineage mismatch')
  }
  if (preflightReceipt !== undefined) {
    assert.deepEqual(receipt.preflightReceipt, preflightReceipt, 'Receipt preflight lineage mismatch')
  }
  if (coverageReceipt !== undefined) {
    assert.deepEqual(receipt.captureReceipt, coverageReceipt, 'Receipt coverage lineage mismatch')
  }
  if (coverageAnalysis !== undefined) {
    assert.deepEqual(receipt.analysis, coverageAnalysis, 'Receipt analysis lineage mismatch')
  }
  if (coverageGuard !== undefined) {
    assert.deepEqual(receipt.coverageGuard, coverageGuard, 'Receipt coverage-guard lineage mismatch')
  }
}
export const assertFrozenCandidate = (config, configFacts) => {
  const path = freezeReceiptPath(config)
  const receipt = JSON.parse(readFileSync(path, 'utf8'))
  assert.equal(receipt.status, 'frozen-clean-committed-candidate')
  assertFrozenBindings({
    receipt,
    configFacts,
    currentImmutableInputs: immutableInputs(config),
  })
  assertPinnedNode(config)
  assert.equal(realpathSync(config.candidateRoot), receipt.candidateRoot)
  assert.equal(git(config.candidateRoot, ['rev-parse', 'HEAD']), receipt.head)
  assert.equal(git(config.candidateRoot, ['rev-parse', 'HEAD^{tree}']), receipt.tree)
  assert.equal(git(config.candidateRoot, ['status', '--porcelain']), '')
  assert.deepEqual(candidateFiles(config.candidateRoot), receipt.files)
  return { path, receipt, facts: fileFacts(path) }
}

export const immutableInputs = config => {
  const requireFromTraceMapping = createRequire(join(config.traceMapping, 'package.json'))
  const facts = {
    node: fileFacts(config.node),
    chromium: fileFacts(config.chromium),
    driver: fileFacts(join(config.officialDriverRoot, 'run.mjs')),
    runner: fileFacts(join(config.officialDriverRoot, 'runner.html')),
    server: fileFacts(join(config.officialDriverRoot, 'server.mjs')),
    verify: fileFacts(join(config.officialDriverRoot, 'verify.mjs')),
    instrumentation: fileFacts(join(config.officialHarnessRoot, 'priv/instrumentation.js')),
    vite: fileFacts(config.vite),
    rimraf: fileFacts(config.rimraf),
    traceMappingPackage: fileFacts(join(config.traceMapping, 'package.json')),
    traceMappingRuntime: fileFacts(requireFromTraceMapping.resolve(config.traceMapping)),
    traceMappingResolveUri: fileFacts(requireFromTraceMapping.resolve('@jridgewell/resolve-uri')),
    traceMappingSourceMapCodec: fileFacts(
      requireFromTraceMapping.resolve('@jridgewell/sourcemap-codec'),
    ),
  }
  assert.equal(facts.node.sha256, '533bd644c5ae0e0ea3a80e433aad16b817447ccba1e1eea701875eac80cb75d4')
  assert.equal(facts.chromium.sha256, '8319963f6625accf51c0dd4f55091ceaf9f09ed39e7a52fed4fae12b2a6b668a')
  assert.equal(facts.driver.sha256, 'a93c12e6fe411eb5fa8abc342e32974d94496622ba8a475b81f7d6dc9bbc26f0')
  assert.equal(facts.runner.sha256, '6d26843332fa4b5bcd55def19f6219ac8d26a0db242c32bc54a2291a6a695ee1')
  assert.equal(facts.server.sha256, 'fb76bfaf628dd7ecd9932c008604b566a0cafaa20fc9f88f8f35bfa3ac980398')
  assert.equal(facts.instrumentation.sha256, '6e3597e81ef7276d99f17cfa4c3430e05beb7768411a1a34bffa0026343f7f69')
  return facts
}

export const runLogged = ({ config, name, args, cwd, env, logRoot }) => {
  mkdirSync(logRoot, { recursive: true })
  const result = spawnSync(config.node, args, {
    cwd,
    env,
    encoding: 'utf8',
    maxBuffer: 64 * 1024 * 1024,
  })
  const log = [
    `$ ${config.node} ${args.join(' ')}`,
    `cwd=${cwd}`,
    `exit=${result.status}`,
    '',
    'stdout:',
    result.stdout ?? '',
    '',
    'stderr:',
    result.stderr ?? '',
    '',
    `error=${result.error?.message ?? ''}`,
  ].join('\n')
  const logPath = join(logRoot, `${name}.log`)
  writeFileSync(logPath, log, { flag: 'wx' })
  assert.equal(result.status, 0, `${name} failed; see ${logPath}`)
  return fileFacts(logPath)
}

export const ordinaryEnvironment = () => {
  const env = { ...process.env }
  delete env.NODE_ENV
  delete env.VITE_USER_NODE_ENV
  delete env.MODE
  delete env.BUILD_VARIANT
  return { ...env, CI: '1', LANG: 'C.UTF-8', LC_ALL: 'C.UTF-8', NO_COLOR: '1' }
}

export const assetReceiptPath = config => join(config.evidenceRoot, 'assets/receipt.json')
export const loadAssetReceipt = (config, configFacts, frozen) => {
  const path = assetReceiptPath(config)
  const receipt = JSON.parse(readFileSync(path, 'utf8'))
  assert.equal(receipt.status, 'complete')
  assertReceiptLineage(receipt, {
    configFacts,
    candidateFreeze: frozen.facts,
    currentImmutableInputs: immutableInputs(config),
  })
  for (const owner of ['main', 'current']) {
    for (const variant of ['naive', 'optimised']) {
      const output = receipt.outputs[owner][variant]
      assert(
        resolve(output.ordinaryRoot).startsWith(`${resolve(config.evidenceRoot)}/`),
        `Asset root escaped evidence root: ${output.ordinaryRoot}`,
      )
      assert.deepEqual(
        filesUnder(output.ordinaryRoot),
        output.ordinaryFiles,
        `${owner} ${variant} ordinary asset files changed after receipt`,
      )
      assert(
        resolve(output.mapRoot).startsWith(`${resolve(config.evidenceRoot)}/`),
        `Map root escaped evidence root: ${output.mapRoot}`,
      )
      assert(
        resolve(output.mapJavaScript.path).startsWith(`${resolve(output.mapRoot)}/`),
        `Map JavaScript escaped map root: ${output.mapJavaScript.path}`,
      )
      assert(
        resolve(output.sourceMap.path).startsWith(`${resolve(output.mapRoot)}/`),
        `Source map escaped map root: ${output.sourceMap.path}`,
      )
      const currentAsset = findJavaScriptAsset(output.ordinaryRoot)
      assert.equal(currentAsset.bytes, output.ordinaryAsset.bytes)
      assert.equal(currentAsset.sha256, output.ordinaryAsset.sha256)
      assert.deepEqual(fileFacts(output.mapJavaScript.path), {
        path: output.mapJavaScript.path,
        bytes: output.mapJavaScript.bytes,
        sha256: output.mapJavaScript.sha256,
      })
      assert.deepEqual(fileFacts(output.sourceMap.path), output.sourceMap)
      assert.equal(output.mapJavaScript.sha256, output.ordinaryAsset.sha256)
    }
  }
  return { path, receipt, facts: fileFacts(path) }
}

export const slots = [
  { name: 'main-optimised-a', owner: 'main', variant: 'optimised' },
  { name: 'current-optimised', owner: 'current', variant: 'optimised' },
  { name: 'main-optimised-b', owner: 'main', variant: 'optimised' },
  { name: 'main-naive-a', owner: 'main', variant: 'naive' },
  { name: 'current-naive', owner: 'current', variant: 'naive' },
  { name: 'main-naive-b', owner: 'main', variant: 'naive' },
]
export const uniqueSlots = [slots[0], slots[1], slots[3], slots[4]]

export const createHarness = (config, configFacts, frozen, root) => {
  assert.equal(existsSync(root), false, `Refusing to overwrite ${root}`)
  const implementations = join(root, 'priv/implementations')
  mkdirSync(implementations, { recursive: true })
  cpSync(
    join(config.officialHarnessRoot, 'priv/instrumentation.js'),
    join(root, 'priv/instrumentation.js'),
  )
  const { receipt } = loadAssetReceipt(config, configFacts, frozen)
  for (const slot of slots) {
    const source = receipt.outputs[slot.owner][slot.variant].ordinaryRoot
    const slotRoot = join(implementations, slot.name)
    mkdirSync(slotRoot, { recursive: true })
    symlinkSync(source, join(slotRoot, 'dist'), 'dir')
    assert.equal(realpathSync(join(slotRoot, 'dist')), realpathSync(source))
  }
  return root
}

export const findJavaScriptAsset = root => {
  const files = filesUnder(root)
    .filter(file => /^assets\/.*\.js$/.test(file.path) && !file.path.endsWith('.js.map'))
  assert.equal(files.length, 1, `Expected one JavaScript asset under ${root}`)
  return { ...files[0], absolutePath: join(root, files[0].path) }
}

export const assertGrant = name =>
  assert.equal(process.env[name], '1', `Refusing to run without ${name}=1`)

export const copyTreeChecked = (source, target) => {
  assert.equal(existsSync(target), false, `Refusing to overwrite ${target}`)
  cpSync(source, target, { recursive: true, dereference: true })
  assert.deepEqual(filesUnder(target), filesUnder(source))
}

export const lstatKind = path =>
  lstatSync(path).isSymbolicLink() ? 'symlink' : statSync(path).isDirectory() ? 'directory' : 'file'

export const baseName = basename
