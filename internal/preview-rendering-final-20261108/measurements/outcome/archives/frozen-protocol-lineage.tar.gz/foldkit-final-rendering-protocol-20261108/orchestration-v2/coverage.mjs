import assert from 'node:assert/strict'
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { pathToFileURL } from 'node:url'

import {
  assertFrozenCandidate,
  assertGrant,
  assertReceiptLineage,
  createHarness,
  fileFacts,
  findJavaScriptAsset,
  immutableInputs,
  loadAssetReceipt,
  loadConfig,
  sha256,
  uniqueSlots,
  writeJson,
} from './common.mjs'

const { config, configFacts } = loadConfig(process.argv[2])
assertGrant('BROWSER_SLOT_GRANTED')
const frozen = assertFrozenCandidate(config, configFacts)
const assets = loadAssetReceipt(config, configFacts, frozen)
const preflightPath = join(config.evidenceRoot, 'preflight/receipt.json')
const preflight = JSON.parse(readFileSync(preflightPath, 'utf8'))
assert.equal(preflight.status, 'complete')
assert.equal(preflight.browserAndServerClosed, true)
assertReceiptLineage(preflight, {
  configFacts,
  candidateFreeze: frozen.facts,
  currentImmutableInputs: immutableInputs(config),
  assetReceipt: assets.facts,
})
const output = join(config.evidenceRoot, 'coverage')
assert.equal(existsSync(output), false, `Refusing to overwrite ${output}`)
mkdirSync(output, { recursive: true })
const harness = createHarness(config, configFacts, frozen, join(output, 'harness'))
const port = config.ports.coverage
const receiptPath = join(output, 'receipt.json')
const receipt = {
  schemaVersion: 1,
  status: 'running',
  interpretation: 'Source-matched precise-coverage call counts only. Coverage changes optimization/cadence; elapsed values are invalid.',
  config: configFacts,
  candidateFreeze: frozen.facts,
  assetReceipt: assets.facts,
  preflightReceipt: fileFacts(preflightPath),
  immutableInputs: immutableInputs(config),
  port,
  itemCount: 100,
  results: [],
  browserAndServerClosed: false,
}
writeJson(receiptPath, receipt)

const { chromium } = await import(
  pathToFileURL(join(config.officialDriverRoot, 'node_modules/playwright/index.mjs')).href
)
const { startServer } = await import(
  pathToFileURL(join(config.officialDriverRoot, 'server.mjs')).href
)
const server = await startServer(harness, config.officialDriverRoot, port)
let browser
try {
  browser = await chromium.launch({ headless: true, executablePath: config.chromium })
  receipt.chromiumVersion = browser.version()
  const baseUrl = `http://localhost:${port}`
  for (const slot of uniqueSlots) {
    const context = await browser.newContext()
    try {
      await context.route(/unpkg\.com|todomvc\.com/, route =>
        route.fulfill({
          status: 200,
          contentType: 'text/css',
          headers: { 'Cross-Origin-Resource-Policy': 'cross-origin' },
          body: '',
        }),
      )
      const page = await context.newPage()
      let pageError
      page.on('pageerror', error => { pageError ??= error })
      await page.goto(`${baseUrl}/__runner/runner.html`)
      const assetOutput = assets.receipt.outputs[slot.owner][slot.variant]
      const asset = findJavaScriptAsset(assetOutput.ordinaryRoot)
      const assetUrl = `${baseUrl}/priv/implementations/${slot.name}/dist/${asset.path}`
      const servedResponse = await context.request.get(assetUrl)
      assert.equal(servedResponse.status(), 200)
      const servedBytes = await servedResponse.body()
      assert.equal(servedBytes.length, asset.bytes)
      assert.equal(sha256(servedBytes), asset.sha256)

      const session = await context.newCDPSession(page)
      const scriptIds = new Map()
      session.on('Debugger.scriptParsed', event => scriptIds.set(event.url, event.scriptId))
      await session.send('Debugger.enable')
      await session.send('Profiler.enable')
      await session.send('Profiler.startPreciseCoverage', {
        callCount: true,
        detailed: true,
        allowTriggeredUpdates: false,
      })
      const result = await page.evaluate(
        ([url, itemCount]) => window.runBenchmark(url, itemCount),
        [`${baseUrl}/priv/implementations/${slot.name}/dist/index.html`, 100],
      )
      const taken = await session.send('Profiler.takePreciseCoverage')
      await session.send('Profiler.stopPreciseCoverage')
      const capture = taken.result.filter(entry => entry.url === assetUrl)
      assert.equal(capture.length, 1, `Expected one coverage script for ${assetUrl}`)
      const scriptId = scriptIds.get(assetUrl)
      assert(scriptId, `Debugger did not observe ${assetUrl}`)
      const { scriptSource } = await session.send('Debugger.getScriptSource', { scriptId })
      assert.equal(Buffer.byteLength(scriptSource), asset.bytes)
      assert.equal(sha256(scriptSource), asset.sha256)
      await session.send('Profiler.disable')
      await session.send('Debugger.disable')
      await session.detach()

      assert.equal(pageError, undefined)
      assert.equal(result.crossOriginIsolated, true)
      assert.deepEqual(result.counts, {
        sync: 400,
        timeout: 0,
        animation_frame: slot.owner === 'main' ? 400 : 600,
        microtask: 0,
        promise: 0,
      })
      const finalDom = await page.evaluate(() => {
        const document_ = document.querySelector('#benchmark')?.contentDocument
        return {
          hasNewTodo: Boolean(document_?.querySelector('.new-todo')),
          todoCount: document_?.querySelectorAll('.todo-list > li').length,
        }
      })
      assert.deepEqual(finalDom, { hasNewTodo: true, todoCount: 0 })
      const capturePath = join(output, `${slot.name}.coverage.json`)
      const captureBytes = Buffer.from(`${JSON.stringify(capture)}\n`)
      writeFileSync(capturePath, captureBytes, { flag: 'wx' })
      receipt.results.push({
        ...slot,
        asset: {
          path: asset.absolutePath,
          bytes: asset.bytes,
          sha256: asset.sha256,
          servedSha256: sha256(servedBytes),
          executedSha256: sha256(scriptSource),
        },
        mapJavaScript: assetOutput.mapJavaScript,
        sourceMap: assetOutput.sourceMap,
        counts: result.counts,
        finalDom,
        capture: fileFacts(capturePath),
        functionCount: capture[0].functions.length,
      })
      writeJson(receiptPath, receipt)
    } finally {
      await context.close()
    }
  }
  receipt.status = 'complete'
} catch (error) {
  receipt.status = 'failed'
  receipt.error = error instanceof Error ? error.stack : String(error)
  throw error
} finally {
  if (browser !== undefined) await browser.close()
  await new Promise((resolve, reject) =>
    server.close(error => (error ? reject(error) : resolve())),
  )
  receipt.browserAndServerClosed = true
  assertFrozenCandidate(config, configFacts)
  writeJson(receiptPath, receipt)
}

process.stdout.write(`${JSON.stringify(receipt, null, 2)}\n`)
