# Prepared orchestration

These scripts are parameterized preparation only. Copy `config.example.json`
to a new path and replace the candidate/evidence paths after the final
candidate is clean and committed.

Order, with an explicit lead grant before each heavy stage:

1. `node freeze-candidate.mjs config.json` records the clean HEAD/tree and all
   relevant source/dist inputs. This stage does not build or launch a browser.
2. `BUILD_SLOT_GRANTED=1 node assets.mjs config.json` builds fresh candidate
   optimized/naive ordinary assets and byte-identical hidden-map twins, then
   copies the audited exact-main assets/maps into the evidence root.
3. `BROWSER_SLOT_GRANTED=1 node preflight.mjs config.json` runs six functional
   slot guards and retains one precise result object for each unique asset.
4. `BROWSER_SLOT_GRANTED=1 node coverage.mjs config.json`, followed by
   `node analyse-coverage.cjs config.json` and
   `node verify-coverage.mjs config.json`, captures count-only evidence and
   enforces unchanged application/descendant/lazy work.
5. Only in the final coordinated quiet window:
   `QUIET_WINDOW_CONFIRMED=1 TIMING_SLOT_GRANTED=1 node timing.mjs config.json`.
   Then run `node analyse-timing.mjs config.json` after cleanup.

Each mutating stage refuses to overwrite its output. Every stage revalidates
the frozen clean candidate source/tree/files, the exact config file, and the
exact immutable driver, runner, server, verifier, instrumentation, Node,
Chromium, Vite, rimraf, trace-mapping package and main assets. Every loaded
receipt must point to the same freeze and exact upstream receipt hashes:
assets -> preflight -> coverage capture/analysis/guard -> timing/readback.
A post-freeze config/tool change or a foreign receipt therefore fails before
the stage can create output. No script changes the application workload or
ordinary driver.

`verify-coverage.mjs` compares complete positioned or logical row inventories
and uses unique exact-row assertions for the named Todo, dispatcher, lazy,
VNode, renderer and DOM boundaries. It does not accept a merely present row;
an extra matching row fails. Run the cheap offline assertion controls with:

```sh
node offline-negative-controls.mjs
```

The retained `offline-negative-controls.json` proves changed config, changed
tool input, a foreign asset receipt, and an extra duplicate coverage row fail
at their intended assertions. It launches no build, compiler, browser,
coverage capture or timing process.

The reused a471 packet is addressed by exact repository-relative paths in
`../additive-refinement.md`. The ordinary total is described only as the
harness measured callback/event-work sum: idle rAF callback time is included,
while unwrapped `MessageChannel.port.onmessage` arming-task CPU is outside the
measurement contract.
