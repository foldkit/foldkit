import assert from 'node:assert/strict'

const positioned = rows => rows
  .map(({ source, name, sourceLine, sourceColumn, count }) => ({
    source,
    name,
    sourceLine,
    sourceColumn,
    count,
  }))
  .sort((left, right) => JSON.stringify(left).localeCompare(JSON.stringify(right)))

const logical = rows => rows
  .map(({ source, name, count }) => ({ source, name, count }))
  .sort((left, right) => JSON.stringify(left).localeCompare(JSON.stringify(right)))

export const matchingRows = (result, source, name) =>
  result.relevantFunctions.filter(row => row.source === source && row.name === name)

export const assertExactPositionedInventory = (
  result,
  reference,
  source,
  name,
  label,
) => {
  const actualRows = positioned(matchingRows(result, source, name))
  const expectedRows = positioned(matchingRows(reference, source, name))
  assert(expectedRows.length > 0, `${label}: authenticated inventory is empty`)
  assert.deepEqual(actualRows, expectedRows, `${label}: positioned inventory differs`)
  return actualRows
}

export const assertExactLogicalInventory = (
  left,
  right,
  source,
  name,
  label,
) => {
  const leftRows = logical(matchingRows(left, source, name))
  const rightRows = logical(matchingRows(right, source, name))
  assert(leftRows.length > 0, `${label}: left inventory is empty`)
  assert.deepEqual(leftRows, rightRows, `${label}: logical inventory differs`)
  return leftRows
}

export const assertUniqueExactRow = (result, source, name, count, label) => {
  const rows = matchingRows(result, source, name)
  assert.equal(rows.length, 1, `${label}: expected one exact source/name row`)
  assert.equal(rows[0].count, count, `${label}: exact row count differs`)
  return positioned(rows)[0]
}
