import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import { join } from 'node:path'

import {
  assertFrozenCandidate,
  assertReceiptLineage,
  fileFacts,
  immutableInputs,
  loadAssetReceipt,
  loadConfig,
  writeJsonExclusive,
} from './common.mjs'

const { config, configFacts } = loadConfig(process.argv[2])
const root = join(config.evidenceRoot, 'timing')
const receiptPath = join(root, 'receipt.json')
const stdoutPath = join(root, 'timing.stdout.log')
const stderrPath = join(root, 'timing.stderr.log')
const receipt = JSON.parse(readFileSync(receiptPath, 'utf8'))
const stdout = readFileSync(stdoutPath, 'utf8')
const stderr = readFileSync(stderrPath, 'utf8')
assert.equal(receipt.status, 'capture-complete-pending-readback')
assert.equal(receipt.exitCode, 0)
assert.equal(receipt.retainedRoundedTotalSamples, 72)
assert.equal(receipt.discardedSamples, 0)
assert.equal(receipt.perRunBucketsAvailable, false)
assert.equal(receipt.perRunCountsAvailable, false)
const frozen = assertFrozenCandidate(config, configFacts)
const assets = loadAssetReceipt(config, configFacts, frozen)
assertReceiptLineage(receipt, {
  configFacts,
  candidateFreeze: frozen.facts,
  currentImmutableInputs: immutableInputs(config),
  assetReceipt: assets.facts,
  preflightReceipt: fileFacts(join(config.evidenceRoot, 'preflight/receipt.json')),
  coverageGuard: fileFacts(join(config.evidenceRoot, 'coverage/guard-receipt.json')),
})
assert.equal(receipt.stdout.sha256, fileFacts(stdoutPath).sha256)
assert.equal(receipt.stderr.sha256, fileFacts(stderrPath).sha256)
assert.deepEqual(receipt.cleanup, {
  portAvailableOnIpv4: true,
  portAvailableOnIpv6: true,
  browserProcessesAfter: [],
})
const knownWarning = 'fatal: not a git repository (or any of the parent directories): .git\n'
assert(stderr === '' || stderr === knownWarning, 'Unexpected timing stderr')
if (stderr === knownWarning) assert.match(stdout, /^harness revision: unknown$/m)

const median = values => {
  const sorted = [...values].sort((a, b) => a - b)
  const middle = Math.floor(sorted.length / 2)
  return sorted.length % 2 === 0
    ? (sorted[middle - 1] + sorted[middle]) / 2
    : sorted[middle]
}
for (const slot of receipt.slots) {
  const totals = receipt.samples
    .filter(sample => sample.slot === slot.name)
    .map(sample => sample.totalMs)
  assert.equal(totals.length, 12)
  const displayedMedian = Number(median(totals).toFixed(1))
  assert(
    Math.abs(receipt.summaries[slot.name].total - displayedMedian) <= 0.100001,
    `${slot.name} summary median differs from its displayed one-decimal samples`,
  )
}
const round = value => Number(value.toFixed(3))
const mulberry32 = seed => () => {
  let next = seed += 0x6d2b79f5
  next = Math.imul(next ^ (next >>> 15), next | 1)
  next ^= next + Math.imul(next ^ (next >>> 7), next | 61)
  return ((next ^ (next >>> 14)) >>> 0) / 4294967296
}
const percentile = (sorted, probability) => {
  const index = (sorted.length - 1) * probability
  const lower = Math.floor(index)
  const upper = Math.ceil(index)
  if (lower === upper) return sorted[lower]
  return sorted[lower] + (sorted[upper] - sorted[lower]) * (index - lower)
}
const bootstrapMean = values => {
  const random = mulberry32(config.bootstrap.seed)
  const means = []
  for (let iteration = 0; iteration < config.bootstrap.resamples; iteration += 1) {
    let total = 0
    for (let index = 0; index < values.length; index += 1) {
      total += values[Math.floor(random() * values.length)]
    }
    means.push(total / values.length)
  }
  means.sort((a, b) => a - b)
  return {
    lower2_5PercentMs: round(percentile(means, 0.025)),
    upper97_5PercentMs: round(percentile(means, 0.975)),
  }
}

const value = (slot, roundNumber) =>
  receipt.samples.find(sample => sample.slot === slot && sample.round === roundNumber)?.totalMs
  ?? assert.fail(`Missing ${slot} round ${roundNumber}`)
const analyseVariant = (name, baselineA, current, baselineB) => {
  const rounds = Array.from({ length: 12 }, (_, index) => {
    const roundNumber = index + 1
    const a = value(baselineA, roundNumber)
    const candidate = value(current, roundNumber)
    const b = value(baselineB, roundNumber)
    const baselineMean = (a + b) / 2
    return {
      round: roundNumber,
      baselineA: a,
      current: candidate,
      baselineB: b,
      baselineMean: round(baselineMean),
      currentMinusBaselineMean: round(candidate - baselineMean),
      duplicateBaselineAbsoluteDifference: round(Math.abs(a - b)),
    }
  })
  const deltas = rounds.map(row => row.currentMinusBaselineMean)
  const aMedian = receipt.summaries[baselineA].total
  const currentMedian = receipt.summaries[current].total
  const bMedian = receipt.summaries[baselineB].total
  const midpoint = (aMedian + bMedian) / 2
  return {
    name,
    slots: { baselineA, current, baselineB },
    summary: {
      baselineAMedianMs: aMedian,
      currentMedianMs: currentMedian,
      baselineBMedianMs: bMedian,
      baselineMedianMidpointMs: round(midpoint),
      currentMinusBaselineMedianMidpointMs: round(currentMedian - midpoint),
      currentMinusBaselineMedianMidpointPercent: round(((currentMedian - midpoint) / midpoint) * 100),
      fasterRounds: deltas.filter(delta => delta < 0).length,
      slowerRounds: deltas.filter(delta => delta > 0).length,
      tiedRounds: deltas.filter(delta => delta === 0).length,
      medianRoundAlignedDeltaMs: round(median(deltas)),
      medianDuplicateBaselineAbsoluteDifferenceMs: round(median(rounds.map(row => row.duplicateBaselineAbsoluteDifference))),
      exploratoryBootstrapMeanDelta: bootstrapMean(deltas),
      representativeSummaryBuckets: {
        baselineA: receipt.summaries[baselineA],
        current: receipt.summaries[current],
        baselineB: receipt.summaries[baselineB],
      },
    },
    rounds,
  }
}

const analysis = {
  schemaVersion: 1,
  status: 'valid-readback',
  interpretation: 'One ordinary harness callback/event-work batch. Optimized is primary; naive secondary. No confident speed claim follows from the exploratory interval.',
  config: configFacts,
  captureReceipt: fileFacts(receiptPath),
  stdout: fileFacts(stdoutPath),
  stderr: {
    ...fileFacts(stderrPath),
    classification: stderr === '' ? 'empty' : 'exact-known-pre-work-non-git-warning',
  },
  retainedRoundedTotalSamples: 72,
  perRunBucketsAvailable: false,
  perRunCountsAvailable: false,
  representativeCountSource: 'The unchanged driver retains the seventh result object for each slot only.',
  measurementScope: 'Standard harness synchronous/wrapped-callback sum. Idle rAF callbacks are included. MessageChannel.port.onmessage arming-task CPU is not instrumented or claimed.',
  uncertaintyMethod: {
    label: 'exploratory descriptive sensitivity check, not a confirmatory confidence interval',
    statistic: 'mean of 12 round-aligned current minus mean(main A, main B) differences',
    method: 'deterministic percentile bootstrap with replacement',
    seed: config.bootstrap.seed,
    resamples: config.bootstrap.resamples,
    percentiles: [2.5, 97.5],
    limitations: [
      'Only 12 paired rounds are available.',
      'Input totals are rounded to 0.1 ms.',
      'Cyclic ordering balances positions over the batch, but the three slots occupy different positions within each round.',
      'The interval is not a basis for a confident speed claim.',
    ],
  },
  variants: [
    analyseVariant('optimised', 'main-optimised-a', 'current-optimised', 'main-optimised-b'),
    analyseVariant('naive', 'main-naive-a', 'current-naive', 'main-naive-b'),
  ],
  samples: receipt.samples,
}
const output = join(root, 'validity-analysis.json')
writeJsonExclusive(output, analysis)
process.stdout.write(`${JSON.stringify(analysis, null, 2)}\n`)
