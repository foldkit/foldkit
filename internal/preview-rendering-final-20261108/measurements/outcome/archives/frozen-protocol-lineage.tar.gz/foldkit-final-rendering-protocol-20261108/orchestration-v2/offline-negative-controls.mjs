import assert from 'node:assert/strict'
import { existsSync, readFileSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'

import {
  assertFrozenBindings,
  assertReceiptLineage,
  scriptRoot,
} from './common.mjs'
import {
  assertExactPositionedInventory,
  assertUniqueExactRow,
} from './coverage-guards.mjs'

const configFacts = { path: '/tmp/config.json', bytes: 10, sha256: 'config-a' }
const immutableInputs = {
  driver: { path: '/tmp/run.mjs', bytes: 20, sha256: 'driver-a' },
  vite: { path: '/tmp/vite.js', bytes: 30, sha256: 'vite-a' },
}
const freezeReceipt = {
  config: configFacts,
  immutableInputs,
}
const freezeFacts = { path: '/tmp/freeze.json', bytes: 40, sha256: 'freeze-a' }
const assetFacts = { path: '/tmp/assets.json', bytes: 50, sha256: 'assets-a' }

const controls = []
const expectFailure = (name, run, pattern) => {
  let error
  try {
    run()
  } catch (caught) {
    error = caught
  }
  assert(error instanceof Error, `${name} unexpectedly passed`)
  assert.match(error.message, pattern)
  controls.push({ name, status: 'expected-failure-observed', message: error.message })
}

assertFrozenBindings({
  receipt: freezeReceipt,
  configFacts,
  currentImmutableInputs: immutableInputs,
})
controls.push({ name: 'canonical-freeze-lineage', status: 'pass' })

expectFailure(
  'changed-config-fails-freeze',
  () => assertFrozenBindings({
    receipt: freezeReceipt,
    configFacts: { ...configFacts, sha256: 'config-mutated' },
    currentImmutableInputs: immutableInputs,
  }),
  /Current config differs from frozen config/,
)

expectFailure(
  'changed-tool-fails-freeze',
  () => assertFrozenBindings({
    receipt: freezeReceipt,
    configFacts,
    currentImmutableInputs: {
      ...immutableInputs,
      vite: { ...immutableInputs.vite, sha256: 'vite-mutated' },
    },
  }),
  /Current immutable tool\/driver inputs differ from frozen inputs/,
)

const canonicalDownstream = {
  config: configFacts,
  candidateFreeze: freezeFacts,
  immutableInputs,
  assetReceipt: assetFacts,
}
assertReceiptLineage(canonicalDownstream, {
  configFacts,
  candidateFreeze: freezeFacts,
  currentImmutableInputs: immutableInputs,
  assetReceipt: assetFacts,
})
controls.push({ name: 'canonical-downstream-lineage', status: 'pass' })

expectFailure(
  'foreign-asset-receipt-fails-lineage',
  () => assertReceiptLineage(
    { ...canonicalDownstream, assetReceipt: { ...assetFacts, sha256: 'foreign' } },
    {
      configFacts,
      candidateFreeze: freezeFacts,
      currentImmutableInputs: immutableInputs,
      assetReceipt: assetFacts,
    },
  ),
  /Receipt asset lineage mismatch/,
)

const source = 'packages/foldkit/src/vdom.ts'
const name = 'visit'
const row = { source, name, sourceLine: 77, sourceColumn: 0, count: 31248 }
const reference = { relevantFunctions: [row] }
const canonicalResult = { relevantFunctions: [row] }
assertExactPositionedInventory(canonicalResult, reference, source, name, 'canonical visit')
assertUniqueExactRow(canonicalResult, source, name, 31248, 'canonical visit')
controls.push({ name: 'canonical-exact-row-inventory', status: 'pass' })

const duplicateResult = { relevantFunctions: [row, { ...row, sourceLine: 78 }] }
expectFailure(
  'extra-duplicate-row-fails-positioned-inventory',
  () => assertExactPositionedInventory(
    duplicateResult,
    reference,
    source,
    name,
    'mutated visit',
  ),
  /positioned inventory differs/,
)
expectFailure(
  'extra-duplicate-row-fails-unique-row',
  () => assertUniqueExactRow(duplicateResult, source, name, 31248, 'mutated visit'),
  /expected one exact source\/name row/,
)

const receipt = {
  schemaVersion: 1,
  status: 'pass',
  interpretation: 'Offline assertion mutation controls only; no build, compiler, browser, coverage or timing process.',
  controls,
}
const output = join(scriptRoot, 'offline-negative-controls.json')
const serialized = `${JSON.stringify(receipt, null, 2)}\n`
if (existsSync(output)) {
  assert.equal(readFileSync(output, 'utf8'), serialized, 'Retained control receipt differs')
} else {
  writeFileSync(output, serialized, { flag: 'wx' })
}
process.stdout.write(`${JSON.stringify({ output, controls: controls.length }, null, 2)}\n`)
