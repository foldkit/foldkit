import assert from 'node:assert/strict'
import { execFileSync } from 'node:child_process'
import { mkdirSync, realpathSync } from 'node:fs'

import {
  assertPinnedNode,
  candidateFiles,
  freezeReceiptPath,
  immutableInputs,
  loadConfig,
  writeJsonExclusive,
} from './common.mjs'

const { config, configFacts } = loadConfig(process.argv[2])
assertPinnedNode(config)
const git = args =>
  execFileSync('git', ['-C', config.candidateRoot, ...args], { encoding: 'utf8' }).trim()
assert.equal(git(['status', '--porcelain']), '', 'Candidate must be fully clean, including untracked files')
const head = git(['rev-parse', 'HEAD'])
const tree = git(['rev-parse', 'HEAD^{tree}'])
assert.match(head, /^[0-9a-f]{40}$/)
assert.match(tree, /^[0-9a-f]{40}$/)
mkdirSync(config.evidenceRoot, { recursive: true })
const receipt = {
  schemaVersion: 1,
  status: 'frozen-clean-committed-candidate',
  createdAt: new Date().toISOString(),
  candidateRoot: realpathSync(config.candidateRoot),
  head,
  tree,
  trackedAndUntrackedStatus: '',
  config: configFacts,
  immutableInputs: immutableInputs(config),
  files: candidateFiles(config.candidateRoot),
}
writeJsonExclusive(freezeReceiptPath(config), receipt)
process.stdout.write(`${JSON.stringify(receipt, null, 2)}\n`)
