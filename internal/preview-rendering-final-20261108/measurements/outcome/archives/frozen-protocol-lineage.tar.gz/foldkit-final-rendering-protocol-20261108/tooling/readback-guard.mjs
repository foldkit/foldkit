import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { readFileSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'

const workspace = '/private/tmp/foldkit-cadence-guard-20261108.befaa'
const evidence = join(workspace, 'evidence')
const failedReceiptPath = join(evidence, 'guards/receipt.json')
const stdoutPath = join(evidence, 'guards/callback.stdout.log')
const stderrPath = join(evidence, 'guards/callback.stderr.log')
const coverageReceiptPath = join(evidence, 'counts/receipt.json')
const analysisPath = join(evidence, 'counts/analysis.json')
const outputPath = join(evidence, 'callback-readback.json')
const sha256 = value => createHash('sha256').update(value).digest('hex')
const facts = path => {
  const bytes = readFileSync(path)
  return { path, bytes: bytes.length, sha256: sha256(bytes) }
}

const failedReceipt = JSON.parse(readFileSync(failedReceiptPath, 'utf8'))
const stdout = readFileSync(stdoutPath, 'utf8')
const stderr = readFileSync(stderrPath, 'utf8')
const coverageReceipt = JSON.parse(readFileSync(coverageReceiptPath, 'utf8'))
const analysis = JSON.parse(readFileSync(analysisPath, 'utf8'))

assert.equal(failedReceipt.status, 'failed')
assert.equal(failedReceipt.callbackGuard.exitCode, 0)
assert.equal(
  stderr,
  'fatal: not a git repository (or any of the parent directories): .git\n',
)
assert.equal(failedReceipt.functional.length, 2)
for (const functional of failedReceipt.functional) {
  assert.match(
    readFileSync(functional.log.path, 'utf8'),
    new RegExp(`VERIFY cadence-${functional.variant}: OK`),
  )
}

const summaries = {}
for (const variant of ['optimised', 'naive']) {
  const match = new RegExp(`^cadence-${variant} (\\{.*\\})$`, 'm').exec(stdout)
  assert(match, `Missing ${variant} summary`)
  summaries[variant] = JSON.parse(match[1])
  assert.equal(summaries[variant].crossOriginIsolated, true)
  assert.equal(summaries[variant].counts.sync, 400)
  assert.equal(summaries[variant].counts.timeout, 0)
  assert.equal(summaries[variant].counts.microtask, 0)
  assert.equal(summaries[variant].counts.promise, 0)
}
assert.equal(summaries.optimised.counts.animation_frame, 600)
assert.equal(summaries.naive.counts.animation_frame, 601)

assert.equal(coverageReceipt.status, 'complete')
assert.equal(coverageReceipt.browserAndServerClosed, true)
assert.equal(analysis.status, 'pass')
for (const focused of analysis.focused) {
  assert.equal(focused.counts.instrumentedAnimationFrameCallbacks, 600)
  assert.equal(focused.counts.renderFramePlain, 600)
  assert.equal(focused.counts.runRenderFrameBody, 400)
  assert.equal(focused.counts.renderSync, 401)
  assert.equal(focused.counts.applicationView, 401)
  assert.equal(focused.counts.patchVNode, 401)
  assert.equal(focused.extraIdleRenderFrameCallbacks, 200)
}

const output = {
  status: 'valid-readback-of-failed-exact-count-guard',
  interpretation:
    'The unchanged driver completed and both functional flows passed, but the old exact 400-rAF validity assertion correctly failed. Elapsed values from this uncoordinated guard and from precise coverage are invalid and unused.',
  failedGuardReceipt: facts(failedReceiptPath),
  rawStdout: facts(stdoutPath),
  rawStderr: facts(stderrPath),
  driverSummaries: Object.fromEntries(
    Object.entries(summaries).map(([variant, summary]) => [
      variant,
      {
        crossOriginIsolated: summary.crossOriginIsolated,
        counts: summary.counts,
      },
    ]),
  ),
  coverageReceipt: facts(coverageReceiptPath),
  sourceMatchedAnalysis: facts(analysisPath),
  focused: analysis.focused,
}
writeFileSync(outputPath, `${JSON.stringify(output, null, 2)}\n`, { flag: 'wx' })
process.stdout.write(
  `${JSON.stringify({ outputPath, sha256: sha256(readFileSync(outputPath)), ...output }, null, 2)}\n`,
)
