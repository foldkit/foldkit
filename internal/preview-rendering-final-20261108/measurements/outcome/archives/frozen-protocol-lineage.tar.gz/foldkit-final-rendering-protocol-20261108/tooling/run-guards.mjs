import assert from 'node:assert/strict'
import { spawnSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import {
  copyFileSync,
  existsSync,
  mkdirSync,
  readFileSync,
  realpathSync,
  readdirSync,
  statSync,
  symlinkSync,
  writeFileSync,
} from 'node:fs'
import { join, relative } from 'node:path'

const workspace = '/private/tmp/foldkit-cadence-guard-20261108.befaa'
const source = join(workspace, 'source')
const evidence = join(workspace, 'evidence')
const output = join(evidence, 'guards')
const harness = join(output, 'harness')
const driverRoot = '/private/tmp/foldkit-record-release-rendering-xpwmm820/driver'
const driver = join(driverRoot, 'run.mjs')
const verify = join(driverRoot, 'verify.mjs')
const instrumentation =
  '/private/tmp/foldkit-record-release-rendering-xpwmm820/harness/priv/instrumentation.js'
const node =
  '/Users/devinjameson/.vite-plus/js_runtime/node/26.13.0/bin/node'
const chromium =
  '/Users/devinjameson/Library/Caches/ms-playwright/chromium-1243/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing'
const assetReceiptPath = join(evidence, 'assets-and-maps.json')
const assetReceipt = JSON.parse(readFileSync(assetReceiptPath, 'utf8'))
const variants = ['optimised', 'naive']

assert.equal(existsSync(output), false, `Refusing to overwrite ${output}`)
mkdirSync(join(harness, 'priv/implementations'), { recursive: true })
copyFileSync(instrumentation, join(harness, 'priv/instrumentation.js'))

const sha256 = value => createHash('sha256').update(value).digest('hex')
const fileFacts = path => {
  const bytes = readFileSync(path)
  return { path, bytes: bytes.length, sha256: sha256(bytes) }
}
const filesUnder = root => {
  const files = []
  const visit = path => {
    for (const entry of readdirSync(path, { withFileTypes: true })) {
      const child = join(path, entry.name)
      if (entry.isDirectory()) visit(child)
      else if (entry.isFile()) {
        files.push({
          path: relative(root, child),
          bytes: statSync(child).size,
          sha256: sha256(readFileSync(child)),
        })
      }
    }
  }
  visit(root)
  return files.sort((left, right) => left.path.localeCompare(right.path))
}

const slots = variants.map(variant => ({
  variant,
  name: `cadence-${variant}`,
  source: join(source, 'internal/lustre-benchmark/dist', variant),
}))
for (const slot of slots) {
  const slotRoot = join(harness, 'priv/implementations', slot.name)
  mkdirSync(slotRoot, { recursive: true })
  symlinkSync(slot.source, join(slotRoot, 'dist'), 'dir')
  assert.equal(realpathSync(join(slotRoot, 'dist')), realpathSync(slot.source))
  const expected = assetReceipt.ordinaryAssets
    .filter(file => file.path.startsWith(`${slot.variant}/`))
    .map(file => ({ ...file, path: file.path.slice(slot.variant.length + 1) }))
  assert.deepEqual(filesUnder(slot.source), expected)
  slot.files = expected
}

const receipt = {
  status: 'running',
  interpretation:
    'Functional behavior and callback-count guards only. The unchanged driver emits elapsed values, but this uncoordinated single guard invocation is not timing evidence and no elapsed comparison is interpreted.',
  sourceHead: assetReceipt.source.head,
  node: fileFacts(node),
  chromium: fileFacts(chromium),
  verify: fileFacts(verify),
  driver: fileFacts(driver),
  runner: fileFacts(join(driverRoot, 'runner.html')),
  server: fileFacts(join(driverRoot, 'server.mjs')),
  instrumentation: fileFacts(instrumentation),
  assetReceipt: fileFacts(assetReceiptPath),
  slots,
  functional: [],
  callbackGuard: undefined,
}
const receiptPath = join(output, 'receipt.json')
const writeReceipt = () =>
  writeFileSync(receiptPath, `${JSON.stringify(receipt, null, 2)}\n`)
writeReceipt()

try {
  for (let index = 0; index < slots.length; index += 1) {
    const slot = slots[index]
    const port = 38640 + index
    const run = spawnSync(node, [verify], {
      cwd: driverRoot,
      env: {
        ...process.env,
        CI: '1',
        LANG: 'C.UTF-8',
        LC_ALL: 'C.UTF-8',
        NO_COLOR: '1',
        HARNESS_DIR: harness,
        IMPL: slot.name,
        PORT: String(port),
        FOLDKIT_BENCH_CHROMIUM: chromium,
      },
      encoding: 'utf8',
      maxBuffer: 1024 * 1024,
    })
    const logPath = join(output, `functional-${slot.variant}.log`)
    writeFileSync(
      logPath,
      [
        `$ ${node} ${verify}`,
        `HARNESS_DIR=${harness}`,
        `IMPL=${slot.name}`,
        `PORT=${port}`,
        `exit=${run.status}`,
        '',
        'stdout:',
        run.stdout ?? '',
        '',
        'stderr:',
        run.stderr ?? '',
      ].join('\n'),
    )
    assert.equal(run.status, 0, `${slot.name} functional guard failed`)
    assert.match(run.stdout, new RegExp(`VERIFY ${slot.name}: OK`))
    assert.equal(run.stderr, '')
    receipt.functional.push({
      variant: slot.variant,
      port,
      log: fileFacts(logPath),
    })
    writeReceipt()
  }

  const callbackPort = 38642
  const callbackRun = spawnSync(node, [driver], {
    cwd: driverRoot,
    env: {
      ...process.env,
      CI: '1',
      LANG: 'C.UTF-8',
      LC_ALL: 'C.UTF-8',
      NO_COLOR: '1',
      HARNESS_DIR: harness,
      IMPLS: slots.map(slot => slot.name).join(','),
      RUNS: '2',
      PORT: String(callbackPort),
      FOLDKIT_BENCH_CHROMIUM: chromium,
    },
    encoding: 'utf8',
    maxBuffer: 4 * 1024 * 1024,
  })
  const stdoutPath = join(output, 'callback.stdout.log')
  const stderrPath = join(output, 'callback.stderr.log')
  writeFileSync(stdoutPath, callbackRun.stdout ?? '')
  writeFileSync(stderrPath, callbackRun.stderr ?? '')
  receipt.callbackGuard = {
    port: callbackPort,
    runCount: 2,
    exitCode: callbackRun.status,
    stdout: fileFacts(stdoutPath),
    stderr: fileFacts(stderrPath),
    summaries: {},
  }
  writeReceipt()
  assert.equal(callbackRun.status, 0, 'unchanged callback driver failed')
  assert.equal(
    callbackRun.stderr,
    'fatal: not a git repository (or any of the parent directories): .git\n',
    'unexpected callback-driver stderr',
  )
  for (const slot of slots) {
    const match = new RegExp(`^${slot.name} (\\{.*\\})$`, 'm').exec(
      callbackRun.stdout,
    )
    assert(match, `Missing ${slot.name} summary`)
    const summary = JSON.parse(match[1])
    receipt.callbackGuard.summaries[slot.variant] = summary
    writeReceipt()
    assert.equal(summary.crossOriginIsolated, true)
    assert.deepEqual(summary.counts, {
      sync: 400,
      timeout: 0,
      animation_frame: 400,
      microtask: 0,
      promise: 0,
    })
  }
  receipt.status = 'pass'
} catch (error) {
  receipt.status = 'failed'
  receipt.error = error instanceof Error ? error.stack : String(error)
  throw error
} finally {
  writeReceipt()
}

process.stdout.write(`${JSON.stringify(receipt, null, 2)}\n`)
