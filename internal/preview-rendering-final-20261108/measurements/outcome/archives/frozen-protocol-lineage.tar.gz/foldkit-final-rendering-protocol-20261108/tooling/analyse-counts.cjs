const assert = require('node:assert/strict')
const { createHash } = require('node:crypto')
const { readFileSync, writeFileSync } = require('node:fs')
const { join } = require('node:path')
const ts = require('/Users/devinjameson/.codex/worktrees/block-completion-record/foldkit-unified-recovery-20261103/node_modules/typescript/lib/typescript.js')
const {
  TraceMap,
  decodedMappings,
} = require('/Users/devinjameson/.codex/worktrees/block-completion-record/foldkit-unified-recovery-20261103/node_modules/.pnpm/@jridgewell+trace-mapping@0.3.31/node_modules/@jridgewell/trace-mapping')

const workspace = '/private/tmp/foldkit-cadence-guard-20261108.befaa'
const evidence = join(workspace, 'evidence')
const captureRoot = join(evidence, 'counts')
const captureReceiptPath = join(captureRoot, 'receipt.json')
const assetReceiptPath = join(evidence, 'assets-and-maps.json')
const captureReceipt = JSON.parse(readFileSync(captureReceiptPath, 'utf8'))
const assetReceipt = JSON.parse(readFileSync(assetReceiptPath, 'utf8'))
const sha256 = value => createHash('sha256').update(value).digest('hex')

assert.equal(captureReceipt.status, 'complete')
assert.equal(captureReceipt.browserAndServerClosed, true)
assert.equal(captureReceipt.assetReceipt.sha256, sha256(readFileSync(assetReceiptPath)))

const normalizeSource = source => {
  if (!source) return undefined
  for (const marker of ['packages/', 'internal/']) {
    const index = source.lastIndexOf(marker)
    if (index >= 0) return source.slice(index)
  }
  return source
}

const astCache = new Map()
const enclosingName = (source, content, line, column) => {
  if (!content || line == null || column == null) return undefined
  let cached = astCache.get(`${source}\0${content}`)
  if (!cached) {
    const file = ts.createSourceFile(source, content, ts.ScriptTarget.Latest, true)
    const functions = []
    const visit = (node, parents) => {
      let names = parents
      if (ts.isFunctionLike(node) && node.body) {
        let name = node.name?.getText(file)
        let owner = node
        if (
          ts.isVariableDeclaration(node.parent) ||
          ts.isPropertyAssignment(node.parent) ||
          ts.isMethodDeclaration(node.parent)
        ) {
          name = node.parent.name?.getText(file) ?? name
          owner = node.parent
        }
        names = name ? [...parents, name] : parents
        const start = owner.getStart(file)
        const startLocation = file.getLineAndCharacterOfPosition(start)
        const endLocation = file.getLineAndCharacterOfPosition(owner.end)
        functions.push({
          start,
          end: owner.end,
          line: startLocation.line + 1,
          endLine: endLocation.line + 1,
          column: startLocation.character,
          name: names.join('.'),
        })
      }
      ts.forEachChild(node, child => visit(child, names))
    }
    visit(file, [])
    cached = { file, functions }
    astCache.set(`${source}\0${content}`, cached)
  }
  const offset = cached.file.getPositionOfLineAndCharacter(line - 1, column)
  const containing = cached.functions
    .filter(item => item.start <= offset && offset < item.end)
    .sort((left, right) => left.end - left.start)[0]
  const lineContaining = cached.functions
    .filter(item => item.line <= line && line <= item.endLine)
    .sort((left, right) => left.end - left.start)[0]
  const declaredOnMappedLine = cached.functions
    .filter(item => item.line === line)
    .sort((left, right) => left.end - left.start)[0]
  const closest = declaredOnMappedLine ?? lineContaining
  if (
    closest &&
    (!containing || closest.end - closest.start < containing.end - containing.start)
  ) {
    return closest.name
  }
  return containing?.name
}

const lowerBound = (mappings, offset) => {
  let low = 0
  let high = mappings.length
  while (low < high) {
    const middle = (low + high) >> 1
    if (mappings[middle].offset < offset) low = middle + 1
    else high = middle
  }
  return low
}

const relevant = source =>
  /(?:internal\/lustre-benchmark\/src\/(?:todo|view\.optimised|application(?:\.optimised)?|entry(?:\.optimised)?)\.ts|packages\/foldkit\/src\/(?:html\/(?:index|lazy)|snabbdom\/(?:h|init)|runtime\/(?:renderer|runtime|program)|vdom)\.ts)/.test(source ?? '')

const results = []
for (const captured of captureReceipt.results) {
  const mapFacts = assetReceipt.hiddenMaps.find(
    item => item.variant === captured.variant,
  )
  assert(mapFacts)
  assert.equal(mapFacts.javascript.sha256, captured.asset.sha256)
  const javascript = readFileSync(mapFacts.javascript.path, 'utf8')
  const rawMap = JSON.parse(readFileSync(mapFacts.map.path, 'utf8'))
  assert.equal(sha256(Buffer.from(javascript)), mapFacts.javascript.sha256)
  assert.equal(sha256(readFileSync(mapFacts.map.path)), mapFacts.map.sha256)
  const trace = new TraceMap(rawMap)
  const lineStarts = [0]
  for (let index = 0; index < javascript.length; index += 1) {
    if (javascript.charCodeAt(index) === 10) lineStarts.push(index + 1)
  }
  const mappings = []
  for (const [line, segments] of decodedMappings(trace).entries()) {
    for (const segment of segments) {
      if (segment.length < 4) continue
      mappings.push({
        offset: lineStarts[line] + segment[0],
        source: rawMap.sources[segment[1]],
        sourceNormalized: normalizeSource(rawMap.sources[segment[1]]),
        line: segment[2] + 1,
        column: segment[3],
        mappedName:
          segment.length >= 5 ? rawMap.names?.[segment[4]] : undefined,
        content: rawMap.sourcesContent?.[segment[1]],
      })
    }
  }

  const captureBytes = readFileSync(join(captureRoot, captured.captureFile))
  assert.equal(sha256(captureBytes), captured.captureSha256)
  const scripts = JSON.parse(captureBytes)
  assert.equal(scripts.length, 1)
  const functions = []
  for (const fn of scripts[0].functions) {
    const range = fn.ranges[0]
    let index = lowerBound(mappings, range.startOffset)
    let mapping
    while (index < mappings.length && mappings[index].offset < range.endOffset) {
      if (mappings[index].source) {
        mapping = mappings[index]
        break
      }
      index += 1
    }
    if (!mapping) continue
    functions.push({
      source: mapping.sourceNormalized,
      name:
        enclosingName(
          mapping.source,
          mapping.content,
          mapping.line,
          mapping.column,
        ) ?? mapping.mappedName ?? fn.functionName ?? '(anonymous)',
      generatedName: fn.functionName,
      line: mapping.line,
      column: mapping.column,
      count: range.count,
      generatedStartOffset: range.startOffset,
      generatedEndOffset: range.endOffset,
    })
  }
  results.push({
    name: captured.name,
    variant: captured.variant,
    assetSha256: captured.asset.sha256,
    captureSha256: captured.captureSha256,
    callbackCounts: captured.counts,
    relevantFunctions: functions.filter(row => relevant(row.source)),
  })
}

const rowsFor = (result, source, functionName) =>
  result.relevantFunctions.filter(
    row =>
      row.source === source &&
      (row.name === functionName || row.name.endsWith(`.${functionName}`)),
  )
const exactCount = (result, source, functionName) => {
  const rows = rowsFor(result, source, functionName)
  assert.equal(
    rows.length,
    1,
    `${result.variant}: expected one ${source} ${functionName}, got ${JSON.stringify(rows)}`,
  )
  return rows[0].count
}
const exactMappedLineCount = (result, source, line) => {
  const rows = result.relevantFunctions.filter(
    row => row.source === source && row.line === line,
  )
  assert.equal(
    rows.length,
    1,
    `${result.variant}: expected one ${source}:${line}, got ${JSON.stringify(rows)}`,
  )
  return rows[0].count
}

if (process.env.DEBUG_RENDERER_ROWS === '1') {
  console.log(
    JSON.stringify(
      results.map(result => ({
        variant: result.variant,
        rows: result.relevantFunctions.filter(
          row => row.source === 'packages/foldkit/src/runtime/renderer.ts',
        ),
      })),
      null,
      2,
    ),
  )
  process.exit(0)
}

const focused = results.map(result => {
  const viewSource =
    result.variant === 'optimised'
      ? 'internal/lustre-benchmark/src/view.optimised.ts'
      : 'internal/lustre-benchmark/src/todo.ts'
  const viewLine = result.variant === 'optimised' ? 225 : 341
  const counts = {
    instrumentedAnimationFrameCallbacks: result.callbackCounts.animation_frame,
    renderFramePlain: exactCount(
      result,
      'packages/foldkit/src/runtime/renderer.ts',
      'renderFramePlain',
    ),
    runRenderFrameBody: exactCount(
      result,
      'packages/foldkit/src/runtime/renderer.ts',
      'runRenderFrameBody',
    ),
    renderSync: exactMappedLineCount(
      result,
      'packages/foldkit/src/runtime/renderer.ts',
      473,
    ),
    armNextRenderFrame: exactMappedLineCount(
      result,
      'packages/foldkit/src/runtime/renderer.ts',
      844,
    ),
    scheduleRenderFrame: exactMappedLineCount(
      result,
      'packages/foldkit/src/runtime/renderer.ts',
      874,
    ),
    applicationView: exactMappedLineCount(result, viewSource, viewLine),
    patchVNode: exactCount(
      result,
      'packages/foldkit/src/vdom.ts',
      '__patchVNode',
    ),
  }
  assert.equal(counts.runRenderFrameBody, 400)
  assert.equal(counts.renderSync, 401)
  assert.equal(counts.applicationView, 401)
  assert.equal(counts.patchVNode, 401)
  assert.equal(counts.renderFramePlain, counts.instrumentedAnimationFrameCallbacks)
  assert(counts.renderFramePlain > counts.runRenderFrameBody)
  return {
    variant: result.variant,
    counts,
    extraIdleRenderFrameCallbacks:
      counts.renderFramePlain - counts.runRenderFrameBody,
  }
})

const output = {
  status: 'pass',
  interpretation:
    'Source-matched precise-coverage counts only; elapsed coverage values are invalid. The callback increase is idle armed renderFramePlain callbacks, not additional render bodies, application views, or patches.',
  sourceHead: captureReceipt.sourceHead,
  captureReceiptSha256: sha256(readFileSync(captureReceiptPath)),
  assetReceiptSha256: sha256(readFileSync(assetReceiptPath)),
  focused,
  results,
}
const outputPath = join(captureRoot, 'analysis.json')
writeFileSync(outputPath, `${JSON.stringify(output, null, 2)}\n`, { flag: 'wx' })
console.log(
  JSON.stringify(
    {
      outputPath,
      sha256: sha256(readFileSync(outputPath)),
      focused,
      rows: results.map(result => ({
        variant: result.variant,
        relevantFunctions: result.relevantFunctions.length,
      })),
    },
    null,
    2,
  ),
)
