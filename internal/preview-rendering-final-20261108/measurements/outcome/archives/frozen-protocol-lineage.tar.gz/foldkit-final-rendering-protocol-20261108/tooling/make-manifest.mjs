import assert from 'node:assert/strict'
import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import {
  existsSync,
  readFileSync,
  readdirSync,
  realpathSync,
  statSync,
  writeFileSync,
} from 'node:fs'
import { join, relative } from 'node:path'

const workspace = '/private/tmp/foldkit-cadence-guard-20261108.befaa'
const source = join(workspace, 'source')
const evidence = join(workspace, 'evidence')
const output = join(evidence, 'manifest.json')
assert.equal(existsSync(output), false, `Refusing to overwrite ${output}`)

const sha256 = value => createHash('sha256').update(value).digest('hex')
const facts = path => {
  const bytes = readFileSync(path)
  return { path, bytes: bytes.length, sha256: sha256(bytes) }
}
const inventory = root => {
  const files = []
  const links = []
  const visit = path => {
    for (const entry of readdirSync(path, { withFileTypes: true })) {
      const child = join(path, entry.name)
      if (entry.isSymbolicLink()) {
        links.push({ path: relative(root, child), target: realpathSync(child) })
      } else if (entry.isDirectory()) {
        visit(child)
      } else if (entry.isFile()) {
        files.push({
          path: relative(root, child),
          bytes: statSync(child).size,
          sha256: sha256(readFileSync(child)),
        })
      }
    }
  }
  visit(root)
  return {
    files: files.sort((left, right) => left.path.localeCompare(right.path)),
    links: links.sort((left, right) => left.path.localeCompare(right.path)),
  }
}
const git = args =>
  execFileSync('git', args, { cwd: source, encoding: 'utf8' }).trim()
const evidenceInventory = inventory(evidence)
const tools = [
  'prepare-assets.mjs',
  'run-guards.mjs',
  'capture-counts.mjs',
  'analyse-counts.cjs',
  'readback-guard.mjs',
  'make-manifest.mjs',
].map(name => facts(join(workspace, name)))

const manifest = {
  formatVersion: 1,
  generatedAt: new Date().toISOString(),
  label:
    'Cadence-only exact-source assets, failed old callback guard, functional checks, and source-matched count evidence; no timing claim',
  workspace,
  source: {
    root: source,
    head: git(['rev-parse', 'HEAD']),
    parent: git(['rev-parse', 'HEAD^']),
    trackedStatus: git(['status', '--short', '--untracked-files=no']),
  },
  disposition: {
    oldExact400RafGuard: 'failed-and-preserved',
    readback: 'valid',
    sourceMatchedCountPass: 'pass',
    ordinaryTiming: 'not-run',
    r11r19: 'excluded',
  },
  tools,
  evidenceFiles: evidenceInventory.files,
  evidenceLinks: evidenceInventory.links,
  openFollowUp:
    'Final integrated baseline/candidate must rerun exact source-matched semantic work guards, preserve and report cadence callback counts, and keep idle callback elapsed work in the ordinary end-to-end total.',
}
writeFileSync(output, `${JSON.stringify(manifest, null, 2)}\n`, { flag: 'wx' })
process.stdout.write(
  `${JSON.stringify({ output, sha256: sha256(readFileSync(output)), files: manifest.evidenceFiles.length, links: manifest.evidenceLinks.length }, null, 2)}\n`,
)
