import assert from 'node:assert/strict'
import { execFileSync, spawnSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import {
  existsSync,
  mkdirSync,
  readFileSync,
  realpathSync,
  readdirSync,
  renameSync,
  statSync,
  writeFileSync,
} from 'node:fs'
import { join, relative } from 'node:path'

const workspace = '/private/tmp/foldkit-cadence-guard-20261108.befaa'
const source = join(workspace, 'source')
const evidence = join(workspace, 'evidence')
const assetRoot = join(evidence, 'assets')
const mapRoot = join(evidence, 'maps')
const node =
  '/Users/devinjameson/.vite-plus/js_runtime/node/26.13.0/bin/node'
const dependencyRoot =
  '/Users/devinjameson/.codex/worktrees/block-completion-record/foldkit-unified-recovery-20261103/node_modules/.pnpm'
const rimraf = join(
  dependencyRoot,
  'rimraf@6.1.3/node_modules/rimraf/dist/esm/bin.mjs',
)
const vite = join(
  dependencyRoot,
  'vite@8.3.5_@types+node@26.4.0_jiti@2.7.0_yaml@2.9.1/node_modules/vite/bin/vite.js',
)
const head = 'befaa93b1565445a841a6c84ffb7fdee25b13cbb'
const cadence = '5c96e577ccbbceb160f500dc958ae542b29395d3'
const baseline = '7cc7d90e68dc5a55b4765bbd7f0469b55cdd928f'
const benchmarkRoot = join(source, 'internal/lustre-benchmark')
const pluginRoot = join(source, 'packages/vite-plugin-foldkit')

assert.equal(existsSync(evidence), false, `Refusing to overwrite ${evidence}`)
mkdirSync(assetRoot, { recursive: true })
mkdirSync(mapRoot, { recursive: true })

const sha256 = value => createHash('sha256').update(value).digest('hex')
const fileFacts = path => {
  const bytes = readFileSync(path)
  return { path, bytes: bytes.length, sha256: sha256(bytes) }
}
const git = args =>
  execFileSync('git', args, { cwd: source, encoding: 'utf8' }).trim()
const lines = value => value === '' ? [] : value.split('\n')
const filesUnder = root => {
  const files = []
  const visit = path => {
    for (const entry of readdirSync(path, { withFileTypes: true })) {
      const child = join(path, entry.name)
      if (entry.isDirectory()) visit(child)
      else if (entry.isFile()) {
        files.push({
          path: relative(root, child),
          bytes: statSync(child).size,
          sha256: sha256(readFileSync(child)),
        })
      }
    }
  }
  visit(root)
  return files.sort((left, right) => left.path.localeCompare(right.path))
}
const run = (name, command, cwd, env) => {
  const result = spawnSync(node, command, {
    cwd,
    env,
    encoding: 'utf8',
    maxBuffer: 16 * 1024 * 1024,
  })
  const output = [
    `$ ${node} ${command.join(' ')}`,
    `cwd=${cwd}`,
    `exit=${result.status}`,
    '',
    'stdout:',
    result.stdout ?? '',
    '',
    'stderr:',
    result.stderr ?? '',
  ].join('\n')
  writeFileSync(join(assetRoot, `${name}.log`), output)
  assert.equal(result.status, 0, `${name} failed:\n${output}`)
}

assert.equal(git(['rev-parse', 'HEAD']), head)
assert.equal(git(['rev-parse', `${head}^`]), cadence)
assert.equal(git(['rev-parse', `${cadence}^`]), baseline)
assert.equal(git(['status', '--short', '--untracked-files=no']), '')
assert.deepEqual(
  lines(git(['diff', '--name-only', cadence, head, '--', 'packages/foldkit/src'])),
  [],
)
assert.deepEqual(
  lines(git(['diff', '--name-only', baseline, cadence, '--', 'packages/foldkit/src'])),
  [
    'packages/foldkit/src/runtime/messageProcessing.test.ts',
    'packages/foldkit/src/runtime/messageQueue.ts',
    'packages/foldkit/src/runtime/renderFrame.test.ts',
    'packages/foldkit/src/runtime/renderer.ts',
  ],
)

const r11Paths = [
  'packages/foldkit/src/domReflection.ts',
  'packages/foldkit/src/html/index.ts',
  'packages/foldkit/src/snabbdom/h.ts',
]
for (const path of r11Paths) {
  assert.equal(
    sha256(readFileSync(join(source, path))),
    sha256(execFileSync('git', ['show', `${baseline}:${path}`], { cwd: source })),
    `${path} differs from the 7cc baseline`,
  )
}

const links = {
  rootDependencies: realpathSync(join(source, 'node_modules')),
  foldkitDependencies: realpathSync(join(source, 'packages/foldkit/node_modules')),
  pluginDependencies: realpathSync(
    join(source, 'packages/vite-plugin-foldkit/node_modules'),
  ),
  benchmarkFoldkit: realpathSync(join(benchmarkRoot, 'node_modules/foldkit')),
  benchmarkPlugin: realpathSync(
    join(benchmarkRoot, 'node_modules/@foldkit/vite-plugin'),
  ),
}
assert.equal(links.benchmarkFoldkit, realpathSync(join(source, 'packages/foldkit')))
assert.equal(links.benchmarkPlugin, pluginRoot)

const commonEnv = { ...process.env }
delete commonEnv.NODE_ENV
delete commonEnv.VITE_USER_NODE_ENV
delete commonEnv.MODE
delete commonEnv.BUILD_VARIANT
Object.assign(commonEnv, {
  CI: '1',
  LANG: 'C.UTF-8',
  LC_ALL: 'C.UTF-8',
  NO_COLOR: '1',
})

run('clean-plugin', [rimraf, 'dist', 'tsconfig.tsbuildinfo'], pluginRoot, commonEnv)
run(
  'build-plugin',
  [join(pluginRoot, 'node_modules/typescript/bin/tsc'), '-b', 'tsconfig.json'],
  pluginRoot,
  commonEnv,
)
run('clean-assets', [rimraf, 'dist'], benchmarkRoot, commonEnv)
run('build-naive', [vite, 'build', '--mode', 'production'], benchmarkRoot, commonEnv)
run(
  'build-optimised',
  [vite, 'build', '--mode', 'production'],
  benchmarkRoot,
  { ...commonEnv, BUILD_VARIANT: 'optimised' },
)
const optimisedSource = join(
  benchmarkRoot,
  'dist/optimised/index.optimised.html',
)
const optimisedTarget = join(benchmarkRoot, 'dist/optimised/index.html')
assert(existsSync(optimisedSource), optimisedSource)
renameSync(optimisedSource, optimisedTarget)

const ordinaryAssets = filesUnder(join(benchmarkRoot, 'dist'))
const mapResults = []
for (const variant of ['naive', 'optimised']) {
  const output = join(mapRoot, variant)
  const env =
    variant === 'optimised'
      ? { ...commonEnv, BUILD_VARIANT: 'optimised' }
      : commonEnv
  const command = [
    vite,
    'build',
    '--mode',
    'production',
    '--sourcemap',
    'hidden',
    '--outDir',
    output,
  ]
  const result = spawnSync(node, command, {
    cwd: benchmarkRoot,
    env,
    encoding: 'utf8',
    maxBuffer: 16 * 1024 * 1024,
  })
  writeFileSync(
    join(mapRoot, `${variant}.log`),
    [
      `$ ${node} ${command.join(' ')}`,
      `cwd=${benchmarkRoot}`,
      `exit=${result.status}`,
      '',
      'stdout:',
      result.stdout ?? '',
      '',
      'stderr:',
      result.stderr ?? '',
    ].join('\n'),
  )
  assert.equal(result.status, 0, `${variant} hidden-map build failed`)
  const assets = join(output, 'assets')
  const names = readdirSync(assets)
  const javascript = names.filter(name => name.endsWith('.js'))
  const maps = names.filter(name => name.endsWith('.js.map'))
  assert.equal(javascript.length, 1)
  assert.equal(maps.length, 1)
  const javascriptFacts = fileFacts(join(assets, javascript[0]))
  const mapFacts = fileFacts(join(assets, maps[0]))
  const expected = ordinaryAssets.find(
    file => file.path.startsWith(`${variant}/assets/`) && file.path.endsWith('.js'),
  )
  assert(expected, `Missing ordinary ${variant} JavaScript`)
  assert.equal(javascriptFacts.bytes, expected.bytes)
  assert.equal(javascriptFacts.sha256, expected.sha256)
  assert(mapFacts.bytes > 0)
  mapResults.push({ variant, javascript: javascriptFacts, map: mapFacts })
}

const receipt = {
  status: 'pass',
  source: {
    root: source,
    head,
    cadence,
    baseline,
    trackedStatus: git(['status', '--short', '--untracked-files=no']),
    cadenceProductionPaths: lines(
      git(['diff', '--name-only', baseline, cadence, '--', 'packages/foldkit/src']),
    ),
    postCadenceProductionPaths: lines(
      git(['diff', '--name-only', cadence, head, '--', 'packages/foldkit/src']),
    ),
    noR11Paths: r11Paths.map(path => fileFacts(join(source, path))),
  },
  links,
  node: fileFacts(node),
  vite: fileFacts(vite),
  pluginFiles: filesUnder(join(pluginRoot, 'dist')),
  lockfile: fileFacts(join(source, 'pnpm-lock.yaml')),
  driver: fileFacts(join(benchmarkRoot, 'bench/run.mjs')),
  optimisedView: fileFacts(join(benchmarkRoot, 'src/view.optimised.ts')),
  ordinaryAssets,
  hiddenMaps: mapResults,
}
writeFileSync(
  join(evidence, 'assets-and-maps.json'),
  `${JSON.stringify(receipt, null, 2)}\n`,
)
process.stdout.write(`${JSON.stringify(receipt, null, 2)}\n`)
