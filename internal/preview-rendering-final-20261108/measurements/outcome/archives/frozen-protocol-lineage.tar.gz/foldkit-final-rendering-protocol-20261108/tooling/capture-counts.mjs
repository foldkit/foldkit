import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import {
  existsSync,
  mkdirSync,
  readFileSync,
  writeFileSync,
} from 'node:fs'
import { basename, join } from 'node:path'
import { pathToFileURL } from 'node:url'

const workspace = '/private/tmp/foldkit-cadence-guard-20261108.befaa'
const evidence = join(workspace, 'evidence')
const output = join(evidence, 'counts')
const harness = join(evidence, 'guards/harness')
const driverRoot = '/private/tmp/foldkit-record-release-rendering-xpwmm820/driver'
const node =
  '/Users/devinjameson/.vite-plus/js_runtime/node/26.13.0/bin/node'
const chromiumPath =
  '/Users/devinjameson/Library/Caches/ms-playwright/chromium-1243/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing'
const assetReceiptPath = join(evidence, 'assets-and-maps.json')
const assetReceipt = JSON.parse(readFileSync(assetReceiptPath, 'utf8'))
const port = 38643
const itemCount = 100

assert.equal(existsSync(output), false, `Refusing to overwrite ${output}`)
mkdirSync(output)

const sha256 = value => createHash('sha256').update(value).digest('hex')
const fileFacts = path => {
  const bytes = readFileSync(path)
  return { path, bytes: bytes.length, sha256: sha256(bytes) }
}
const variants = ['optimised', 'naive'].map(variant => {
  const asset = assetReceipt.ordinaryAssets.find(
    file => file.path.startsWith(`${variant}/assets/`) && file.path.endsWith('.js'),
  )
  const map = assetReceipt.hiddenMaps.find(item => item.variant === variant)
  assert(asset, `Missing ${variant} asset`)
  assert(map, `Missing ${variant} map`)
  assert.equal(asset.sha256, map.javascript.sha256)
  return {
    variant,
    name: `cadence-${variant}`,
    asset,
    map: map.map,
  }
})

const { chromium } = await import(
  pathToFileURL(join(driverRoot, 'node_modules/playwright/index.mjs')).href
)
const { startServer } = await import(
  pathToFileURL(join(driverRoot, 'server.mjs')).href
)
assert.equal(sha256(readFileSync(process.execPath)), sha256(readFileSync(node)))
assert.equal(
  sha256(readFileSync(chromiumPath)),
  '8319963f6625accf51c0dd4f55091ceaf9f09ed39e7a52fed4fae12b2a6b668a',
)

const receipt = {
  status: 'running',
  interpretation:
    'One source-matched precise-coverage count pass only. Precise coverage changes optimization and elapsed cadence; no elapsed value is retained or valid.',
  sourceHead: assetReceipt.source.head,
  node: fileFacts(node),
  chromium: fileFacts(chromiumPath),
  runner: fileFacts(join(driverRoot, 'runner.html')),
  server: fileFacts(join(driverRoot, 'server.mjs')),
  instrumentation: fileFacts(join(harness, 'priv/instrumentation.js')),
  assetReceipt: fileFacts(assetReceiptPath),
  port,
  itemCount,
  workload:
    'Unchanged full add-100, toggle-100, delete-100 runner with two requestAnimationFrame waits per logical action and final quiet-frame gate.',
  results: [],
  browserAndServerClosed: false,
}
const receiptPath = join(output, 'receipt.json')
const writeReceipt = () =>
  writeFileSync(receiptPath, `${JSON.stringify(receipt, null, 2)}\n`)
writeReceipt()

const server = await startServer(harness, driverRoot, port)
let browser
try {
  browser = await chromium.launch({
    headless: true,
    executablePath: chromiumPath,
  })
  receipt.chromium.version = browser.version()
  const baseUrl = `http://localhost:${port}`

  for (const variant of variants) {
    const context = await browser.newContext()
    try {
      await context.route(/unpkg\.com|todomvc\.com/, route =>
        route.fulfill({
          status: 200,
          contentType: 'text/css',
          headers: { 'Cross-Origin-Resource-Policy': 'cross-origin' },
          body: '',
        }),
      )
      const page = await context.newPage()
      let pageError
      page.on('pageerror', error => {
        pageError ??= error
      })
      await page.goto(`${baseUrl}/__runner/runner.html`)

      const assetPath = variant.asset.path.slice(variant.variant.length + 1)
      const assetUrl = `${baseUrl}/priv/implementations/${variant.name}/dist/${assetPath}`
      const servedResponse = await context.request.get(assetUrl)
      assert.equal(servedResponse.status(), 200)
      const servedBytes = await servedResponse.body()
      assert.equal(servedBytes.length, variant.asset.bytes)
      assert.equal(sha256(servedBytes), variant.asset.sha256)

      const session = await context.newCDPSession(page)
      const scriptIds = new Map()
      session.on('Debugger.scriptParsed', event => {
        scriptIds.set(event.url, event.scriptId)
      })
      await session.send('Debugger.enable')
      await session.send('Profiler.enable')
      await session.send('Profiler.startPreciseCoverage', {
        callCount: true,
        detailed: true,
        allowTriggeredUpdates: false,
      })

      const result = await page.evaluate(
        ([url, count]) => window.runBenchmark(url, count),
        [
          `${baseUrl}/priv/implementations/${variant.name}/dist/index.html`,
          itemCount,
        ],
      )
      const taken = await session.send('Profiler.takePreciseCoverage')
      await session.send('Profiler.stopPreciseCoverage')
      const capture = taken.result.filter(entry => entry.url === assetUrl)
      assert.equal(capture.length, 1, `Expected one coverage script for ${assetUrl}`)

      const scriptId = scriptIds.get(assetUrl)
      assert(scriptId, `Debugger did not observe ${assetUrl}`)
      const { scriptSource } = await session.send('Debugger.getScriptSource', {
        scriptId,
      })
      assert.equal(Buffer.byteLength(scriptSource), variant.asset.bytes)
      assert.equal(sha256(scriptSource), variant.asset.sha256)
      await session.send('Profiler.disable')
      await session.send('Debugger.disable')
      await session.detach()

      assert.equal(pageError, undefined)
      assert.equal(result.crossOriginIsolated, true)
      assert.equal(result.counts.sync, 400)
      assert.equal(result.counts.timeout, 0)
      assert.equal(result.counts.microtask, 0)
      assert.equal(result.counts.promise, 0)
      const finalDom = await page.evaluate(() => {
        const document_ = document.querySelector('#benchmark')?.contentDocument
        return {
          hasNewTodo: Boolean(document_?.querySelector('.new-todo')),
          todoCount: document_?.querySelectorAll('.todo-list > li').length,
        }
      })
      assert.deepEqual(finalDom, { hasNewTodo: true, todoCount: 0 })

      const captureFile = `${variant.name}.coverage.json`
      const captureBytes = Buffer.from(`${JSON.stringify(capture)}\n`)
      writeFileSync(join(output, captureFile), captureBytes)
      receipt.results.push({
        variant: variant.variant,
        name: variant.name,
        asset: {
          file: basename(variant.asset.path),
          bytes: variant.asset.bytes,
          sha256: variant.asset.sha256,
          servedSha256: sha256(servedBytes),
          executedSha256: sha256(scriptSource),
        },
        map: variant.map,
        counts: result.counts,
        finalDom,
        captureFile,
        captureBytes: captureBytes.length,
        captureSha256: sha256(captureBytes),
        functionCount: capture[0].functions.length,
      })
      writeReceipt()
    } finally {
      await context.close()
    }
  }
  receipt.status = 'complete'
} catch (error) {
  receipt.status = 'failed'
  receipt.error = error instanceof Error ? error.stack : String(error)
  throw error
} finally {
  if (browser !== undefined) await browser.close()
  await new Promise((resolve, reject) =>
    server.close(error => (error ? reject(error) : resolve())),
  )
  receipt.browserAndServerClosed = true
  writeReceipt()
}

process.stdout.write(`${JSON.stringify(receipt, null, 2)}\n`)
