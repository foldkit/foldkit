# Additive work-count refinement

This note refines `protocol.md` without changing the frozen file.

The accepted view-default migration intentionally adds no Runtime render
wrapper. The final source-matched coverage gate therefore requires the same
application, descendant-view, lazy-cache, VNode-construction, normalization,
render-body and DOM-diff work counts previously authenticated for exact main.
It does not grant a blanket allowance for view-default-related count changes.
Within each optimized and naive pair, every unchanged application handler,
descendant-view function and `html/lazy` function row must match exactly after
source mapping. A missing, extra or different call-count row fails the gate.

The two source trees still use different framework architecture. Exact-main's
legacy `Runtime.makeApplication` update owner and current's Block/Program
dispatch, scoped-view, Program-view, Mount-registration and lowering wrappers
cannot be structurally equated. The coverage readback must name and retain all
reached current framework-wrapper rows. Known architecture-specific rows are
reported separately; they do not waive equality for the shared application,
descendant/lazy and renderer work boundaries.

The ordinary driver limit remains unchanged: every per-round total is retained
at 0.1 ms precision, while per-bucket times are only summary medians and
callback counts are only the representative seventh result for each slot.

The immutable exact-main packet is
`internal/preview-final-20261107/rendering/measurements/official-workcount-cpu-20261108`
in the clean repository. Reused provenance is located at:

- receipt: `receipts/official-final-artifact-receipt.json.gz`;
- optimized JavaScript/map:
  `maps/foldkit-main-optimised.js.gz` and
  `maps/foldkit-main-optimised.js.map.gz`;
- naive JavaScript/map: `maps/foldkit-main.js.gz` and
  `maps/foldkit-main.js.map.gz`.

The receipt's decompressed SHA-256 is
`9e4713466acc76e4f063e257212f209bf8533828c92c36f6eab8cd49a9c2bbde`.
The optimized JavaScript/map hashes are
`852eddbf31ec2d3274568f1f0d503dfeabc6e181c8d2361489b435b13ce14ded`
and `9d632a69c71bc066080470498aa7eab3bd60388caf1e242dd07542e65bc8710a`;
the naive hashes are
`d3e37e9f695531f98727dadc3ead8bddd4b0bdb93f52b64029880c3d7a78adb4`
and `da77296108fbefa88581c14bc2745f1055de0c7e39fa1f93583f7e51ccfd011f`.
The orchestration verifies every copied main dist file against the receipt
before use.

Finally, the ordinary result is the harness's measured callback/event-work
sum, not complete process CPU or wall time. Standard instrumentation measures
the synchronous event work and wrapped timeout, rAF, microtask and Promise
callbacks. It does not wrap `MessageChannel.port.onmessage`, including cadence
arming tasks. Idle rAF callback time remains included and must not be
subtracted, but no report may claim that cadence arming-task CPU is included.
