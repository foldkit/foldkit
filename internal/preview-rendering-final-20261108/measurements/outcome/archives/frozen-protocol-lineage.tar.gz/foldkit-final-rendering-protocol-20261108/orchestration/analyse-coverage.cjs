const assert = require('node:assert/strict')
const { createHash } = require('node:crypto')
const { readFileSync, writeFileSync } = require('node:fs')
const { join, resolve } = require('node:path')

const configPath = resolve(process.argv[2] ?? assert.fail('Pass config.json'))
const config = JSON.parse(readFileSync(configPath, 'utf8'))
const { TraceMap, decodedMappings } = require(config.traceMapping)
const ts = require(join(
  config.candidateRoot,
  'packages/foldkit/node_modules/typescript/lib/typescript.js',
))
const root = join(config.evidenceRoot, 'coverage')
const receiptPath = join(root, 'receipt.json')
const receipt = JSON.parse(readFileSync(receiptPath, 'utf8'))
assert.equal(receipt.status, 'complete')
assert.equal(receipt.browserAndServerClosed, true)
const sha256 = value => createHash('sha256').update(value).digest('hex')

const normalizeSource = source => {
  if (!source) return undefined
  for (const marker of ['packages/', 'internal/']) {
    const index = source.lastIndexOf(marker)
    if (index >= 0) return source.slice(index)
  }
  return source
}

const astCache = new Map()
const enclosingName = (source, content, line, column) => {
  if (!content || line == null || column == null) return undefined
  const key = `${source}\0${content}`
  let cached = astCache.get(key)
  if (!cached) {
    const file = ts.createSourceFile(source, content, ts.ScriptTarget.Latest, true)
    const functions = []
    const visit = (node, parents) => {
      let names = parents
      if (ts.isFunctionLike(node) && node.body) {
        let name = node.name?.getText(file)
        let owner = node
        if (
          ts.isVariableDeclaration(node.parent) ||
          ts.isPropertyAssignment(node.parent) ||
          ts.isMethodDeclaration(node.parent)
        ) {
          name = node.parent.name?.getText(file) ?? name
          owner = node.parent
        }
        names = name ? [...parents, name] : parents
        functions.push({ start: owner.getStart(file), end: owner.end, name: names.join('.') })
      }
      ts.forEachChild(node, child => visit(child, names))
    }
    visit(file, [])
    cached = { file, functions }
    astCache.set(key, cached)
  }
  const offset = cached.file.getPositionOfLineAndCharacter(line - 1, column)
  return cached.functions
    .filter(item => item.start <= offset && offset < item.end)
    .sort((left, right) => left.end - left.start)[0]?.name
}

const lowerBound = (mappings, offset) => {
  let low = 0
  let high = mappings.length
  while (low < high) {
    const middle = (low + high) >> 1
    if (mappings[middle].offset < offset) low = middle + 1
    else high = middle
  }
  return low
}

const relevant = source =>
  /(?:internal\/lustre-benchmark\/src\/|packages\/foldkit\/src\/(?:block\/|domReflection|html\/|snabbdom\/|runtime\/|struct\/|vdom))/.test(source ?? '')

const results = []
for (const captured of receipt.results) {
  const javascript = readFileSync(captured.mapJavaScript.path, 'utf8')
  const rawMapBytes = readFileSync(captured.sourceMap.path)
  const rawMap = JSON.parse(rawMapBytes)
  assert.equal(sha256(Buffer.from(javascript)), captured.asset.sha256)
  assert.equal(sha256(rawMapBytes), captured.sourceMap.sha256)
  const trace = new TraceMap(rawMap)
  const lineStarts = [0]
  for (let index = 0; index < javascript.length; index += 1) {
    if (javascript.charCodeAt(index) === 10) lineStarts.push(index + 1)
  }
  const mappings = []
  for (const [line, segments] of decodedMappings(trace).entries()) {
    for (const segment of segments) {
      if (segment.length < 4) continue
      mappings.push({
        offset: lineStarts[line] + segment[0],
        source: rawMap.sources[segment[1]],
        normalizedSource: normalizeSource(rawMap.sources[segment[1]]),
        line: segment[2] + 1,
        column: segment[3],
        mappedName: segment.length >= 5 ? rawMap.names?.[segment[4]] : undefined,
        content: rawMap.sourcesContent?.[segment[1]],
      })
    }
  }
  const captureBytes = readFileSync(captured.capture.path)
  assert.equal(sha256(captureBytes), captured.capture.sha256)
  const scripts = JSON.parse(captureBytes)
  assert.equal(scripts.length, 1)
  const functions = []
  for (const fn of scripts[0].functions) {
    const range = fn.ranges[0]
    let index = lowerBound(mappings, range.startOffset)
    let mapping
    while (index < mappings.length && mappings[index].offset < range.endOffset) {
      if (mappings[index].source) {
        mapping = mappings[index]
        break
      }
      index += 1
    }
    if (!mapping) continue
    functions.push({
      source: mapping.normalizedSource,
      name: enclosingName(mapping.source, mapping.content, mapping.line, mapping.column)
        ?? mapping.mappedName ?? fn.functionName ?? '(anonymous)',
      generatedName: fn.functionName,
      sourceLine: mapping.line,
      sourceColumn: mapping.column,
      count: range.count,
      generatedStartOffset: range.startOffset,
      generatedEndOffset: range.endOffset,
    })
  }
  results.push({
    name: captured.name,
    owner: captured.owner,
    variant: captured.variant,
    assetSha256: captured.asset.sha256,
    captureSha256: captured.capture.sha256,
    relevantFunctions: functions.filter(row => relevant(row.source)),
  })
}

const output = {
  schemaVersion: 1,
  status: 'complete',
  interpretation: 'Source-matched precise-coverage call counts only; elapsed values are invalid.',
  captureReceiptSha256: sha256(readFileSync(receiptPath)),
  results,
}
const outputPath = join(root, 'analysis.json')
writeFileSync(outputPath, `${JSON.stringify(output, null, 2)}\n`, { flag: 'wx' })
process.stdout.write(`${JSON.stringify({ outputPath, sha256: sha256(readFileSync(outputPath)) }, null, 2)}\n`)
