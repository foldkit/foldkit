import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import { join } from 'node:path'
import { gunzipSync } from 'node:zlib'

import {
  assertFrozenCandidate,
  fileFacts,
  loadConfig,
  writeJsonExclusive,
} from './common.mjs'

const { config, configFacts } = loadConfig(process.argv[2])
const frozen = assertFrozenCandidate(config)
const root = join(config.evidenceRoot, 'coverage')
const receiptPath = join(root, 'receipt.json')
const analysisPath = join(root, 'analysis.json')
const receipt = JSON.parse(readFileSync(receiptPath, 'utf8'))
const analysis = JSON.parse(readFileSync(analysisPath, 'utf8'))
const authenticatedReferencePath = join(
  config.repoEvidenceRoot,
  'analysis/source-matched-analysis-final.json.gz',
)
const authenticatedReference = JSON.parse(
  gunzipSync(readFileSync(authenticatedReferencePath)),
)
assert.equal(receipt.status, 'complete')
assert.equal(receipt.browserAndServerClosed, true)
assert.equal(analysis.status, 'complete')

for (const result of receipt.results) {
  assert.equal(result.asset.sha256, result.asset.servedSha256)
  assert.equal(result.asset.sha256, result.asset.executedSha256)
  assert.deepEqual(result.finalDom, { hasNewTodo: true, todoCount: 0 })
  assert.deepEqual(result.counts, {
    sync: 400,
    timeout: 0,
    animation_frame: result.owner === 'main' ? 400 : 600,
    microtask: 0,
    promise: 0,
  })
}

const by = (owner, variant) =>
  analysis.results.find(result => result.owner === owner && result.variant === variant)
    ?? assert.fail(`Missing ${owner} ${variant}`)
const compact = rows => rows
  .map(({ source, name, sourceLine, sourceColumn, count }) => ({
    source,
    name,
    sourceLine,
    sourceColumn,
    count,
  }))
  .sort((left, right) => JSON.stringify(left).localeCompare(JSON.stringify(right)))
const rows = (result, predicate) => compact(result.relevantFunctions.filter(predicate))
const logicalRows = (result, predicate) => result.relevantFunctions
  .filter(predicate)
  .map(({ source, name, count }) => ({ source, name, count }))
  .sort((left, right) => JSON.stringify(left).localeCompare(JSON.stringify(right)))
const referenceBy = (owner, variant) => {
  const slot = owner === 'main'
    ? `foldkit-main${variant === 'optimised' ? '-optimised' : ''}`
    : `foldkit-preview-final${variant === 'optimised' ? '-optimised' : ''}`
  return authenticatedReference.coverageResults.find(result => result.slot === slot)
    ?? assert.fail(`Missing authenticated reference ${slot}`)
}
const has = (result, source, name, count) => {
  assert(
    result.relevantFunctions.some(row =>
      row.source === source && row.name === name && row.count === count,
    ),
    `Missing ${result.name}: ${source} ${name} count ${count}`,
  )
}

const exactPairs = []
const frameworkWrappers = []
for (const variant of ['optimised', 'naive']) {
  const main = by('main', variant)
  const current = by('current', variant)

  const applicationPredicate = row =>
    /internal\/lustre-benchmark\/src\/(?:todo|view\.optimised)\.ts$/.test(row.source ?? '') &&
    !(row.source.endsWith('/todo.ts') && row.name === 'update')
  const mainApplication = rows(main, applicationPredicate)
  const currentApplication = rows(current, applicationPredicate)
  const referenceMain = referenceBy('main', variant)
  const referenceCurrent = referenceBy('current', variant)
  assert.deepEqual(
    mainApplication,
    rows(referenceMain, applicationPredicate),
    `${variant} exact-main positioned application rows differ from authenticated reference`,
  )
  assert.deepEqual(
    currentApplication,
    rows(referenceCurrent, applicationPredicate),
    `${variant} current positioned application rows differ from authenticated reference`,
  )
  assert.deepEqual(
    logicalRows(current, applicationPredicate),
    logicalRows(main, applicationPredicate),
    `${variant} unchanged application handlers/descendant views differ`,
  )

  const lazyPredicate = row =>
    row.source === 'packages/foldkit/src/html/lazy.ts' &&
    row.name !== 'trackedBoundaryOccurrencesAreCurrent'
  const mainLazy = rows(main, lazyPredicate)
  const currentLazy = rows(current, lazyPredicate)
  assert.deepEqual(
    mainLazy,
    rows(referenceMain, lazyPredicate),
    `${variant} exact-main positioned html/lazy rows differ from authenticated reference`,
  )
  assert.deepEqual(
    currentLazy,
    rows(referenceCurrent, lazyPredicate),
    `${variant} current positioned html/lazy rows differ from authenticated reference`,
  )
  assert.deepEqual(
    logicalRows(current, lazyPredicate),
    logicalRows(main, lazyPredicate),
    `${variant} unchanged html/lazy functions differ`,
  )

  const expected = variant === 'optimised'
    ? { build: 3906, normalize: 3906, visit: 31248, updateChildren: 3387 }
    : { build: 132125, normalize: 132125, visit: 160063, updateChildren: 131606 }
  for (const result of [main, current]) {
    has(result, 'packages/foldkit/src/html/index.ts', 'buildVNodeData', expected.build)
    has(result, 'packages/foldkit/src/html/index.ts', 'buildElement', expected.build)
    has(result, 'packages/foldkit/src/html/index.ts', 'copyChildrenDroppingEmpty', expected.normalize)
    has(result, 'packages/foldkit/src/vdom.ts', 'visit', expected.visit)
    has(result, 'packages/foldkit/src/runtime/renderer.ts', 'makeRenderer.renderSync', 401)
    has(result, 'packages/foldkit/src/runtime/renderer.ts', 'makeRenderer.runRenderFrameBody', 400)
    has(result, 'packages/foldkit/src/snabbdom/init.ts', 'init.patch', 401)
    has(result, 'packages/foldkit/src/snabbdom/init.ts', 'init.updateChildren', expected.updateChildren)
  }
  has(main, 'internal/lustre-benchmark/src/todo.ts', 'update', 400)
  const currentDispatchRows = current.relevantFunctions.filter(row =>
    row.source === 'packages/foldkit/src/block/delivery.ts' &&
    row.name === 'createCompositionUpdate.makeUpdateFromCases.dualDispatch',
  )
  assert.equal(currentDispatchRows.length, 1, `${variant} current exact dispatcher row is not unique`)
  assert.equal(currentDispatchRows[0].count, 400, `${variant} current exact dispatcher count differs`)
  if (variant === 'optimised') {
    has(main, 'packages/foldkit/src/html/lazy.ts', 'argsEqual', 26739)
    has(current, 'packages/foldkit/src/html/lazy.ts', 'argsEqual', 26739)
    has(main, 'packages/foldkit/src/html/lazy.ts', 'resolveOrCache', 26844)
    has(current, 'packages/foldkit/src/html/lazy.ts', 'resolveOrCache', 26844)
  }

  const wrapperPredicate = row => row.count > 0 && (
    /packages\/foldkit\/src\/(?:block\/|runtime\/program|struct\/)/.test(row.source ?? '') ||
    row.name === 'trackedBoundaryOccurrencesAreCurrent' ||
    row.name.includes('assertLayeredMountsAreRegistered') ||
    row.name === 'makeRenderer.renderFramePlain'
  )
  frameworkWrappers.push({ variant, rows: rows(current, wrapperPredicate) })
  exactPairs.push({
    variant,
    unchangedApplicationRows: mainApplication.length,
    unchangedLazyRows: mainLazy.length,
    expectedSharedWork: expected,
  })
}

const guard = {
  schemaVersion: 1,
  status: 'pass',
  interpretation: 'Exact source-matched equality passed for every unchanged application handler, descendant-view and html/lazy row within optimized and naive pairs. Shared VNode/render/DOM work counts also passed. Current architecture wrappers are named separately, not waived as view-default changes.',
  config: configFacts,
  candidateFreeze: frozen.facts,
  captureReceipt: fileFacts(receiptPath),
  analysis: fileFacts(analysisPath),
  authenticatedReference: fileFacts(authenticatedReferencePath),
  exactPairs,
  frameworkWrappers,
  measurementScope: 'Coverage count evidence only. Ordinary harness instrumentation does not wrap MessageChannel.port.onmessage; no cadence arming-task CPU inclusion is claimed.',
}
const guardPath = join(root, 'guard-receipt.json')
writeJsonExclusive(guardPath, guard)
process.stdout.write(`${JSON.stringify(guard, null, 2)}\n`)
