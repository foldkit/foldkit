# Additive orchestration v2 repair

This additive packet supersedes only the prepared orchestration scripts in
`orchestration/`. The original preparation manifest, original orchestration,
cadence evidence, protocol, and earlier archives remain byte-for-byte
preserved. A future authorized execution must use `orchestration-v2/`.

## Transitive freeze and receipt binding

The clean committed-candidate freeze now authenticates both the exact config
file and every immutable executable/tool input. Every later stage recomputes
those facts and compares them with the freeze. Loaded asset, preflight,
coverage-capture, coverage-analysis, coverage-guard, timing, and timing
readback receipts are also bound to the same freeze and exact upstream receipt
facts. Asset files and hidden maps are re-read from disk when an asset receipt
is loaded, with paths constrained to the evidence root.

This prevents a changed config or tool, a foreign asset packet, or a receipt
from another freeze from being mixed into the chain after the freeze.

## Exact work inventories

Coverage verification no longer treats the presence of one matching row as a
work proof. Unchanged application handlers, descendant views, and Html/lazy
functions retain exact source-positioned authentication and exact logical
main/current equality. The shared VNode, render, and DOM boundaries are
checked as complete authenticated inventories or unique exact rows. The Todo
update, current exact dispatcher, cadence callback entry, `argsEqual`, and
`resolveOrCache` boundaries each require one exact source/name row and its
expected count. Source line and column remain part of positioned equality, so
an extra or swapped anonymous/repeated function row cannot pass.

## Offline negative controls

`orchestration-v2/offline-negative-controls.mjs` exercises the assertions
without running a build, compiler, browser, coverage capture, or timing stage.
Its retained receipt records expected failures for changed config, changed
Vite input, a foreign asset receipt, and an extra duplicate VNode row, plus
canonical passing controls.

No candidate build, browser process, coverage capture, or ordinary timing was
run while preparing this repair.
