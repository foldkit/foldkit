# Exact-main/current-candidate rendering protocol

Status: prepared only. Do not start builds, browsers, coverage or ordinary
timing until the final candidate is integrated, its correctness gates pass,
and the lead grants the corresponding windows.

## Comparison and frozen identities

The comparison is exact main
`a471adb24d750ab9e8d8312edad53ff6f26d961b` versus the final integrated
current candidate containing the accepted cadence and view-default changes.
R11/R19 remains excluded.

Reuse the authenticated main assets only when every stored byte and input
guard still passes:

- optimized JavaScript: 306,590 bytes,
  `852eddbf31ec2d3274568f1f0d503dfeabc6e181c8d2361489b435b13ce14ded`;
- optimized hidden map:
  `9d632a69c71bc066080470498aa7eab3bd60388caf1e242dd07542e65bc8710a`;
- naive JavaScript: 304,187 bytes,
  `d3e37e9f695531f98727dadc3ead8bddd4b0bdb93f52b64029880c3d7a78adb4`;
- naive hidden map:
  `da77296108fbefa88581c14bc2745f1055de0c7e39fa1f93583f7e51ccfd011f`;
- official artifact receipt:
  `9e4713466acc76e4f063e257212f209bf8533828c92c36f6eab8cd49a9c2bbde`.

That receipt authenticates the a471 Foldkit and Vite-plugin Git blobs and the
legacy `Runtime.makeApplication` adapter. The retained main build was copied
from the independently reviewed November 4 build rather than independently
reinstalled. Preserve that limitation. Do not rebuild exact main with the
current plugin. If a main asset, its a471 source/plugin provenance, the
benchmark workload, the driver, or the pinned toolchain no longer matches,
create a fresh isolated a471 build instead of substituting a near match.

The final current candidate gets a fresh isolated, self-contained source copy
after integration. Record its exact HEAD/tree, clean status, source and dist
hashes, package links, lockfile, Vite plugin, benchmark inputs, ordinary
assets, and byte-identical hidden-map twins. Pin:

- Node executable
  `533bd644c5ae0e0ea3a80e433aad16b817447ccba1e1eea701875eac80cb75d4`;
- Chromium executable
  `8319963f6625accf51c0dd4f55091ceaf9f09ed39e7a52fed4fae12b2a6b668a`;
- unchanged `run.mjs`
  `a93c12e6fe411eb5fa8abc342e32974d94496622ba8a475b81f7d6dc9bbc26f0`;
- unchanged `runner.html`
  `6d26843332fa4b5bcd55def19f6219ac8d26a0db242c32bc54a2291a6a695ee1`;
- unchanged `server.mjs`
  `fb76bfaf628dd7ecd9932c008604b566a0cafaa20fc9f88f8f35bfa3ac980398`.

## What the unchanged driver records

Keep the driver and full add-100, toggle-100, delete-100 workload unchanged.
The normal harness instrumentation remains enabled: it wraps synchronous,
timeout, animation-frame, microtask and Promise callbacks to produce the
benchmark totals. Ordinary timing adds no Debugger, CDP CPU profiler, precise
coverage, tracing or other profiling instrumentation.

With six slots and `RUNS=12`, the driver prints and therefore retains exactly
12 per-round totals for each slot, rounded to 0.1 ms. It does **not** print or
retain each run's raw bucket times or callback counts. At the end it prints,
for each slot:

- the median total and independently calculated bucket medians, each rounded
  to 0.1 ms;
- the median boot total;
- one representative `counts` object taken from the seventh stored run for
  that slot (`runs[Math.floor(12 / 2)]`);
- the relative-to-fastest summary.

Consequently the final report may claim all 72 rounded totals were retained,
but must not claim per-run buckets or counts. The representative summary count
is not proof that all 12 runs had that count.

## Preflight and semantic-work controls

Run these outside the timing window and preserve their elapsed values only as
non-timing diagnostics:

1. Wire six slot directories:
   `main-optimized-a`, `current-optimized`, `main-optimized-b`,
   `main-naive-a`, `current-naive`, `main-naive-b`. Require each duplicate
   main pair to serve byte-identical JavaScript.
2. Run the ordinary functional Todo flow against all six directories, with
   cross-origin isolation, no page error, the input present, and an empty final
   Todo list.
3. Run a separate full-result callback guard for each unique asset. This
   helper may retain one complete result object without changing `run.mjs`.
   Require main sync400/rAF400 and current sync400/rAF in the predeclared
   observed set `{600, 601}`, with timeout/microtask/Promise all zero. Preserve
   any failure rather than widening the set.
4. Run one separate source-matched precise-coverage pass over the four unique
   assets. Require 400 update dispatches, 100 calls to each exact Todo handler,
   400 `runRenderFrameBody` calls, and boot-inclusive 401 outer views,
   `renderSync` calls and root patches. Retain descendant/lazy work counts as
   mutation controls, while allowing explicitly reviewed view-default wrapper
   changes to have their own exact source-matched counts.

The cadence-only packet proves 600 `renderFramePlain` entries and 400 frame
bodies in its separate coverage run, hence 200 early-return idle callbacks.
Its ordinary naive result reported 601 callbacks, but the 601st callback's
identity is unresolved. Do not describe it as proved trailing-idle work unless
new source-matched evidence establishes that. All observed callback work stays
inside the ordinary end-to-end result; subtract nothing.

## One bounded ordinary batch

After every correctness and preflight guard passes, reserve one explicit quiet
window. Use the six slots above, `RUNS=12`, one pinned Chromium process and a
fresh context for each workload. The unchanged driver rotates the six-slot
order by one position per round, so every slot occupies every ordinal position
twice. There is no declared warmup.

Preserve raw stdout and stderr, the 72 rounded totals, summary rows, exact
environment, source/asset hashes, host snapshots, start/end timestamps, and
owned browser/server/listener cleanup. Preserve every failure and do not
discard or retry samples. A setup or semantic failure before a valid sample is
still retained and stops the batch.

If the unchanged driver's caught Git-revision lookup emits the known 69-byte
warning from a generated non-Git harness directory, retain it verbatim. It can
be classified as a pre-work warning only when its exact bytes/hash and ordering
match and there is no other stderr. Do not rewrite the raw receipt or call
different stderr clean.

The representative current summary count may be 600 or 601 only after the
separate preflight established the bounded set and exact 400-body semantic
work. A value outside that set is a failed readback. Because per-run counts are
unavailable, the ordinary report must not imply that all current timing runs
had identical callback counts.

## Analysis contract

Optimized is the primary comparison. Naive is a secondary control and is not
pooled with optimized.

For each variant report:

- all 12 rounded totals for main A, current and main B;
- each slot median;
- main A/B duplicate-baseline spread;
- current minus the midpoint of the two main medians, in milliseconds and
  percent;
- 12 round-aligned exploratory differences, each calculated as current minus
  the mean of main A and main B from the same round;
- the direction count for those 12 differences.

If an uncertainty interval is useful, label it exploratory and publish the
method: a deterministic percentile bootstrap of the 12 round-aligned
differences, 10,000 resamples with replacement and a recorded PRNG seed,
reporting the 2.5th and 97.5th percentiles of the resampled mean. State that
the input totals are rounded to 0.1 ms, there are only 12 paired rounds, and
the cyclic ordinal positions differ within each round. This interval is a
descriptive sensitivity check, not a confirmatory confidence interval and not
a basis for a confident speed claim.

Compare any apparent current/main shift with the duplicate-main spread and
the paired direction count. Make no speedup claim from a noisy or
baseline-sized difference. Do not normalize by callback count, subtract idle
callbacks, combine optimized and naive, or assign the end-to-end difference to
one internal phase. Main uses the legacy Runtime entry while current uses the
Block/Program path; that architecture difference is part of the comparison.
