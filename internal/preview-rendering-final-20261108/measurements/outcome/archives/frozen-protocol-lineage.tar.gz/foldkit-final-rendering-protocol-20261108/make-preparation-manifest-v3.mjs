import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { readFileSync, readdirSync, writeFileSync } from 'node:fs'
import { basename, dirname, join, relative } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = dirname(fileURLToPath(import.meta.url))
const output = join(root, 'preparation-manifest-v3.json')
const sha256 = value => createHash('sha256').update(value).digest('hex')
const fileFacts = path => {
  const bytes = readFileSync(path)
  return { path: basename(path), bytes: bytes.length, sha256: sha256(bytes) }
}

const preservedManifests = [
  fileFacts(join(root, 'preparation-manifest.json')),
  fileFacts(join(root, 'preparation-manifest-v2.json')),
]
assert.deepEqual(
  preservedManifests.map(({ sha256: hash }) => hash),
  [
    '43f983fc533511656de24227abd32d5dbd56757561bdf35e328de241fcaf8294',
    '6ac3d0a210e8c07128f35433b3e3fdfe20ed1b26c813410fd00009767e0103a3',
  ],
)
const preservedArchives = [
  fileFacts(`${root}.tar.gz`),
  fileFacts(`${root}-prepared.tar.gz`),
  fileFacts(`${root}-prepared-v2.tar.gz`),
]
assert.deepEqual(
  preservedArchives.map(({ sha256: hash }) => hash),
  [
    'f601e8fb669719bb3373e8d9675ec0ac5ec3ffb5808500df573b588c72640d75',
    'b3e62b048c626d2671d54f608fa887243415f50ec9ea43a5392ef8898ac0dea5',
    '25d022b0ed3eff878abf8477f92351494d085c6fae5a6e1a2efd8c356023f508',
  ],
)

const negativeControlsPath = join(
  root,
  'orchestration-v3/offline-negative-controls-v3-final.json',
)
const negativeControls = JSON.parse(readFileSync(negativeControlsPath, 'utf8'))
assert.equal(negativeControls.status, 'pass')
assert.deepEqual(
  negativeControls.controls.map(({ name, status }) => ({ name, status })),
  [
    { name: 'canonical-freeze-lineage', status: 'pass' },
    { name: 'changed-config-fails-freeze', status: 'expected-failure-observed' },
    { name: 'changed-tool-fails-freeze', status: 'expected-failure-observed' },
    { name: 'changed-analysis-typescript-runtime-fails-freeze', status: 'expected-failure-observed' },
    { name: 'changed-orchestration-script-fails-freeze', status: 'expected-failure-observed' },
    { name: 'canonical-downstream-lineage', status: 'pass' },
    { name: 'foreign-asset-receipt-fails-lineage', status: 'expected-failure-observed' },
    { name: 'canonical-exact-row-inventory', status: 'pass' },
    { name: 'extra-duplicate-row-fails-positioned-inventory', status: 'expected-failure-observed' },
    { name: 'extra-duplicate-row-fails-unique-row', status: 'expected-failure-observed' },
    { name: 'moved-singleton-row-fails-position-guard', status: 'expected-failure-observed' },
  ],
)

const parserSmokePath = join(root, 'orchestration-v3/analysis-parser-smoke-v3.json')
const parserSmoke = JSON.parse(readFileSync(parserSmokePath, 'utf8'))
assert.equal(parserSmoke.status, 'pass')
assert.equal(parserSmoke.typescript.version, '6.0.3')
assert.equal(parserSmoke.cases.length, 5)
for (const testCase of parserSmoke.cases) {
  assert.equal(testCase.actual, testCase.expected)
}

const files = []
const visit = path => {
  for (const entry of readdirSync(path, { withFileTypes: true })) {
    const child = join(path, entry.name)
    const name = relative(root, child)
    if (name === 'preparation-manifest-v3.json') continue
    if (entry.isDirectory()) visit(child)
    else if (entry.isFile()) {
      const bytes = readFileSync(child)
      files.push({ path: name, bytes: bytes.length, sha256: sha256(bytes) })
    }
  }
}
visit(root)
files.sort((left, right) => left.path.localeCompare(right.path))

const manifest = {
  schemaVersion: 3,
  status: 'prepared-not-executed',
  createdAt: new Date().toISOString(),
  interpretation: 'Additive v3 repair binding the reviewed stage scripts and directly invoked TypeScript/Playwright package inputs, with owner-position coverage guards and offline mutations. No asset build, browser, coverage capture, compiler or timing stage was executed by this repair.',
  preservedManifests,
  preservedArchives,
  offlineNegativeControls: {
    receipt: fileFacts(negativeControlsPath),
    controls: negativeControls.controls.length,
    status: negativeControls.status,
  },
  analysisParserSmoke: {
    receipt: fileFacts(parserSmokePath),
    typescript: parserSmoke.typescript.version,
    cases: parserSmoke.cases.length,
    status: parserSmoke.status,
  },
  files,
}
writeFileSync(output, `${JSON.stringify(manifest, null, 2)}\n`)
process.stdout.write(`${JSON.stringify({ output, files: files.length, sha256: sha256(readFileSync(output)) }, null, 2)}\n`)
