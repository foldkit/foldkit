# Additive orchestration v3 repair

This v3 packet is additive. The original preparation and the complete v2
directory, manifests, controls, and archives remain preserved. A future
authorized execution must use `orchestration-v3/`; v2 remains review history.

## Recorded executable and script inventory

The candidate freeze now records the exact reviewed v3 stage-script inventory.
Changing `common.mjs`, a stage, the coverage guard, or the offline control after
the freeze fails the immutable-input comparison.

The recorded immutable inventory also includes the complete regular-file inventory for
the TypeScript wrapper directly invoked by the plugin build and its resolved
native package, plus the launcher and native executable facts. It includes the
complete regular-file inventories of Playwright and Playwright Core used by the browser stages,
their ESM entries, and the Playwright Core CommonJS runtime entry. The retained
main/current source-position reference and cadence current-owner reference are
recorded too. These additions complement the already recorded Node, Chromium,
driver, runner, server, verifier, instrumentation, Vite, rimraf, and selected
trace-mapping runtime facts. They deliberately describe the recorded inventory;
they do not claim to freeze unrelated installed tools.

The coverage decoder now directly uses the repository's JavaScript compiler
API alias at `node_modules/typescript/lib/typescript.js`, not the Foldkit
package's TS7-native-only link. The alias package, its resolved
`@typescript/old` TypeScript 6.0.3 package, and the exact runtime entry are
inventoried separately from the plugin's native TS7 compiler. A moved alias or
changed analysis runtime therefore cannot alter source-name or source-position
inference outside the frozen inventory.

`analysis-parser-smoke.cjs` runs the exact decoder naming algorithm through the
real TypeScript 6.0.3 API against five current renderer/delivery/Todo source
positions. Its retained receipt proves every expected enclosing name before
the candidate freeze; this is an AST/parser smoke, not a compiler invocation.

## Owner-position guards

Coverage work guards now authenticate source line and column, not only a
source/name/count match, for:

- current `renderSync` and `runRenderFrameBody`, against the cadence current
  owner reference;
- main Todo `update`, against the main source-matched reference;
- current `dualDispatch`, against the current source-matched reference; and
- current `renderFramePlain`, against the cadence current owner reference.

Complete inventories remain required where one authored function maps to
multiple coverage rows. The named expected-count row must also be a singleton
at the exact owner-reference position. This preserves legitimate nested
zero-count rows while rejecting an extra or moved hot row.

`orchestration-v3/offline-negative-controls-v3-final.json` adds a changed-script
mutation, an analysis-TypeScript-runtime mutation, and a singleton
moved-line mutation to the prior config, tool, foreign-receipt, and
duplicate-row controls.

No asset build, compiler, browser, coverage capture, or ordinary timing was
run while preparing v3.
