import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { readFileSync, writeFileSync } from 'node:fs'
import { join, resolve } from 'node:path'

import { assertAuthorityStatic } from '../orchestration-v5/authority-guards.mjs'
import { assertAnalysisInputFacts, verifyV4 } from '../orchestration-v5/verify-core.mjs'

const reviewRoot = resolve(import.meta.dirname)
const copiesRoot = join(reviewRoot, 'actual-v4-receipts')
const originalRoot = '/private/tmp/foldkit-final-rendering-evidence-6f1c988-v4'
const protocolRoot = resolve(reviewRoot, '../orchestration-v5')
const publishedAnalysis = '/Users/devinjameson/.codex/worktrees/block-completion-record/foldkit-unified-recovery-20261103/internal/preview-final-20261107/rendering/measurements/official-workcount-cpu-20261108/analysis/source-matched-analysis-final.json.gz'

const read = path => JSON.parse(readFileSync(path, 'utf8'))
const facts = path => {
  const bytes = readFileSync(path)
  return {
    path,
    bytes: bytes.length,
    sha256: createHash('sha256').update(bytes).digest('hex'),
  }
}
const contentFacts = path => {
  const { bytes, sha256 } = facts(path)
  return { bytes, sha256 }
}
const assertSourceContains = (file, fragments) => {
  const source = readFileSync(join(protocolRoot, file), 'utf8')
  for (const fragment of fragments) {
    assert(source.includes(fragment), `${file}: missing audited status contract ${fragment}`)
  }
}

const files = [
  'candidate-freeze.json',
  'assets/receipt.json',
  'reference/authority.json',
  'preflight/receipt.json',
  'coverage/receipt.json',
  'coverage/analysis.json',
]
const copiedReceipts = files.map(relativePath => {
  const original = join(originalRoot, relativePath)
  const copy = join(copiesRoot, relativePath)
  assert.deepEqual(contentFacts(copy), contentFacts(original), `${relativePath}: copy differs from actual fresh v4 receipt`)
  return { relativePath, original: facts(original), copy: facts(copy) }
})

const assets = read(join(copiesRoot, 'assets/receipt.json'))
const authority = read(join(copiesRoot, 'reference/authority.json'))
const preflight = read(join(copiesRoot, 'preflight/receipt.json'))
const capture = read(join(copiesRoot, 'coverage/receipt.json'))
const analysis = read(join(copiesRoot, 'coverage/analysis.json'))

assert.equal(assets.status, 'complete')
assert.equal(authority.status, 'pass')
assert.equal(preflight.status, 'complete')
assert.equal(preflight.browserAndServerClosed, true)
assert.equal(preflight.functional.length, 6)
assert.equal(capture.status, 'complete')
assert.equal(capture.browserAndServerClosed, true)
assert.equal(capture.results.length, 4)
assert.equal(analysis.status, 'complete')
assert.equal(analysis.results.length, 4)

assertAuthorityStatic(authority, publishedAnalysis)
assert.deepEqual(
  analysis.referenceAuthority,
  facts(join(originalRoot, 'reference/authority.json')),
  'Actual analysis does not bind the original fresh authority bytes',
)
assertAnalysisInputFacts(analysis, capture)
const proof = verifyV4(authority, analysis, {
  publishedAnalysisPath: publishedAnalysis,
  authorityFacts: analysis.referenceAuthority,
})
assert.equal(proof.status, 'pass')

assertSourceContains('assets.mjs', ["status: 'complete'"])
assertSourceContains('common.mjs', [
  "assert.equal(receipt.status, 'complete')",
  "assert.equal(receipt.status, 'pass')",
])
assertSourceContains('reference-authority.cjs', ["status: 'pass'"])
assertSourceContains('preflight.mjs', ["receipt.status = 'complete'"])
assertSourceContains('coverage.mjs', [
  "assert.equal(preflight.status, 'complete')",
  "receipt.status = 'complete'",
])
assertSourceContains('analyse-coverage.cjs', [
  "assert.equal(receipt.status, 'complete')",
  "status: 'complete'",
])
assertSourceContains('verify-coverage.mjs', [
  "assert.equal(receipt.status, 'complete')",
  "assert.equal(analysis.status, 'complete')",
])
assertSourceContains('verify-core.mjs', [
  "assert.equal(authority.status, 'pass')",
  "assert.equal(analysis.status, 'complete')",
  "status: 'pass'",
])
assertSourceContains('offline-negative-controls.mjs', ["status: 'pass'"])
assertSourceContains('timing.mjs', [
  "assert.equal(preflight.status, 'complete')",
  "assert.equal(coverageGuard.status, 'pass')",
  "receipt.status = 'capture-complete-pending-readback'",
])
assertSourceContains('analyse-timing.mjs', [
  "assert.equal(receipt.status, 'capture-complete-pending-readback')",
  "status: 'valid-readback'",
])
assertSourceContains('README.md', ['all must pass before any timing grant'])

const result = {
  schemaVersion: 1,
  status: 'validation-only-pass',
  interpretation: 'Pre-grant integration proof over byte-identical copies of the actual fresh v4 receipts. This is not a canonical v5 receipt, does not adopt v4 evidence into v5, and authorizes no build, browser, coverage, or timing stage.',
  copiedReceipts,
  actualProducerStatuses: {
    assets: assets.status,
    authority: authority.status,
    preflight: preflight.status,
    coverageCapture: capture.status,
    coverageAnalysis: analysis.status,
  },
  actualShapeChecks: {
    functionalSlots: preflight.functional.length,
    coverageCaptures: capture.results.length,
    decodedResults: analysis.results.length,
    preflightCleanup: preflight.browserAndServerClosed,
    coverageCleanup: capture.browserAndServerClosed,
    staticAuthority: 'pass',
    decodedInputFacts: 'pass',
    correctedCoreVerifier: proof.status,
  },
  auditedStatusContract: [
    { producer: 'assets', produced: 'complete', consumers: ['common.loadAssetReceipt'] },
    { producer: 'reference authority', produced: 'pass', consumers: ['common.loadReferenceAuthority', 'verifyV5'] },
    { producer: 'preflight', produced: 'complete', consumers: ['coverage', 'timing'] },
    { producer: 'coverage capture', produced: 'complete', consumers: ['analyse-coverage', 'verify-coverage'] },
    { producer: 'coverage analysis', produced: 'complete', consumers: ['verify-coverage', 'verifyV5'] },
    { producer: 'coverage guard', produced: 'pass', consumers: ['mutation controls', 'timing'] },
    { producer: 'mutation controls', produced: 'pass', consumers: ['external timing grant'] },
    { producer: 'timing capture', produced: 'capture-complete-pending-readback', consumers: ['analyse-timing'] },
    { producer: 'timing readback', produced: 'valid-readback', consumers: [] },
  ],
  correctedProof: proof,
}

const output = join(reviewRoot, 'actual-v4-shape-integration-proof-v2.json')
writeFileSync(output, `${JSON.stringify(result, null, 2)}\n`, { flag: 'wx' })
process.stdout.write(`${JSON.stringify({ output, facts: facts(output) }, null, 2)}\n`)
