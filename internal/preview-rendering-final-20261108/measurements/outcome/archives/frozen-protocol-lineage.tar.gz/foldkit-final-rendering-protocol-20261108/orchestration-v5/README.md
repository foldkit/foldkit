# Prepared v5 rendering orchestration

This is the bounded metadata-contract repair of the frozen v4 protocol. It
preserves v3, v4, every v4 capture, and the original v4 verifier failure; it
does not adopt or reinterpret any old receipt. The fresh v4 decoder correctly
produced an analysis with status `complete`, while the shared verifier
incorrectly required that input to already be `pass`. V5 requires `complete`
for the decoded analysis and continues to reserve `pass` for the guard receipt
created only after every check succeeds. Copy `config.example.json` to a new
path only after the final candidate is clean and committed. V5 reuses only
the byte-authenticated durable old/cadence reference inputs stored under the
v4 packet; it does not reuse a v4 freeze, asset, preflight, capture, analysis,
guard, or control receipt.

Run in this order, with an explicit lead grant before each heavy stage:

1. `node freeze-candidate.mjs config.json` records the clean HEAD/tree and all
   relevant source, dist, tool, reference, and orchestration inputs.
2. `BUILD_SLOT_GRANTED=1 node assets.mjs config.json` builds fresh optimized and
   naive candidate assets and byte-identical hidden-map twins, then copies the
   audited exact-main assets/maps.
3. `node reference-authority.cjs config.json` reconstructs all four durable old
   raw coverage/map pairs with the frozen decoder. The legacy projection must
   exactly reproduce the committed published analysis. The corrected
   line-aware projection, both current map variants, exact current-map/Git
   source inventory, cadence raw/map pairs, and three-owner `html/index.ts`
   initializer/body identity plus exact +630 relocation are frozen before any
   new capture.
4. `BROWSER_SLOT_GRANTED=1 node preflight.mjs config.json` runs all six
   functional slots and callback-count guards.
5. `BROWSER_SLOT_GRANTED=1 node coverage.mjs config.json`, followed by
   `node analyse-coverage.cjs config.json`, `node verify-coverage.mjs
   config.json`, and `node offline-negative-controls.mjs config.json`, captures
   count-only evidence and atomically validates authority, receipt lineage,
   functional/callback results, complete positioned owner inventories, reached
   application work, and the closed six-row optimized zero-only delta.
6. Only in a separately confirmed quiet window:
   `QUIET_WINDOW_CONFIRMED=1 TIMING_SLOT_GRANTED=1 node timing.mjs config.json`.
   Run `node analyse-timing.mjs config.json` only after cleanup.

Every mutating stage refuses to overwrite its output and revalidates the clean
candidate, exact config, frozen scripts, driver/runner/server/instrumentation,
Node/Chromium/build tools, TypeScript parser and native compiler packages,
Playwright packages, durable old captures, all old/current optimized and naive
owner-map inputs, and corrected cadence capture/map inputs. Receipts form one
chain: assets -> reference authority -> preflight -> coverage
capture/analysis/guard -> timing/readback.

The coverage verifier invokes the static authority validator itself. It does
not trust a self-matching authority/analysis pair. The complete relocated Html
reference is recomputed from the frozen old line-aware rows, exact proved owner
set, and +630 delta. Current renderer positions come from corrected decoding of
the authenticated cadence raw inputs. Unchanged application, lazy, VNode,
Snabbdom, and delivery sources use separate exact main/current owner references;
only their cross-owner logical work is compared where source positions differ.

The real-receipt control stage mutates config, freeze, asset, reference, raw-capture,
capture-receipt, analysis, and orchestration-script lineage, plus positive work,
closed zero deltas, outer/nested/zero Html rows, every relocated owner, and
current positions. Each mutation must fail at its intended assertion.

Ordinary timing remains the unchanged harness measured callback/event-work sum.
Idle rAF callback time is included. The standard instrumentation does not wrap
`MessageChannel.port.onmessage`, so no cadence arming-task CPU inclusion or
end-to-end CPU claim is made.

## Frozen offline proof used for code review

Before any fresh stage, the v4 decoder/verifier was exercised over the retained
raw captures without using them to define expectations. V5 additionally replays
the corrected shared verifier over copies of the actual fresh v4 authority and
decoded analysis, retaining their real `pass`/`complete` producer statuses:

- `../orchestration-v4-design/reference-authority-v5.json` reconstructs all
  old/cadence raw inputs and both map variants; SHA-256 `98899d1f…`.
- `../orchestration-v4-design/reanalysed-existing-v4-v2.json` is validation
  input only; SHA-256 `a6add359…`.
- `../orchestration-v4-design/guard-proof-v4.json` is the complete passing
  guard result; SHA-256 `bc781454…`.
- `../orchestration-v4-design/offline-negative-controls-v4-v2.json` records
  33 canonical/expected-failure controls, including every relocated owner,
  both map variants, nested positive/zero work, closed zero deltas, and real
  reference-authority byte lineage; SHA-256 `23c4c8a8…`.
- `../orchestration-v5-review/actual-v4-shape-integration-proof-v2.json` records
  the validation-only corrected core replay and complete producer/consumer
  status audit over byte-identical copies of the actual fresh v4 receipts;
  SHA-256 `be0369dc…`. It is not a v5 receipt and cannot be adopted by a stage.
- `/private/tmp/foldkit-v5-status-review/actual-6f-verify-coverage-guard.json`
  records an independent validation-only full wrapper replay over the actual
  fresh v4 receipt shapes; SHA-256 `e6e74e97…`.
- `/private/tmp/foldkit-v5-status-review/actual-6f-offline-negative-controls.json`
  records all 45 independently replayed canonical and expected-failure
  controls over those actual shapes; SHA-256 `78033afb…`. Its review wrappers
  changed only the status contract and absolute import/output paths and are
  not canonical v5 stage receipts.

The fresh chain must still run its real config/freeze/asset mutations after the
asset stage and its raw-capture/capture-receipt/analysis/script mutations after
coverage. Those future receipts are intentionally not fabricated or adopted
from this offline proof, and all must pass before any timing grant.
