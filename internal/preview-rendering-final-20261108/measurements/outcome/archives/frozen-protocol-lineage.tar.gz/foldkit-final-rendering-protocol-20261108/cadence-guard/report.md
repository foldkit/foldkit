# Cadence-only benchmark callback guard

Date: 2026-11-08

## Outcome

The cadence change intentionally invalidates the benchmark's former exact
`400` total-rAF callback guard. Under the unchanged full add-100, toggle-100,
delete-100 driver, the cadence-only optimized asset reported `600` rAF
callbacks and the naive asset reported `601`. Both still reported exactly
`400` synchronous callbacks, zero timeout/microtask/Promise callbacks,
cross-origin isolation, and passing functional TodoMVC flows.

The old assertion was not relaxed. Its failed receipt and raw output are
preserved. One separately authorized source-matched precise-coverage pass then
showed, for both optimized and naive assets:

| Reached work | Count |
| --- | ---: |
| instrumented rAF callbacks | 600 |
| `renderFramePlain` | 600 |
| `runRenderFrameBody` | 400 |
| `renderSync` including boot | 401 |
| application view including boot | 401 |
| `__patchVNode` including boot | 401 |
| `scheduleRenderFrame` | 400 |
| `armNextRenderFrame` | 400 |

The additional `200` reached `renderFramePlain` calls are armed idle callbacks:
they return before `runRenderFrameBody`. They do not add view or patch work.
They are still real Runtime callback work, and an ordinary end-to-end result
must include their elapsed cost rather than subtracting it.

The single `601` ordinary-driver observation is consistent with boundary
variation in when a trailing armed idle callback enters the runner's
measurement snapshot; this bounded packet did not add another run to prove
that inference. The source-matched pass observed `600` in both variants. This
packet does not use either run's elapsed values and does not establish a
latency result.

## Source and asset identity

- Isolated source:
  `/private/tmp/foldkit-cadence-guard-20261108.befaa/source`
- Exact HEAD: `befaa93b1565445a841a6c84ffb7fdee25b13cbb`
- Cadence parent: `5c96e577ccbbceb160f500dc958ae542b29395d3`
- Pre-cadence parent: `7cc7d90e68dc5a55b4765bbd7f0469b55cdd928f`
- `befaa` adds no `packages/foldkit/src` changes after `5c96`.
- The R11/R19 production paths `domReflection.ts`, `html/index.ts`, and
  `snabbdom/h.ts` are byte-identical to `7cc`; this tree contains no R11/R19
  candidate patch.
- Node executable SHA-256:
  `533bd644c5ae0e0ea3a80e433aad16b817447ccba1e1eea701875eac80cb75d4`
- Unchanged driver SHA-256:
  `a93c12e6fe411eb5fa8abc342e32974d94496622ba8a475b81f7d6dc9bbc26f0`
- Runner SHA-256:
  `6d26843332fa4b5bcd55def19f6219ac8d26a0db242c32bc54a2291a6a695ee1`
- Instrumentation SHA-256:
  `6e3597e81ef7276d99f17cfa4c3430e05beb7768411a1a34bffa0026343f7f69`

Ordinary assets and exact hidden-map twins:

| Variant | JavaScript SHA-256 | Map SHA-256 |
| --- | --- | --- |
| optimized | `8ca6342300f942ac369260c8e6a56043a7a92318b5b88b2ad78cd36787a2791e` | `b6253a1a3e4fe42052d719a312f9978f05dc70db61ccfa6844da7048f4722e1d` |
| naive | `4af36600058784c83fd2c8edfd6e8d74e680c9229ece4a7a090fdd0f80f2587a` | `eb8ea7cfd57831941079ec1c536331cb94dd3a12ced5e0c7974fffbd8a61c225` |

## Evidence

- Asset/map receipt: `assets-and-maps.json`, SHA-256
  `2c0a9f4a11720b7bac14add747a43414fb3a8a636e66dac1dc60fecdf2cbe376`.
- Preserved failed old-count guard: `guards/receipt.json`, SHA-256
  `4cf6a4c931092e6370910a10fb536a3af35bb120562ef3bf6cdf3d7b4d9394b4`.
- Valid readback of that failure: `callback-readback.json`, SHA-256
  `2838e8ad607b1ed32c360ea9226b958afd7d0c5a9d7cd1a4b34fbb1dd006f5e2`.
- Count capture receipt: `counts/receipt.json`, SHA-256
  `6eed360239a8bbfae1c645dc8b287139b4d8955dfdf4283968b69fd278c8df0d`.
- Source-matched analysis: `counts/analysis.json`, SHA-256
  `ea22e28822e6000864956e7ed62b1f0a1c308ea1bc2d393ba1d7bdfd9a0cd89f`.
- The initial local-listen permission failure is separately retained under
  `guards.failed-local-listen/`; it launched no page and has no performance
  meaning.

All accepted captures authenticate served and executed JavaScript bytes, final
empty TodoMVC state, source maps, Node and Chromium identities. Browsers and
servers closed, and owned ports had no remaining listeners.

## Final current-candidate protocol

1. Build final baseline and candidate from exact recorded source identities;
   both must include the accepted cadence behavior, while R11/R19 remains out.
2. Keep the application workload and unchanged driver intact. Run functional
   flows and a count-only source-matched preflight outside the timing batch.
3. Require exactly `400` render bodies and exactly `401` boot-inclusive views
   and patches in that preflight, with exact served/executed asset hashes.
   This is the semantic-work guard that the total-rAF count can no longer
   provide.
4. In the ordinary quiet-window batch, retain and report the exact total-rAF
   count for every summarized slot. Accept `600` or the observed trailing-idle
   boundary value `601` only when the preflight proves the exact render/view/
   patch counts above; any other count or any count asymmetry needs diagnosis,
   not a widened guard.
5. Keep the idle-callback elapsed work inside the ordinary total. Do not phase
   subtract it, modify the workload, or reinterpret the count-only coverage
   elapsed values as timing evidence.

This protocol makes the cadence cost visible while preventing armed idle
callbacks from being mistaken for 200 additional renders.
