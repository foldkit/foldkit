# Final current-rendering protocol packet

Prepared 2026-11-08. This packet contains a corrected, frozen plan for the
eventual exact-main/current-candidate ordinary rendering comparison and an
unchanged copy of the cadence-only guard evidence. It contains no new timing
observation.

## Contents

- `protocol.md`: the runner contract and bounded final measurement plan.
- `additive-refinement.md`: the stricter unchanged-work and measurement-scope
  refinement approved after the frozen protocol.
- `orchestration/`: parameterized, source-checked preparation for freezing the
  eventual clean committed candidate and running the gated stages. Nothing in
  this directory has been executed against a candidate.
- `cadence-guard/`: byte-for-byte copies of the cadence-only evidence files.
  Its original `manifest.json` authenticates the copied files and records the
  original absolute source and tool paths.
- `tooling/`: byte-for-byte copies of the cadence-only preparation, guard,
  coverage and manifest tools. These are retained for review; this packet is
  not a replacement source checkout.

The original cadence report's final-protocol section predates the runner
storage correction. `protocol.md` is authoritative for the future ordinary
batch: the unchanged driver retains every per-round total rounded to 0.1 ms,
but only summary bucket medians and one representative count record per slot.
It does not retain per-run bucket or count objects.

## Cadence evidence disposition

- The former exact-400-rAF guard failed and remains failed in
  `cadence-guard/guards/receipt.json`.
- The separate source-matched coverage capture established 600
  `renderFramePlain` entries, 400 `runRenderFrameBody` calls, and therefore
  200 early-return idle callbacks for each cadence-only asset.
- The ordinary naive guard's 601st callback remains unresolved. It is only
  consistent with a trailing callback near the result boundary; this packet
  does not claim that identity was proved.
- Coverage elapsed values are not timing evidence.
- R11/R19 is excluded.

The copied harness implementation links retain their original absolute link
targets as provenance. The raw receipts, logs, JavaScript, maps and coverage
captures needed for review are regular copied files in this packet.
