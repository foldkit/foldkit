import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { readFileSync, readdirSync, statSync, writeFileSync } from 'node:fs'
import { basename, dirname, join, relative } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = dirname(fileURLToPath(import.meta.url))
const output = join(root, 'preparation-manifest-v2.json')
const sha256 = value => createHash('sha256').update(value).digest('hex')
const fileFacts = path => {
  const bytes = readFileSync(path)
  return { path: basename(path), bytes: bytes.length, sha256: sha256(bytes) }
}

const preservedV1Manifest = fileFacts(join(root, 'preparation-manifest.json'))
assert.equal(
  preservedV1Manifest.sha256,
  '43f983fc533511656de24227abd32d5dbd56757561bdf35e328de241fcaf8294',
)
const preservedArchives = [
  fileFacts(`${root}.tar.gz`),
  fileFacts(`${root}-prepared.tar.gz`),
]
assert.deepEqual(
  preservedArchives.map(({ sha256: hash }) => hash),
  [
    'f601e8fb669719bb3373e8d9675ec0ac5ec3ffb5808500df573b588c72640d75',
    'b3e62b048c626d2671d54f608fa887243415f50ec9ea43a5392ef8898ac0dea5',
  ],
)

const negativeControlsPath = join(
  root,
  'orchestration-v2/offline-negative-controls.json',
)
const negativeControls = JSON.parse(readFileSync(negativeControlsPath, 'utf8'))
assert.equal(negativeControls.status, 'pass')
assert.deepEqual(
  negativeControls.controls.map(({ name, status }) => ({ name, status })),
  [
    { name: 'canonical-freeze-lineage', status: 'pass' },
    { name: 'changed-config-fails-freeze', status: 'expected-failure-observed' },
    { name: 'changed-tool-fails-freeze', status: 'expected-failure-observed' },
    { name: 'canonical-downstream-lineage', status: 'pass' },
    { name: 'foreign-asset-receipt-fails-lineage', status: 'expected-failure-observed' },
    { name: 'canonical-exact-row-inventory', status: 'pass' },
    { name: 'extra-duplicate-row-fails-positioned-inventory', status: 'expected-failure-observed' },
    { name: 'extra-duplicate-row-fails-unique-row', status: 'expected-failure-observed' },
  ],
)

const files = []
const visit = path => {
  for (const entry of readdirSync(path, { withFileTypes: true })) {
    const child = join(path, entry.name)
    const name = relative(root, child)
    if (name === 'preparation-manifest-v2.json') continue
    if (entry.isDirectory()) visit(child)
    else if (entry.isFile()) {
      const bytes = readFileSync(child)
      files.push({ path: name, bytes: bytes.length, sha256: sha256(bytes) })
    }
  }
}
visit(root)
files.sort((left, right) => left.path.localeCompare(right.path))

const manifest = {
  schemaVersion: 2,
  status: 'prepared-not-executed',
  createdAt: new Date().toISOString(),
  interpretation: 'Additive v2 orchestration repair with transitive freeze/receipt lineage, exact coverage inventories and offline negative controls. No asset build, browser, coverage capture, compiler or timing stage was executed by this repair.',
  preservedV1Manifest,
  preservedArchives,
  offlineNegativeControls: {
    receipt: fileFacts(negativeControlsPath),
    controls: negativeControls.controls.length,
    status: negativeControls.status,
  },
  files,
}
writeFileSync(output, `${JSON.stringify(manifest, null, 2)}\n`)
process.stdout.write(`${JSON.stringify({ output, files: files.length, sha256: sha256(readFileSync(output)) }, null, 2)}\n`)
