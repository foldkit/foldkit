# Website readiness first-attempt diagnostic

## Status

Prepared only. No Website server, browser or Playwright suite has been started
from this packet. Run it once after the lead grants a local browser slot:

```text
node /private/tmp/foldkit-website-readiness-diagnostic-20261108/run-diagnostic.mjs
```

The runner refuses a second invocation once `run/` exists. Preserve that
directory whatever the result; do not rerun to obtain a more favorable result.
The repository's one ordinary retry remains enabled, so a failed first attempt
may pass on its configured retry. That is part of the existing suite, not a
second diagnostic run.

## Exact scope

The diagnostic imports the repository's real Website Playwright config and
uses its complete unchanged test directory. It asserts these repository
semantics before loading the override:

- fully parallel local execution;
- one configured retry;
- the 60-second test timeout;
- the 120-second web-server timeout;
- `reuseExistingServer: false`; and
- the repository's ordinary `on-first-retry` trace policy.

The wrapper then makes only these diagnostic/relocation changes:

- pins the observed local concurrency to five workers;
- changes trace retention to `retain-on-failure`, so a failed first attempt is
  preserved even if its configured retry passes;
- writes the normal list output plus an all-results JSON report under this
  packet;
- relocates `testDir`, `globalSetup`, web-server cwd and output paths to their
  exact absolute locations because the wrapper itself lives outside the repo;
  and
- gives the unchanged Vite dev-server command the dedicated port 38742.

It does not change any test, selector, 5-second assertion timeout, suite retry,
test timeout, global setup behavior, Website source, Vite behavior or browser
project. In particular, it does not warm the client runtime and does not alter
the eager snippet registry.

## Identity and process controls

`expected-source.json` binds the run to commit
`c3ffef0cedd9401359105076038b867502960ea4`, tree
`a2d925ca9fe2dfbbc3d509647627aa9f1079c4b1`, Node 26.13.0,
Playwright 1.63.0 and Vite 8.3.5. It records hashes for the repository config,
the accessibility test and readiness helper, global setup, normal e2e wrapper,
Website package manifest, lockfile and installed Playwright/Vite wrappers. The
runner also refuses relevant uncommitted Website/test changes.

Before launch it proves port 38742 is free. Vite still receives `--strictPort`
and `reuseExistingServer` stays false. Playwright is launched as a new process
group. On success, failure, interruption or signal, the runner terminates that
whole group, checks the port, escalates only that owned group to `SIGKILL` if
needed, and records cleanup. A non-free port after cleanup makes the diagnostic
fail independently of the suite result.

## Evidence boundary

One invocation creates `run/` with:

- `preflight.json`: exact command, source/tool/config hashes and semantic
  controls before Playwright starts;
- `stdout.log` and `stderr.log`: complete process output;
- `results.json`: Playwright's complete JSON result inventory, including
  passed, failed, flaky and retried attempts;
- `test-results/`: Playwright failure artifacts. Under
  `retain-on-failure`, a failing first attempt should retain its raw trace even
  when the configured retry succeeds; and
- `run-receipt.json`: exit/signal and process-group/port cleanup result.

A completely passing run may have no retained trace. A flaky run's failed
first-attempt trace is the causal diagnostic; the successful retry remains a
control. The packet does not itself interpret network completion, console/page
errors or the first Foldkit view/patch timestamp, and it does not authorize a
timeout increase, client warmup or snippet-registry change.
