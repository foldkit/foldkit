import baseConfig from '/Users/devinjameson/.codex/worktrees/block-completion-record/foldkit-unified-recovery-20261103/packages/website/playwright.config.ts'

const repositoryRoot =
  '/Users/devinjameson/.codex/worktrees/block-completion-record/foldkit-unified-recovery-20261103'
const websiteRoot = `${repositoryRoot}/packages/website`
const evidenceRoot =
  '/private/tmp/foldkit-website-readiness-diagnostic-20261108/run'
const port = 38742

if (process.env['CI'] !== undefined) {
  throw new Error('The readiness diagnostic requires the local Website configuration, without CI.')
}
if (process.env['FOLDKIT_LIVE_WEBSITE_URL'] !== undefined) {
  throw new Error('The readiness diagnostic requires the local Website server, not a live URL.')
}
if (baseConfig.fullyParallel !== true) {
  throw new Error('Expected the Website suite to remain fully parallel.')
}
if (baseConfig.retries !== 1) {
  throw new Error(`Expected the local Website retry count to remain 1; received ${String(baseConfig.retries)}.`)
}
if (baseConfig.timeout !== 60_000) {
  throw new Error(`Expected the Website test timeout to remain 60000; received ${String(baseConfig.timeout)}.`)
}
if (baseConfig.use?.trace !== 'on-first-retry') {
  throw new Error('Expected the repository trace policy to remain on-first-retry before the diagnostic override.')
}
if (Array.isArray(baseConfig.webServer) || baseConfig.webServer === undefined) {
  throw new Error('Expected one repository Website webServer configuration.')
}
if (baseConfig.webServer.reuseExistingServer !== false) {
  throw new Error('Expected the repository Website server to refuse reuse.')
}
if (baseConfig.webServer.timeout !== 120_000) {
  throw new Error('Expected the repository Website server timeout to remain 120000.')
}

export default {
  ...baseConfig,
  testDir: `${websiteRoot}/e2e`,
  outputDir: `${evidenceRoot}/test-results`,
  workers: 5,
  reporter: [
    ['list'],
    ['json', { outputFile: `${evidenceRoot}/results.json` }],
  ],
  use: {
    ...baseConfig.use,
    trace: 'retain-on-failure',
  },
  globalSetup: `${websiteRoot}/e2e/globalSetup.ts`,
  webServer: {
    ...baseConfig.webServer,
    command: `pnpm dev --port ${port} --strictPort`,
    cwd: websiteRoot,
    url: `http://localhost:${port}/theme-init.js`,
    reuseExistingServer: false,
  },
}
