# Diagnostic v2 outcome

## Classification

Setup failure before tests and before any browser result. This run provides no
new evidence about Website hydration readiness, client compilation or runtime
failure.

The v2 preflight authenticated commit
`c3ffef0cedd9401359105076038b867502960ea4`, tree
`a2d925ca9fe2dfbbc3d509647627aa9f1079c4b1`, Node 26.13.0,
Playwright 1.63.0, Vite 8.3.5 and the expected source/tool hashes. The loaded
Playwright config reports five workers, one retry, the unchanged 60-second test
and 120-second server timeouts, the exact repository suite/global setup and the
dedicated strict server on port 38742.

The v2 wrapper re-exports `BASE_URL` as `http://localhost:38742`. The separate
direct config-load check imported that named export and verified all configured
facts without starting Playwright, Vite, a server or a browser. Nevertheless,
Playwright's external active-config loader redirected the unchanged repository
global setup's `../playwright.config.ts` import through a default-only compiled
config module. Setup therefore stopped again with:

```text
SyntaxError: The requested module '../playwright.config.ts' does not provide an export named 'BASE_URL'
```

`results.json` records no suites and zero expected, skipped, unexpected and
flaky tests. `.last-run.json` records failure with an empty `failedTests`
array. No failed-attempt trace or hydration result exists. This is distinct
from the original packet's setup failure: v2 proves adding the named source
export does not overcome Playwright's external-config module wrapping.

## Cleanup

The one-shot runner exited 1 and recorded `completed-and-cleaned`. Its owned
process group was terminated and port 38742 was free. A subsequent privileged,
read-only process check found no process whose command named the v2 config,
port, packet, Playwright invocation or Vite invocation.

The v2 suite invocation was not patched or retried. A future diagnostic would
need separate authorization and should avoid an external active config, for
example by using the repository config with command-line trace/worker/output
overrides. This packet does not authorize that run.
