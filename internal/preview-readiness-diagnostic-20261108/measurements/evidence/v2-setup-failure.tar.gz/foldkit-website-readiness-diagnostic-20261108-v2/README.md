# Website readiness first-attempt diagnostic v2

## Status

Prepared only. No server, browser or Playwright suite has been started from
this v2 packet. The original packet remains byte-exact evidence of its setup
failure:

- original preparation manifest SHA-256:
  `ccef18ab12d331debda1f60bd28ebab0fefe0a432161ba630a83e9be1781f313`;
- original failed-run manifest SHA-256:
  `9314ae61534d2dc8193df50b51c5e666cccf6146cd4451fef5c9f37e897ac0c5`.

The original run executed no tests and produced no Website hydration evidence.
It is not adopted or relabeled by v2.

## Correction

`wrapper-delta.patch` is the complete wrapper delta from the original packet.
It makes two changes only:

1. redirects output from the original immutable `run/` to this packet's
   `run/`; and
2. re-exports `BASE_URL` as `http://localhost:38742` from the active wrapper.

The named export is required because the unchanged repository
`e2e/globalSetup.ts` imports `BASE_URL` from `../playwright.config.ts` and
Playwright resolves that import to the active external config. All other
wrapper bytes, the runner and `expected-source.json` are identical to the
original packet. Port 38742 remains consistent across the named export, Vite
command, readiness URL, environment and runner's exclusive-bind/cleanup guard.

## Static config-load check

The following check imports the exact v2 wrapper, including its named export,
and verifies the active URL, five workers, complete e2e directory, global
setup, retry/time limits, trace policy, strict server command, disabled server
reuse and isolated output path:

```text
/Users/devinjameson/.vite-plus/bin/node /private/tmp/foldkit-website-readiness-diagnostic-20261108-v2/check-config-load.mjs
```

It does not invoke Playwright, Vite, global setup, a server or a browser.

## One-shot command

After an exclusive browser slot is granted and the static check passes, run
exactly once:

```text
/Users/devinjameson/.vite-plus/bin/node /private/tmp/foldkit-website-readiness-diagnostic-20261108-v2/run-diagnostic.mjs
```

The runner is byte-identical to the original. It authenticates commit c3, the
repository tree, Node 26.13.0, Playwright 1.63.0, Vite 8.3.5 and the recorded
Website/test/tool hashes. It refuses relevant source changes, CI/live mode, an
occupied dedicated port and a second invocation. It owns the entire detached
Playwright/Vite process group, preserves the suite's one retry and unchanged
timeouts, retains failed first-attempt traces, and records port cleanup.

No client warmup, timeout change, test change, snippet-registry change or
favorable-result rerun is authorized by this packet.
