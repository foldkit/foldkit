import { readFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const packetRoot = dirname(fileURLToPath(import.meta.url))
const expected = JSON.parse(
  readFileSync(join(packetRoot, 'expected-source.json'), 'utf8'),
)
const port = expected.port
const baseURL = `http://localhost:${port}`
const websiteRoot = join(expected.repositoryRoot, 'packages/website')
const expectedOutputRoot = join(packetRoot, 'run')

if (process.env.CI !== undefined) {
  throw new Error('The config-load check requires local Website semantics.')
}
if (process.env.FOLDKIT_LIVE_WEBSITE_URL !== undefined) {
  throw new Error('The config-load check refuses a live Website target.')
}

process.env.FOLDKIT_WEBSITE_E2E_PORT = String(port)

const { BASE_URL, default: config } = await import(
  './playwright.diagnostic.config.ts'
)

const assert = (condition, message) => {
  if (!condition) throw new Error(message)
}

assert(BASE_URL === baseURL, `Expected exported BASE_URL ${baseURL}.`)
assert(config.fullyParallel === true, 'Expected fully parallel execution.')
assert(config.workers === 5, 'Expected exactly five workers.')
assert(config.retries === 1, 'Expected exactly one configured retry.')
assert(config.timeout === 60_000, 'Expected the unchanged test timeout.')
assert(
  config.use?.trace === 'retain-on-failure',
  'Expected failed-first-attempt trace retention.',
)
assert(
  config.testDir === join(websiteRoot, 'e2e'),
  'Expected the exact repository e2e directory.',
)
assert(
  config.globalSetup === join(websiteRoot, 'e2e/globalSetup.ts'),
  'Expected the exact repository global setup.',
)
assert(
  !Array.isArray(config.webServer) && config.webServer !== undefined,
  'Expected one Website server.',
)
assert(
  config.webServer.command === `pnpm dev --port ${port} --strictPort`,
  'Expected the unchanged strict Vite command on the dedicated port.',
)
assert(config.webServer.url === `${baseURL}/theme-init.js`, 'Server URL mismatch.')
assert(config.webServer.cwd === websiteRoot, 'Website server cwd mismatch.')
assert(config.webServer.reuseExistingServer === false, 'Server reuse must stay disabled.')
assert(config.webServer.timeout === 120_000, 'Expected the unchanged server timeout.')
assert(config.outputDir === join(expectedOutputRoot, 'test-results'), 'Output directory mismatch.')

const globalSetupSource = readFileSync(
  join(websiteRoot, 'e2e/globalSetup.ts'),
  'utf8',
)
assert(
  globalSetupSource.includes(
    "import { BASE_URL } from '../playwright.config.ts'",
  ),
  'The repository global setup no longer imports the expected named BASE_URL.',
)

process.stdout.write(
  `${JSON.stringify({
    status: 'pass',
    BASE_URL,
    port,
    workers: config.workers,
    retries: config.retries,
    testTimeout: config.timeout,
    serverTimeout: config.webServer.timeout,
    trace: config.use.trace,
    testDir: config.testDir,
    globalSetup: config.globalSetup,
    outputDir: config.outputDir,
  })}\n`,
)
