# Website readiness diagnostic v3

Status: prepared, setup proof complete, Website suite not started.

This packet replaces the invalid external-config approach with the repository's actual `packages/website/playwright.config.ts` and documented Playwright CLI overrides only. It does not alter the Website suite, global setup, retry count, test timeout, web-server timeout, or the 5-second readiness marker assertions.

## Frozen inputs

- Repository commit: `c3ffef0cedd9401359105076038b867502960ea4`
- Repository tree: `a2d925ca9fe2dfbbc3d509647627aa9f1079c4b1`
- Node: `/Users/devinjameson/.vite-plus/js_runtime/node/26.13.0/bin/node`, `v26.13.0`
- Playwright: `1.63.0`
- Vite: `8.3.5`
- Working directory: `/Users/devinjameson/.codex/worktrees/block-completion-record/foldkit-unified-recovery-20261103/packages/website`
- Dedicated port: `38742`; the real config supplies `--strictPort` and `reuseExistingServer: false`.
- Exact source and tool hashes: `expected-source.json`.

The diagnostic child command uses the installed Playwright CLI with:

```text
test
--config=/Users/devinjameson/.codex/worktrees/block-completion-record/foldkit-unified-recovery-20261103/packages/website/playwright.config.ts
--trace=retain-on-failure
--workers=5
--output=/private/tmp/foldkit-website-readiness-diagnostic-20261108-v3/run/test-results
--reporter=list,json
```

The process environment sets `FOLDKIT_WEBSITE_E2E_PORT=38742` and the installed JSON reporter's documented `PLAYWRIGHT_JSON_OUTPUT_FILE` to `run/results.json`. The runner refuses an occupied port, changed Website inputs, a changed commit/tree, incorrect tool versions, CI or a live Website target, or a second invocation. It starts Playwright in its own process group and records group cleanup and port release.

## Repository-config list proof

`run-list-proof.mjs` ran the same real config and overrides with `--list`, writing only to `setup-proof/`. Playwright exited zero and discovered 22 tests in five files. It did not start the configured web server or a browser. `stderr.log` is empty, port 38742 was free after the command, and a subsequent scoped process check found no retained Playwright, Vite, or packet process.

The original `proof-receipt.json` says `list-proof-failed` because the preparation runner incorrectly required `stats.expected > 0`. Playwright list mode instead represents all 22 discovered tests as skipped in its JSON summary while retaining them under nested suites/specs. `classification.json` authenticates the unchanged receipt/results/stdout/stderr, checks the nested 22-test inventory and real configuration fields, and records the corrected setup-only interpretation. The failed post-check is preserved rather than relabeled.

An earlier invocation stopped in the preparation script while parsing malformed `expected-source.json`, before Playwright, the port check, output-directory creation, server, browser, or test discovery. The JSON serialization was corrected before the retained list proof. It is not Website evidence.

## One-shot command, awaiting exclusive slot

Do not invoke until the lead grants the exclusive local/browser slot:

```text
cd /private/tmp/foldkit-website-readiness-diagnostic-20261108-v3
/Users/devinjameson/.vite-plus/js_runtime/node/26.13.0/bin/node run-diagnostic.mjs
```

This will be the first Website suite invocation in v3. Preserve every outcome; do not retry for a favorable result. Successful and failed attempts remain in the private output directory because `retain-on-failure` overrides the repository's first-retry trace policy for this run only. The separate JSON reporter output will permit exact attempt/result classification.

## Preserved invalid setup packets

The prior packets remain byte-exact and are not Website evidence because neither reached test execution:

- v1 preparation manifest `ccef18ab12d331debda1f60bd28ebab0fefe0a432161ba630a83e9be1781f313`; failed-run manifest `9314ae61534d2dc8193df50b51c5e666cccf6146cd4451fef5c9f37e897ac0c5`.
- v2 preparation manifest `77c0cdbf6d694d9bff02192e37cada7474636411bb1c28d931293707d4fd6c98`; failed-run manifest `108ce4e72425789a228293ebbd9c1617eeee05b417e210a3b38a533fac619784`.

Both failed while loading external wrapper configs. V3 uses no external Playwright config wrapper.
