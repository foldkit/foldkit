# Website readiness diagnostic result

Classification: valid non-reproduction.

The one authorized suite invocation used the frozen repository config, exact Node 26.13.0 executable, five workers, existing retries and timeouts, unchanged readiness assertions, and `retain-on-failure`. It completed 22/22 tests on their first attempt in 124.511 seconds. Playwright reported no failed, retried, skipped, unexpected, or flaky result. The dedicated port and scoped process group were clean afterward.

No trace archive exists because no attempt failed. This is the expected behavior of `retain-on-failure`, not lost evidence. The JSON reporter output contains exactly 22 attempts, each with retry index zero, passed status, no error and no attachment.

The run proves that the 5-second client-readiness assertions are not deterministically failing at the frozen source/configuration under the same five-worker local suite. It does not explain the prior intermittent failures and cannot separate slow client compilation/module acquisition from a client runtime failure because it captured neither failure state. It also does not justify increasing the timeout, weakening the SSR handoff marker, warming the client, or claiming the earlier defect is fixed.

The next discriminating evidence is a failed first-attempt trace from a naturally recurring failure, retaining its network/module timeline, console errors, and both marker states. This packet must not be rerun for a favorable result.
