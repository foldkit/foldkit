import { createHash } from 'node:crypto'
import { createWriteStream, existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { createServer } from 'node:net'
import { dirname, join } from 'node:path'
import { spawn, spawnSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'

const packetRoot = dirname(fileURLToPath(import.meta.url))
const expected = JSON.parse(
  readFileSync(join(packetRoot, 'expected-source.json'), 'utf8'),
)
const repositoryRoot = expected.repositoryRoot
const websiteRoot = join(repositoryRoot, 'packages/website')
const outputRoot = join(packetRoot, 'run')
const configPath = join(websiteRoot, 'playwright.config.ts')
const playwrightPath = join(
  repositoryRoot,
  'packages/website/node_modules/.bin/playwright',
)
const playwrightCliPath = join(
  repositoryRoot,
  'node_modules/.pnpm/playwright@1.63.0/node_modules/playwright/cli.js',
)
const port = expected.port
const command = [
  process.execPath,
  playwrightCliPath,
  'test',
  `--config=${configPath}`,
  '--trace=retain-on-failure',
  '--workers=5',
  `--output=${join(outputRoot, 'test-results')}`,
  '--reporter=list,json',
]

const sha256 = path =>
  createHash('sha256').update(readFileSync(path)).digest('hex')

const runCommand = (commandName, args) => {
  const result = spawnSync(commandName, args, {
    cwd: repositoryRoot,
    encoding: 'utf8',
  })
  if (result.status !== 0) {
    throw new Error(
      `${commandName} ${args.join(' ')} failed: ${result.stderr || result.stdout}`,
    )
  }
  return result.stdout.trim()
}

const assertExpectedSource = () => {
  if (process.env.CI !== undefined) {
    throw new Error('Refusing to change the repository local Website semantics under CI.')
  }
  if (process.env.FOLDKIT_LIVE_WEBSITE_URL !== undefined) {
    throw new Error('Refusing to target a live Website URL.')
  }
  if (process.version !== expected.node) {
    throw new Error(`Expected Node ${expected.node}; received ${process.version}.`)
  }

  const commit = runCommand('git', ['rev-parse', 'HEAD'])
  const tree = runCommand('git', ['rev-parse', 'HEAD^{tree}'])
  if (commit !== expected.commit || tree !== expected.tree) {
    throw new Error(
      `Expected commit/tree ${expected.commit}/${expected.tree}; received ${commit}/${tree}.`,
    )
  }

  const relevantStatus = runCommand('git', [
    'status',
    '--porcelain',
    '--',
    'packages/website/e2e',
    'packages/website/playwright.config.ts',
    'packages/website/package.json',
    'scripts/run-website-e2e.sh',
    'pnpm-lock.yaml',
  ])
  if (relevantStatus !== '') {
    throw new Error(`Website diagnostic inputs are modified:\n${relevantStatus}`)
  }

  for (const [relativePath, expectedHash] of Object.entries(expected.files)) {
    const actualHash = sha256(join(repositoryRoot, relativePath))
    if (actualHash !== expectedHash) {
      throw new Error(
        `Source hash mismatch for ${relativePath}: expected ${expectedHash}, received ${actualHash}.`,
      )
    }
  }

  const playwrightVersion = runCommand(playwrightPath, ['--version']).replace(
    /^Version /,
    '',
  )
  const viteVersion = runCommand(
    join(repositoryRoot, 'packages/website/node_modules/.bin/vite'),
    ['--version'],
  ).match(/^vite\/(\S+)/)?.[1]
  if (playwrightVersion !== expected.playwright || viteVersion !== expected.vite) {
    throw new Error(
      `Tool version mismatch: Playwright ${String(playwrightVersion)}, Vite ${String(viteVersion)}.`,
    )
  }

  return { commit, tree, playwrightVersion, viteVersion }
}

const assertPortFree = () =>
  new Promise((resolve, reject) => {
    const server = createServer()
    server.unref()
    server.once('error', error => {
      reject(new Error(`Dedicated port ${port} is unavailable: ${error.message}`))
    })
    server.listen({ host: '::', port, exclusive: true }, () => {
      server.close(error => (error === undefined ? resolve() : reject(error)))
    })
  })

const waitForPortFree = async (attempts = 20) => {
  for (let attempt = 0; attempt < attempts; attempt += 1) {
    try {
      await assertPortFree()
      return true
    } catch {
      await new Promise(resolve => setTimeout(resolve, 250))
    }
  }
  return false
}

if (existsSync(outputRoot)) {
  throw new Error(
    `${outputRoot} already exists. This packet permits exactly one suite invocation; preserve it and prepare a new packet instead of rerunning.`,
  )
}

const setupProofPath = join(packetRoot, 'setup-proof/classification.json')
if (!existsSync(setupProofPath)) {
  throw new Error('The repository-config --list proof is missing.')
}
const setupProof = JSON.parse(readFileSync(setupProofPath, 'utf8'))
if (setupProof.status !== 'listed-without-server-or-browser') {
  throw new Error(`The repository-config --list proof did not pass: ${String(setupProof.status)}.`)
}

const source = assertExpectedSource()
await assertPortFree()
mkdirSync(outputRoot, { recursive: false })

const startedAt = new Date().toISOString()
const preflight = {
  formatVersion: 1,
  status: 'ready-to-run',
  startedAt,
  repositoryRoot,
  websiteRoot,
  outputRoot,
  configPath,
  command,
  cwd: websiteRoot,
  port,
  workers: 5,
  fullyParallel: true,
  retries: 1,
  testTimeoutMilliseconds: 60_000,
  webServerTimeoutMilliseconds: 120_000,
  trace: 'retain-on-failure',
  source,
  setupProofSha256: sha256(setupProofPath),
  expectedSourceSha256: sha256(join(packetRoot, 'expected-source.json')),
  repositoryConfigSha256: sha256(configPath),
  runnerSha256: sha256(fileURLToPath(import.meta.url)),
}
writeFileSync(
  join(outputRoot, 'preflight.json'),
  `${JSON.stringify(preflight, null, 2)}\n`,
)

const stdout = createWriteStream(join(outputRoot, 'stdout.log'), {
  flags: 'wx',
})
const stderr = createWriteStream(join(outputRoot, 'stderr.log'), {
  flags: 'wx',
})
let receivedSignal
let isFinishing = false

const child = spawn(command[0], command.slice(1), {
  cwd: websiteRoot,
  detached: true,
  env: {
    ...process.env,
    FOLDKIT_WEBSITE_E2E_PORT: String(port),
    PLAYWRIGHT_JSON_OUTPUT_FILE: join(outputRoot, 'results.json'),
  },
  stdio: ['ignore', 'pipe', 'pipe'],
})

child.stdout.pipe(stdout)
child.stderr.pipe(stderr)
child.stdout.pipe(process.stdout)
child.stderr.pipe(process.stderr)

const signalNumber = { SIGHUP: 1, SIGINT: 2, SIGTERM: 15 }
for (const signal of Object.keys(signalNumber)) {
  process.once(signal, () => {
    receivedSignal = signal
    try {
      process.kill(-child.pid, signal)
    } catch (error) {
      if (error.code !== 'ESRCH') throw error
    }
  })
}

const result = await new Promise((resolve, reject) => {
  child.once('error', reject)
  child.once('close', (code, signal) => resolve({ code, signal }))
})

if (!isFinishing) {
  isFinishing = true
  try {
    process.kill(-child.pid, 'SIGTERM')
  } catch (error) {
    if (error.code !== 'ESRCH') throw error
  }
}

let isPortFree = await waitForPortFree()
if (!isPortFree) {
  try {
    process.kill(-child.pid, 'SIGKILL')
  } catch (error) {
    if (error.code !== 'ESRCH') throw error
  }
  isPortFree = await waitForPortFree()
}

const waitForClosed = stream =>
  stream.closed
    ? Promise.resolve()
    : new Promise(resolve => stream.once('close', resolve))
await Promise.all([waitForClosed(stdout), waitForClosed(stderr)])

const completedAt = new Date().toISOString()
const receipt = {
  ...preflight,
  status: isPortFree ? 'completed-and-cleaned' : 'cleanup-failed',
  completedAt,
  childExitCode: result.code,
  childSignal: result.signal,
  receivedSignal,
  dedicatedPortFreeAfterRun: isPortFree,
  output: {
    stdout: 'stdout.log',
    stderr: 'stderr.log',
    jsonResults: 'results.json',
    testResults: 'test-results/',
  },
}
writeFileSync(
  join(outputRoot, 'run-receipt.json'),
  `${JSON.stringify(receipt, null, 2)}\n`,
)

if (!isPortFree) {
  process.exitCode = 70
} else if (receivedSignal !== undefined) {
  process.exitCode = 128 + signalNumber[receivedSignal]
} else if (result.code !== null) {
  process.exitCode = result.code
} else {
  process.exitCode = 1
}
