import { createHash } from 'node:crypto'
import { readFile, writeFile } from 'node:fs/promises'
import { join } from 'node:path'

const packetRoot = new URL('.', import.meta.url).pathname.replace(/\/$/, '')
const proofRoot = join(packetRoot, 'setup-proof')

const read = async (name) => readFile(join(proofRoot, name))
const sha256 = (value) => createHash('sha256').update(value).digest('hex')

const receiptBytes = await read('proof-receipt.json')
const resultsBytes = await read('results.json')
const stdoutBytes = await read('stdout.log')
const stderrBytes = await read('stderr.log')
const receipt = JSON.parse(receiptBytes)
const results = JSON.parse(resultsBytes)

let specCount = 0
let testCount = 0
const visitSuite = (suite) => {
  for (const spec of suite.specs ?? []) {
    specCount += 1
    testCount += (spec.tests ?? []).length
  }
  for (const child of suite.suites ?? []) visitSuite(child)
}
for (const suite of results.suites ?? []) visitSuite(suite)

const stdout = stdoutBytes.toString('utf8')
const isValid =
  receipt.status === 'list-proof-failed' &&
  receipt.childExitCode === 0 &&
  receipt.childSignal === null &&
  receipt.dedicatedPortFreeAfterRun === true &&
  stderrBytes.length === 0 &&
  results.config?.configFile === receipt.configPath &&
  results.config?.workers === 5 &&
  results.config?.projects?.[0]?.retries === 1 &&
  results.config?.projects?.[0]?.timeout === 60_000 &&
  results.config?.webServer?.reuseExistingServer === false &&
  results.config?.webServer?.command === 'pnpm dev --port 38742 --strictPort' &&
  results.config?.webServer?.url === 'http://localhost:38742/theme-init.js' &&
  results.config?.webServer?.timeout === 120_000 &&
  results.stats?.expected === 0 &&
  results.stats?.skipped === 22 &&
  results.stats?.unexpected === 0 &&
  specCount === 22 &&
  testCount === 22 &&
  (results.suites ?? []).length === 5 &&
  stdout.includes('Total: 22 tests in 5 files')

const classification = {
  formatVersion: 1,
  status: isValid ? 'listed-without-server-or-browser' : 'invalid-list-proof',
  interpretation:
    'Playwright list mode reports discovered tests as skipped and leaves stats.expected at zero; the retained nested suite/spec inventory is the discovery authority.',
  originalReceipt: {
    path: 'proof-receipt.json',
    sha256: sha256(receiptBytes),
    status: receipt.status,
    postCheckFailure:
      'The preparation runner incorrectly required stats.expected > 0 for list mode after Playwright itself exited zero.',
  },
  retained: {
    results: { path: 'results.json', sha256: sha256(resultsBytes) },
    stdout: { path: 'stdout.log', sha256: sha256(stdoutBytes) },
    stderr: { path: 'stderr.log', sha256: sha256(stderrBytes) },
  },
  observed: {
    childExitCode: receipt.childExitCode,
    childSignal: receipt.childSignal,
    rootSuites: (results.suites ?? []).length,
    specs: specCount,
    tests: testCount,
    stats: results.stats,
    stderrBytes: stderrBytes.length,
    dedicatedPortFreeAfterRun: receipt.dedicatedPortFreeAfterRun,
  },
  limits: [
    'List mode loads and validates the actual repository config and test inventory but does not start the configured web server or a browser.',
    'Port cleanup is recorded by the original process-group runner; this classification does not rerun discovery.',
  ],
}

await writeFile(
  join(proofRoot, 'classification.json'),
  `${JSON.stringify(classification, null, 2)}\n`,
)

if (!isValid) process.exitCode = 1
