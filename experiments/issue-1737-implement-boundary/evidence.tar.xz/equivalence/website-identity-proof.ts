// Temporary proof file (not committed): old and new spellings produce identical Block types.
import { ApplicationComposition } from './composition'
import { init } from './init'
import { EffectsLayer } from './layer'
import { UiComposition } from './page/ui/composition'
import { init as uiInit } from './page/ui/init'
import { update as uiUpdate } from './page/ui/update'
import { view as uiView } from './page/ui/view'
import { subscriptions } from './subscription'
import { update } from './update'
import { view } from './view/view'
import { ApplicationBlock } from './block'
import { UiBlock } from './page/ui/block'

type Equal<Left, Right> =
  (<Value>() => Value extends Left ? 1 : 2) extends <Value>() => Value extends Right ? 1 : 2 ? true : false

const OldUiBlock = UiComposition.assembleBlock({ init: uiInit, update: uiUpdate, view: uiView })
const OldApplicationBlock = ApplicationComposition.assembleBlock({ init, update, view, subscriptions, EffectsLayer })

export const uiIdentity: Equal<typeof OldUiBlock, typeof UiBlock> = true
export const applicationIdentity: Equal<typeof OldApplicationBlock, typeof ApplicationBlock> = true
// Negative control: the proof relation distinguishes different Blocks.
export const negativeControl: Equal<typeof OldUiBlock, typeof ApplicationBlock> = false
