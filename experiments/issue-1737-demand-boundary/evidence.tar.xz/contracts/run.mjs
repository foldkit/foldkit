import { spawn, spawnSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { closeSync, existsSync, mkdirSync, openSync, readFileSync, readdirSync, realpathSync, statSync, writeFileSync } from 'node:fs'
import { dirname, isAbsolute, join, relative, resolve } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'

const directory = dirname(fileURLToPath(import.meta.url))
const root = resolve(directory, '../../..')
const manifest = JSON.parse(readFileSync(join(directory, 'manifest.json'), 'utf8'))
const args = process.argv.slice(2)
const usage = 'node experiments/issue-1737-demand-boundary/contracts/run.mjs [--execute --label NAME --output /new/external/directory [--only website-source]]'
const options = new Map()
for (let index = 0; index < args.length; index++) {
  const argument = args[index]
  if (argument === '--execute') {
    if (options.has(argument)) throw new Error(`Duplicate ${argument}`)
    options.set(argument, true)
  } else if (['--label', '--output', '--only'].includes(argument)) {
    const value = args[++index]
    if (!value || value.startsWith('--') || options.has(argument)) throw new Error(usage)
    options.set(argument, value)
  } else {
    throw new Error(usage)
  }
}
if (!options.has('--execute')) {
  console.log(JSON.stringify({ status: 'not-executed', usage, manifest }, null, 2))
} else {
  if (process.platform === 'win32') throw new Error('Owned process-group cleanup requires POSIX')
  const output = options.get('--output')
  const label = options.get('--label')
  if (!output || !isAbsolute(output) || !label) throw new Error(usage)
  const outputParent = realpathSync(dirname(output))
  const destination = join(outputParent, output.slice(output.lastIndexOf('/') + 1))
  const outputRelative = relative(realpathSync(root), destination)
  if (outputRelative === '' || (!outputRelative.startsWith('../') && !isAbsolute(outputRelative))) {
    throw new Error('Output must be outside the checkout')
  }
  const only = options.get('--only')
  if (only !== undefined && only !== 'website-source') throw new Error('Only website-source may be selected for the paired consumer check')
  mkdirSync(destination) // Exclusive directory creation: never overwrite evidence.
  const hash = path => createHash('sha256').update(readFileSync(path)).digest('hex')
  const report = {
    formatVersion: 1,
    status: 'running',
    label,
    root: realpathSync(root),
    declaredBase: manifest.base,
    startedAt: new Date().toISOString(),
    node: { version: process.version, executable: realpathSync(process.execPath), sha256: hash(process.execPath) },
    platform: { os: process.platform, arch: process.arch },
    environment: { GOMEMLIMIT: process.env.GOMEMLIMIT ?? null, GOGC: process.env.GOGC ?? null },
    guards: manifest.guards,
    manifestSha256: hash(join(directory, 'manifest.json')),
    compilers: [],
    commands: manifest.commands.map(command => ({ ...command, status: only && command.id !== only ? 'not-selected' : 'pending' })),
  }
  const save = () => writeFileSync(join(destination, 'report.json'), `${JSON.stringify(report, null, 2)}\n`)
  const metadataCommand = (argv, cwd = root) => {
    const result = spawnSync(argv[0], argv.slice(1), { cwd, encoding: 'utf8', timeout: 10000 })
    const evidence = { argv, cwd, exitCode: result.status, signal: result.signal, stdout: result.stdout ?? '', stderr: result.stderr ?? '', error: result.error?.message ?? null }
    if (result.status !== 0 || result.error) throw new Error(`Identity command failed: ${JSON.stringify(evidence)}`)
    return evidence
  }
  const snapshot = () => {
    const inventory = {}
    const visit = path => {
      const absolute = join(root, path)
      if (statSync(absolute).isDirectory()) {
        for (const name of readdirSync(absolute).sort()) visit(join(path, name))
      } else {
        inventory[path] = hash(absolute)
      }
    }
    for (const path of manifest.immutableDuringRun) visit(path)
    return inventory
  }
  let active
  let interrupted
  const killOwnedGroup = () => {
    if (active?.pid) {
      try { process.kill(-active.pid, 'SIGKILL') } catch (error) { if (error.code !== 'ESRCH') throw error }
    }
  }
  const onInterrupt = () => { interrupted = 'SIGINT'; killOwnedGroup() }
  const onTerminate = () => { interrupted = 'SIGTERM'; killOwnedGroup() }
  process.on('SIGINT', onInterrupt)
  process.on('SIGTERM', onTerminate)
  save()
  try {
    report.pnpm = metadataCommand(['pnpm', '--version'])
    if (report.pnpm.stdout.trim() !== manifest.expectedPnpm) throw new Error(`Expected pnpm ${manifest.expectedPnpm}`)
    // jj workspace baseline is supplied by the parent; inventory the actual bytes too.
    report.revision = metadataCommand(['jj', 'log', '-r', '@-', '--no-graph', '-T', 'commit_id'])
    if (report.revision.stdout.trim() !== manifest.base) throw new Error('Workspace parent is not the pinned issue baseline')
    for (const path of manifest.builtPrerequisites) {
      if (!existsSync(join(root, path))) throw new Error(`Missing ${path}; do not rebuild during measurements`)
    }
    for (const packagePath of manifest.compilerPackages) {
      const packageRoot = realpathSync(join(root, packagePath))
      const packageJson = JSON.parse(readFileSync(join(packageRoot, 'package.json'), 'utf8'))
      const resolver = join(packageRoot, 'lib/getExePath.js')
      const { default: getExePath } = await import(pathToFileURL(resolver).href)
      const executable = realpathSync(getExePath())
      const version = metadataCommand([executable, '--version'])
      report.compilers.push({ packagePath, packageRoot, packageVersion: packageJson.version, packageJsonSha256: hash(join(packageRoot, 'package.json')), resolverSha256: hash(resolver), executable, executableSha256: hash(executable), version })
      if (packageJson.version !== manifest.expectedCompiler || version.stdout.trim() !== `Version ${manifest.expectedCompiler}`) throw new Error('Compiler identity does not match the unchanged baseline budgets')
    }
    report.budgetHashesBefore = Object.fromEntries(Object.keys(manifest.budgetHashes).map(path => [path, hash(join(root, path))]))
    if (JSON.stringify(report.budgetHashesBefore) !== JSON.stringify(manifest.budgetHashes)) throw new Error('Budget/config hashes differ from baseline')
    report.inventoryBefore = snapshot()
    save()
    for (const command of report.commands) {
      if (command.status === 'not-selected') continue
      if (interrupted) break
      command.status = 'running'
      command.startedAt = new Date().toISOString()
      command.actualCwd = resolve(root, command.cwd)
      command.stdoutFile = `${command.id}.stdout.log`
      command.stderrFile = `${command.id}.stderr.log`
      save()
      const stdout = openSync(join(destination, command.stdoutFile), 'wx')
      const stderr = openSync(join(destination, command.stderrFile), 'wx')
      const start = performance.now()
      let timer
      try {
        await new Promise((complete, reject) => {
          active = spawn(command.argv[0], command.argv.slice(1), { cwd: command.actualCwd, env: process.env, detached: true, stdio: ['ignore', stdout, stderr] })
          active.once('error', reject)
          timer = setTimeout(() => { command.timedOut = true; killOwnedGroup() }, manifest.guards.commandTimeoutMs)
          active.once('close', (exitCode, signal) => {
            command.exitCode = exitCode
            command.signal = signal
            complete()
          })
        })
        command.status = command.exitCode === 0 && !command.timedOut && !interrupted ? 'passed' : 'failed'
      } catch (error) {
        command.status = 'failed'
        command.error = error.message
      } finally {
        clearTimeout(timer)
        killOwnedGroup()
        active = undefined
        closeSync(stdout)
        closeSync(stderr)
        command.durationMs = performance.now() - start
        command.finishedAt = new Date().toISOString()
        save()
      }
    }
    report.inventoryAfter = snapshot()
    report.changedPaths = [...new Set([...Object.keys(report.inventoryBefore), ...Object.keys(report.inventoryAfter)])].filter(path => report.inventoryBefore[path] !== report.inventoryAfter[path])
    report.budgetHashesAfter = Object.fromEntries(Object.keys(manifest.budgetHashes).map(path => [path, hash(join(root, path))]))
    const selected = report.commands.filter(command => command.status !== 'not-selected')
    report.status = !interrupted && report.changedPaths.length === 0 && selected.every(command => command.status === 'passed') ? 'passed' : 'failed'
    report.evidenceScope = only ? 'website-source-only; not full source/emitted/budget proof' : 'existing source, emitted and compiler-budget gates'
    if (interrupted) report.interruptedBy = interrupted
  } catch (error) {
    report.status = 'failed'
    report.error = error.stack ?? error.message
  } finally {
    killOwnedGroup()
    process.off('SIGINT', onInterrupt)
    process.off('SIGTERM', onTerminate)
    report.finishedAt = new Date().toISOString()
    save()
  }
  console.log(JSON.stringify({ status: report.status, report: join(destination, 'report.json') }))
  if (report.status !== 'passed') process.exitCode = 1
}
