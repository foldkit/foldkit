import { spawnSync } from 'node:child_process'
import { writeFileSync } from 'node:fs'
const args = ['/private/tmp/foldkit-1737-tools/mutation/scope-root-editor-probe.mjs', '--workspace', '/private/tmp/foldkit-1737-editor', '--disposable-workspace', '--output', '/private/tmp/foldkit-1737-tools/hover-message-mutation.json', '--mode', 'root-hover']
const env = { ...process.env }
delete env.GOMEMLIMIT
delete env.GOGC
const result = spawnSync(process.execPath, args, { env, encoding: 'utf8', timeout: 35000 })
writeFileSync('/private/tmp/foldkit-1737-tools/hover-message-mutation.node-execution.json', JSON.stringify({ command: [process.execPath, ...args], status: result.status, signal: result.signal, error: result.error?.message ?? null, stdout: result.stdout, stderr: result.stderr }, null, 2) + '\n', { flag: 'wx' })
console.log(result.stdout)
console.error(result.stderr)
if (result.status !== 1) process.exit(1)
