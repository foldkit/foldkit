import { spawnSync } from 'node:child_process'
import { writeFileSync } from 'node:fs'

const [label, start = '1', end = start] = process.argv.slice(2)
if (!label || !/^[a-z0-9-]+$/.test(label)) throw new Error('Specify a unique report label')
const environment = { ...process.env }
delete environment.GOMEMLIMIT
delete environment.GOGC
for (let repetition = Number(start); repetition <= Number(end); repetition++) {
  for (const mode of ['root-incomplete', 'root-hover', 'root-diagnostics']) {
    const directory = '/private/tmp/foldkit-1737-tools'
    const prefix = `${directory}/${label}-${mode}-${repetition}`
    const probe = mode === 'root-hover' ? `${directory}/hover/scope-root-editor-probe.mjs` : `${directory}/scope-root-editor-probe.mjs`
    const args = [probe, '--workspace', '/private/tmp/foldkit-1737-editor', '--disposable-workspace', '--output', `${prefix}.json`, '--mode', mode]
    const result = spawnSync(process.execPath, args, { env: environment, encoding: 'utf8', timeout: 35000 })
    writeFileSync(`${prefix}.stdout.log`, result.stdout ?? '', { flag: 'wx' })
    writeFileSync(`${prefix}.stderr.log`, result.stderr ?? '', { flag: 'wx' })
    writeFileSync(`${prefix}.exit.json`, JSON.stringify({ command: [process.execPath, ...args], status: result.status, signal: result.signal, error: result.error?.message ?? null }) + '\n', { flag: 'wx' })
    console.log(result.stdout)
    if (result.status !== 0 || result.error) {
      console.error(result.stderr, result.error ?? '')
      process.exit(1)
    }
  }
}
