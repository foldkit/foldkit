import assert from 'node:assert/strict'
import { createRequire } from 'node:module'
import { readFile } from 'node:fs/promises'
import { resolve } from 'node:path'
import { pathToFileURL } from 'node:url'
import { setImmediate as nextTurn } from 'node:timers/promises'

const repository = resolve(process.env.FOLDKIT_REPO ?? process.cwd())
const packageFile = resolve(repository, 'packages/foldkit/package.json')
const metadata = JSON.parse(await readFile(packageFile, 'utf8'))
const requireFromPackage = createRequire(packageFile)
const loadDependency = name => import(pathToFileURL(requireFromPackage.resolve(name)).href)
const entry = resolve(repository, 'packages/foldkit', metadata.exports['.'].import)
const { Layer, Schema } = await loadDependency('effect')
const { Window } = await loadDependency('happy-dom')
const { Block, Program, Runtime, Message } = await import(pathToFileURL(entry).href)
const window = new Window({ url: 'https://root-surface.invalid/' })
const previousGlobals = new Map()
for (const name of [
  'window', 'document', 'navigator', 'location', 'history', 'localStorage',
  'sessionStorage', 'Node', 'Element', 'HTMLElement', 'HTMLDialogElement',
  'HTMLInputElement', 'HTMLSelectElement', 'HTMLTextAreaElement', 'SVGElement',
  'Document', 'DocumentFragment', 'Text', 'Comment', 'Event', 'MouseEvent',
  'CustomEvent', 'MutationObserver', 'DOMParser', 'XMLSerializer',
  'requestAnimationFrame', 'cancelAnimationFrame', 'getComputedStyle',
]) {
  previousGlobals.set(name, Object.getOwnPropertyDescriptor(globalThis, name))
  const value = name === 'window' ? window : window[name]
  assert.notEqual(value, undefined, `DOM harness missing ${name}`)
  Object.defineProperty(globalThis, name, {
    configurable: true,
    writable: true,
    value: ['requestAnimationFrame', 'cancelAnimationFrame', 'getComputedStyle'].includes(name)
      ? value.bind(window)
      : value,
  })
}
const observations = { messages: [], failures: [] }
const Model = Schema.Struct({ length: Schema.Number })
const LocalMessage = Message.defineMessageUnion({ UpdatedQuery: { query: Schema.String } })
const NavigationMessage = Message.defineMessageUnion({ ChangedLocation: {} })
const Composition = Block.makeDefinition('RootSurfaceRouting', {
  Model,
  Message: LocalMessage,
}).makeComposition()
const root = Composition.assembleRoot({
  init: _url => ({ model: Model.make({ length: 0 }) }),
  update: Composition.makeUpdate((_model, message) => {
    observations.messages.push({ tag: message._tag, hasQuery: Object.hasOwn(message, 'query') })
    try {
      return { model: Model.make({ length: message.query.length }) }
    } catch (error) {
      observations.failures.push({ name: error.name, message: error.message })
      throw error
    }
  }),
  view: Composition.makeView(model => ({ title: globalThis.String(model.length), body: null })),
  EffectsLayer: Layer.empty,
})
const container = document.createElement('div')
container.id = 'root-surface-routing'
document.body.append(container)
const program = Program.make({
  block: root,
  container,
  devTools: false,
  routing: {
    onUrlRequest: () => NavigationMessage.ChangedLocation(),
    onUrlChange: () => NavigationMessage.ChangedLocation(),
  },
})
const eventually = async (label, assertion) => {
  const deadline = performance.now() + 10000
  let lastError
  while (performance.now() < deadline) {
    try {
      assertion()
      return
    } catch (error) {
      lastError = error
    }
    await nextTurn()
  }
  throw new Error(`Timed out: ${label}`, { cause: lastError })
}
let handle
try {
  handle = Runtime.embed(program)
  await eventually('initial document render after navigation listener installation', () => {
    assert.equal(document.title, '0')
  })
  window.dispatchEvent(new window.PopStateEvent('popstate'))
  await eventually('routed unsupported Message reaches actual update', () => {
    assert.deepEqual(observations.messages, [{ tag: 'ChangedLocation', hasQuery: false }])
    assert.equal(observations.failures.length, 1)
    assert.equal(observations.failures[0].name, 'TypeError')
    assert.match(observations.failures[0].message, /length/)
  })
  console.log(JSON.stringify({
    marker: 'ROOT_SURFACE_ROUTING_REPRODUCED',
    artifact: entry,
    event: 'popstate',
    ...observations,
  }))
} finally {
  handle?.dispose()
  await window.happyDOM.close()
  for (const [name, descriptor] of previousGlobals) {
    if (descriptor === undefined) delete globalThis[name]
    else Object.defineProperty(globalThis, name, descriptor)
  }
}
