import { Effect, Layer, Option, Schema } from 'effect'
import * as Block from 'foldkit/block'
import { defineMessageUnion } from 'foldkit/message'
import * as Program from 'foldkit/program'

const Message = defineMessageUnion({ Done: {} })
const Definition = Block.makeDefinition('UnionProvision', { Model: Schema.Null, Message })
const Session = Definition.makeResource<string>()('Session')
const Read = Definition.makeCommand('Read', {
  messages: [Message.Done],
  handler: function* () {
    return () => Session.get.pipe(
      Effect.map(() => Message.Done()),
      Effect.catch(() => Effect.succeed(Message.Done())),
    )
  },
})
const managedResources = Definition.makeManagedResources(entry => ({
  session: entry('ManageSession', Schema.Option(Schema.Null), {
    resource: Session,
    modelToMaybeRequirements: () => Option.some(null),
    onAcquired: () => Message.Done(),
    onReleased: () => Message.Done(),
    onAcquireError: () => Message.Done(),
    handler: function* () {
      return { acquire: () => Effect.succeed('ready'), release: () => Effect.void }
    },
  }),
}))
const Composition = Definition.makeComposition()
const common = {
  init: Composition.makeInit(() => ({ model: null, commands: [Read()] })),
  update: Composition.makeUpdate(model => ({ model })),
  view: Composition.makeView(() => null),
}
const A = Composition.assembleBlock({
  ...common,
  managedResources,
  EffectsLayer: Layer.merge(Read.layer, managedResources.session.layer),
})
const B = Composition.assembleBlock({ ...common, EffectsLayer: Read.layer })
function makeSelected(block: typeof A | typeof B) {
  return Program.makeElement({ block, container: null }).provide(Layer.empty)
}
// @ts-expect-error The selected B alternative requires a Session provider.
const boot: Effect.Effect<void> = makeSelected(B).start()
