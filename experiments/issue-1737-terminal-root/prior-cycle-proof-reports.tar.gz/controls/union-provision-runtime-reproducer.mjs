import assert from 'node:assert/strict'
import { createRequire } from 'node:module'
import { readFile } from 'node:fs/promises'
import { resolve } from 'node:path'
import { pathToFileURL } from 'node:url'
import { setImmediate as nextTurn } from 'node:timers/promises'

const repository = resolve(process.env.FOLDKIT_REPO ?? process.cwd())
const packageFile = resolve(repository, 'packages/foldkit/package.json')
const metadata = JSON.parse(await readFile(packageFile, 'utf8'))
const requireFromPackage = createRequire(packageFile)
const loadDependency = name => import(pathToFileURL(requireFromPackage.resolve(name)).href)
const entry = resolve(repository, 'packages/foldkit', metadata.exports['.'].import)
const { Cause, Effect, Layer, Option, Schema } = await loadDependency('effect')
const { Window } = await loadDependency('happy-dom')
const { Block, Program, Runtime, Message } = await import(pathToFileURL(entry).href)
const window = new Window({ url: 'https://union-provision.invalid/' })
const previousGlobals = new Map()
for (const name of [
  'window', 'document', 'navigator', 'location', 'history', 'localStorage',
  'sessionStorage', 'Node', 'Element', 'HTMLElement', 'HTMLDialogElement',
  'HTMLInputElement', 'HTMLSelectElement', 'HTMLTextAreaElement', 'SVGElement',
  'Document', 'DocumentFragment', 'Text', 'Comment', 'Event', 'MouseEvent',
  'CustomEvent', 'MutationObserver', 'DOMParser', 'XMLSerializer',
  'requestAnimationFrame', 'cancelAnimationFrame', 'getComputedStyle',
]) {
  previousGlobals.set(name, Object.getOwnPropertyDescriptor(globalThis, name))
  const value = name === 'window' ? window : window[name]
  assert.notEqual(value, undefined, `DOM harness missing ${name}`)
  Object.defineProperty(globalThis, name, {
    configurable: true,
    writable: true,
    value: ['requestAnimationFrame', 'cancelAnimationFrame', 'getComputedStyle'].includes(name)
      ? value.bind(window)
      : value,
  })
}
const observations = { successfulResourceReads: 0, failures: [] }
const LocalMessage = Message.defineMessageUnion({ Done: {} })
const Definition = Block.makeDefinition('UnionProvision', { Model: Schema.Null, Message: LocalMessage })
const Session = Definition.makeResource()('Session')
const Read = Definition.makeCommand('Read', {
  messages: [LocalMessage.Done],
  handler: function* () {
    return () => Session.get.pipe(
      Effect.tap(() => Effect.sync(() => { observations.successfulResourceReads += 1 })),
      Effect.map(() => LocalMessage.Done()),
      Effect.catch(() => Effect.succeed(LocalMessage.Done())),
      Effect.tapCause(cause => Effect.sync(() => {
        observations.failures.push(Cause.pretty(cause))
      })),
    )
  },
})
const managedResources = Definition.makeManagedResources(entry => ({
  session: entry('ManageSession', Schema.Option(Schema.Null), {
    resource: Session,
    modelToMaybeRequirements: () => Option.some(null),
    onAcquired: () => LocalMessage.Done(),
    onReleased: () => LocalMessage.Done(),
    onAcquireError: () => LocalMessage.Done(),
    handler: function* () {
      return { acquire: () => Effect.succeed('ready'), release: () => Effect.void }
    },
  }),
}))
const Composition = Definition.makeComposition()
const common = {
  init: Composition.makeInit(() => ({ model: null, commands: [Read()] })),
  update: Composition.makeUpdate(model => ({ model })),
  view: Composition.makeView(() => null),
}
const A = Composition.assembleBlock({
  ...common,
  managedResources,
  EffectsLayer: Layer.merge(Read.layer, managedResources.session.layer),
})
const B = Composition.assembleBlock({ ...common, EffectsLayer: Read.layer })
assert.notEqual(A, B)
const container = document.createElement('div')
container.id = 'union-provision'
document.body.append(container)
function makeSelected(block) {
  return Program.makeElement({ block, container, devTools: false }).provide(Layer.empty)
}
const program = makeSelected(B)
let handle
try {
  handle = Runtime.embed(program)
  const deadline = performance.now() + 10000
  while (observations.failures.length === 0 && performance.now() < deadline) {
    await nextTurn()
  }
  assert.equal(observations.failures.length, 1, 'Read must reach the actual missing managed-resource service')
  assert.match(observations.failures[0], /Service not found/)
  assert.match(observations.failures[0], /Session/)
  console.log(JSON.stringify({ marker: 'UNION_PROVISION_MISSING_SERVICE_REPRODUCED', artifact: entry, selected: 'B', provider: 'Layer.empty', ...observations }))
} finally {
  handle?.dispose()
  await window.happyDOM.close()
  for (const [name, descriptor] of previousGlobals) {
    if (descriptor === undefined) delete globalThis[name]
    else Object.defineProperty(globalThis, name, descriptor)
  }
}
