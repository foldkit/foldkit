import assert from 'node:assert/strict'
import { createRequire } from 'node:module'
import { readFile } from 'node:fs/promises'
import { resolve } from 'node:path'
import { pathToFileURL } from 'node:url'
import { setImmediate as nextTurn } from 'node:timers/promises'

// Run after building the candidate, from the repository root (or set FOLDKIT_REPO).
// No source imports, loaders, test runner, listeners, or external services are used.
const repository = resolve(process.env.FOLDKIT_REPO ?? process.cwd())
const packageFile = resolve(repository, 'packages/foldkit/package.json')
const packageMetadata = JSON.parse(await readFile(packageFile, 'utf8'))
const requireFromPackage = createRequire(packageFile)
const loadDependency = name => import(pathToFileURL(requireFromPackage.resolve(name)).href)
const loadPublic = subpath => {
  const entry = packageMetadata.exports[subpath]?.import
  assert.equal(typeof entry, 'string', `Missing public export ${subpath}`)
  return import(pathToFileURL(resolve(repository, 'packages/foldkit', entry)).href)
}
const { Context, Effect, Layer, Schema } = await loadDependency('effect')
const { Window } = await loadDependency('happy-dom')
const { Block, Program, Runtime, Message, Struct } = await loadPublic('.')
const Server = await loadPublic('./experimental/server')
assert.equal(typeof Block.makeDefinition, 'function')
assert.equal(typeof Message.defineMessageUnion, 'function')
console.log(`ARTIFACT ${resolve(repository, 'packages/foldkit', packageMetadata.exports['.'].import)}`)

const window = new Window({ url: 'https://root-smoke.invalid/' })
const previousGlobals = new Map()
for (const name of [
  'window', 'document', 'navigator', 'location', 'history', 'localStorage',
  'sessionStorage', 'Node', 'Element', 'HTMLElement', 'HTMLDialogElement',
  'HTMLInputElement', 'HTMLSelectElement', 'HTMLTextAreaElement', 'SVGElement',
  'Document', 'DocumentFragment', 'Text', 'Comment', 'Event', 'MouseEvent',
  'CustomEvent', 'MutationObserver', 'DOMParser', 'XMLSerializer',
  'requestAnimationFrame', 'cancelAnimationFrame', 'getComputedStyle',
]) {
  previousGlobals.set(name, Object.getOwnPropertyDescriptor(globalThis, name))
  const value = name === 'window' ? window : window[name]
  assert.notEqual(value, undefined, `DOM harness missing ${name}`)
  Object.defineProperty(globalThis, name, {
    configurable: true,
    writable: true,
    value: ['requestAnimationFrame', 'cancelAnimationFrame', 'getComputedStyle'].includes(name)
      ? value.bind(window)
      : value,
  })
}

const passed = []
const pass = name => {
  passed.push(name)
  console.log(`PASS ${name}`)
}
const eventually = async (label, assertion) => {
  const deadline = performance.now() + 10000
  let lastError
  while (performance.now() < deadline) {
    try {
      assertion()
      return
    } catch (error) {
      lastError = error
    }
    await nextTurn()
  }
  throw new Error(`Timed out: ${label}`, { cause: lastError })
}
const click = (container, id) => {
  const button = container.querySelector(`#${id}`)
  assert.ok(button, `Missing button #${id}`)
  button.dispatchEvent(new MouseEvent('click', { bubbles: true }))
  return button
}
const counts = values => Object.fromEntries(
  [...new Set(values)].sort().map(value => [value, values.filter(candidate => candidate === value).length]),
)

function makeGraph(label, isDocument) {
  const observations = {
    init: 0,
    serviceAcquired: [],
    serviceReleased: [],
    constructors: [],
    handlersReleased: [],
    rootCommands: [],
    reads: [],
    acquired: [],
    released: [],
    resources: new Map(),
  }
  const service = { token: Symbol(label) }
  const Controls = Context.Service(`RootSmoke/${label}/Controls`)
  const provider = Layer.effect(Controls, Effect.acquireRelease(
    Effect.sync(() => {
      observations.serviceAcquired.push(service)
      return service
    }),
    released => Effect.sync(() => {
      assert.equal(released, service, 'External service release identity')
      observations.serviceReleased.push(released)
    }),
  ))
  const trackHandler = name => Effect.acquireRelease(
    Effect.sync(() => observations.constructors.push(name)),
    () => Effect.sync(() => observations.handlersReleased.push(name)),
  )
  const ItemMessage = Message.defineMessageUnion({
    ClickedRead: {},
    CompletedRead: { value: Schema.String },
    CompletedObserve: {},
  })
  const ItemModel = Schema.Struct({
    id: Schema.Number,
    source: Schema.String,
    observed: Schema.String,
  })
  const ItemDefinition = Block.makeDefinition(`RootSmoke${label}Item`, {
    Model: ItemModel,
    Message: ItemMessage,
  })
  const Read = ItemDefinition.makeCommand('Read', {
    args: { source: Schema.String },
    messages: [ItemMessage.CompletedRead],
    handler: function* () {
      const provided = yield* Controls
      assert.equal(provided, service, 'Child Command service identity')
      yield* trackHandler('Read')
      return ({ source }) => Effect.sync(() => {
        observations.reads.push(source)
        return ItemMessage.CompletedRead({ value: source })
      })
    },
  })
  const Observe = ItemDefinition.makeMount('Observe', {
    args: { source: Schema.String },
    messages: [ItemMessage.CompletedObserve],
    handler: function* () {
      const provided = yield* Controls
      assert.equal(provided, service, 'Mount service identity')
      yield* trackHandler('Observe')
      return ({ source }) => Effect.gen(function* () {
        yield* Effect.acquireRelease(
          Effect.sync(() => {
            const resource = { source, provided }
            observations.resources.set(source, resource)
            observations.acquired.push(source)
            return resource
          }),
          resource => Effect.sync(() => {
            assert.equal(resource, observations.resources.get(source), 'Mount release resource identity')
            assert.equal(resource.provided, service, 'Mount release service identity')
            observations.released.push(source)
          }),
        )
        return ItemMessage.CompletedObserve()
      })
    },
  })
  const ItemComposition = ItemDefinition.makeComposition({ mounts: [Observe] })
  const ItemBlock = ItemComposition.assembleBlock({
    init: ItemComposition.makeInit((id, source) => ({
      model: { id, source, observed: 'pending' },
    })),
    update: ItemComposition.makeUpdate((model, message) => ItemMessage.match(message, {
      ClickedRead: () => ({ model, commands: [Read({ source: model.source })] }),
      CompletedRead: ({ value }) => ({
        model: Struct.modifyFields(model, { observed: () => value }),
      }),
      CompletedObserve: () => ({ model }),
    })),
    view: ItemComposition.makeView((model, h) => h.keyed('section')(
      globalThis.String(model.id),
      [h.OnMount(Observe({ source: model.source }))],
      [
        h.button([h.Id(`read-${model.id}`), h.OnClick(ItemMessage.ClickedRead())], ['Read']),
        h.span([h.Id(`observed-${model.id}`)], [model.observed]),
        h.span([h.Id(`source-${model.id}`)], [model.source]),
      ],
    )),
    EffectsLayer: Layer.merge(Read.layer, Observe.layer),
  })
  const RootMessage = Message.defineMessageUnion({
    ClickedUpdate: {},
    ClickedRemove: {},
    CompletedRecord: { phase: Schema.String },
  })
  const RootDefinition = Block.makeDefinition(`RootSmoke${label}Application`, {
    Model: Schema.Struct({ entries: Schema.Array(ItemModel), phase: Schema.String }),
    Message: RootMessage,
  })
  const Record = RootDefinition.makeCommand('Record', {
    args: { phase: Schema.String },
    messages: [RootMessage.CompletedRecord],
    handler: function* () {
      const provided = yield* Controls
      assert.equal(provided, service, 'Root Command service identity')
      yield* trackHandler('Record')
      return ({ phase }) => Effect.sync(() => {
        observations.rootCommands.push(phase)
        return RootMessage.CompletedRecord({ phase })
      })
    },
  })
  const EntriesBinding = RootDefinition.makeBinding(ItemBlock, { field: 'entries', key: 'id' })
  const Composition = RootDefinition.makeComposition({ bindings: [EntriesBinding] })
  assert.equal(Composition.assembleRoot, Composition.assembleBlock, 'Root and Block runtime assembly route')
  const init = Composition.makeInit(() => {
    observations.init += 1
    return {
      model: {
        entries: [ItemBlock.init(1, 'old').model, ItemBlock.init(2, 'other').model],
        phase: 'starting',
      },
      commands: [Record({ phase: 'init' })],
    }
  })
  const update = Composition.makeUpdate((model, message) => RootMessage.match(message, {
    ClickedUpdate: () => ({ model, commands: [Record({ phase: 'update' })] }),
    ClickedRemove: () => ({
      model: Struct.modifyFields(model, { entries: entries => entries.filter(entry => entry.id !== 1) }),
    }),
    CompletedRecord: ({ phase }) => ({ model: Struct.modifyFields(model, { phase: () => phase }) }),
  }))
  const body = (model, h) => h.main([], [
    h.span([h.Id('phase')], [model.phase]),
    h.button([h.Id('update'), h.OnClick(RootMessage.ClickedUpdate())], ['Update']),
    h.button([h.Id('remove'), h.OnClick(RootMessage.ClickedRemove())], ['Remove']),
    ...model.entries.map(entry => h.block(EntriesBinding.embedView({
      key: entry.id,
      slotId: globalThis.String(entry.id),
      model: entry,
    }))),
  ])
  const view = Composition.makeView((model, h) => isDocument
    ? { title: `Root smoke ${label}`, body: body(model, h) }
    : body(model, h))
  const root = { ...Composition.assembleRoot({ init, update, view, EffectsLayer: Record.layer }) }
  assert.equal(root.init, init, 'Root retains authored init identity')
  return { root, provider, observations, service }
}

function assertPassive(observations) {
  assert.equal(observations.init, 0)
  for (const name of [
    'serviceAcquired', 'serviceReleased', 'constructors', 'handlersReleased',
    'rootCommands', 'reads', 'acquired', 'released',
  ]) assert.deepEqual(observations[name], [], `Passive ${name}`)
}

async function runProgram(kind) {
  const graph = makeGraph(kind, kind === 'Document')
  const { root, provider, observations, service } = graph
  const container = document.createElement('div')
  container.id = `root-smoke-${kind}`
  const beforeTitle = document.title
  if (kind === 'Document') {
    document.body.replaceChildren(container)
  } else {
    document.body.append(container)
  }
  const hostContainer = container
  const configured = (kind === 'Element' ? Program.makeElement : Program.make)({
    block: root,
    container: hostContainer,
    devTools: false,
  }).provide(provider)
  assertPassive(observations)
  pass(`${kind}: passive assembly, configuration and provide; same assembly route and init identity`)
  const handle = Runtime.embed(configured)
  try {
    await eventually(`${kind} startup`, () => {
      assert.equal(document.querySelector('#phase')?.textContent, 'init')
      assert.deepEqual(observations.acquired, ['old', 'other'])
      assert.deepEqual(observations.rootCommands, ['init'])
      assert.deepEqual(observations.serviceAcquired, [service])
      assert.equal(observations.init, 1)
      assert.deepEqual(counts(observations.constructors), { Observe: 1, Read: 1, Record: 1 })
    })
    if (kind === 'Document') assert.equal(document.title, `Root smoke ${kind}`)
    else assert.equal(document.title, beforeTitle)
    const otherNode = document.querySelector('#source-2')
    click(document, 'read-1')
    click(document, 'read-2')
    await eventually('child Commands complete', () => {
      assert.deepEqual(observations.reads, ['old', 'other'])
      assert.equal(document.querySelector('#observed-1')?.textContent, 'old')
      assert.equal(document.querySelector('#observed-2')?.textContent, 'other')
    })
    click(document, 'update')
    await eventually('root update Command', () => assert.equal(document.querySelector('#phase')?.textContent, 'update'))
    assert.deepEqual(observations.rootCommands, ['init', 'update'])
    assert.deepEqual(observations.released, [])
    assert.equal(document.querySelector('#source-2'), otherNode, 'Unchanged keyed sibling DOM retained')
    pass(`${kind}: provided service identity, init/update Commands and retained child/Mount`)

    click(document, 'remove')
    await eventually('old child Mount release', () => {
      assert.deepEqual(observations.released, ['old'])
    })
    assert.deepEqual(observations.handlersReleased, [], 'Shared handlers retained until host disposal')
    assert.deepEqual(observations.serviceReleased, [], 'External service retained until host disposal')
    assert.equal(document.querySelector('#source-2'), otherNode)
    assert.deepEqual(counts(observations.constructors), { Observe: 1, Read: 1, Record: 1 })
    pass(`${kind}: registered child/Mount disposal for removed child only; surviving child retained`)
  } finally {
    handle.dispose()
    await eventually(`${kind} exact resource teardown`, () => {
      assert.deepEqual(counts(observations.released), { old: 1, other: 1 })
      assert.deepEqual(counts(observations.handlersReleased), { Observe: 1, Read: 1, Record: 1 })
      assert.deepEqual(observations.serviceReleased, [service])
    })
    container.remove()
  }
  pass(`${kind}: registered child Mounts, shared handlers and provided service released exactly once with identity`)
}

async function runServer() {
  const { root, provider, observations } = makeGraph('Server', true)
  const rendering = Server.renderToString(root, {}, { isHydratable: false })
  const providedRendering = Effect.provide(rendering, provider)
  assertPassive(observations)
  pass('Server: assembly, render effect construction and provider configuration are passive')
  const rendered = await Effect.runPromise(providedRendering)
  assert.equal(rendered.title, 'Root smoke Server')
  assert.match(rendered.html, /old/)
  assert.match(rendered.html, /other/)
  assert.match(rendered.html, /starting/)
  assert.equal(observations.init, 1)
  assert.deepEqual(observations.constructors, [], 'SSR never builds Command/Mount handlers')
  assert.deepEqual(observations.rootCommands, [], 'SSR never executes init Commands')
  assert.deepEqual(observations.acquired, [], 'SSR never acquires Mounts')
  assert.deepEqual(observations.released, [])
  assert.deepEqual(observations.reads, [])
  assert.equal(observations.serviceAcquired.length, 1)
  assert.deepEqual(observations.serviceReleased, observations.serviceAcquired)
  pass('Server: actual registered-child render, no Command/Mount execution, scoped provider released')
}

try {
  await runServer()
  await runProgram('Element')
  await runProgram('Document')
  console.log(`ROOT_RUNTIME_SMOKE_OK ${passed.length} assertions groups`)
} finally {
  await window.happyDOM.close()
  for (const [name, descriptor] of previousGlobals) {
    if (descriptor === undefined) delete globalThis[name]
    else Object.defineProperty(globalThis, name, descriptor)
  }
}
