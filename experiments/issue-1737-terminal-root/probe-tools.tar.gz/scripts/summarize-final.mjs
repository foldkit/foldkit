import { createHash } from 'node:crypto'
import { readFileSync, writeFileSync } from 'node:fs'
import { resolve } from 'node:path'

const [inputArgument, outputArgument, ...extra] = process.argv.slice(2)
if (!inputArgument || !outputArgument || extra.length) throw new Error('Usage: node summarize-final.mjs REPORT_DIRECTORY NEW_SUMMARY_JSON')
const input = resolve(inputArgument)
const output = resolve(outputArgument)
const arms = ['baseline', 'candidate']
const modes = ['root-incomplete', 'root-valid', 'root-hover', 'root-diagnostics']
const hash = value => createHash('sha256').update(value).digest('hex')
const same = (left, right) => JSON.stringify(left) === JSON.stringify(right)
const requireThat = (condition, message) => { if (!condition) throw new Error(message) }
const originalLabels = ['OutMessage?', 'makeView', 'replaceEffectsLayer', 'provideHandlers', 'owner', 'Model', 'Message', 'mounts', 'bindings', 'init', 'update', 'operations', 'subscriptions', 'managedResources', 'EffectsLayer', 'LocalEffectsLayerTypeId', '__blockHandlerRequirements', 'hostHandlers'].sort()
const terminalLabels = ['owner', 'Model', 'Message', 'init', 'update', 'operations'].sort()
const hoverSignature = ['.Model: Struct<', 'readonly route: RouteUnion<', 'readonly Home: {};', 'readonly ExampleDetail: {', 'exampleSlug: String;', 'readonly search: Struct<']
const scriptHashes = {
 original: '1491ea5fe44f546a4adfb74126a42ec866e7235a3c62f25dead66a6b75cc1751',
 candidate: 'f7268c088ee254f69be0cefea43a647bcfd10796a673ae9c67d000e7a55cd139',
 hover: '5c690ddfbb7c3eae0b824867a98a7aa69bb5285291567759308a876bb5e76bc8',
 guard: 'f82396c66ef418574707f23e1056609be22b492308436d817d0102daefaa9eaf',
}
const compilerKeys = ['compilerManifest', 'compilerLauncher', 'compilerLauncherImplementation', 'nativeResolver', 'protocolClient', 'nativeManifest', 'executable']
const hoverText = result => {
 const contents = result?.contents
 if (typeof contents === 'string') return contents
 if (Array.isArray(contents)) return contents.map(part => typeof part === 'string' ? part : part?.value ?? '').join('\n')
 return contents?.value ?? ''
}
const stats = values => {
 const sorted = [...values].sort((a, b) => a - b)
 return { n: values.length, median: sorted[1], min: sorted[0], max: sorted[2], values }
}
let sharedIdentity
const armState = new Map()
const rawReports = []
for (const arm of arms) for (const mode of modes) for (const round of [1, 2, 3]) {
 const file = `final-${arm}-${mode}-${round}.json`
 const bytes = readFileSync(resolve(input, file))
 const r = JSON.parse(bytes)
 const check = (condition, message) => requireThat(condition, `${file}: ${message}`)
 check(r.formatVersion === 1 && r.mode === mode && r.status === 'Passed', 'wrong format, mode, or status')
 check(!r.failure && !r.aborted && !r.verificationFailure && !r.spawnError, 'failure or abort metadata present')
 check(r.disposableWorkspaceAcknowledged === true && r.childEnvironmentChanged === false, 'workspace/environment acknowledgement missing')
 check(r.sourceUnchanged === true && r.diskUnchanged === true && r.compilerAndHarnessUnchanged === true && r.serverExitedBeforeCleanup === false, 'unchanged-file or owned-process guards failed')
 check(same(r.identitiesBefore, r.identitiesAfter) && same(r.sourceHashesBefore, r.sourceHashesAfter), 'before/after evidence differs')
 check(r.compilerManifest?.name === 'typescript' && r.compilerManifest.version === '7.0.2' && r.nativeManifest?.name === '@typescript/typescript-darwin-arm64' && r.nativeManifest.version === '7.0.2', 'expected installed native TypeScript 7.0.2 on darwin-arm64')
 check(r.node?.version === 'v22.23.3' && r.node.platform === 'darwin' && r.node.arch === 'arm64', 'unexpected Node/host identity')
 check(r.serverInfo?.name === 'typescript-go' && r.serverInfo.version === '7.0.2', 'unexpected LSP server identity')
 check(['GOMEMLIMIT', 'GOGC', 'GOMAXPROCS', 'GODEBUG', 'GOEXPERIMENT', 'GOENV'].every(key => r.goEnvironment?.[key] === null), 'expected unset default Go runtime flags')
 check(r.rssKillLimitBytes === 3 * 1024 ** 3 && r.footprintKillLimitBytes === 4 * 1024 ** 3 && r.wallKillLimitMs === 22000 && r.requestTimeoutMs === 18000, 'guard limits differ')
 check(Number.isInteger(r.pid) && r.pid > 1 && Number.isInteger(r.monitorPid) && r.monitorPid > 1 && r.pid !== r.monitorPid, 'missing distinct owned process IDs')
 check(Array.isArray(r.memory) && r.memory.length > 0 && !r.memory.some(row => row.error || row.killed), 'missing or failed memory monitor')
 const samples = r.memory.filter(row => Number.isFinite(row.rssBytes) && Number.isFinite(row.footprintBytes))
 check(samples.length === r.memory.length && samples.every(row => row.pid === r.pid && Number.isInteger(row.ownedParentPid) && row.ownedParentPid > 1 && row.pidBirthMachAbsoluteTicks > 0 && row.cpuUnitsVersion === 2 && Number.isFinite(row.cpuNanoseconds) && row.rssBytes <= r.rssKillLimitBytes && row.footprintBytes <= r.footprintKillLimitBytes), 'invalid ownership, memory, or CPU samples')
 check(samples.every(row => row.ownedParentPid === samples[0].ownedParentPid && row.pidBirthMachAbsoluteTicks === samples[0].pidBirthMachAbsoluteTicks), 'process parent or birth identity changed')
 check(r.monitorExit && !r.monitorExit.stderr && !r.monitorExit.remainder && r.exit && (r.exit.signal === 'SIGTERM' || r.exit.signal === 'SIGKILL' || r.exit.code === 1), 'missing process cleanup evidence or unexpected owned LSP exit')
 const probeHash = mode === 'root-hover' ? scriptHashes.hover : arm === 'baseline' ? scriptHashes.original : scriptHashes.candidate
 check(r.identitiesBefore?.probe?.sha256 === probeHash && r.identitiesBefore?.memoryGuard?.sha256 === scriptHashes.guard, 'probe/guard is not the documented revision')
 for (const key of compilerKeys) check(/^[a-f0-9]{64}$/.test(r.identitiesBefore?.[key]?.sha256 ?? ''), `missing ${key} hash`)
 const identity = { node: r.node, compiler: { name: r.compilerManifest.name, version: r.compilerManifest.version, gitHead: r.compilerManifest.gitHead, sha256: r.compilerManifest.sha256 }, native: { name: r.nativeManifest.name, version: r.nativeManifest.version, gitHead: r.nativeManifest.gitHead, sha256: r.nativeManifest.sha256 }, compilerHashes: Object.fromEntries(compilerKeys.map(key => [key, r.identitiesBefore[key].sha256])), goEnvironment: r.goEnvironment, serverInfo: r.serverInfo }
 sharedIdentity ??= identity
 check(same(identity, sharedIdentity), 'compiler/client/runtime identities differ across reports (installation paths may differ)')
 check(typeof r.originalText === 'string' && hash(r.originalText) === r.sourceSha256 && hash(r.openedText) === r.inMemorySha256, 'document hashes do not match text')
 check(r.sourcePath === `${r.workspace}/packages/website/src/block.ts`, 'wrong source file')
 const state = { workspace: r.workspace, sourceSha256: r.sourceSha256, sourceHashes: r.sourceHashesBefore }
 if (!armState.has(arm)) armState.set(arm, state)
 check(same(state, armState.get(arm)), 'workspace/source changed between rounds or modes of this arm')
 const diagnostic = mode === 'root-diagnostics'
 const hover = mode === 'root-hover'
 const expectedOpened = diagnostic ? r.originalText + '\nexport const CodexDiagnosticGuard: number = 1\n' : r.originalText + `\nconst codexMemberProbe = ApplicationBlock.${mode === 'root-incomplete' ? '' : 'Model'}\n`
 check(r.openedText === expectedOpened, 'wrong initial workload text')
 check(same(r.expectedRootLabels, hover || arm === 'candidate' ? terminalLabels : originalLabels), 'unexpected completion-surface contract')
 if (hover) check(same(r.expectedRootModelHoverSignature, hoverSignature) && typeof r.fixtureAdaptation === 'string', 'hover adaptation metadata differs')
 const expectedLabels = diagnostic ? ['initialize', 'cold clean root diagnostics', 'root error appearance', 'root error clear'] : hover ? ['initialize', 'cold root Model hover', 'warm root Model hover', 'post-edit root Model hover', 'semantic edit guard'] : ['initialize', 'cold completion', 'warm completion', 'post-edit completion', 'semantic edit guard']
 const expectedVersions = diagnostic ? [1, 1, 2, 3] : [1, 1, 1, 2, 3]
 check(Array.isArray(r.measurements) && same(r.measurements.map(row => row.label), expectedLabels), 'missing, duplicate, or reordered requests')
 check(Array.isArray(r.documents) && r.documents.length === 3 && same(r.documents.map(doc => doc.version), [1, 2, 3]), 'wrong document-version flow')
 const expectedTexts = diagnostic ? [r.openedText, r.openedText.replace(/CodexDiagnosticGuard: number = 1\n$/, 'CodexDiagnosticGuard: number = "bad"\n'), r.openedText] : [r.openedText, r.openedText + '\n', 'export const CodexAppliedEditGuard = 1737\n' + r.openedText + '\n']
 check(same(r.documents.map(doc => doc.text), expectedTexts), 'semantic edit text differs')
 check(same(r.documents.map(doc => doc.reason), diagnostic ? ['didOpen', 'diagnostic guard replacement', 'diagnostic guard replacement'] : ['didOpen', 'post-edit newline', 'semantic edit application guard']), 'edit workload reason differs')
 for (const doc of r.documents) check(doc.sha256 === hash(doc.text), 'document history hash differs')
 for (const [index, row] of r.measurements.entries()) {
  const expectedMethod = index === 0 ? 'initialize' : diagnostic ? 'textDocument/diagnostic' : hover || index === 4 ? 'textDocument/hover' : 'textDocument/completion'
  check(row.method === expectedMethod && row.outcome === 'Resolved' && Number.isFinite(row.latencyMs) && row.latencyMs >= 0 && row.documentVersion === expectedVersions[index] && row.documentSha256 === r.documents[row.documentVersion - 1].sha256, `invalid measurement ${row.label}`)
  if (index === 0) continue
  if (diagnostic) {
   check(row.result?.kind === 'full' && Array.isArray(row.result.items), 'expected full diagnostics')
   const errors = row.result.items.filter(item => item.severity === 1)
   check(index === 2 ? errors.some(item => item.code === 2322 && /string/.test(item.message) && /number/.test(item.message)) : errors.length === 0, `wrong diagnostics for ${row.label}`)
  } else if (index === 4) {
   check(JSON.stringify(row.result).includes('1737'), 'semantic edit application guard missing')
  } else if (hover) {
   const text = hoverText(row.result)
   check(hoverSignature.every(token => text.includes(token)) && !/ApplicationRoot\.Message|\.Message:/.test(text), 'wrong canonical Model hover')
   check(text.replace(/\r\n/g, '\n').trim() === hoverText(r.measurements[1].result).replace(/\r\n/g, '\n').trim(), 'hover semantic contents changed')
  } else {
   const items = Array.isArray(row.result) ? row.result : row.result?.items
   check(Array.isArray(items) && same(items.map(item => item.label).sort(), arm === 'baseline' ? originalLabels : terminalLabels), 'wrong completion members')
  }
 }
 rawReports.push({
  file,
  sha256: hash(bytes),
  arm,
  mode,
  round,
  workspace: r.workspace,
  sourceSha256: r.sourceSha256,
  probeSha256: probeHash,
  measurements: r.measurements.map(({ label, method, documentVersion, latencyMs }) => ({ label, method, documentVersion, latencyMs })),
  elapsedMs: r.elapsedMs,
  maxRssBytes: Math.max(...samples.map(row => row.rssBytes)),
  maxFootprintBytes: Math.max(...samples.map(row => row.footprintBytes)),
  maxSampledCpuNanoseconds: Math.max(...samples.map(row => row.cpuNanoseconds)),
  cleanup: { exit: r.exit, monitorExit: r.monitorExit },
 })
}
const groups = []
for (const mode of modes) for (const arm of arms) {
 const reports = rawReports.filter(r => r.mode === mode && r.arm === arm)
 groups.push({ arm, mode, metricsMs: Object.fromEntries(reports[0].measurements.map(row => [row.label, stats(reports.map(r => r.measurements.find(m => m.label === row.label).latencyMs))])), maxRssBytes: stats(reports.map(r => r.maxRssBytes)), maxFootprintBytes: stats(reports.map(r => r.maxFootprintBytes)) })
}
const summary = {
 formatVersion: 1,
 reportCount: rawReports.length,
 baselineCommit: '9a5f9307cb4af2aca8a1e28bbf7b21cf64e5f87c',
 identity: sharedIdentity,
 aggregation: 'Three independent fresh-process runs per arm/mode. Median and min/max of request latency in milliseconds; warm and post-edit remain separate. Memory values are sampled process peaks, not continuous maxima.',
 limitations: [
  'No Neovim or live all-day editor proof.',
  'No claim that all composition costs are improved.',
  'Unrelated editor servers and Vite were left running; not a fully idle host.',
  'In-memory newline edits and a separate semantic application guard do not represent arbitrary source edits.',
  'Native process cleanup may record a nonzero exit after the harness terminates its owned LSP process; Passed requires successful requests and cleanup guards, not exit code zero.',
 ],
 groups,
 rawReports,
}
writeFileSync(output, JSON.stringify(summary, null, 2) + '\n', { flag: 'wx' })
console.log(`Validated ${rawReports.length} reports; wrote ${output}. Raw inputs were not changed.`)
