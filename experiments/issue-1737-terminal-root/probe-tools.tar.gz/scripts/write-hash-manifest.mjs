import { createHash } from 'node:crypto'
import { readdirSync, readFileSync, statSync, writeFileSync } from 'node:fs'
import { basename, relative, resolve } from 'node:path'

const [stagingArgument, proofArgument, outputArgument, ...extra] = process.argv.slice(2)
if (!stagingArgument || !proofArgument || !outputArgument || extra.length) throw new Error('Usage: node write-hash-manifest.mjs PACK_STAGING_DIR PROOF_DIR NEW_MANIFEST_JSON')
const staging = resolve(stagingArgument)
const proof = resolve(proofArgument)
const output = resolve(outputArgument)
const hash = bytes => createHash('sha256').update(bytes).digest('hex')
const include = new Map()
const addFile = (base, path, role) => {
 const absolute = resolve(base, path)
 const bytes = readFileSync(absolute)
 const key = `${basename(base)}/${relative(base, absolute).replaceAll('\\', '/')}`
 include.set(key, { path: key, role, bytes: bytes.length, sha256: hash(bytes) })
}
for (const path of [
 'README.md',
 'input-hashes.json',
 'session-metadata.json',
 'scripts/scope-root-editor-probe.mjs',
 'scripts/candidate-root-editor-probe.mjs',
 'scripts/lazy-hover-probe.mjs',
 'scripts/memory-guard.py',
 'scripts/summarize-final.mjs',
 'scripts/write-hash-manifest.mjs',
]) addFile(staging, path, 'pack-staging')
try { addFile(staging, 'final-summary.json', 'generated-summary') } catch (error) { if (error.code !== 'ENOENT') throw error }
const rawPattern = /^final-(baseline|candidate)-(root-incomplete|root-valid|root-hover|root-diagnostics)-[123]\.json$/
for (const entry of readdirSync(proof).sort()) {
 if (rawPattern.test(entry)) addFile(proof, entry, 'final-raw-report')
}
for (const entry of readdirSync(proof).sort()) {
 if (!rawPattern.test(entry) && entry.endsWith('.json') && statSync(resolve(proof, entry)).isFile()) addFile(proof, entry, 'exploratory-or-failed-report-retained-outside-final-comparison')
}
const manifest = { formatVersion: 1, generatedBy: 'write-hash-manifest.mjs', finalReportPattern: 'final-(baseline|candidate)-(root-incomplete|root-valid|root-hover|root-diagnostics)-[1-3].json', entries: [...include.values()] }
writeFileSync(output, JSON.stringify(manifest, null, 2) + '\n', { flag: 'wx' })
console.log(`Wrote ${output} with ${manifest.entries.length} entries.`)
