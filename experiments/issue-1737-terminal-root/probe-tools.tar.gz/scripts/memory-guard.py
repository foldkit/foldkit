import ctypes
import json
import os
import signal
import sys
import time


if sys.platform != 'darwin':
    raise SystemExit('memory-guard.py requires macOS libproc; other platforms are unsupported')
if len(sys.argv) != 3:
    raise SystemExit('usage: memory-guard.py OWNED_NATIVE_PID MAX_SECONDS')
pid = int(sys.argv[1])
duration = float(sys.argv[2])
if pid <= 1 or not 0 < duration <= 27:
    raise ValueError('guard requires a native PID greater than one and a lifetime within 27 seconds')
owner = os.getppid()
started = time.monotonic()
initial = None
can_emit = True


class Usage(ctypes.Structure):
    _fields_ = [('uuid', ctypes.c_ubyte * 16)] + [
        (name, ctypes.c_uint64)
        for name in ['user', 'system', 'idle', 'interrupts', 'pageins', 'wired', 'resident', 'footprint', 'start', 'exit']
    ]


class ProcessInfo(ctypes.Structure):
    _fields_ = [(name, ctypes.c_uint32) for name in [
        'flags', 'status', 'xstatus', 'pid', 'ppid', 'uid', 'gid', 'ruid', 'rgid', 'svuid', 'svgid', 'reserved'
    ]] + [('comm', ctypes.c_char * 16), ('name', ctypes.c_char * 32)] + [
        (name, ctypes.c_uint32) for name in ['nfiles', 'pgid', 'pjobc', 'terminal', 'terminal_pgid']
    ] + [('nice', ctypes.c_int32), ('start_seconds', ctypes.c_uint64), ('start_microseconds', ctypes.c_uint64)]


class MachTimebase(ctypes.Structure):
    _fields_ = [('numer', ctypes.c_uint32), ('denom', ctypes.c_uint32)]


lib = ctypes.CDLL('/usr/lib/libproc.dylib')
lib.proc_pid_rusage.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_void_p]
lib.proc_pid_rusage.restype = ctypes.c_int
lib.proc_pidinfo.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_uint64, ctypes.c_void_p, ctypes.c_int]
lib.proc_pidinfo.restype = ctypes.c_int
system = ctypes.CDLL('/usr/lib/libSystem.B.dylib')
system.mach_timebase_info.argtypes = [ctypes.POINTER(MachTimebase)]
system.mach_timebase_info.restype = ctypes.c_int
timebase = MachTimebase()
if system.mach_timebase_info(ctypes.byref(timebase)) != 0 or timebase.denom == 0:
    raise RuntimeError('Cannot determine Mach absolute timebase')


def emit(row):
    global can_emit
    if can_emit:
        try:
            print(json.dumps(row), flush=True)
        except BrokenPipeError:
            can_emit = False


def current_usage():
    usage = Usage()
    if lib.proc_pid_rusage(pid, 0, ctypes.byref(usage)) != 0:
        return None
    return usage


while True:
    usage = current_usage()
    if usage is None:
        if initial is None:
            emit({'error': 'Could not sample the owned native process before it exited'})
        break
    if initial is None:
        info = ProcessInfo()
        if lib.proc_pidinfo(pid, 3, 0, ctypes.byref(info), ctypes.sizeof(info)) != ctypes.sizeof(info):
            emit({'error': 'Cannot verify the native process parent with macOS libproc'})
            break
        if info.pid != pid or info.ppid != owner:
            emit({'error': 'Refusing to monitor a process not owned by the probe parent'})
            break
        initial = usage.start
    if usage.start != initial:
        emit({'error': 'Native PID birth identity changed; refusing to signal the replacement'})
        break
    elapsed = time.monotonic() - started
    row = {
        'elapsedMs': elapsed * 1000,
        'pid': pid,
        'ownedParentPid': owner,
        'pidBirthMachAbsoluteTicks': initial,
        'rssBytes': usage.resident,
        'footprintBytes': usage.footprint,
        'cpuUnitsVersion': 2,
        'cpuMachAbsoluteTicks': usage.user + usage.system,
        'machTimebaseNumer': timebase.numer,
        'machTimebaseDenom': timebase.denom,
        'cpuNanoseconds': (usage.user + usage.system) * timebase.numer // timebase.denom,
    }
    emit(row)
    reason = None
    if usage.resident > 3 * 1024 ** 3 or usage.footprint > 4 * 1024 ** 3:
        reason = 'RSS3GiB or physical-footprint4GiB limit'
    elif os.getppid() != owner:
        reason = 'Probe owner exited'
    elif elapsed >= duration:
        reason = 'Bounded memory guard lifetime reached'
    if reason:
        latest = current_usage()
        if latest is not None and latest.start == initial:
            try:
                os.kill(pid, signal.SIGKILL)
                emit({'killed': True, 'reason': reason, 'pid': pid, 'pidBirthMachAbsoluteTicks': initial})
            except ProcessLookupError:
                pass
        break
    time.sleep(0.25)
