import { spawn } from 'node:child_process'
import { createHash } from 'node:crypto'
import { closeSync, constants, fstatSync, lstatSync, openSync, readdirSync, readFileSync, readlinkSync, realpathSync, writeFileSync } from 'node:fs'
import { createRequire } from 'node:module'
import { dirname, isAbsolute, join, relative, resolve, sep } from 'node:path'
import { performance } from 'node:perf_hooks'
import { fileURLToPath, pathToFileURL } from 'node:url'

const modes = ['root-incomplete', 'root-valid', 'composition-incomplete', 'definition-incomplete', 'schema-incomplete', 'plain-incomplete', 'root-diagnostics']
const usage = 'node root-editor-probe.mjs --workspace /absolute/disposable-checkout --disposable-workspace --output /absolute/new-result.json [--mode root-incomplete]'
const arguments_ = process.argv.slice(2)
const options = {}
for (let index = 0; index < arguments_.length; index += 1) {
 const argument = arguments_.at(index)
 if (argument === '--disposable-workspace') {
  if (options.disposable) throw new Error('Duplicate --disposable-workspace')
  options.disposable = true
 } else if (['--workspace', '--output', '--mode'].includes(argument)) {
  const key = argument.slice(2)
  if (options[key] !== undefined) throw new Error(`Duplicate ${argument}`)
  const value = arguments_.at(index + 1)
  if (!value || value.startsWith('--')) throw new Error(`Missing value for ${argument}; ${usage}`)
  options[key] = value
  index += 1
 } else if (argument === '--help') {
  console.log(usage)
  process.exit(0)
 } else {
  throw new Error(`Unknown argument ${argument}; ${usage}`)
 }
}
if (!options.disposable || !options.workspace || !options.output) throw new Error(`Explicit disposable checkout acknowledgement, workspace, and new output are required; ${usage}`)
const mode = options.mode ?? 'root-incomplete'
if (!modes.includes(mode)) throw new Error(`Unsupported mode ${mode}; expected ${modes.join(', ')}`)
if (process.platform !== 'darwin') throw new Error('This bounded harness requires macOS libproc memory accounting; other platforms are unsupported')
for (const name of ['GOMEMLIMIT', 'GOGC']) {
 if (process.env[name] !== undefined) throw new Error(`${name} is set; unset GOMEMLIMIT and GOGC before this default-Go-runtime benchmark. The harness does not change inherited environment variables`)
}
const hash = bytes => createHash('sha256').update(bytes).digest('hex')
const isWithin = (parent, child) => child === parent || child.startsWith(parent + sep)
const canonicalExisting = (path, label) => {
 if (!isAbsolute(path) || resolve(path) !== path || realpathSync(path) !== path) throw new Error(`${label} must be an absolute canonical path with no symlink components: ${path}`)
 return path
}
const workspace = canonicalExisting(options.workspace, 'Workspace')
if (!lstatSync(workspace).isDirectory()) throw new Error('Workspace must be a directory')
const probePath = canonicalExisting(fileURLToPath(import.meta.url), 'Probe script')
const packDirectory = dirname(probePath)
if (isWithin(workspace, packDirectory)) throw new Error('Keep this harness in a separate directory outside the disposable checkout')
const guardPath = canonicalExisting(join(packDirectory, 'memory-guard.py'), 'Memory guard')
const output = options.output
if (!isAbsolute(output) || resolve(output) !== output || !output.endsWith('.json')) throw new Error('Output must be an absolute normalized path ending in .json')
canonicalExisting(dirname(output), 'Output parent directory')
if (isWithin(workspace, output)) throw new Error('Output must be outside the disposable checkout')
const sourcePath = canonicalExisting(join(workspace, 'packages/website/src/block.ts'), 'Root block source')
if (!lstatSync(sourcePath).isFile()) throw new Error('Root block source must be a regular file')
const original = readFileSync(sourcePath, 'utf8')
const manifestPath = realpathSync(join(workspace, 'packages/foldkit/node_modules/typescript/package.json'))
const compilerDirectory = dirname(manifestPath)
const compilerManifest = JSON.parse(readFileSync(manifestPath, 'utf8'))
const isSupportedVersion = version => version === '7.0.2' || /^7\.1\.0-beta(?:[.-]|$)/.test(version)
if (compilerManifest.name !== 'typescript' || !isSupportedVersion(compilerManifest.version)) throw new Error(`Expected the installed native TypeScript 7.0.2 or 7.1.0-beta wrapper, received ${compilerManifest.name}@${compilerManifest.version}`)
const requireCompiler = createRequire(manifestPath)
if (typeof compilerManifest.imports?.['#getExePath'] !== 'string' || typeof compilerManifest.imports?.['#vscode-jsonrpc/node'] !== 'string') throw new Error('Installed wrapper does not declare the expected native resolver and vendored JSON-RPC client')
const resolverPath = realpathSync(requireCompiler.resolve('#getExePath'))
const clientPath = realpathSync(requireCompiler.resolve('#vscode-jsonrpc/node'))
const launcherPath = realpathSync(join(compilerDirectory, compilerManifest.bin?.tsc ?? ''))
const launcherImplementationPath = realpathSync(join(compilerDirectory, 'lib/tsc.js'))
if (!readFileSync(launcherImplementationPath, 'utf8').includes('getExePath')) throw new Error('Installed wrapper launcher does not use the expected native resolver')
const { default: getExePath } = await import(pathToFileURL(resolverPath).href)
const executable = realpathSync(getExePath())
const platformPackageName = `@typescript/typescript-${process.platform}-${process.arch}`
if (!Object.hasOwn(compilerManifest.optionalDependencies ?? {}, platformPackageName)) throw new Error('Wrapper does not declare the current native platform package')
const nativeManifestPath = realpathSync(requireCompiler.resolve(platformPackageName + '/package.json'))
const nativeManifest = JSON.parse(readFileSync(nativeManifestPath, 'utf8'))
if (nativeManifest.name !== platformPackageName || !isSupportedVersion(nativeManifest.version)) throw new Error(`Unexpected installed native compiler package ${nativeManifest.name}@${nativeManifest.version}`)
if (executable !== realpathSync(join(dirname(nativeManifestPath), 'lib/tsc'))) throw new Error('Wrapper resolver selected an executable outside its installed native platform package')
const { createMessageConnection, StreamMessageReader, StreamMessageWriter } = await import(pathToFileURL(clientPath).href)
const pinnedPaths = { probe: probePath, memoryGuard: guardPath, compilerManifest: manifestPath, compilerLauncher: launcherPath, compilerLauncherImplementation: launcherImplementationPath, nativeResolver: resolverPath, protocolClient: clientPath, nativeManifest: nativeManifestPath, executable }
const identitiesBefore = Object.fromEntries(Object.entries(pinnedPaths).map(([name, path]) => [name, { path, sha256: hash(readFileSync(path)) }]))
const diskHashes = () => {
 const hashes = {}
 const visit = directory => {
  for (const entry of readdirSync(directory, { withFileTypes: true }).sort((left, right) => left.name.localeCompare(right.name))) {
   if (entry.name === 'node_modules' || entry.name === '.git') continue
   const path = join(directory, entry.name)
   const key = relative(workspace, path)
   const details = lstatSync(path)
   if (details.isSymbolicLink()) hashes[key] = `symlink:${readlinkSync(path)}`
   else if (details.isDirectory()) visit(path)
   else if (details.isFile()) hashes[key] = hash(readFileSync(path))
   else throw new Error(`Unsupported special file in workspace: ${path}`)
  }
 }
 visit(workspace)
 return hashes
}
const sourceHashesBefore = diskHashes()
const target = mode.startsWith('root') ? 'ApplicationBlock' : mode.startsWith('composition') ? 'ApplicationComposition' : mode.startsWith('definition') ? 'ApplicationDefinition' : mode.startsWith('schema') ? 'Model' : 'codexPlainObject'
const extraImport = target === 'ApplicationDefinition' ? "import { ApplicationDefinition } from './definition'\n" : target === 'Model' ? "import { Model } from './model'\n" : ''
const plain = mode.startsWith('plain') ? '\nconst codexPlainObject = { count: 0, title: "probe" }\n' : ''
const member = target === 'codexPlainObject' ? 'count' : target === 'Model' ? 'fields' : 'Model'
const expression = mode === 'root-valid' ? `${target}.${member}` : `${target}.`
let text = mode === 'root-diagnostics' ? original + '\nexport const CodexDiagnosticGuard: number = 1\n' : extraImport + original + plain + `\nconst codexMemberProbe = ${expression}\n`
let version = 1
const uri = pathToFileURL(sourcePath).href
const offset = text.lastIndexOf(`${target}.`) + target.length + 1
const before = text.slice(0, offset).split('\n')
const position = { line: before.length - 1, character: before.at(-1).length }
const expectedRootLabels = ['OutMessage?', 'makeView', 'replaceEffectsLayer', 'provideHandlers', 'owner', 'Model', 'Message', 'mounts', 'bindings', 'init', 'update', 'operations', 'subscriptions', 'managedResources', 'EffectsLayer', 'LocalEffectsLayerTypeId', '__blockHandlerRequirements', 'hostHandlers'].sort()
const goEnvironment = Object.fromEntries(['GOMEMLIMIT', 'GOGC', 'GOMAXPROCS', 'GODEBUG', 'GOEXPERIMENT', 'GOENV'].map(name => [name, process.env[name] ?? null]))
const report = {
 formatVersion: 1, mode, workspace, disposableWorkspaceAcknowledged: true, sourcePath, originalText: original, openedText: text,
 sourceSha256: hash(original), inMemorySha256: hash(text), position, expectedRootLabels, node: { version: process.version, executable: process.execPath, platform: process.platform, arch: process.arch },
 compilerManifest: { path: manifestPath, name: compilerManifest.name, version: compilerManifest.version, gitHead: compilerManifest.gitHead, sha256: identitiesBefore.compilerManifest.sha256 },
 nativeManifest: { path: nativeManifestPath, name: nativeManifest.name, version: nativeManifest.version, gitHead: nativeManifest.gitHead, sha256: identitiesBefore.nativeManifest.sha256 },
 protocolClient: { path: clientPath, wrapperVersion: compilerManifest.version, wrapperGitHead: compilerManifest.gitHead, sha256: identitiesBefore.protocolClient.sha256 },
 executable, identitiesBefore, sourceHashesBefore, goEnvironment, childEnvironmentChanged: false,
 rssKillLimitBytes: 3 * 1024 ** 3, footprintKillLimitBytes: 4 * 1024 ** 3, wallKillLimitMs: 22000, requestTimeoutMs: 18000,
 measurements: [], memory: [], publishedDiagnostics: [], stderr: '', status: 'Running', documents: [{ version, text, sha256: hash(text), reason: 'didOpen' }],
 limitations: [
  'One fresh native LSP process and one sequential request flow; this is a bounded reproduction, not a general editor or profiling benchmark.',
  'Memory is sampled with macOS libproc every 250 ms; brief peaks between samples may be missed. The native process is killed above 3 GiB RSS or 4 GiB physical footprint, or after 22 seconds.',
  'Workspace hashes cover readable regular files and symlink targets, including source and dist, excluding every node_modules and .git directory; symlinks are recorded without following them. Compiler/client/launcher/guard hashes are recorded separately, not a full dependency inventory.',
  'Only in-memory didOpen/didChange edits are sent. The output report is the only intended persistent write. The disposable checkout must be idle; hashes detect covered file changes but do not prevent concurrent writers.',
  'The installed wrapper resolves the native executable and supplies its vendored JSON-RPC client. Actual identities are recorded without hardcoded package or profiler pins.',
 ],
}
const outputDescriptor = openSync(output, constants.O_WRONLY | constants.O_CREAT | constants.O_EXCL | constants.O_NOFOLLOW, 0o600)
if (!fstatSync(outputDescriptor).isFile()) throw new Error('Output must be a new regular file')
const started = performance.now()
const recordDocument = (reason, contentChanges) => report.documents.push({ version, text, sha256: hash(text), reason, contentChanges, elapsedMs: performance.now() - started })
let child
let monitor
let connection
let wall
let exited = false
let monitorExited = false
let aborted
let monitorExpectedExit = false
let exit
let monitorExit
const kill = reason => {
 aborted ??= reason
 if (child?.pid && !exited) child.kill('SIGKILL')
}
const interruptCleanup = () => kill('Probe received SIGINT')
const terminateCleanup = () => kill('Probe received SIGTERM')
const exitCleanup = () => {
 if (child?.pid && !exited) child.kill('SIGKILL')
 if (monitor?.pid && !monitorExited) monitor.kill('SIGTERM')
}
process.on('SIGINT', interruptCleanup)
process.on('SIGTERM', terminateCleanup)
process.on('exit', exitCleanup)
try {
 child = spawn(executable, ['--lsp', '--stdio'], { cwd: workspace, env: { ...process.env }, stdio: ['pipe', 'pipe', 'pipe'] })
 report.pid = child.pid
 exit = new Promise(resolveExit => child.once('close', (code, signal) => { exited = true; report.exit = { code, signal }; resolveExit() }))
 child.on('error', error => { report.spawnError = String(error); aborted ??= `Native spawn failed: ${String(error)}` })
 child.stderr.on('data', data => { report.stderr += data.toString() })
 if (!child.pid) throw new Error('Native compiler did not receive an owned PID')
 wall = setTimeout(() => kill('22-second process wall limit'), 22000)
 connection = createMessageConnection(new StreamMessageReader(child.stdout), new StreamMessageWriter(child.stdin))
 connection.onRequest((method, params) => {
  if (method === 'workspace/configuration') return (params?.items ?? []).map(() => null)
  if (method === 'workspace/workspaceFolders') return [{ uri: pathToFileURL(workspace).href, name: 'foldkit-root-editor-reproducer' }]
  return null
 })
 connection.onNotification('textDocument/publishDiagnostics', params => { report.publishedDiagnostics.push({ elapsedMs: performance.now() - started, params }) })
 connection.onError(() => {})
 connection.listen()
 monitor = spawn('python3', ['-B', guardPath, String(child.pid), '27'], { stdio: ['ignore', 'pipe', 'pipe'] })
 report.monitorPid = monitor.pid
 let memoryBuffer = ''
 let monitorStderr = ''
 monitor.stderr.on('data', data => { monitorStderr += data.toString() })
 monitor.on('error', error => kill(`Memory guard spawn failed: ${String(error)}`))
 monitorExit = new Promise(resolveExit => monitor.once('close', (code, signal) => {
  monitorExited = true
  report.monitorExit = { code, signal, stderr: monitorStderr, remainder: memoryBuffer }
  if (!monitorExpectedExit && !exited) kill('Memory guard exited before owned cleanup')
  resolveExit()
 }))
 monitor.stdout.on('data', data => {
  memoryBuffer += data.toString()
  const lines = memoryBuffer.split('\n')
  memoryBuffer = lines.pop()
  for (const line of lines) {
   if (!line) continue
   try {
    const row = JSON.parse(line)
    report.memory.push(row)
    if (row.killed || row.error) kill(row.reason ?? row.error)
   } catch (error) { kill(`Invalid memory guard JSON: ${String(error)}`) }
  }
 })
 const request = async (label, method, params) => {
  const from = performance.now()
  const row = { label, method, params, documentVersion: version, documentSha256: hash(text), startedMs: from - started }
  report.measurements.push(row)
  let timer
  try {
   const result = await Promise.race([
    params === undefined ? connection.sendRequest(method) : connection.sendRequest(method, params),
    new Promise((_, reject) => { timer = setTimeout(() => { kill(`${label}: 18000ms request timeout`); reject(new Error(aborted)) }, 18000) }),
    exit.then(() => { throw new Error(aborted ?? 'Server exited during request') }),
   ])
   clearTimeout(timer)
   const items = Array.isArray(result) ? result : result?.items
   Object.assign(row, { outcome: 'Resolved', responseMs: performance.now() - started, latencyMs: performance.now() - from, count: items?.length, labels: items?.map(item => item.label), result })
   return result
  } catch (error) {
   Object.assign(row, { outcome: 'Rejected', error: String(error), code: error?.code, data: error?.data })
   throw error
  } finally {
   clearTimeout(timer)
   row.latencyMs ??= performance.now() - from
   console.log(JSON.stringify({ label: row.label, outcome: row.outcome, documentVersion: row.documentVersion, latencyMs: row.latencyMs, count: row.count, error: row.error }))
  }
 }
 const initialized = await request('initialize', 'initialize', {
  processId: process.pid, clientInfo: { name: 'Bounded completed Block probe', version: '1' }, rootUri: pathToFileURL(workspace).href,
  capabilities: { general: { positionEncodings: ['utf-16'] }, workspace: { configuration: true, workspaceFolders: true }, textDocument: { completion: { completionItem: { snippetSupport: true } }, hover: { contentFormat: ['markdown', 'plaintext'] }, diagnostic: { dynamicRegistration: true }, publishDiagnostics: { versionSupport: true } } },
  workspaceFolders: [{ uri: pathToFileURL(workspace).href, name: 'foldkit-root-editor-reproducer' }],
 })
 report.serverInfo = initialized.serverInfo
 await connection.sendNotification('initialized', {})
 await connection.sendNotification('textDocument/didOpen', { textDocument: { uri, languageId: 'typescript', version, text } })
 if (mode === 'root-diagnostics') {
  const diagnostic = async (label, isBad) => {
   const result = await request(label, 'textDocument/diagnostic', { textDocument: { uri } })
   if (result?.kind !== 'full' || !Array.isArray(result.items)) throw new Error('Expected full diagnostics')
   const errors = result.items.filter(item => item.severity === 1)
   if (isBad) {
    if (!errors.some(item => item.code === 2322 && /string/.test(item.message) && /number/.test(item.message))) throw new Error('Expected string-to-number error 2322')
   } else if (errors.length) throw new Error('Expected clean diagnostics: ' + JSON.stringify(errors))
  }
  await diagnostic('cold clean root diagnostics', false)
  const prefix = 'export const CodexDiagnosticGuard: number = '
  const startOffset = text.lastIndexOf(prefix) + prefix.length
  const lines = text.slice(0, startOffset).split('\n')
  const start = { line: lines.length - 1, character: lines.at(-1).length }
  const change = async (previous, replacement) => {
   if (text.slice(startOffset, startOffset + previous.length) !== previous) throw new Error('Diagnostic edit range did not match the expected current document')
   const end = { ...start, character: start.character + previous.length }
   text = text.slice(0, startOffset) + replacement + text.slice(startOffset + previous.length)
   version += 1
   const contentChanges = [{ range: { start, end }, text: replacement }]
   recordDocument('diagnostic guard replacement', contentChanges)
   await connection.sendNotification('textDocument/didChange', { textDocument: { uri, version }, contentChanges })
  }
  await change('1', '"bad"')
  await diagnostic('root error appearance', true)
  await change('"bad"', '1')
  await diagnostic('root error clear', false)
 } else {
  const completionParams = { textDocument: { uri }, position, context: { triggerKind: 2, triggerCharacter: '.' } }
  const expected = target === 'codexPlainObject' ? ['count', 'title'] : target === 'ApplicationComposition' ? ['Model', 'makeView', 'assembleBlock'] : target === 'ApplicationDefinition' ? ['Model', 'makeBinding', 'makeComposition'] : target === 'Model' ? ['make', 'fields'] : ['Model', 'Message', 'EffectsLayer', 'init', 'update', 'makeView']
  const validate = result => {
   const items = Array.isArray(result) ? result : result?.items ?? []
   const labels = items.map(item => item.label).sort()
   if (target === 'ApplicationBlock') {
    if (JSON.stringify(labels) !== JSON.stringify(expectedRootLabels)) throw new Error('Root completion did not return exactly the expected 18 members')
   } else {
    for (const label of expected) if (!labels.includes(label)) throw new Error('Missing completion ' + label)
   }
   return labels.join('|')
  }
  const coldLabels = validate(await request('cold completion', 'textDocument/completion', completionParams))
  if (validate(await request('warm completion', 'textDocument/completion', { ...completionParams, context: { triggerKind: 1 } })) !== coldLabels) throw new Error('Warm completion changed labels')
  const endLines = text.split('\n')
  const end = { line: endLines.length - 1, character: endLines.at(-1).length }
  text += '\n'
  version += 1
  const newlineChanges = [{ range: { start: end, end }, text: '\n' }]
  recordDocument('post-edit newline', newlineChanges)
  await connection.sendNotification('textDocument/didChange', { textDocument: { uri, version }, contentChanges: newlineChanges })
  if (validate(await request('post-edit completion', 'textDocument/completion', completionParams)) !== coldLabels) throw new Error('Edited completion changed labels')
  const guardText = 'export const CodexAppliedEditGuard = 1737\n'
  text = guardText + text
  version += 1
  const guardChanges = [{ range: { start: { line: 0, character: 0 }, end: { line: 0, character: 0 } }, text: guardText }]
  recordDocument('semantic edit application guard', guardChanges)
  await connection.sendNotification('textDocument/didChange', { textDocument: { uri, version }, contentChanges: guardChanges })
  const guard = await request('semantic edit guard', 'textDocument/hover', { textDocument: { uri }, position: { line: 0, character: 17 } })
  if (!JSON.stringify(guard).includes('1737')) throw new Error('Semantic edit guard missing')
 }
 report.status = 'Passed'
} catch (error) {
 report.status = 'Failed'
 report.failure = String(error)
} finally {
 report.serverExitedBeforeCleanup = exited
 monitorExpectedExit = true
 if (child?.pid && !exited) {
  child.kill('SIGTERM')
  await Promise.race([exit, new Promise(resolveWait => setTimeout(resolveWait, 500))])
  if (!exited) { child.kill('SIGKILL'); await exit }
 }
 clearTimeout(wall)
 if (monitor?.pid && !monitorExited) monitor.kill('SIGTERM')
 if (monitorExit) await monitorExit
 connection?.dispose()
 process.removeListener('SIGINT', interruptCleanup)
 process.removeListener('SIGTERM', terminateCleanup)
 process.removeListener('exit', exitCleanup)
 report.aborted = aborted
 report.elapsedMs = performance.now() - started
 try {
  report.sourceUnchanged = hash(readFileSync(sourcePath, 'utf8')) === hash(original)
  report.sourceHashesAfter = diskHashes()
  report.diskUnchanged = JSON.stringify(report.sourceHashesBefore) === JSON.stringify(report.sourceHashesAfter)
  report.identitiesAfter = Object.fromEntries(Object.entries(pinnedPaths).map(([name, path]) => [name, { path, sha256: hash(readFileSync(path)) }]))
  report.compilerAndHarnessUnchanged = JSON.stringify(identitiesBefore) === JSON.stringify(report.identitiesAfter)
 } catch (error) { report.verificationFailure = String(error) }
 if (!report.sourceUnchanged || !report.diskUnchanged || !report.compilerAndHarnessUnchanged || aborted || !exited || report.serverExitedBeforeCleanup || !report.memory.some(row => Number.isFinite(row.rssBytes) && Number.isFinite(row.footprintBytes) && row.ownedParentPid === process.pid) || report.memory.some(row => row.error || row.killed) || report.verificationFailure) {
  report.status = 'Failed'
  report.failure ??= 'Owned process, memory monitor, or unchanged-file guard failed'
 }
 try { writeFileSync(outputDescriptor, JSON.stringify(report, null, 2) + '\n') } finally { closeSync(outputDescriptor) }
 console.log(JSON.stringify({ status: report.status, failure: report.failure, aborted, elapsedMs: report.elapsedMs, maxRssMiB: Math.max(0, ...report.memory.map(row => row.rssBytes ?? 0)) / 1024 ** 2, maxFootprintMiB: Math.max(0, ...report.memory.map(row => row.footprintBytes ?? 0)) / 1024 ** 2, sourceUnchanged: report.sourceUnchanged, diskUnchanged: report.diskUnchanged, compilerAndHarnessUnchanged: report.compilerAndHarnessUnchanged, output }))
 process.exitCode = report.status === 'Passed' ? 0 : 1
}
